/**
 * Syntax check for every JavaScript file in the slice.
 *
 * `node --check` alone cannot see ES modules in a directory without a
 * `package.json` `"type": "module"` (it has one), and it cannot see a *classic
 * script* at all when the file happens to parse as a module — `client.js` is
 * loaded with `new Function`, i.e. as a script, so checking it as a module
 * would miss script-only errors. This script checks each file under both
 * interpretations and reports the one that applies.
 *
 * @module scripts/check-syntax
 */

import { spawnSync } from 'node:child_process';
import { readdirSync, readFileSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';

const ROOT = new URL('..', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1');
const SKIP = new Set(['node_modules', '.git', 'test']);

/** Collect every `.js` / `.mjs` file under a directory. */
function collect(dir, out = []) {
  for (const entry of readdirSync(dir)) {
    if (SKIP.has(entry)) continue;
    const full = join(dir, entry);
    const info = statSync(full);
    if (info.isDirectory()) collect(full, out);
    else if (full.endsWith('.js') || full.endsWith('.mjs')) out.push(full);
  }
  return out;
}

/** Run `node --check` on one file with the given module mode. */
function check(file, asModule) {
  const args = asModule ? ['--check', file] : ['--input-type=commonjs', '--check', file];
  const result = spawnSync(process.execPath, args, { encoding: 'utf8' });
  return { ok: result.status === 0, stderr: (result.stderr ?? '').trim() };
}

/**
 * Whether a file is a classic script meant for `new Function` / a browser tag.
 *
 * The test is structural, not a substring search: the page loads `client.js` as a
 * *script*, whose first statement is the `window.__ModuleLoader__.load({...})`
 * call. A module (this file, `index.js`, anything under `lib/`) either starts with
 * an `import` or has no top-level loader call. Searching for the loader string
 * anywhere would misfire on this very file, which mentions it in a comment.
 *
 * @param {string} file absolute path
 * @returns {boolean} true when the file must be evaluated as a script
 */
function isClassicScript(file) {
  const source = readFileSync(file, 'utf8')
    .replace(/^\/\*[\s\S]*?\*\//, '')
    .replace(/^\s*(\/\/[^\n]*\n)/, '')
    .trimStart();
  return source.startsWith('window.__ModuleLoader__');
}

const files = collect(ROOT);
let failed = 0;
for (const file of files) {
  const label = relative(ROOT, file).replace(/\\/g, '/');
  const classic = isClassicScript(file);
  if (classic) {
    // A classic script is not parsed as a module by the page; `--input-type=commonjs`
    // would misread `const` at top level only inside functions, so evaluate it the
    // way the page does: as a script body.
    const source = readFileSync(file, 'utf8');
    try {
      // eslint-disable-next-line no-new-func
      new Function(source);
      console.log(`ok   ${label} (classic script)`);
    } catch (error) {
      failed += 1;
      console.error(`FAIL ${label} (classic script): ${error.message}`);
    }
    continue;
  }
  const result = check(file, true);
  if (result.ok) {
    console.log(`ok   ${label} (module)`);
  } else {
    failed += 1;
    console.error(`FAIL ${label} (module): ${result.stderr}`);
  }
}

if (files.length === 0) {
  console.error('no files found');
  process.exit(1);
}
console.log(`\n${files.length} file(s) checked, ${failed} failure(s)`);
process.exit(failed === 0 ? 0 : 1);
