/**
 * Mutation harness: break one fix at a time, prove the guarding test goes red, put
 * it back, prove it goes green again.
 *
 * Not part of the shipped bundle — it exists so `10-fix-report.md` can cite a real
 * command and a real exit code per defect instead of an assertion that the tests
 * "would" catch it. Run it with:
 *
 *   node scripts/mutate.mjs            # all mutations
 *   node scripts/mutate.mjs D-06 D-08  # a subset
 *
 * Each mutation is a literal text replacement on one shipped file. A mutation whose
 * `find` no longer matches fails loudly rather than silently proving nothing.
 */

import { execFileSync } from 'node:child_process';
import { readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));

/** Every mutation: one defect, one break, one guarding test name pattern. */
const MUTATIONS = [
  {
    id: 'D-01a',
    what: 'client click path returns to idle immediately (the pre-fix behaviour)',
    file: 'client.js',
    find: '          startTicker();\n          notify();\n          void runRequest(job);',
    replace: '          startTicker();\n          notify();\n          // MUTATION: the first slice cleared the run here instead of calling out.\n          store.cancel(started.token);\n          stopTicker();\n          notify();',
    test: 'a click leaves idle',
    expect: 'red',
  },
  {
    id: 'D-01b',
    what: 'somebody hand-edits the inlined client kernel without regenerating it',
    file: 'client.js',
    find: '      return { state: SEAT_STATES.running, reason: null, elapsedMs, revertible: false };',
    replace: '      return { state: SEAT_STATES.idle, reason: null, elapsedMs, revertible: false };',
    test: 'the inlined kernel region is current',
    expect: 'red',
  },
  {
    id: 'D-01c',
    what: 'an early return is moved above the hooks, so the hook count changes per render',
    file: 'client.js',
    find: "            useStore(subscribe, snapshotVersion);\n\n            /**\n             * Publish what the composer holds **now**",
    replace: "            if (!isDraftActionable(draft)) return null;\n            useStore(subscribe, snapshotVersion);\n\n            /**\n             * Publish what the composer holds **now**",
    test: 'stable hook count',
    expect: 'red',
  },
  {
    id: 'D-04',
    what: 'degraded settings render all four seats again (the pre-fix plan)',
    file: 'lib/seats.js',
    find: "    return { visible: ['general'], degraded: true, presetId: null };",
    replace: '    return { visible: PRESET_IDS, degraded: true, presetId: null };',
    test: 'an unreadable settings service renders exactly one general seat',
    expect: 'red',
    rebuild: true,
  },
  {
    id: 'D-01a-inject',
    what: 'the client drops the remote.commands sub-path from its inject list (D-01a)',
    file: 'client.js',
    find: "inject: ['slots', 'locale', 'configForms', 'remote', 'remote.commands'],",
    replace: "inject: ['slots', 'locale', 'configForms', 'remote'],",
    test: 'the factory declares the services it uses and exposes apply()',
    expect: 'red',
  },
  {
    id: 'D-01b-envelope',
    what: 'the click path reads answer.text instead of the gateway envelope (D-01b)',
    file: 'client.js',
    find: '          const envelope = readCommandAnswer(answer);',
    replace: "          const envelope = { ok: true, text: answer?.text ?? null, error: null };",
    test: 'a finished rewrite settles in revertible',
    expect: 'red',
  },
  {
    id: 'D-02-overlay',
    what: 'the overlay is accumulated with mergeSettings, which seeds it with defaults (D-02)',
    file: 'lib/host.js',
    find: '      state.setOverlay(mergePatch(state.overlay(), payload.patch));',
    replace: '      state.setOverlay(mergeSettings(state.overlay(), payload.patch));',
    test: 'does not overwrite config fields the patch did not name',
    expect: 'red',
  },
  {
    id: 'D-03-events',
    what: 'a malformed surface snapshot reads as zero events again (D-03)',
    file: 'lib/host.js',
    find: '    return Array.isArray(snapshot?.events) ? snapshot.events : null;',
    replace: '    return Array.isArray(snapshot?.events) ? snapshot.events : [];',
    test: 'reports messageCount null for a malformed surface snapshot',
    expect: 'red',
  },
  {
    id: 'D-04-status',
    what: 'an unavailable form status is mapped to "available but empty" again (D-04)',
    file: 'client.js',
    find: "        if (snapshot?.status !== 'ready') return { settingsAvailable: false, settings: null };",
    replace: "        if (snapshot?.status !== 'ready') return { settingsAvailable: true, settings: null };",
    test: 'an unavailable form status is unavailable',
    expect: 'red',
  },
  {
    id: 'D-05',
    what: 'the published entryId is forced back into the include: directory form (D-05 regression)',
    file: 'lib/host.js',
    find: '  return value.startsWith(ENTRY_ID_PREFIX) ? value.slice(ENTRY_ID_PREFIX.length) : value;',
    replace: '  return value.startsWith(ENTRY_ID_PREFIX) ? value : `${ENTRY_ID_PREFIX}${value}`;',
    test: 'readEntryId returns the bare patchId',
    expect: 'red',
  },
  {
    id: 'D-06',
    what: 'the session triple is read from the invented sessionQuery.modelSelection again',
    file: 'lib/host.js',
    find: "  if (typeof sessionQuery.observeSession !== 'function') return null;",
    replace: '  if (typeof sessionQuery.modelSelection === \'function\') return sessionQuery.modelSelection(sessionId);\n  if (typeof sessionQuery.observeSession !== \'function\') return null;',
    test: 'the old invented method name is gone',
    expect: 'red',
  },
  {
    id: 'D-07',
    what: 'buildResult drops the Host failure text again',
    file: 'lib/wire.js',
    find: "    detail: typeof input.detail === 'string' && input.detail !== ''\n      ? input.detail\n      : null,",
    replace: '    detail: null,',
    test: 'buildResult puts detail in the payload only for a failure',
    expect: 'red',
  },
  {
    id: 'D-08',
    what: 'the guard lets a request with neither fetch-metadata header through again',
    file: 'lib/guard.js',
    find: "  if (site === null && origin === null) {\n    return { allowed: false, status: 403, reason: 'fetch-metadata-missing' };\n  }",
    replace: '',
    test: 'the guard refuses a request that carries neither fetch-metadata header',
    expect: 'red',
  },
  {
    id: 'D-09',
    what: 'scripts/assert-preset.mjs is absent again',
    file: 'scripts/assert-preset.mjs',
    remove: true,
    test: 'assert-preset judges the four presets',
    expect: 'red',
  },
];

/** Run the suite filtered to one test name; returns `{ status, output }`. */
function runTest(pattern) {
  try {
    const output = execFileSync(
      process.execPath,
      ['--test', `--test-name-pattern=${pattern}`, 'test/*.test.js'],
      { cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] },
    );
    return { status: 0, output };
  } catch (error) {
    return { status: error.status ?? 1, output: `${error.stdout ?? ''}${error.stderr ?? ''}` };
  }
}

/** Regenerate the client kernel region after a `lib/` edit. */
function rebuildClient() {
  execFileSync(process.execPath, ['scripts/build-client.mjs'], { cwd: ROOT, encoding: 'utf8' });
}

/** One-line summary of a test run. */
function summarise(run) {
  const tests = /ℹ tests (\d+)/.exec(run.output);
  const pass = /ℹ pass (\d+)/.exec(run.output);
  const fail = /ℹ fail (\d+)/.exec(run.output);
  const parts = [];
  if (tests) parts.push(`tests=${tests[1]}`);
  if (pass) parts.push(`pass=${pass[1]}`);
  if (fail) parts.push(`fail=${fail[1]}`);
  parts.push(`exit=${run.status}`);
  return parts.join(' ');
}

const requested = process.argv.slice(2);
const selected = requested.length === 0
  ? MUTATIONS
  : MUTATIONS.filter((entry) => requested.includes(entry.id));

let failed = 0;
for (const mutation of selected) {
  const path = `${ROOT}${mutation.file}`;
  process.stdout.write(`\n=== ${mutation.id}: ${mutation.what}\n`);
  const original = readFileSync(path, 'utf8');
  try {
    if (mutation.remove === true) {
      const aside = `${path}.mutation-aside`;
      renameSync(path, aside);
    } else {
      if (!original.includes(mutation.find)) {
        throw new Error(`${mutation.file} no longer contains the text this mutation targets`);
      }
      writeFileSync(path, original.replace(mutation.find, mutation.replace), 'utf8');
    }
    if (mutation.rebuild === true) rebuildClient();
    const broke = runTest(mutation.test);
    process.stdout.write(`  broken  : ${summarise(broke)}\n`);
    if (broke.status === 0) {
      failed += 1;
      process.stdout.write('  RESULT  : NOT PROVEN — the guarding test stayed green\n');
      continue;
    }
    // Show the assertion line so the report can quote it.
    const reason = /AssertionError[^\n]*\n?[^\n]*/.exec(broke.output);
    if (reason !== null) process.stdout.write(`  reason  : ${reason[0].replace(/\s+/g, ' ').trim()}\n`);
  } finally {
    if (mutation.remove === true) {
      const aside = `${path}.mutation-aside`;
      if (existsSync(aside)) renameSync(aside, path);
    } else {
      writeFileSync(path, original, 'utf8');
    }
    if (mutation.rebuild === true) rebuildClient();
  }
  const restored = runTest(mutation.test);
  process.stdout.write(`  restored: ${summarise(restored)}\n`);
  if (restored.status !== 0) {
    failed += 1;
    process.stdout.write('  RESULT  : BROKEN AFTER RESTORE\n');
    continue;
  }
  process.stdout.write('  RESULT  : red → green proven\n');
}

process.stdout.write(`\n${failed === 0 ? 'ALL MUTATIONS PROVEN' : `${failed} MUTATION(S) FAILED`} (${selected.length} run)\n`);
process.exit(failed === 0 ? 0 : 1);
