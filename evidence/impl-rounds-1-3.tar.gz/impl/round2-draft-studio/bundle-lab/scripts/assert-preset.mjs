/**
 * B5 判据 2: assert the four rewritten drafts against their per-preset structure
 * predicates (`01-requirements.md` §3-B5, 判据 2).
 *
 * `09-verification.md` D-09: `01` §4 lists this command as available from P2 and
 * `02-plan.md` refers to it by name, but the file did not exist, so B5 could only
 * ever be judged on 判据 1 (the request side) and the output side was unjudgeable.
 *
 * The four predicates are **independent per preset and only partially
 * discriminating** — that is the requirement's own wording, not a shortcut. They are
 * used as "does this output look like what THIS preset asked for", never as "which
 * preset produced it": `02` §7.2.2-N-3 records that `writing` and `translate` are
 * structurally identical for English input that keeps its paragraphs.
 *
 * Input file: a JSON object keyed by preset id, each value either the draft string
 * itself or `{ text }` / `{ outputs: [text, …] }` (B5 判据 3 allows two attempts and
 * **either** passing counts).
 *
 *   { "general": "…", "coding": "…", "writing": "…", "translate": "…" }
 *
 * Usage:
 *   node scripts/assert-preset.mjs <outputs.json>
 *   node scripts/assert-preset.mjs <outputs.json> --json
 *
 * Exit code 0 = every preset passed; 1 = at least one failed (the failures are
 * printed with the reason); 2 = the file or its shape is unusable.
 *
 * @module scripts/assert-preset
 */

import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

/** A numbered-step line: `1.` `2)` `3、` … (`01` §3-B5 判据 2). */
const NUMBERED_STEP = /^\s*\d+[.、)]\s/;

/** A bullet line (`- ` at the start, possibly indented). */
const BULLET = /^-\s/;

/** A triple-backtick fence. */
const FENCE = /^\s*```/;

/** A word of at least two Latin letters. */
const LATIN_WORD = /[A-Za-z]{2,}/;

/** CJK (Han) characters, for the translate ratio. */
const CJK = /[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]/u;

/**
 * Split text into lines.
 *
 * @param {string} text the draft
 * @returns {string[]} its lines
 */
function linesOf(text) {
  return typeof text === 'string' ? text.split(/\r?\n/) : [];
}

/**
 * Count the numbered-step lines.
 *
 * @param {string} text the draft
 * @returns {number} how many lines begin with a step number
 */
export function countNumberedSteps(text) {
  return linesOf(text).filter((line) => NUMBERED_STEP.test(line)).length;
}

/**
 * Count the `- ` bullet lines.
 *
 * @param {string} text the draft
 * @returns {number} how many lines begin with a bullet
 */
export function countBullets(text) {
  return linesOf(text).filter((line) => BULLET.test(line)).length;
}

/**
 * Whether the text contains a triple-backtick fence.
 *
 * @param {string} text the draft
 * @returns {boolean} true when a fence is present
 */
export function hasFence(text) {
  return linesOf(text).some((line) => FENCE.test(line));
}

/**
 * Count the paragraphs: non-empty blocks separated by blank lines.
 *
 * @param {string} text the draft
 * @returns {number} the paragraph count
 */
export function countParagraphs(text) {
  if (typeof text !== 'string' || text.trim() === '') return 0;
  return text.split(/\n\s*\n/).filter((block) => block.trim() !== '').length;
}

/**
 * The share of CJK characters among all non-whitespace characters.
 *
 * @param {string} text the draft
 * @returns {number} a ratio in `[0, 1]`; 0 for an empty draft
 */
export function cjkRatio(text) {
  if (typeof text !== 'string') return 0;
  const visible = [...text].filter((char) => char.trim() !== '');
  if (visible.length === 0) return 0;
  const cjk = visible.filter((char) => CJK.test(char)).length;
  return cjk / visible.length;
}

/**
 * The four predicates, each returning `{ pass, detail }`.
 *
 * Each one is written against the requirement's table verbatim; `input` is the
 * draft the rewrite was asked to improve, needed only by `writing` (paragraph count
 * must not shrink).
 */
export const PREDICATES = Object.freeze({
  general(text) {
    const bullets = countBullets(text);
    const steps = countNumberedSteps(text);
    const fence = hasFence(text);
    const pass = bullets >= 3 && steps === 0 && !fence;
    return {
      pass,
      detail: `要点行 ${bullets}（要求 ≥3）; 编号步骤行 ${steps}（要求 =0）; 代码围栏 ${fence ? '有' : '无'}（要求无）`,
    };
  },

  coding(text) {
    const steps = countNumberedSteps(text);
    const pass = steps >= 3;
    return { pass, detail: `编号步骤行 ${steps}（要求 ≥3）` };
  },

  writing(text, input) {
    const steps = countNumberedSteps(text);
    const bullets = countBullets(text);
    const fence = hasFence(text);
    const paragraphs = countParagraphs(text);
    const wanted = input === undefined ? 1 : Math.max(1, countParagraphs(input));
    const pass = steps === 0 && paragraphs >= wanted && !fence && bullets < 3;
    return {
      pass,
      detail: `编号步骤行 ${steps}（要求 =0）; 段落 ${paragraphs}（要求 ≥ 输入 ${wanted}）; `
        + `代码围栏 ${fence ? '有' : '无'}（要求无）; 要点行 ${bullets}（要求 <3）`,
    };
  },

  translate(text) {
    const ratio = cjkRatio(text);
    const latin = LATIN_WORD.test(typeof text === 'string' ? text : '');
    const steps = countNumberedSteps(text);
    const bullets = countBullets(text);
    const pass = ratio <= 0.05 && latin && steps === 0 && bullets < 3;
    return {
      pass,
      detail: `CJK 占比 ${(ratio * 100).toFixed(2)}%（要求 ≤5%）; 含英文词 ${latin ? '是' : '否'}（要求是）; `
        + `编号步骤行 ${steps}（要求 =0）; 要点行 ${bullets}（要求 <3）`,
    };
  },
});

/** The preset ids in the order `01` §5 lists them. */
export const PRESET_IDS = Object.freeze(['general', 'coding', 'writing', 'translate']);

/**
 * Normalize one file entry into the list of candidate outputs.
 *
 * @param {unknown} value the entry as given
 * @returns {string[]} zero or more candidate drafts (B5 判据 3: up to two attempts)
 */
export function candidatesOf(value) {
  if (typeof value === 'string') return [value];
  if (value === null || typeof value !== 'object') return [];
  if (Array.isArray(value.outputs)) return value.outputs.filter((item) => typeof item === 'string');
  if (typeof value.text === 'string') return [value.text];
  if (Array.isArray(value)) return value.filter((item) => typeof item === 'string');
  return [];
}

/**
 * Judge one preset's candidates: **any** candidate passing is a pass (判据 3).
 *
 * @param {string} presetId which preset
 * @param {string[]} candidates the drafts to judge
 * @param {string} [input] the draft that was rewritten (used by `writing`)
 * @returns {{ presetId: string, pass: boolean, attempts: Array<object> }} the verdict
 */
export function judgePreset(presetId, candidates, input) {
  const predicate = PREDICATES[presetId];
  if (predicate === undefined) throw new Error(`unknown preset: ${presetId}`);
  const attempts = candidates.map((text, index) => ({
    attempt: index + 1,
    ...predicate(text, input),
  }));
  return { presetId, pass: attempts.some((attempt) => attempt.pass), attempts };
}

/**
 * Judge a whole `{ presetId: outputs }` document.
 *
 * @param {object} document the parsed input file
 * @returns {{ pass: boolean, presets: Array<object>, missing: string[] }} the verdict
 */
export function judgeDocument(document) {
  const source = document !== null && typeof document === 'object' && !Array.isArray(document) ? document : {};
  const inputs = source.inputs !== null && typeof source.inputs === 'object' ? source.inputs : {};
  const outputs = source.outputs !== null && typeof source.outputs === 'object' ? source.outputs : source;
  const presets = [];
  const missing = [];
  for (const presetId of PRESET_IDS) {
    const candidates = candidatesOf(outputs[presetId]);
    if (candidates.length === 0) {
      missing.push(presetId);
      continue;
    }
    presets.push(judgePreset(presetId, candidates, typeof inputs[presetId] === 'string' ? inputs[presetId] : undefined));
  }
  return { pass: missing.length === 0 && presets.every((entry) => entry.pass), presets, missing };
}

/** Format one preset verdict as one block of text. */
function formatVerdict(verdict) {
  const head = `${verdict.pass ? 'PASS' : 'FAIL'}  ${verdict.presetId}`;
  const lines = [head];
  for (const attempt of verdict.attempts) {
    lines.push(`  第 ${attempt.attempt} 次: ${attempt.pass ? 'PASS' : 'FAIL'} — ${attempt.detail}`);
  }
  return lines.join('\n');
}

const invokedDirectly = process.argv[1] !== undefined
  && fileURLToPath(import.meta.url) === fileURLToPath(new URL(`file://${process.argv[1].replace(/\\/g, '/')}`));

if (invokedDirectly) {
  const args = process.argv.slice(2).filter((arg) => !arg.startsWith('--'));
  const asJson = process.argv.includes('--json');
  if (args.length !== 1) {
    console.error('usage: node scripts/assert-preset.mjs <outputs.json> [--json]');
    process.exit(2);
  }
  let document;
  try {
    document = JSON.parse(readFileSync(args[0], 'utf8'));
  } catch (error) {
    console.error(`cannot read ${args[0]}: ${error.message}`);
    process.exit(2);
  }
  const verdict = judgeDocument(document);
  if (asJson) {
    console.log(JSON.stringify(verdict, null, 2));
  } else {
    for (const preset of verdict.presets) console.log(formatVerdict(preset));
    for (const presetId of verdict.missing) console.error(`MISSING ${presetId} — 没有该预设的改写稿`);
    console.log(`\n${verdict.pass ? 'B5 判据 2: PASS' : 'B5 判据 2: FAIL'} `
      + `(${verdict.presets.filter((entry) => entry.pass).length}/${PRESET_IDS.length} 套通过)`);
  }
  process.exit(verdict.pass ? 0 : 1);
}
