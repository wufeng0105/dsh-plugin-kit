/**
 * Host entry point.
 *
 * The module exports the two forms the Loader accepts together: the static `Config`
 * schema and `apply(ctx, config)`. The Config is loaded lazily so a profile without
 * the schemastery dependency degrades to "no Config surface" instead of failing the
 * whole plugin — the Client then reports settings as unavailable rather than
 * pretending to save (`01` §3-B20).
 *
 * Every Host service this plugin needs is optional on purpose: `commands` is
 * required for the seat to do anything, but `llm` and `sessionQuery` degrade, and
 * `webServer` is only touched by the guarded fallback. That keeps the failure mode
 * "one button that says why" instead of "the plugin row fails to mount".
 *
 * The settings write path (`persist`) is deliberately absent: the Host settings
 * document belongs to the `ui-settings` provider and reaching it from here is the
 * S6 slice's work. `save-settings` therefore answers `persist-unavailable` instead
 * of pretending (`09-verification.md` records this as the known gap it is).
 *
 * @module index
 */

import { createHost } from './lib/host.js';
import { createConfigSchema, loadSchemastery } from './lib/schema.js';

const schemastery = await loadSchemastery();

/** The plugin Config schema, or `undefined` when schemastery is unavailable. */
export const Config = schemastery === null ? undefined : createConfigSchema(schemastery);

/**
 * Mount the Host half.
 *
 * @param {object} ctx the Cordis context owning this plugin row
 * @param {object} config the parsed config; volatile fields are references with `.get()`
 */
export function apply(ctx, config) {
  const host = createHost({
    ctx,
    config,
    deps: {
      llm: typeof ctx?.get === 'function' ? ctx.get('llm') : ctx?.llm,
      // D-06: the model triple is read through `sessionQuery.observeSession(...)`
      // — the only projection read on the Host side. `sessionController.projections`
      // is a `@Remote` (browser) seam and is not callable from here.
      sessionQuery: typeof ctx?.get === 'function' ? ctx.get('sessionQuery') : ctx?.sessionQuery,
      now: () => Date.now(),
      setTimeout: (fn, ms) => setTimeout(fn, ms),
      clearTimeout: (handle) => clearTimeout(handle),
    },
  });

  if (typeof ctx?.effect === 'function') {
    ctx.effect(() => () => host.dispose(), 'lab-draft-studio: host wiring');
  }
  return host;
}
