# 草稿工坊（实验） / Draft Studio (lab)

> **这是实验产物，不是产品。** 它**与已安装的 `dsh-draft-studio@1.2.2` 并存**，两者**功能不共享**：
> 不共享设置、不共享预设、不共享按钮、不共享任何数据；本项目不会删除、停用或改动前代及其数据。
>
> **This is an experimental artifact, not a product.** It **coexists** with the installed
> `dsh-draft-studio@1.2.2` and **shares nothing** with it — no settings, no presets, no buttons,
> no data. This project never deletes, disables, or modifies the installed package or its data.

## 并存策略（为什么满屏都是 `lab-` 前缀）

负责人裁定（`06-lead-decision.md` §1）选的是**显式并存**，不是替换。所以：

| 位置 | 本实验用的值 | 在装产品的值 | 为什么必须不同 |
|---|---|---|---|
| 包名 | `@local/lab-draft-studio` | `dsh-draft-studio` | 安装后是两个模块，互不覆盖 |
| Loader patch 行 `id` | `lab-draft-studio` | `dsh-draft-studio` | `Config.listConfigs` 的 entryId = `include:<patchId>`，相同即同一格 |
| 座位 id（`conversation.input.right`） | `lab-draft-general` … `lab-draft-translate` | `dsh-draft-studio`（order 60） | list 座位**同 id 会替换**该 cell（`probes.md` P1/P24），不同 id 才并排 |
| 设置页 id（`settings.section`） | `lab-draft-studio` | `dsh-draft-studio`（order 60） | 同上 |
| `meta.title` | 草稿工坊（实验） | 草稿工坊 | 用户在界面上要能一眼分辨 |

**副作用如实记录**：装上之后输入框右侧工具行会**并排出现**前代 1 颗 + 队友模型选择器 1 颗 + 本项目最多 4 颗 = **最多 6 个控件**，设置里会有**两个**草稿工坊页。验收判据（`01` §3）不受影响——一切页面事实都按 `data-draft-studio-*` 属性过滤，前代那些属性 0 命中。

## 这个切片有什么 / 没什么

**有（离线可验）**：纯逻辑内核（预设与路由、上下文裁剪、写回决策、请求校验、设置读写校验）、Host 半骨架（命令通道 + Config + **带守卫的**降级 A 路由）、Client 半骨架（四颗座位 + 四态 + 设置页），以及 `test/` 下零第三方依赖的 `node:test`。

**没有（留 P3）**：安装、真实 `$DSH_HOME` 写入、运行时验证、`ctx.remote.commands.execute` 的真实调用接线（需要会话 id，属 S5/S6）。详见 `07-implementation.md` 的"空壳及原因"。

## 怎么跑测试

```powershell
cd bundle-lab
node --test "test/*.test.js"
node scripts/check-syntax.mjs
```

零第三方依赖：不需要 `npm install`，不需要 `node_modules`。
