/**
 * Tests for the pure kernel: presets, context, boundary, write-back, request
 * validation, settings, run state, wire format, the guard, and the sha256.
 *
 * Every case names the acceptance item it protects (`01` §3 B1–B21) so a reader
 * can go the other way — from a requirement to the test that would fail if it were
 * broken. Cases without a B number are decisions recorded in 07-implementation.md.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import {
  BUILTIN_LABELS,
  BUILTIN_PROMPTS,
  PRESET_IDS,
  STANDING_RULES,
  STRUCTURE_BLOCKS,
  buildSystemPrompt,
  isPresetId,
  readPresetMarker,
  resolvePresetId,
} from '../lib/prompt.js';
import { sha256Hex } from '../lib/sha256.js';
import {
  DEFAULT_MAX_CHARS,
  DEFAULT_MAX_ROUNDS,
  assembleContext,
  clampBudget,
  flattenEvent,
  readout,
  renderContextSection,
} from '../lib/context.js';
import {
  classifyDraft,
  countReferencePlaceholders,
  hasCommandChip,
  hasReferencePlaceholder,
  isDraftActionable,
} from '../lib/boundary.js';
import {
  VERDICTS,
  decideRevert,
  decideWriteBack,
  isUsableResult,
  revertStillSafe,
  spanStillValid,
} from '../lib/writeback.js';
import {
  DEFAULT_TIMEOUT_MS,
  ROUTE_PATH,
  dispatch,
  dumpRequest,
  effectiveTimeout,
  readSelftestEnv,
  resolveSettings,
  runRefine,
} from '../lib/host.js';
import {
  buildResult,
  decodeLine,
  decodeResult,
  encodeLine,
  encodeResult,
  toBase64Url,
  fromBase64Url,
} from '../lib/wire.js';
import {
  generateToken,
  guardRequest,
  isSilentRefusal,
  readHeader,
  TOKEN_HEADER,
} from '../lib/guard.js';
import {
  EDITABLE_SPECS,
  READONLY_SPECS,
  SETTINGS_SPEC,
  codePointLength,
  countUnsaved,
  defaultSettings,
  pinnedUsable,
  resolveLabel,
  resolvePrompt,
  specCounts,
  validateLabel,
  validatePatch,
  validatePrompt,
} from '../lib/settings.js';
import {
  composeLlmOptions,
  makeConfigure,
  normalizeRoute,
  previewEffort,
  resolveEffort,
} from '../lib/llm-options.js';
import { REASON_CODES, SEAT_STATES, createRunStore } from '../lib/run-store.js';
import {
  MAX_DRAFT_CHARS,
  seatPlan,
  validateRefineRequest,
  validateSaveRequest,
  visibleSeats,
} from '../lib/request.js';
import { createConfigSchema, readConfig, unwrapField } from '../lib/schema.js';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import {
  createHost,
  ENTRY_ID_PREFIX,
  normalizeEntryId,
  prepareDumpRequest,
  readEntryId,
} from '../lib/host.js';
import {
  PREDICATES as PRESET_PREDICATES,
  cjkRatio,
  countBullets,
  countNumberedSteps,
  countParagraphs,
  hasFence,
  judgeDocument,
} from '../scripts/assert-preset.mjs';

/** The shipped Host text, for the "the invented method is gone" assertion. */
const HOST_SOURCE = readFileSync(fileURLToPath(new URL('../lib/host.js', import.meta.url)), 'utf8');

// ---------------------------------------------------------------------------
// sha256 — the hashing primitive B5/B7 rest on
// ---------------------------------------------------------------------------

test('sha256 matches the FIPS-180-4 vectors (B5 depends on this)', () => {
  assert.equal(sha256Hex(''), 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  assert.equal(sha256Hex('abc'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  assert.equal(
    sha256Hex('abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq'),
    '248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1',
  );
});

test('sha256 hashes UTF-8, so a Chinese preset body hashes like the bytes the Host sends', () => {
  const hash = sha256Hex('通用');
  assert.equal(hash.length, 64);
  assert.match(hash, /^[0-9a-f]{64}$/);
  // Distinct inputs keep distinct hashes even when they differ only in CJK text.
  assert.notEqual(hash, sha256Hex('编程'));
});

test('sha256 accepts raw bytes and mixes long inputs across many blocks', () => {
  const bytes = new Uint8Array([0x61, 0x62, 0x63]);
  assert.equal(sha256Hex(bytes), sha256Hex('abc'));
  const long = 'x'.repeat(1000);
  assert.equal(sha256Hex(long).length, 64);
  assert.notEqual(sha256Hex(long), sha256Hex(`${long}y`));
});

// ---------------------------------------------------------------------------
// presets & routing (B5 judgement 1, B7)
// ---------------------------------------------------------------------------

test('the four preset ids are exactly the ones 01 §2 fixes', () => {
  assert.deepEqual([...PRESET_IDS], ['general', 'coding', 'writing', 'translate']);
  for (const id of PRESET_IDS) assert.equal(isPresetId(id), true);
  assert.equal(isPresetId('General'), false, 'ids are lowercase');
  assert.equal(isPresetId(''), false);
  assert.equal(isPresetId(null), false);
});

test('each structure block is copied verbatim from 01 §3-B5 (B5-a)', () => {
  assert.equal(
    STRUCTURE_BLOCKS.general,
    '【结构要求 preset=general】\n- 输出 3–7 条以 "- " 开头的要点；\n- 不使用编号步骤，不使用代码围栏。',
  );
  assert.equal(
    STRUCTURE_BLOCKS.coding,
    '【结构要求 preset=coding】\n- 输出有序步骤，至少 3 步，每步以 "1." "2." 这样的编号开头；\n- 含代码时使用三反引号围栏。',
  );
  assert.equal(
    STRUCTURE_BLOCKS.writing,
    '【结构要求 preset=writing】\n- 保留输入的段落划分，不合并段落；\n- 不使用编号步骤，不使用代码围栏；\n- 输出语言与输入一致。',
  );
  assert.equal(
    STRUCTURE_BLOCKS.translate,
    '【结构要求 preset=translate】\n- 输出译为英文；\n- 不保留中文正文（专有名词可保留原名）；\n- 不添加解释或编号步骤。',
  );
});

test('every built system prompt contains its own structure block (B5-a)', () => {
  for (const id of PRESET_IDS) {
    const system = buildSystemPrompt(id);
    assert.equal(system.includes(STRUCTURE_BLOCKS[id]), true, `B5-a failed for ${id}`);
    assert.equal(system.includes(STANDING_RULES), true, 'the standing rules are on every preset');
  }
});

test('the four system prompts hash pairwise differently (B5-b)', () => {
  const hashes = PRESET_IDS.map((id) => sha256Hex(buildSystemPrompt(id)));
  assert.equal(new Set(hashes).size, 4, `expected 4 distinct hashes, got ${hashes.join(',')}`);
});

test('the marker line names the preset the request asked for (B5-c, catches a crossed table)', () => {
  for (const id of PRESET_IDS) {
    assert.equal(readPresetMarker(buildSystemPrompt(id)), id);
  }
});

test('a user-edited prompt body replaces the built-in body but keeps the structure block', () => {
  const system = buildSystemPrompt('coding', '我的自定义指令');
  assert.equal(system.startsWith('我的自定义指令'), true);
  assert.equal(system.includes(STRUCTURE_BLOCKS.coding), true);
  assert.equal(system.includes(BUILTIN_PROMPTS.coding), false, 'the override replaced the built-in body');
});

test('an empty or whitespace prompt body means "restore the built-in" (01 §5 #6–#9)', () => {
  for (const empty of ['', '   ', '\n\t ']) {
    assert.equal(buildSystemPrompt('general', empty), buildSystemPrompt('general'));
  }
});

test('buildSystemPrompt refuses an unknown preset instead of guessing', () => {
  assert.throws(() => buildSystemPrompt('nope'), /unknown presetId/);
});

test('resolvePresetId degrades an unknown id to general and says it did', () => {
  assert.deepEqual(resolvePresetId('coding'), { presetId: 'coding', fallback: false });
  assert.deepEqual(resolvePresetId('CODING'), { presetId: 'general', fallback: true });
  assert.deepEqual(resolvePresetId(undefined), { presetId: 'general', fallback: true });
});

test('a rename changes the display name but never the system prompt (B7)', () => {
  const base = defaultSettings();
  const before = sha256Hex(buildSystemPrompt('writing', resolvePrompt(base, 'writing')));

  const renamed = validatePatch({ presets: { writing: { label: '文案' } } }, base).value;
  assert.equal(resolveLabel(renamed, 'writing'), '文案');
  const after = sha256Hex(buildSystemPrompt('writing', resolvePrompt(renamed, 'writing')));
  assert.equal(after, before, 'B7 fails if a label ever reaches the system prompt');

  assert.equal(resolveLabel(defaultSettings(), 'writing'), BUILTIN_LABELS.writing, 'the default comes back');
});

// ---------------------------------------------------------------------------
// context assembly (B3 readout, §5 #3/#4)
// ---------------------------------------------------------------------------

test('flattenEvent keeps conversational text and drops tool traffic', () => {
  assert.deepEqual(flattenEvent({ role: 'user', content: '你好' }), { role: 'user', text: '你好' });
  assert.deepEqual(
    flattenEvent({ role: 'assistant', content: [{ type: 'text', text: 'a' }, { type: 'reasoning', text: 'b' }] }),
    { role: 'assistant', text: 'a' },
  );
  assert.equal(flattenEvent({ role: 'tool', content: 'x' }), null);
  assert.equal(flattenEvent({ role: 'user', content: [{ type: 'image' }] }), null);
  assert.equal(flattenEvent(null), null);
});

test('assembleContext keeps the newest N rounds and reports how many it dropped', () => {
  const events = Array.from({ length: 10 }, (_, i) => ({ role: i % 2 === 0 ? 'user' : 'assistant', content: `m${i}` }));
  const result = assembleContext({ enabled: true, events, maxRounds: 4, maxChars: 8000 });
  assert.equal(result.rounds, 4);
  assert.deepEqual(result.messages.map((m) => m.text), ['m6', 'm7', 'm8', 'm9']);
  assert.equal(result.dropped.byRounds, 6);
  assert.equal(result.reason, 'ok');
});

test('assembleContext drops from the oldest end to satisfy the character budget', () => {
  const events = [
    { role: 'user', content: 'x'.repeat(900) },
    { role: 'assistant', content: 'y'.repeat(900) },
    { role: 'user', content: 'z'.repeat(200) },
  ];
  const result = assembleContext({ enabled: true, events, maxRounds: 6, maxChars: 200 });
  assert.equal(result.rounds, 1, 'only the newest message fits');
  assert.equal(result.messages[0].text, 'z'.repeat(200));
  assert.equal(result.dropped.byChars, 2);
});

test('assembleContext keeps at least the newest message even when it alone overflows', () => {
  const events = [{ role: 'user', content: 'q'.repeat(500) }];
  const result = assembleContext({ enabled: true, events, maxRounds: 6, maxChars: 200 });
  assert.equal(result.rounds, 1, 'an empty context is less useful than a truncated one');
  assert.equal(result.reason, 'ok');
});

test('assembleContext explains every empty result instead of returning bare []', () => {
  assert.equal(assembleContext({ enabled: false, events: [] }).reason, 'disabled');
  assert.equal(assembleContext({ enabled: true, events: null }).reason, 'read-failed');
  assert.equal(assembleContext({ enabled: true, events: 'nope' }).reason, 'read-failed');
  assert.equal(assembleContext({ enabled: true, events: null, error: 'no-session' }).reason, 'no-session');
  assert.equal(assembleContext({ enabled: true, events: [] }).reason, 'empty');
  assert.equal(assembleContext({ enabled: true, events: [{ role: 'tool' }] }).reason, 'empty');
});

test('clampBudget clamps into range and reports the move', () => {
  assert.deepEqual(clampBudget(0, { min: 1, max: 20 }, DEFAULT_MAX_ROUNDS), { value: 1, clamped: true });
  assert.deepEqual(clampBudget(99, { min: 1, max: 20 }, DEFAULT_MAX_ROUNDS), { value: 20, clamped: true });
  assert.deepEqual(clampBudget(6, { min: 1, max: 20 }, DEFAULT_MAX_ROUNDS), { value: 6, clamped: false });
  assert.deepEqual(clampBudget(undefined, { min: 1, max: 20 }, DEFAULT_MAX_ROUNDS), { value: DEFAULT_MAX_ROUNDS, clamped: true });
});

test('renderContextSection is empty when there is nothing to send', () => {
  assert.equal(renderContextSection(assembleContext({ enabled: false, events: [] })), '');
  const section = renderContextSection(assembleContext({
    enabled: true,
    events: [{ role: 'user', content: '你好' }],
    maxRounds: 6,
    maxChars: DEFAULT_MAX_CHARS,
  }));
  assert.match(section, /【会话上下文】/);
  assert.match(section, /用户：你好/);
});

test('readout reports rounds, chars and the reason for the readout row (§5 #20)', () => {
  assert.deepEqual(readout(null), { readRounds: 0, readChars: 0, reason: 'read-failed' });
  const context = assembleContext({ enabled: true, events: [{ role: 'user', content: 'abc' }] });
  assert.deepEqual(readout(context), { readRounds: 1, readChars: 3, reason: 'ok' });
});

// ---------------------------------------------------------------------------
// boundary (B1-d, B2, B21)
// ---------------------------------------------------------------------------

test('a whitespace-only draft is empty, including the full-width space (B2)', () => {
  assert.equal(isDraftActionable(' \n\t '), false);
  assert.equal(isDraftActionable('\u3000'), false, 'B2 negative case: \\u3000 is trimmed by trim()');
  assert.equal(isDraftActionable('\u3000\u3000'), false);
  assert.equal(isDraftActionable('你好'), true);
  assert.equal(isDraftActionable(' \u3000 x '), true);
  assert.equal(isDraftActionable(undefined), false);
  assert.equal(isDraftActionable(null), false);
  assert.equal(isDraftActionable(42), false);
});

test('reference placeholders are counted across the Host sentinel range (B21)', () => {
  assert.equal(countReferencePlaceholders('\uE100'), 1);
  assert.equal(countReferencePlaceholders('\uE11D x \uFFFC'), 2);
  assert.equal(countReferencePlaceholders('plain'), 0);
  assert.equal(countReferencePlaceholders(null), 0);
  assert.equal(hasReferencePlaceholder('\uE105'), true);
  assert.equal(hasReferencePlaceholder('\uE200'), false, 'outside the documented range');
});

test('a leading slash command is detected, a mid-text slash is not (B21)', () => {
  assert.equal(hasCommandChip('/plan 帮我改'), true);
  assert.equal(hasCommandChip('  /plan x'), true);
  assert.equal(hasCommandChip('/plan'), true);
  assert.equal(hasCommandChip('a / b'), false);
  assert.equal(hasCommandChip('a/plan'), false);
});

test('classifyDraft returns the raw draft untouched (B4 needs the untrimmed text)', () => {
  const classified = classifyDraft('  你好  ');
  assert.equal(classified.actionable, true);
  assert.equal(classified.text, '  你好  ');
  assert.equal(classified.command, false);
  assert.equal(classified.references, 0);
});

// ---------------------------------------------------------------------------
// write-back (B4, B13, B15, B21)
// ---------------------------------------------------------------------------

test('a clean run writes the result back and lands in revertible', () => {
  const decision = decideWriteBack({
    result: '改写稿',
    capture: { draftRev: 7, text: '原文', references: 0 },
    current: { draftRev: 7, text: '原文', phase: 'plain', references: 0 },
  });
  assert.equal(decision.verdict, VERDICTS.write);
  assert.equal(decision.state, 'revertible');
  assert.equal(decision.text, '改写稿');
});

test('a draft that moved during the wait is never overwritten (B13, second red line)', () => {
  const changedText = decideWriteBack({
    result: '改写稿',
    capture: { draftRev: 7, text: '原文', references: 0 },
    current: { draftRev: 7, text: '新的输入', phase: 'plain', references: 0 },
  });
  assert.equal(changedText.verdict, VERDICTS.retryPending);
  assert.equal(changedText.reason, 'draft-changed');
  assert.equal(changedText.text, null, 'nothing is written');
  assert.equal(changedText.keepResult, true, 'the result is kept for a retry (A9)');

  const changedRev = decideWriteBack({
    result: '改写稿',
    capture: { draftRev: 7, text: '原文', references: 0 },
    current: { draftRev: 8, text: '原文', phase: 'plain', references: 0 },
  });
  assert.equal(changedRev.verdict, VERDICTS.retryPending);
});

test('a sent draft discards the late result instead of writing (B14, A7)', () => {
  for (const phase of ['submitting', 'sending', 'adjudicating']) {
    const decision = decideWriteBack({
      result: '改写稿',
      capture: { draftRev: 7, text: '原文', references: 0 },
      current: { draftRev: 7, text: '原文', phase, references: 0 },
    });
    assert.equal(decision.verdict, VERDICTS.discard, `phase=${phase}`);
    assert.equal(decision.state, 'idle');
    assert.equal(decision.keepResult, false);
  }
  const disposed = decideWriteBack({ result: 'x', capture: {}, current: { disposed: true } });
  assert.equal(disposed.verdict, VERDICTS.discard);
});

test('an empty result is a failure, never a silent erase (A12)', () => {
  for (const empty of ['', '   ', null, undefined, 42]) {
    const decision = decideWriteBack({
      result: empty,
      capture: { draftRev: 1, text: '原文', references: 0 },
      current: { draftRev: 1, text: '原文', phase: 'plain', references: 0 },
    });
    assert.equal(decision.verdict, VERDICTS.failed);
    assert.equal(decision.reason, 'empty-result');
    assert.equal(decision.text, null);
  }
  assert.equal(isUsableResult('  x  '), true);
});

test('a result that lost a reference placeholder is held back (B21)', () => {
  const decision = decideWriteBack({
    result: '改写稿丢了标记',
    capture: { draftRev: 1, text: '看 \uE100 这个', references: 1 },
    current: { draftRev: 1, text: '看 \uE100 这个', phase: 'plain', references: 1 },
  });
  assert.equal(decision.verdict, VERDICTS.retryPending);
  assert.equal(decision.reason, 'reference-lost');

  const kept = decideWriteBack({
    result: '改写后仍保留 \uE100',
    capture: { draftRev: 1, text: '看 \uE100', references: 1 },
    current: { draftRev: 1, text: '看 \uE100', phase: 'plain', references: 1 },
  });
  assert.equal(kept.verdict, VERDICTS.write);
});

test('spanStillValid refuses a span the draft has moved around', () => {
  assert.equal(spanStillValid({ span: { start: 0, end: 2 }, captureText: '原文', currentText: '原文' }), true);
  assert.equal(spanStillValid({ span: { start: 0, end: 2 }, captureText: '原文', currentText: '原文之后' }), true);
  assert.equal(spanStillValid({ span: { start: 0, end: 2 }, captureText: '原文', currentText: '新文' }), false);
  assert.equal(spanStillValid({ span: null, captureText: 'a', currentText: 'a' }), false);
  assert.equal(spanStillValid({ span: { start: 5, end: 2 }, captureText: 'a', currentText: 'a' }), false);
});

test('revert restores only our own write (B4, B16)', () => {
  assert.equal(revertStillSafe({ written: '改写稿', currentText: '改写稿' }), true);
  assert.equal(revertStillSafe({ written: '改写稿', currentText: '改写稿 plus my edit' }), false);
  assert.deepEqual(
    decideRevert({ original: '原文', written: '改写稿', currentText: '改写稿' }),
    { verdict: VERDICTS.write, text: '原文', reason: null },
  );
  assert.equal(
    decideRevert({ original: '原文', written: '改写稿', currentText: '别的' }).verdict,
    VERDICTS.discard,
  );
});

// ---------------------------------------------------------------------------
// settings (B6, B7, B17, B18, B19)
// ---------------------------------------------------------------------------

test('the spec is 20 items: 19 editable plus one read-only readout (B18, A13)', () => {
  assert.deepEqual(specCounts(), { editable: 19, readonly: 1, total: 20 });
  assert.equal(READONLY_SPECS.length, 1);
  assert.equal(READONLY_SPECS[0].key, 'lastResult');
  assert.equal(EDITABLE_SPECS.some((row) => row.key === 'lastResult'), false);
  assert.equal(SETTINGS_SPEC[19].index, 20);
});

test('writing the read-only readout is rejected, not ignored (B18 negative case)', () => {
  const result = validatePatch({ lastResult: { text: 'x' } }, defaultSettings());
  assert.equal(result.ok, false);
  assert.deepEqual(result.errors, [{ key: 'lastResult', error: 'readonly' }]);
});

test('an unknown settings key is rejected so a typo cannot pass silently', () => {
  const result = validatePatch({ notASetting: 1 }, defaultSettings());
  assert.equal(result.ok, false);
  assert.equal(result.errors[0].error, 'unknown-key');
});

test('a timeout below 30 seconds is refused and the old value survives (B17 negative)', () => {
  const base = defaultSettings();
  const result = validatePatch({ timeoutMs: 5000 }, base);
  assert.equal(result.ok, false);
  assert.deepEqual(result.errors, [{ key: 'timeoutMs', error: 'below-min' }]);
  assert.equal(result.value.timeoutMs, 480000, 'nothing was applied');

  assert.equal(validatePatch({ timeoutMs: 30000 }, base).ok, true, 'the lower bound itself is legal');
  assert.equal(validatePatch({ timeoutMs: 600000 }, base).ok, true, 'the upper bound itself is legal');
  assert.equal(validatePatch({ timeoutMs: 600001 }, base).ok, false);
  assert.equal(defaultSettings().timeoutMs, 480000, 'the default is 480 s (01 §5 #17)');
});

test('one invalid field rejects the whole patch (all-or-nothing)', () => {
  const result = validatePatch({ enabled: false, temperature: 2 }, defaultSettings());
  assert.equal(result.ok, false);
  assert.equal(result.value.enabled, true, 'the valid field was not applied either');
});

test('a display name is limited to 12 code points (B7)', () => {
  assert.deepEqual(validateLabel('文案'), { value: '文案', error: null });
  const twelve = '一'.repeat(12);
  assert.equal(codePointLength(twelve), 12);
  assert.deepEqual(validateLabel(twelve), { value: twelve, error: null }, '12 is legal');
  const thirteen = '一'.repeat(13);
  assert.equal(codePointLength(thirteen), 13);
  assert.deepEqual(validateLabel(thirteen), { value: null, error: 'too-long' }, '13 is refused');
  assert.deepEqual(validateLabel(''), { value: null, error: null }, 'empty means restore the default');
  assert.deepEqual(validateLabel('   '), { value: null, error: null });
  // An emoji is one code point, not two UTF-16 units.
  assert.equal(codePointLength('😀'.repeat(12)), 12);
  assert.deepEqual(validateLabel('😀'.repeat(12)), { value: '😀'.repeat(12), error: null });
  assert.deepEqual(validateLabel('😀'.repeat(13)), { value: null, error: 'too-long' });
});

test('an empty prompt means "restore the built-in", not "store an empty string"', () => {
  assert.deepEqual(validatePrompt('  '), { value: null, error: null });
  assert.deepEqual(validatePrompt('自定义'), { value: '自定义', error: null });
  const base = defaultSettings();
  const cleared = validatePatch({ presets: { coding: { prompt: '   ' } } }, {
    ...base,
    presets: { ...base.presets, coding: { prompt: '旧的', label: null } },
  }).value;
  assert.equal(cleared.presets.coding.prompt, null);
  assert.equal(resolvePrompt(cleared, 'coding'), BUILTIN_PROMPTS.coding, 'the built-in is back');
});

test('a nested preset patch and its flattened form accept the same thing', () => {
  const nested = validatePatch({ presets: { translate: { label: '英译' } } }, defaultSettings());
  const flat = validatePatch({ 'presets.translate.label': '英译' }, defaultSettings());
  assert.equal(nested.ok, true);
  assert.equal(flat.ok, true);
  assert.equal(nested.value.presets.translate.label, '英译');
  assert.deepEqual(nested.value, flat.value);
});

test('an unknown preset id in a patch is rejected', () => {
  const result = validatePatch({ presets: { klingon: { prompt: 'x' } } }, defaultSettings());
  assert.equal(result.ok, false);
  assert.deepEqual(result.errors, [{ key: 'presets.klingon', error: 'unknown-preset' }]);
});

test('visible presets are stored in canonical seat order and de-duplicated (B1-b)', () => {
  const result = validatePatch({ visiblePresets: ['translate', 'general', 'translate'] }, defaultSettings());
  assert.equal(result.ok, true);
  assert.deepEqual(result.value.visiblePresets, ['general', 'translate']);
  assert.equal(validatePatch({ visiblePresets: ['nope'] }, defaultSettings()).ok, false);
});

test('unsaved count is the number of changed fields across 4 presets, de-duplicated (B19)', () => {
  const saved = defaultSettings();
  const one = {
    ...saved,
    presets: { ...saved.presets, coding: { prompt: '新', label: null } },
  };
  assert.equal(countUnsaved(one, saved), 1, 'editing one field counts once no matter how many times');

  const two = {
    ...saved,
    presets: {
      ...saved.presets,
      coding: { prompt: '新', label: '编程2' },
      writing: { prompt: null, label: '文案' },
    },
  };
  assert.equal(countUnsaved(two, saved), 3, '8 fields max, across all four presets');
  assert.equal(countUnsaved(saved, saved), 0);
});

test('a pinned model with a missing half does not count as usable (§7-A8)', () => {
  const base = defaultSettings();
  assert.deepEqual(pinnedUsable(base), { usable: false, reason: 'not-pinned' });
  const pinned = validatePatch({ modelSource: 'pinned', pinnedModel: { provider: 'p', model: 'm' } }, base).value;
  assert.deepEqual(pinnedUsable(pinned), { usable: true, reason: null });
  const broken = { ...pinned, pinnedModel: { provider: 'p' } };
  assert.deepEqual(pinnedUsable(broken), { usable: false, reason: 'model-missing' });
});

// ---------------------------------------------------------------------------
// request validation (B1-d, B2, B15 fallback)
// ---------------------------------------------------------------------------

test('a whitespace-only draft is refused at the request boundary (B2)', () => {
  for (const draft of ['', '   ', '\u3000', '\n\t']) {
    const result = validateRefineRequest({ action: 'refine', draft });
    assert.equal(result.ok, false);
    assert.equal(result.errors.some((entry) => entry.error === 'empty'), true);
  }
});

test('a non-string draft is refused rather than coerced', () => {
  assert.equal(validateRefineRequest({ draft: 42 }).ok, false);
  assert.equal(validateRefineRequest({ draft: null }).ok, false);
  assert.equal(validateRefineRequest(null).ok, false);
});

test('an unknown preset id falls back to general with a soft notice (B15 fallback)', () => {
  const result = validateRefineRequest({ draft: '你好', presetId: 'klingon' });
  assert.equal(result.ok, true, 'a stale client must not get an error');
  assert.equal(result.value.presetId, 'general');
  assert.equal(result.value.presetIdFallback, true);
  assert.deepEqual(result.errors, [{ field: 'presetId', error: 'unknown-preset-fallback-applied', soft: true }]);
});

test('a draft longer than the wire cap is refused with a typed reason', () => {
  const result = validateRefineRequest({ draft: 'x'.repeat(MAX_DRAFT_CHARS + 1) });
  assert.equal(result.ok, false);
  assert.equal(result.errors[0].error, 'too-long');
});

test('the master switch hides every seat; the ticked set survives for later (B1-c, B6)', () => {
  const settings = { enabled: false, visiblePresets: ['general', 'translate'] };
  assert.deepEqual(visibleSeats(settings), { visible: [], masterOff: true });
  assert.deepEqual(
    visibleSeats({ enabled: true, visiblePresets: ['general', 'translate'] }),
    { visible: ['general', 'translate'], masterOff: false },
  );
});

test('an unreachable settings service degrades to exactly one general seat (B20)', () => {
  assert.deepEqual(seatPlan(null, false), { visible: ['general'], degraded: true, presetId: null });
  assert.equal(seatPlan(defaultSettings(), true).degraded, false);
});

// ---------------------------------------------------------------------------
// LLM options (B8, B9, B10)
// ---------------------------------------------------------------------------

test('follow mode uses the session triple verbatim (B8)', () => {
  const composed = composeLlmOptions(defaultSettings(), { provider: 'p', model: 'm', reasoningEffort: 'high' });
  assert.deepEqual(composed.route, { provider: 'p', model: 'm', reasoningEffort: 'high' });
  assert.equal(composed.source, 'follow');
  assert.equal(composed.degraded, false);
});

test('pinned mode ignores the session selection entirely (B9)', () => {
  const settings = validatePatch({
    modelSource: 'pinned',
    pinnedModel: { provider: 'pm', model: 'mm' },
    pinnedEffort: 'low',
  }, defaultSettings()).value;
  const composed = composeLlmOptions(settings, { provider: 'session-p', model: 'session-m', reasoningEffort: 'high' });
  assert.deepEqual(composed.route, { provider: 'pm', model: 'mm', reasoningEffort: 'low' });
  assert.equal(composed.source, 'pinned');
});

test('a pinned model that is gone degrades to follow instead of failing (§7-A8)', () => {
  const settings = { ...defaultSettings(), modelSource: 'pinned', pinnedModel: { provider: 'p' } };
  const composed = composeLlmOptions(settings, { provider: 'sp', model: 'sm' });
  assert.equal(composed.source, 'follow');
  assert.equal(composed.degraded, true);
  assert.equal(composed.reason, 'pinned-model-unavailable');
});

test('composeLlmOptions throws rather than inventing a route when nothing is readable', () => {
  assert.throws(() => composeLlmOptions(defaultSettings(), null), /unreadable/);
});

test('temperature and maxTokens ride along only when they are set (§5 #18/#19)', () => {
  const unset = composeLlmOptions(defaultSettings(), { provider: 'p', model: 'm' });
  assert.deepEqual(unset.controls, {});
  const set = composeLlmOptions(
    { ...defaultSettings(), temperature: 0, maxTokens: 1024 },
    { provider: 'p', model: 'm' },
  );
  assert.deepEqual(set.controls, { temperature: 0, maxTokens: 1024 });
});

test('normalizeRoute drops empty efforts and rejects half routes', () => {
  assert.deepEqual(normalizeRoute({ provider: ' p ', model: ' m ', reasoningEffort: '' }), { provider: 'p', model: 'm' });
  assert.equal(normalizeRoute({ provider: 'p' }), null);
  assert.equal(normalizeRoute({ provider: '', model: 'm' }), null);
  assert.equal(normalizeRoute(null), null);
});

test('an unsupported effort falls back to the model default before I/O (B10)', () => {
  const resolution = resolveEffort({ requested: 'high', efforts: ['low', 'medium'], defaultEffort: 'medium' });
  assert.deepEqual(resolution, { effort: 'medium', fallback: true, reason: 'effort-not-in-model-efforts' });

  const supported = resolveEffort({ requested: 'low', efforts: ['low', 'medium'], defaultEffort: 'medium' });
  assert.deepEqual(supported, { effort: 'low', fallback: false, reason: null });

  const unknownModel = resolveEffort({ requested: 'high', efforts: [], defaultEffort: undefined });
  assert.deepEqual(unknownModel, { effort: undefined, fallback: true, reason: 'model-declares-no-efforts' });
});

test('an unrequested effort is left alone and is not reported as a fallback', () => {
  assert.deepEqual(resolveEffort({ requested: undefined, efforts: ['low'], defaultEffort: 'low' }), {
    effort: undefined,
    fallback: false,
    reason: null,
  });
});

test('makeConfigure rewrites the controls the way resolveEffort decided (B10)', () => {
  const configure = makeConfigure('high');
  const out = configure({ temperature: 0 }, { reasoning: { efforts: ['low'], defaultEffort: 'low' } });
  assert.deepEqual(out, { temperature: 0, reasoningEffort: 'low' });

  const dropped = makeConfigure('high')({}, { reasoning: { efforts: [] } });
  assert.deepEqual(dropped, {});
  assert.equal(previewEffort({ requested: 'high', model: { reasoning: { efforts: [] } } }).fallback, true);
});

// ---------------------------------------------------------------------------
// run store (B11, B12, B13, B14, B16)
// ---------------------------------------------------------------------------

test('only one run is active at a time; a second start is refused (B11)', () => {
  const store = createRunStore();
  assert.deepEqual(store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 }), { token: 1 });
  assert.equal(store.start({ sessionId: 's1', presetId: 'writing', draft: 'x', draftRev: 1, now: 1 }), null);
});

test('elapsed time grows from the caller clock, so the seat shows real seconds (B11)', () => {
  const store = createRunStore();
  store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 1000 });
  assert.equal(store.elapsed(1000), 0);
  assert.equal(store.elapsed(2400), 1400, 'two samples 1.4 s apart differ by 1400 ms (>= 900)');
});

test('a late result whose token is stale is ignored (B13/B16 race guard)', () => {
  const store = createRunStore();
  const { token } = store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 });
  store.cancel(token);
  assert.equal(store.finish(token, { written: 'y', original: 'x' }), false, 'the cancelled run cannot settle');
});

test('cancel returns to idle and keeps nothing (B12)', () => {
  const store = createRunStore();
  const { token } = store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 });
  assert.equal(store.cancel(token), true);
  assert.equal(store.active(), null);
  assert.equal(store.record('coding'), null, 'no revert state survives a cancel');
});

test('sending the draft stops the run and drops its result (B14 / A7)', () => {
  const store = createRunStore();
  const { token } = store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 });
  assert.equal(store.abortOnSend(token), true);
  assert.equal(store.active(), null);
  assert.equal(store.record('coding'), null);
});

test('a finished run shows on its own seat only, and other seats are blocked (B11/B16)', () => {
  const store = createRunStore();
  const { token } = store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 });
  store.finish(token, { written: 'y', original: 'x' });
  assert.deepEqual(
    store.seatState({ presetId: 'coding', sessionId: 's1', now: 10 }),
    { state: SEAT_STATES.revertible, reason: null, elapsedMs: null, revertible: true },
  );
  assert.equal(store.seatState({ presetId: 'writing', sessionId: 's1', now: 10 }).state, SEAT_STATES.idle);
  // The record is per seat: reverting writing must not see coding's record.
  assert.equal(store.record('writing'), null);
});

test('a run in another session does not block this session seat (B14)', () => {
  const store = createRunStore();
  store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 });
  const other = store.seatState({ presetId: 'general', sessionId: 's2', now: 10 });
  assert.equal(other.state, SEAT_STATES.idle);
  assert.notEqual(other.blockedByOther, true);
});

test('a failure settles with one of the six documented reason codes (B15)', () => {
  const store = createRunStore();
  const { token } = store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 });
  store.fail(token, 'timeout');
  assert.deepEqual(
    store.seatState({ presetId: 'coding', sessionId: 's1', now: 10 }),
    { state: SEAT_STATES.failed, reason: 'timeout', elapsedMs: null, revertible: false },
  );
  assert.deepEqual([...REASON_CODES], [
    'timeout',
    'provider-error',
    'aborted',
    'empty-result',
    'unsupported-effort',
    'settings-unavailable',
  ]);

  const again = createRunStore();
  const second = again.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 0 });
  again.fail(second.token, 'not-a-real-code');
  assert.equal(again.record('coding').reason, 'provider-error', 'an unknown code is normalized, never leaked to the UI');
});

test('the running seat reports elapsed ms and only that seat is running (B11)', () => {
  const store = createRunStore();
  store.start({ sessionId: 's1', presetId: 'coding', draft: 'x', draftRev: 1, now: 1000 });
  const coding = store.seatState({ presetId: 'coding', sessionId: 's1', now: 2000 });
  assert.equal(coding.state, SEAT_STATES.running);
  assert.equal(coding.elapsedMs, 1000);
  const other = store.seatState({ presetId: 'general', sessionId: 's1', now: 2000 });
  assert.equal(other.state, SEAT_STATES.idle);
  assert.equal(other.blockedByOther, true, 'the other seats are greyed out');
});

// ---------------------------------------------------------------------------
// wire format
// ---------------------------------------------------------------------------

test('a line round-trips any draft, including newlines and chip placeholders', () => {
  const payload = { action: 'refine', presetId: 'coding', draft: '第一行\n第二行 "引号" \uE100 \\ 反斜杠', sessionId: 's1' };
  const line = encodeLine(payload);
  assert.equal(line.startsWith('/lab-draft '), true);
  assert.equal(line.includes('\n'), false, 'the payload must stay on one line');
  const decoded = decodeLine(line);
  assert.equal(decoded.ok, true);
  assert.deepEqual(decoded.payload, payload);
});

test('an 8000-character draft survives the wire unchanged (U3)', () => {
  const draft = 'x'.repeat(8000);
  const decoded = decodeLine(encodeLine({ action: 'refine', draft }));
  assert.equal(decoded.ok, true);
  assert.equal(decoded.payload.draft.length, 8000);
});

test('decodeLine reports typed errors instead of throwing', () => {
  assert.equal(decodeLine('/other-cmd abc').error, 'unknown-command');
  assert.equal(decodeLine('/lab-draft').error, 'empty-payload');
  assert.equal(decodeLine('/lab-draft !!!not-base64!!!').error, 'not-base64url');
  assert.equal(decodeLine(null).error, 'line-not-a-string');
  const notJson = toBase64Url(new TextEncoder().encode('not json'));
  assert.equal(decodeLine(`/lab-draft ${notJson}`).error, 'not-json');
});

test('base64url round-trips arbitrary bytes without padding or +/', () => {
  for (const bytes of [new Uint8Array([0]), new Uint8Array([0xff, 0xfe]), new Uint8Array([1, 2, 3, 4, 5])]) {
    const encoded = toBase64Url(bytes);
    assert.equal(encoded.includes('+'), false);
    assert.equal(encoded.includes('/'), false);
    assert.equal(encoded.includes('='), false);
    assert.deepEqual([...fromBase64Url(encoded)], [...bytes]);
  }
  assert.equal(fromBase64Url('===='), null, 'an all-padding body is not a body');
  assert.equal(fromBase64Url(''), null);
});

test('a result round-trips through CommandResult.text', () => {
  const payload = buildResult({ text: '改写稿', presetId: 'coding', system: 's', systemSha256: 'h' });
  const decoded = decodeResult(encodeResult(payload));
  assert.equal(decoded.ok, true);
  assert.equal(decoded.payload.text, '改写稿');
  assert.equal(decoded.payload.ok, true);
  assert.equal(decodeResult('').error, 'empty-result-text');
  assert.equal(decodeResult('not json').error, 'result-not-json');
  assert.equal(decodeResult('[1,2]').error, 'result-not-an-object');
});

test('a failed result reports ok:false and keeps its reason code', () => {
  const payload = buildResult({ reason: 'timeout' });
  assert.equal(payload.ok, false);
  assert.equal(payload.reason, 'timeout');
  assert.equal(payload.text, '');
});

// ---------------------------------------------------------------------------
// the HTTP fallback guard (R10: the route has no Host-side auth)
// ---------------------------------------------------------------------------

const GOOD_HEADERS = {
  'sec-fetch-site': 'same-origin',
  origin: 'http://127.0.0.1:6727',
  [TOKEN_HEADER]: 'tok',
};

test('the guard accepts exactly a same-origin POST with the token', () => {
  const decision = guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: GOOD_HEADERS,
    token: 'tok',
    origin: 'http://127.0.0.1:6727',
  });
  assert.equal(decision.allowed, true);
  assert.equal(decision.status, 200);
});

test('the guard refuses a request with no token — the exact hole 06 §4 found', () => {
  const decision = guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: { 'sec-fetch-site': 'same-origin' },
    token: 'tok',
    origin: 'http://127.0.0.1:6727',
  });
  assert.equal(decision.allowed, false);
  assert.equal(decision.status, 403);
  assert.equal(decision.reason, 'token-mismatch');
});

test('the guard refuses a wrong method, a wrong path and a wrong origin', () => {
  assert.equal(guardRequest({ method: 'GET', path: ROUTE_PATH, expectedPath: ROUTE_PATH, headers: GOOD_HEADERS, token: 'tok' }).reason, 'method-not-allowed');
  assert.equal(guardRequest({ method: 'POST', path: '/other', expectedPath: ROUTE_PATH, headers: GOOD_HEADERS, token: 'tok' }).status, 404);
  assert.equal(
    guardRequest({
      method: 'POST',
      path: ROUTE_PATH,
      expectedPath: ROUTE_PATH,
      headers: { ...GOOD_HEADERS, origin: 'http://evil.example' },
      token: 'tok',
      origin: 'http://127.0.0.1:6727',
    }).reason,
    'origin-rejected',
  );
});

test('the guard refuses a cross-site browser request even with a stolen token', () => {
  const decision = guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: { ...GOOD_HEADERS, 'sec-fetch-site': 'cross-site' },
    token: 'tok',
    origin: 'http://127.0.0.1:6727',
  });
  assert.equal(decision.reason, 'fetch-site-rejected');
});

test('the guard fails closed when no token was ever armed', () => {
  const decision = guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: GOOD_HEADERS,
    token: null,
  });
  assert.equal(decision.allowed, false);
  assert.equal(decision.status, 503);
});

test('the guard refuses a request that carries neither fetch-metadata header (D-08)', () => {
  // `06` §4's attack shape is a local script speaking raw HTTP: it sends neither
  // `Sec-Fetch-Site` nor `Origin`. `lib/guard.js:21-22` says that is exactly what
  // this gate is for, so "absent" must not read as "same-origin" — the first slice
  // let it through and left the token as the only gate (`09-verification.md` D-08).
  const bareWithToken = guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: { [TOKEN_HEADER]: 'tok' },
    token: 'tok',
    origin: 'http://127.0.0.1:6727',
  });
  assert.equal(bareWithToken.allowed, false, 'a raw HTTP client must not reach the handler');
  assert.equal(bareWithToken.status, 403);
  assert.equal(bareWithToken.reason, 'fetch-metadata-missing');

  // Negative control: the same request **with** the browser's metadata and the token
  // passes, so the refusal above is the header rule and not a blanket 403.
  const browser = guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: GOOD_HEADERS,
    token: 'tok',
    origin: 'http://127.0.0.1:6727',
  });
  assert.equal(browser.allowed, true);

  // One header but no token is still refused by gate 3, and a wrong Origin by gate 2.
  assert.equal(guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: { 'sec-fetch-site': 'same-origin' },
    token: 'tok',
    origin: 'http://127.0.0.1:6727',
  }).reason, 'token-mismatch');
  assert.equal(guardRequest({
    method: 'POST',
    path: ROUTE_PATH,
    expectedPath: ROUTE_PATH,
    headers: { 'sec-fetch-site': 'same-origin', origin: 'http://127.0.0.1:9999', [TOKEN_HEADER]: 'tok' },
    token: 'tok',
    origin: 'http://127.0.0.1:6727',
  }).reason, 'origin-rejected');
});

test('refusals are silent: no reason leaks into a response body', () => {
  assert.equal(isSilentRefusal({ allowed: false, reason: 'token-mismatch' }), true);
  assert.equal(isSilentRefusal({ allowed: true, reason: 'ok' }), false);
});

test('readHeader works with a Headers-like object and with a plain map', () => {
  const headers = new Map([['x-lab-draft-token', 'abc']]);
  const headersLike = { get: (name) => headers.get(name) ?? null };
  assert.equal(readHeader(headersLike, TOKEN_HEADER), 'abc');
  assert.equal(readHeader({ 'X-Lab-Draft-Token': 'abc' }, TOKEN_HEADER), 'abc');
  assert.equal(readHeader(null, TOKEN_HEADER), null);
});

test('a generated token is non-empty and unique per call', () => {
  const a = generateToken();
  const b = generateToken();
  assert.equal(typeof a, 'string');
  assert.equal(a.length > 0, true);
  assert.notEqual(a, b);
  assert.equal(generateToken(null).length > 0, true, 'the fallback path still produces a token');
});

// ---------------------------------------------------------------------------
// Host: dump-request (B5, B8, B9, B10), settings resolution, timeout source
// ---------------------------------------------------------------------------

function settingsWith(patch) {
  return validatePatch(patch, defaultSettings()).value;
}

/**
 * A pinned-route settings object.
 *
 * Most `runRefine` cases need *a* route to exist before the interesting failure can
 * happen; with no session selection and no pinned model the composer already
 * returns `settings-unavailable`, which would mask the failure under test (B8's
 * "no route at all" path is exercised by its own case below).
 */
const PINNED = settingsWith({
  modelSource: 'pinned',
  pinnedModel: { provider: 'p', model: 'm' },
});

test('dump-request carries the system, its hash, and the marker for that preset (B5)', () => {
  const dump = dumpRequest({
    settings: defaultSettings(),
    presetId: 'coding',
    sessionSelection: { provider: 'p', model: 'm' },
  });
  assert.equal(dump.presetId, 'coding');
  assert.equal(dump.system.includes(STRUCTURE_BLOCKS.coding), true);
  assert.equal(sha256Hex(dump.system), dump.systemSha256);
  assert.equal(dump.marker, 'coding');
  assert.equal(dump.label, BUILTIN_LABELS.coding);
});

test('the four dump-request payloads hash pairwise differently (B5-b)', () => {
  const hashes = PRESET_IDS.map((presetId) => dumpRequest({
    settings: defaultSettings(),
    presetId,
    sessionSelection: { provider: 'p', model: 'm' },
  }).systemSha256);
  assert.equal(new Set(hashes).size, 4);
});

test('dump-request reports the composed route for follow and pinned (B8/B9)', () => {
  const follow = dumpRequest({
    settings: defaultSettings(),
    presetId: 'general',
    sessionSelection: { provider: 'sp', model: 'sm', reasoningEffort: 'high' },
  });
  assert.equal(follow.options.provider, 'sp');
  assert.equal(follow.options.model, 'sm');
  assert.equal(follow.options.reasoningEffort, 'high');
  assert.equal(follow.source, 'follow');

  const pinned = dumpRequest({
    settings: settingsWith({ modelSource: 'pinned', pinnedModel: { provider: 'pp', model: 'pm' } }),
    presetId: 'general',
    sessionSelection: { provider: 'sp', model: 'sm' },
  });
  assert.equal(pinned.options.provider, 'pp');
  assert.equal(pinned.options.model, 'pm');
  assert.equal(pinned.source, 'pinned');
});

test('the negative switches poison the field so the Host has to prove it arrived', () => {
  const negativeModel = dumpRequest({
    settings: defaultSettings(),
    presetId: 'general',
    sessionSelection: { provider: 'p', model: 'm' },
    negative: 'model',
  });
  assert.equal(negativeModel.options.model, '__lab_draft_nonexistent_model__');

  const negativeEffort = dumpRequest({
    settings: defaultSettings(),
    presetId: 'general',
    sessionSelection: { provider: 'p', model: 'm', reasoningEffort: 'low' },
    negative: 'effort',
  });
  assert.equal(negativeEffort.options.reasoningEffort, '__lab_draft_unknown_effort__');
});

test('dump-request reports effortFallback when the model rejects the effort (B10)', () => {
  const dump = dumpRequest({
    settings: defaultSettings(),
    presetId: 'general',
    sessionSelection: { provider: 'p', model: 'm' },
    forceEffort: 'ultra',
    model: { reasoning: { efforts: ['low', 'medium'], defaultEffort: 'medium' } },
  });
  assert.equal(dump.effortFallback, true);
  assert.equal(dump.options.reasoningEffort, 'medium');
  assert.equal(dump.effortUsed, 'medium');
});

test('an unknown preset in dump-request degrades to general and says so', () => {
  const dump = dumpRequest({ settings: defaultSettings(), presetId: 'klingon', sessionSelection: { provider: 'p', model: 'm' } });
  assert.equal(dump.presetId, 'general');
  assert.equal(dump.presetIdFallback, true);
});

test('readConfig tolerates plain and volatile fields, and unset sentinels', () => {
  const plain = readConfig({ enabled: false, timeoutMs: 30000, temperature: 0, maxTokens: 0 });
  assert.equal(plain.enabled, false);
  assert.equal(plain.timeoutMs, 30000);
  assert.equal(plain.temperature, 0, '0 is a real temperature, not "unset"');
  assert.equal(plain.maxTokens, null, '0 means "not set" for maxTokens');

  const volatile = readConfig({
    enabled: { get: () => false },
    timeoutMs: { get: () => 60000 },
    temperature: { get: () => -1 },
  });
  assert.equal(volatile.enabled, false);
  assert.equal(volatile.timeoutMs, 60000);
  assert.equal(volatile.temperature, null, '-1 is the "unset" sentinel');

  assert.deepEqual(readConfig(null), defaultSettings());
  assert.equal(unwrapField({ get() { throw new Error('boom'); } }), undefined);
});

test('resolveSettings clamps a hand-edited config instead of refusing to load', () => {
  const resolved = resolveSettings({ contextMaxRounds: 999, contextMaxChars: 1, visiblePresets: ['coding'] });
  assert.equal(resolved.contextMaxRounds, 20, 'clamped to the documented range');
  assert.equal(resolved.contextMaxChars, 200);
  assert.deepEqual(resolved.visiblePresets, ['coding']);
});

test('a hand-edited config keeps the fields that are fine (clamping is per field, not all-or-nothing)', () => {
  const resolved = resolveSettings({ contextMaxRounds: 999, enabled: false, readContext: false });
  assert.equal(resolved.contextMaxRounds, 20);
  assert.equal(resolved.enabled, false, 'a good field next to a bad one still applies');
  assert.equal(resolved.readContext, false);
});

test('a settings overlay is applied after the config and before validation', () => {
  const resolved = resolveSettings({ enabled: true }, { enabled: false, presets: { coding: { prompt: '覆盖' } } });
  assert.equal(resolved.enabled, false);
  assert.equal(resolved.presets.coding.prompt, '覆盖');
});

test('the self-test env channel is off unless explicitly enabled (B17)', () => {
  assert.deepEqual(readSelftestEnv({}), { selftest: false, timeoutMs: null });
  assert.deepEqual(readSelftestEnv({ DSH_DRAFT_STUDIO_SELFTEST: '1', DSH_DRAFT_STUDIO_TIMEOUT_MS: '1000' }), {
    selftest: true,
    timeoutMs: 1000,
  });
  assert.deepEqual(readSelftestEnv({ LAB_DRAFT_STUDIO_SELFTEST: '1', LAB_DRAFT_STUDIO_TIMEOUT_MS: '1500' }), {
    selftest: true,
    timeoutMs: 1500,
  });
  assert.equal(readSelftestEnv({ DSH_DRAFT_STUDIO_TIMEOUT_MS: '1000' }).selftest, false, 'no timeout without the enable flag');
});

test('the effective timeout reports its source so dump-settings can prove it (B17)', () => {
  assert.deepEqual(effectiveTimeout(defaultSettings(), { selftest: false, timeoutMs: null }), {
    ms: DEFAULT_TIMEOUT_MS,
    source: 'settings',
  });
  assert.deepEqual(effectiveTimeout(defaultSettings(), { selftest: true, timeoutMs: 1000 }), {
    ms: 1000,
    source: 'selftest',
  });
  assert.equal(DEFAULT_TIMEOUT_MS, 480000);
});

// ---------------------------------------------------------------------------
// Host: dispatch (each action reaches a typed payload)
// ---------------------------------------------------------------------------

function fakeDeps(overrides = {}) {
  return {
    llm: null,
    sessionQuery: null,
    now: () => 0,
    setTimeout: (fn, ms) => setTimeout(fn, ms),
    clearTimeout: (handle) => clearTimeout(handle),
    ...overrides,
  };
}

function hostState(settings, deps) {
  return {
    entryId: 'lab-draft-studio',
    deps,
    overlay: () => null,
    setOverlay: () => {},
    settings: () => settings,
  };
}

test('dispatch(dump-settings) reports the settings, the visible seats and the timeout source', async () => {
  const result = await dispatch({ action: 'dump-settings' }, hostState(defaultSettings(), fakeDeps()));
  assert.equal(result.ok, true);
  assert.deepEqual(result.visible, ['general', 'coding', 'writing', 'translate']);
  assert.equal(result.timeoutSource, 'settings');
  assert.equal(result.entryId, 'lab-draft-studio', 'the entry id proves the lab prefix survived (U7)');
  assert.equal(result.labels.coding, BUILTIN_LABELS.coding);
});

test('dispatch(refine) with an empty draft fails with empty-result and does not call the model', async () => {
  let called = false;
  const deps = fakeDeps({ llm: { prepareCall: async () => { called = true; } } });
  const result = await dispatch({ action: 'refine', draft: '   ' }, hostState(defaultSettings(), deps));
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'empty-result');
  assert.equal(called, false);
});

test('dispatch(dump-draft) reports messageCount null for a malformed surface snapshot (D-03)', async () => {
  const deps = fakeDeps({ sessionQuery: { readSurface: async () => ({}) } });
  const result = await dispatch(
    { action: 'dump-draft', draft: 'x', sessionId: 's1' },
    hostState(defaultSettings(), deps),
  );
  assert.equal(result.messageCount, null, 'a snapshot without an events array is "unreadable", not "0 messages"');
});

test('dispatch(dump-draft) counts placeholders and reads messageCount from the surface (B3/B21)', async () => {
  const deps = fakeDeps({
    sessionQuery: { readSurface: async () => ({ events: [{ role: 'user' }, { role: 'assistant' }] }) },
  });
  const result = await dispatch(
    { action: 'dump-draft', draft: '看 \uE100 和 \uE101', sessionId: 's1' },
    hostState(defaultSettings(), deps),
  );
  assert.equal(result.references, 2);
  assert.equal(result.messageCount, 2);
});

test('dump-draft reports messageCount null when the surface cannot be read (B3 → 无法判定)', async () => {
  const throwing = fakeDeps({ sessionQuery: { readSurface: async () => { throw new Error('nope'); } } });
  const result = await dispatch({ action: 'dump-draft', draft: 'x', sessionId: 's1' }, hostState(defaultSettings(), throwing));
  assert.equal(result.messageCount, null, 'null is what makes B3 record 无法判定 rather than pass');
});

test('dispatch(save-settings) refuses honestly when no write path is wired', async () => {
  const result = await dispatch(
    { action: 'save-settings', patch: { enabled: false } },
    hostState(defaultSettings(), fakeDeps()),
  );
  assert.equal(result.ok, false);
  assert.equal(result.errors[0].error, 'persist-unavailable', 'a write that cannot happen must not report success');
});

test('dispatch(save-settings) refuses an invalid patch before it reaches the write path', async () => {
  const result = await dispatch(
    { action: 'save-settings', patch: { timeoutMs: 5 } },
    hostState(defaultSettings(), fakeDeps()),
  );
  assert.equal(result.ok, false);
  assert.equal(result.errors[0].error, 'below-min');
});

test('dispatch(save-settings) does not overwrite config fields the patch did not name (D-02)', async () => {
  // The pre-fix path accumulated the overlay with `mergeSettings(state.overlay(), patch)`.
  // With a `null` overlay, `cloneSettings(null)` produced a full default settings
  // object, which then overrode the config: saving only `timeoutMs` wiped
  // `temperature` (0.3 → null).
  const config = { temperature: 0.3, timeoutMs: 90000 };
  let overlay = null;
  const state = {
    entryId: 'lab-draft-studio',
    deps: fakeDeps({ persist: async () => true }),
    overlay: () => overlay,
    setOverlay: (next) => { overlay = next; },
    settings: () => resolveSettings(config, overlay),
  };
  const before = state.settings();
  assert.equal(before.temperature, 0.3, 'the config starts with a temperature');
  const result = await dispatch({ action: 'save-settings', patch: { timeoutMs: 60000 } }, state);
  assert.equal(result.ok, true);
  const after = state.settings();
  assert.equal(after.timeoutMs, 60000, 'the saved field takes effect');
  assert.equal(after.temperature, 0.3, 'D-02: an unnamed config field must survive the save');
  assert.deepEqual(overlay, { timeoutMs: 60000 }, 'the overlay stays sparse — no default-filled copy');
});

test('dispatch(save-settings) applies the patch after a successful persist and keeps it for the next read', async () => {
  let stored = null;
  const state = {
    entryId: 'lab-draft-studio',
    deps: fakeDeps({ persist: async (patch) => { stored = patch; return true; } }),
    overlay: () => null,
    setOverlay: (next) => { state._overlay = next; },
    settings: () => resolveSettings(null, state._overlay ?? null),
  };
  const result = await dispatch({ action: 'save-settings', patch: { enabled: false } }, state);
  assert.equal(result.ok, true);
  assert.deepEqual(stored, { enabled: false });
  assert.equal(state.settings().enabled, false, 'the next read sees the saved value (B18 改完即时生效)');
});

test('dispatch(unknown action) is a typed failure', async () => {
  const result = await dispatch({ action: 'nope' }, hostState(defaultSettings(), fakeDeps()));
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'unknown-action');
});

// ---------------------------------------------------------------------------
// Host: runRefine failure paths (B12, B15, B17, B20)
// ---------------------------------------------------------------------------

/** Build a fake `llm` whose stream yields whatever the test wants. */
function fakeLlm(chunks, calls = []) {
  return {
    resolveModelInfo: async () => ({ reasoning: { efforts: ['low'], defaultEffort: 'low' } }),
    prepareCall: async (config, signal, configure) => {
      const controls = typeof configure === 'function'
        ? configure({ temperature: config.temperature }, { reasoning: { efforts: ['low'], defaultEffort: 'low' } })
        : {};
      const preparedConfig = { ...config, ...controls };
      calls.push({ config: preparedConfig, signal });
      return {
        config: preparedConfig,
        stream: async function* stream() {
          for (const chunk of chunks) {
            if (signal?.aborted) {
              yield { type: 'finish', reason: { kind: 'aborted', failure: { message: 'aborted', code: 'aborted' } } };
              return;
            }
            yield chunk;
          }
        },
      };
    },
  };
}

test('runRefine returns the text and metadata when the model answers', async () => {
  const deps = fakeDeps({ llm: fakeLlm([{ type: 'text-delta', text: '改写' }, { type: 'text-delta', text: '稿' }, { type: 'finish', reason: { kind: 'stop' } }]) });
  const result = await runRefine({
    settings: PINNED,
    presetId: 'coding',
    draft: '帮我写个登录',
    sessionId: null,
    deps,
  });
  assert.equal(result.ok, true);
  assert.equal(result.text, '改写稿');
  assert.equal(result.systemSha256, sha256Hex(result.system));
  assert.equal(result.readout.reason, 'no-session', 'no session means nothing to read, reported honestly');
  assert.equal(result.timeoutSource, 'settings');
});

test('runRefine classifies an empty model answer as empty-result (A12)', async () => {
  const deps = fakeDeps({ llm: fakeLlm([{ type: 'text-delta', text: '   ' }, { type: 'finish', reason: { kind: 'stop' } }]) });
  const result = await runRefine({ settings: PINNED, presetId: 'general', draft: 'x', sessionId: null, deps });
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'empty-result');
});

test('runRefine classifies a provider error chunk as provider-error (B15)', async () => {
  const deps = fakeDeps({
    llm: fakeLlm([{ type: 'finish', reason: { kind: 'error', failure: { message: 'boom', code: 'E_PROVIDER' } } }]),
  });
  const result = await runRefine({ settings: PINNED, presetId: 'general', draft: 'x', sessionId: null, deps });
  assert.equal(result.reason, 'provider-error');
});

test('runRefine times out on its own clock and reports the timeout source (B17)', async () => {
  const deps = fakeDeps({
    llm: {
      prepareCall: async (config) => ({
        config,
        stream: async function* stream() {
          await new Promise((resolve) => setTimeout(resolve, 50));
          yield { type: 'finish', reason: { kind: 'stop' } };
        },
      }),
    },
    selftest: { selftest: true, timeoutMs: 5 },
  });
  const result = await runRefine({ settings: PINNED, presetId: 'general', draft: 'x', sessionId: null, deps });
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'timeout');
  assert.equal(result.timeoutSource, 'selftest', 'B17 requires the source to be provable');
});

test('runRefine reports settings-unavailable when no route can be composed (B20)', async () => {
  const deps = fakeDeps({ llm: fakeLlm([]) });
  const result = await runRefine({ settings: defaultSettings(), presetId: 'general', draft: 'x', sessionId: null, deps });
  assert.equal(result.reason, 'settings-unavailable', 'no session selection and no pinned route');
});

test('runRefine honours the caller abort signal as aborted, not as a timeout (B12)', async () => {
  const controller = new AbortController();
  const deps = fakeDeps({
    llm: {
      prepareCall: async (config) => ({
        config,
        stream: async function* stream() {
          controller.abort();
          yield { type: 'finish', reason: { kind: 'aborted', failure: { message: 'aborted', code: 'aborted' } } };
        },
      }),
    },
  });
  const result = await runRefine({
    settings: settingsWith({ modelSource: 'pinned', pinnedModel: { provider: 'p', model: 'm' } }),
    presetId: 'general',
    draft: 'x',
    sessionId: null,
    deps,
    signal: controller.signal,
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'aborted');
});

test('runRefine includes the assembled context in the user turn', async () => {
  const captured = [];
  const deps = fakeDeps({
    llm: {
      prepareCall: async (config) => ({
        config,
        stream: async function* stream() {
          yield { type: 'finish', reason: { kind: 'stop' } };
        },
      }),
    },
    sessionQuery: { readSurface: async () => ({ events: [{ role: 'user', content: '历史一句' }] }) },
  });
  const original = deps.llm.prepareCall;
  deps.llm.prepareCall = async (config) => {
    const prepared = await original(config);
    return {
      ...prepared,
      stream(options) {
        captured.push(options);
        return prepared.stream(options);
      },
    };
  };
  await runRefine({
    settings: settingsWith({ modelSource: 'pinned', pinnedModel: { provider: 'p', model: 'm' } }),
    presetId: 'general',
    draft: '草稿',
    sessionId: 's1',
    deps,
  });
  const text = captured[0].messages[0].content[0].text;
  assert.match(text, /【会话上下文】/);
  assert.match(text, /历史一句/);
  assert.match(text, /【待改写草稿】\n草稿/);
});

test('runRefine without context sends just the draft', async () => {
  const captured = [];
  const llm = fakeLlm([{ type: 'finish', reason: { kind: 'stop' } }, { type: 'text-delta', text: 'ok' }]);
  const original = llm.prepareCall;
  const deps = fakeDeps({
    llm: {
      ...llm,
      prepareCall: async (config, signal, configure) => {
        const prepared = await original(config, signal, configure);
        return {
          ...prepared,
          stream(options) {
            captured.push(options);
            return prepared.stream(options);
          },
        };
      },
    },
    sessionQuery: { readSurface: async () => ({ events: [] }) },
  });
  await runRefine({
    settings: settingsWith({ modelSource: 'pinned', pinnedModel: { provider: 'p', model: 'm' } }),
    presetId: 'general',
    draft: '只有草稿',
    sessionId: 's1',
    deps,
  });
  assert.equal(captured[0].messages[0].content[0].text, '只有草稿');
});

// ---------------------------------------------------------------------------
// schema declaration
// ---------------------------------------------------------------------------

test('createConfigSchema marks every editable field volatile', () => {
  const volatileCalls = [];
  const chain = (name) => ({
    default: () => chain(name),
    volatile: () => {
      volatileCalls.push(name);
      return chain(name);
    },
    required: () => chain(name),
  });
  const fakeZ = {
    object: (shape) => ({ shape }),
    boolean: () => chain('boolean'),
    number: () => chain('number'),
    string: () => chain('string'),
    array: (inner) => ({ inner, default: () => chain('array'), volatile: () => { volatileCalls.push('array'); return chain('array'); } }),
    dict: (inner) => ({ inner, default: () => chain('dict'), volatile: () => { volatileCalls.push('dict'); return chain('dict'); } }),
    union: (members) => ({ members, default: () => chain('union'), volatile: () => { volatileCalls.push('union'); return chain('union'); } }),
    const: (value) => ({ const: value }),
  };
  const schema = createConfigSchema(fakeZ);
  assert.equal(Object.keys(schema.shape).length, 14);
  assert.equal(volatileCalls.filter((name) => name === 'boolean').length, 2, 'enabled + readContext');
  assert.equal(volatileCalls.filter((name) => name === 'number').length, 5, 'rounds, chars, timeout, temperature, maxTokens');
  assert.equal(volatileCalls.includes('dict'), true, 'the preset dicts are volatile too');
});

test('createConfigSchema refuses a z that lacks the builders it needs', () => {
  assert.throws(() => createConfigSchema({}), /needs z\.object/);
});

// ---------------------------------------------------------------------------
// D-06: the session model triple comes from the real `observeSession` contract
// ---------------------------------------------------------------------------

/** A `sessionQuery` whose only useful method is `observeSession`, as the Host has it. */
function fakeSessionQuery(projectionValues, seen = []) {
  return {
    /** The method `09-verification.md` D-06 proved exists (15-method table). */
    async observeSession(sessionId, options) {
      seen.push({ sessionId, options });
      return {
        projections: projectionValues === undefined
          ? undefined
          : { asOfSeq: 1, values: projectionValues },
        dispose: async () => {},
      };
    },
    /** The method the first slice invented; present so its absence is proven. */
    modelSelection: undefined,
    async readSurface() {
      return { events: [] };
    },
  };
}

test('follow mode reads the session triple through observeSession().projections (D-06)', async () => {
  const seen = [];
  const deps = fakeDeps({
    llm: { prepareCall: async () => ({ config: { provider: 'sp', model: 'sm', reasoningEffort: 'high' }, stream: () => (async function* () {})() }) },
    sessionQuery: fakeSessionQuery({ modelSelection: { lastUsed: null, next: { provider: 'sp', model: 'sm', reasoningEffort: 'high' } } }, seen),
  });
  const dump = await dispatch(
    { action: 'dump-request', presetId: 'coding', sessionId: 's1' },
    hostState(defaultSettings(), deps),
  );
  assert.equal(dump.ok, true);
  assert.equal(dump.options.provider, 'sp', 'D-06: the projection is what supplies the route');
  assert.equal(dump.options.model, 'sm');
  assert.equal(dump.options.reasoningEffort, 'high');
  assert.equal(dump.source, 'follow');
  assert.equal(seen.length, 1, 'the read goes through observeSession');
  assert.equal(seen[0].sessionId, 's1');
  assert.equal(seen[0].options.projectionMode, 'all', 'the projection must be requested explicitly');
});

test('the old invented method name is gone from the host half (D-06)', () => {
  // Comments are allowed to name the defect they record; code is not. Strip block
  // and line comments before asserting, so the check is about what runs.
  const code = HOST_SOURCE
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/^\s*\/\/.*$/gm, '');
  assert.doesNotMatch(
    code,
    /sessionQuery\.modelSelection/,
    'D-06: `sessionQuery.modelSelection` is not on the Host contract',
  );
  assert.match(code, /observeSession\(/, 'the real read is observeSession');
});

test('a projection with lastUsed but no next still yields a route (D-06)', async () => {
  const deps = fakeDeps({
    llm: null,
    sessionQuery: fakeSessionQuery({ modelSelection: { lastUsed: { provider: 'lp', model: 'lm' }, next: null } }),
  });
  const dump = await dispatch(
    { action: 'dump-request', presetId: 'general', sessionId: 's1' },
    hostState(defaultSettings(), deps),
  );
  assert.equal(dump.options.provider, 'lp', 'the Host composer itself prefers `next ?? lastUsed`');
  assert.equal(dump.options.model, 'lm');
});

test('a cold session makes dump-request answer with a reason instead of throwing (D-06)', async () => {
  const deps = fakeDeps({ llm: null, sessionQuery: fakeSessionQuery(undefined) });
  const dump = await dispatch(
    { action: 'dump-request', presetId: 'general', sessionId: 'cool' },
    hostState(defaultSettings(), deps),
  );
  assert.equal(dump.ok, false, 'B8 must be recorded as 无法判定, which needs an answer');
  assert.equal(dump.reason, 'settings-unavailable');
  assert.match(dump.detail, /session model selection is unreadable/, 'D-07: the text survives');
  assert.equal(dump.options.provider, null);
});

// ---------------------------------------------------------------------------
// D-07: the Host's failure text is carried in `detail`, not swallowed
// ---------------------------------------------------------------------------

test('a Host rejection keeps its text in `detail` (B8/B9 negative control, D-07)', async () => {
  const deps = fakeDeps({
    llm: {
      prepareCall: async () => {
        throw new Error("Model '__lab_draft_nonexistent_model__' is not routable");
      },
    },
    sessionQuery: fakeSessionQuery({ modelSelection: { next: { provider: 'p', model: 'm' } } }),
  });
  const dump = await dispatch(
    { action: 'dump-request', presetId: 'coding', sessionId: 's1', prepare: true, negative: 'model' },
    hostState(defaultSettings(), deps),
  );
  assert.equal(dump.ok, false);
  assert.equal(dump.reason, 'provider-error');
  assert.match(dump.detail, /__lab_draft_nonexistent_model__/, 'B8: the error text must contain the poisoned model');
  assert.equal(dump.prepared, null, 'a rejected call has no prepared config');
});

test('`dump-request --prepare` fills prepared.config from the Host (B8/B9, D-07)', async () => {
  const deps = fakeDeps({
    llm: {
      prepareCall: async (config, signal, configure) => {
        const controls = typeof configure === 'function' ? configure({}, { reasoning: { efforts: ['low'], defaultEffort: 'low' } }) : {};
        return { config: { ...config, ...controls } };
      },
    },
    sessionQuery: fakeSessionQuery({ modelSelection: { next: { provider: 'sp', model: 'sm', reasoningEffort: 'low' } } }),
  });
  const dump = await dispatch(
    { action: 'dump-request', presetId: 'coding', sessionId: 's1', prepare: true },
    hostState(defaultSettings(), deps),
  );
  assert.equal(dump.ok, true);
  assert.equal(dump.prepared.provider, 'sp', 'B8: prepared.config is the Host materialization');
  assert.equal(dump.prepared.model, 'sm');
  assert.equal(dump.prepared.reasoningEffort, 'low');
  assert.deepEqual(dump.options.provider, dump.prepared.provider, 'B8: both observation points agree');
});

test('without --prepare nothing is materialized, and `prepared` stays null honestly (B8)', async () => {
  const deps = fakeDeps({ llm: null, sessionQuery: fakeSessionQuery({ modelSelection: { next: { provider: 'p', model: 'm' } } }) });
  const dump = await dispatch(
    { action: 'dump-request', presetId: 'coding', sessionId: 's1' },
    hostState(defaultSettings(), deps),
  );
  assert.equal(dump.prepared, null);
  assert.equal(dump.detail, null);
});

test('runRefine keeps the thrown text so a timeout-vs-error mix-up stays diagnosable (D-07)', async () => {
  const deps = fakeDeps({
    llm: { prepareCall: async () => { throw new Error('adapter refused: effort ultra'); } },
    sessionQuery: { readSurface: async () => ({ events: [] }) },
  });
  const result = await runRefine({
    settings: settingsWith({ modelSource: 'pinned', pinnedModel: { provider: 'p', model: 'm' } }),
    presetId: 'coding',
    draft: '你好',
    sessionId: 's1',
    deps,
  });
  assert.equal(result.reason, 'provider-error');
  assert.match(result.detail, /effort ultra/, 'the Host words are the evidence');
});

test('buildResult puts detail in the payload only for a failure (D-07)', () => {
  assert.equal(buildResult({ text: 'x' }).detail, null);
  assert.equal(buildResult({ text: 'x', reason: 'timeout' }).detail, null, 'no invented detail');
  assert.equal(buildResult({ reason: 'provider-error', detail: 'boom' }).detail, 'boom');
});

// ---------------------------------------------------------------------------
// D-05: the settings namespace is the bare patchId
// ---------------------------------------------------------------------------

test('readEntryId returns the bare patchId, the settings namespace (D-05)', () => {
  assert.equal(ENTRY_ID_PREFIX, 'include:', 'the directory prefix exists only to be stripped');
  assert.equal(readEntryId({ fiber: { entry: { options: { id: 'lab-draft-studio' } } } }), 'lab-draft-studio');
  assert.equal(readEntryId(undefined), undefined);
  assert.equal(
    readEntryId({ fiber: { entry: { options: { id: 'include:lab-draft-studio' } } } }),
    'lab-draft-studio',
    'a Loader that reports the directory form is normalized back to the namespace',
  );
  assert.equal(normalizeEntryId('include:ui-settings'), 'ui-settings');
});

test('createHost publishes the bare patchId and keeps it distinct from the installed product (D-05)', () => {
  const host = createHost({
    ctx: { fiber: { entry: { options: { id: 'lab-draft-studio' } } } },
    config: null,
    deps: fakeDeps(),
  });
  assert.equal(host.entryId, 'lab-draft-studio');
  assert.notEqual(host.entryId, 'dsh-draft-studio');
});

test('the published index-injection row carries the settings namespace (D-05)', () => {
  const injections = [];
  const host = createHost({
    ctx: {
      fiber: { entry: { options: { id: 'lab-draft-studio' } } },
      on: (name, listener) => {
        if (name === 'webserver/index-inject') injections.push(listener);
      },
    },
    config: null,
    deps: fakeDeps(),
  });
  const table = [];
  for (const listener of injections) listener(table);
  assert.equal(table.length, 1);
  assert.equal(table[0].kind, 'global');
  assert.equal(table[0].name, '__DSH_LAB_DRAFT_STUDIO__');
  assert.equal(table[0].value.entryId, 'lab-draft-studio', 'the browser copies this straight into configForms.get');
  void host;
});

// ---------------------------------------------------------------------------
// B20: the degraded request names no preset and carries no structure block
// ---------------------------------------------------------------------------

test('a null presetId yields presetId null and no structure block (B20③)', () => {
  const dump = dumpRequest({
    settings: defaultSettings(),
    presetId: null,
    sessionSelection: { provider: 'p', model: 'm' },
  });
  assert.equal(dump.presetId, null, 'B20③: no preset id in the request');
  assert.equal(dump.marker, null, 'B20③: no `preset=` marker');
  assert.doesNotMatch(dump.system, /【结构要求 preset=/, 'B20③: the system carries no structure block');
  assert.match(dump.system, /只输出改写后的提示词本身/, 'the standing rules still apply');
});

test('a null preset runs the degraded request end to end (B20③)', async () => {
  const deps = fakeDeps({
    llm: fakeLlm([{ type: 'text-delta', text: '改写' }, { type: 'finish', reason: { kind: 'stop' } }]),
    sessionQuery: { readSurface: async () => ({ events: [] }) },
  });
  const result = await runRefine({
    settings: settingsWith({ modelSource: 'pinned', pinnedModel: { provider: 'p', model: 'm' } }),
    presetId: null,
    draft: '你好',
    sessionId: 's1',
    deps,
  });
  assert.equal(result.ok, true);
  assert.equal(result.presetId, null, 'B20③');
  assert.doesNotMatch(result.system, /【结构要求 preset=/, 'B20③: no block in the system that was actually sent');
});

test('an unknown (non-null) preset still falls back to general with its block (B15)', () => {
  const dump = dumpRequest({
    settings: defaultSettings(),
    presetId: 'klingon',
    sessionSelection: { provider: 'p', model: 'm' },
  });
  assert.equal(dump.presetId, 'general');
  assert.equal(dump.presetIdFallback, true);
  assert.equal(dump.marker, 'general', 'a stale client keeps a working button');
});

// ---------------------------------------------------------------------------
// D-09: scripts/assert-preset.mjs is the B5 output-side judge
// ---------------------------------------------------------------------------

test('assert-preset judges the four presets it was written for (B5 判据 2, D-09)', () => {
  const passing = {
    general: '- 要点一\n- 要点二\n- 要点三',
    coding: '1. 第一步\n2. 第二步\n3. 第三步',
    writing: '第一段。\n\n第二段。',
    translate: 'This is the English rewrite.',
  };
  const verdict = judgeDocument(passing);
  assert.equal(verdict.pass, true, JSON.stringify(verdict, null, 2));
  assert.equal(verdict.missing.length, 0);
});

test('assert-preset catches the three constructible reds `01` §3-B5 names (D-09)', () => {
  // 负例 3: coding output with paragraphs but no numbered steps.
  const noSteps = judgeDocument({
    general: '- a\n- b\n- c',
    coding: '先做这个。\n\n再做那个。',
    writing: '第一段。\n\n第二段。',
    translate: 'An English rewrite.',
  });
  assert.equal(noSteps.pass, false);
  assert.equal(noSteps.presets.find((entry) => entry.presetId === 'coding').pass, false);

  // A crossed block: coding output that looks like general's.
  const crossed = judgeDocument({
    general: '- a\n- b\n- c',
    coding: '- a\n- b\n- c',
    writing: '第一段。\n\n第二段。',
    translate: 'An English rewrite.',
  });
  assert.equal(crossed.pass, false);
  assert.match(crossed.presets.find((entry) => entry.presetId === 'coding').attempts[0].detail, /编号步骤行 0/);
});

test('assert-preset counts a second attempt as a pass, as 判据 3 requires (D-09)', () => {
  const verdict = judgeDocument({
    general: ['- a\n- b\n- c', '- x\n- y\n- z'],
    coding: { outputs: ['先做这个。', '1. 一\n2. 二\n3. 三'] },
    writing: '第一段。\n\n第二段。',
    translate: 'An English rewrite.',
  });
  assert.equal(verdict.pass, true);
  assert.equal(verdict.presets.find((entry) => entry.presetId === 'coding').attempts[0].pass, false);
  assert.equal(verdict.presets.find((entry) => entry.presetId === 'coding').attempts[1].pass, true);
});

test('assert-preset reports a missing preset instead of passing it silently (D-09)', () => {
  const verdict = judgeDocument({ general: '- a\n- b\n- c' });
  assert.equal(verdict.pass, false);
  assert.deepEqual(verdict.missing, ['coding', 'writing', 'translate'], 'a preset with no output is a failure, not a skip');
});

test('assert-preset measures paragraphs and CJK ratio the way the table words them (D-09)', () => {
  assert.equal(countParagraphs('一\n\n二\n\n三'), 3);
  assert.equal(countParagraphs('   '), 0);
  // `^\s*\d+[.、)]\s` is the requirement's own regex: it needs the space after the
  // marker, so `3、c` is not a step line while `3、 c` is.
  assert.equal(countNumberedSteps('1. a\n2) b\n3、 c\n- d'), 3);
  assert.equal(countNumberedSteps('3、c'), 0);
  // `^-\s` is anchored at the start of the line in the requirement's own regex, so
  // an indented ` - b` is not a bullet line.
  assert.equal(countBullets('- a\n - b\n- c\n*c'), 2, 'only a line-leading `- ` counts');
  assert.equal(countBullets('*a\n+b'), 0);
  assert.equal(hasFence('```js\nx\n```'), true);
  assert.ok(cjkRatio('纯中文') === 1);
  assert.ok(cjkRatio('English only') === 0);
  assert.ok(cjkRatio('中文 and English') < 0.5);
  assert.equal(Object.keys(PRESET_PREDICATES).length, 4);
});
