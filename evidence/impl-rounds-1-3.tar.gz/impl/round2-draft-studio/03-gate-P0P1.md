# 03 阶段门审查 — P0 / P1（dsh-draft-studio）

> 审查员独立判定。只读产物，不写代码，不替开发者补产物；未安装任何插件，未读写 `$DSH_HOME`，未改 `01-requirements.md` / `02-plan.md` / `probes.md`。
> 依据：`process-lab/spec/process-v1.md` 的 P0/P1 出口判据；`requirements/REQ-02-dsh-draft-studio.md`；`00-client-answers.md`；开发者产物 `01-requirements.md`、`02-plan.md`、`probes.md`。
> 时间：2026-11-08（Asia/Shanghai）。

## 0. 结论摘要

| 项 | 判定 | 一句话 |
|---|---|---|
| **P0 需求** | **不通过** | 三条出口判据中两条未满足：B5 是"靠人看"的验收；A1 被误标为「客户裁定」且其技术前提按任务转述不成立。 |
| **P1 计划** | **不通过** | 依赖矩阵与最大风险应对本体合格；但 U2/U3/U5/U6/U7 的补探时刻落在 P2 内，与"P2 开工前必须清零"及规格 P2 入口冲突；D1 漏掉 list 座位的硬注册契约（`id`）；S5 的完成证据与 01 §4 自相矛盾。 |
| **C1 断言核查** | **不成立（按任务转述的强命题）** | `conversation.input.right` 是 list 座位，位于发送键左侧且正好在模型选择器之前，可放 1–4 颗；开发者 C1 原文的窄命题（"发送键与模型选择器之间只有活动区"）成立，但把 list 座位说成"容差妥协"、把 A1 标成客户裁定是错的。 |
| **放行意见** | **不能进入 P2** | P0 打回重写；P1 修正补探时序与 list 注册契约后重门。 |

---

## 1. P0 判定：不通过

### 1.1 判据一：每条验收能判真假

逐条核对 `01-requirements.md` §3（B1–B21）：

| 条目 | 能判真假？ | 理由 / 问题 |
|---|---|---|
| B1 按钮出现与消失 | **否（有条件）** | "N = 勾选数，且 1 ≤ N ≤ 4"没有排除总开关关闭。§5 #1 明说"关 = 一颗按钮都不出现"，此时 0 颗是正确行为，却直接违反 B1 的 `1 ≤ N`。验收在自己的配置契约下会误判。另"遮住编辑区"缺可操作定义（几何相交？遮挡比例？）。 |
| B2 空白草稿不反应 | 是 | `trim()` 后为空，观察有/无按钮，可判。 |
| B3 写回不发送 | 是 | 消息列表条数前后对比 + URL/视图不变，可判；负例明确。 |
| B4 回退还原 | 是 | 文本完全相等；Ctrl+Z 已降为附加观察，处理得当。 |
| **B5 四套预设各自生效** | **否（硬伤）** | 通过条件写成"四条结果两两不完全相同，且**人工按预设意图判读'方向对'**"。"方向对"没有可复跑判据，第二个人无法用命令复现同一结论；"两两不完全相同"还受模型随机性影响，可能假红。这是把"靠人看"写成了"可判定"。 |
| B6 隐藏与恢复 | 是 | 勾选/取消 + 预设内容仍在，可判。 |
| B7 改名只改显示 | 是 | 显示名、请求模板、≤12 码位，可判。 |
| B8 跟随模式 | **是，但证据源不成立** | 判据本身可判；但 §4 说用 `command/run` / `command/done` 及其参数证明"模型、强度"——宿主契约里 `CommandInvocation` 只有 `rawInput` / `agent` / `attachments` / `signal`，`command/run` 是 handler 前的 log-only 追加，**不保证记录 llm 的 provider/model/reasoningEffort**。见 M-4。 |
| B9 固定模式 | 同上 | 同上。 |
| B10 强度不支持时退回 | 是（构造条件偏弱） | 判据可判；"选一个不支持 S3 的模型"在模型目录里未必存在，需给出确定性构造（如无效 effort 或指定目录项），否则现场可能无法执行。 |
| B11 一颗在跑其余置灰 | 是 | 置灰 + 点击无反应 + 秒表递增 + 取消入口，可判。 |
| B12 运行中可取消 | 是 | 回空闲、原稿不变、无改写稿、无"可回退"，可判。 |
| B13 不覆盖新输入 | 是 | 三条同时满足，负例明确；这是第二红线，写得好。 |
| B14 并发宽容 | 是 | 请求次数可用 `command/run` 条数证明；发送后自停 + 晚到不写回，可判。 |
| B15 失败态 | **偏软** | "悬停显示**可读原因**（含失败类别的中文说明，不只是一串英文栈）"——"可读"靠人；"含中文类别、不含英文栈"可操作化，但需把"可读"删掉或给出固定字段。 |
| B16 回退/重试只作用于自己那次 | 是（措辞需收紧） | "此时对'编程'的操作"未说明操作对象（已无回退控件）；应写成"编程按钮不再提供回退入口/点击无效"，否则现场会问"点哪里"。 |
| B17 超时 | **否（自相矛盾）** | 操作写"把超时配置调到极小（如 1 秒）"，但 §5 #17 的取值是 **30–600 秒**。按设置页正常路径做不到 1 秒，这条验收无法按其字面执行。 |
| B18 设置页与即时生效 | **否（自相矛盾）** | "20 项逐项可改"与 §5 #20"上次改写回显｜**只读展示**"直接冲突：第 20 项按定义不可改。只能改成"19 项可改 + 第 20 项只读展示"。另负例同样用"改超时为 1s"，撞 #17 下限。 |
| B19 预设编辑门 | **偏软** | "未保存 N 项"没有定义 N 的计数单位（字段数？套数？跨套合计？），现场两个人可能数出不同结果。 |
| B20 设置不可用降级 | 是 | 一颗按钮、可改写、不带预设 id、无红色报错，可判。 |
| B21 芯片边界 | 是（定义可再收紧） | "无半损坏芯片（既不是芯片也不是原文）"给出了操作化方向；建议补一句判定动作（如引用节点仍可点、`references` 长度/偏移不变）。 |

**判据一结论：不通过。** 一条硬伤（B5），三条验收在自己的配置契约下不可执行（B1/B17/B18），一条证据源不成立（B8/B9）。

### 1.2 判据二：歧义清单

逐条核对 §7（A1–A12）：

| 编号 | 标注 | 判定 |
|---|---|---|
| A1 位置 | **客户裁定** | **错。应为「自查可解」。** 详见第 3 节：`conversation.input.right` 是 list 座位，正好在模型选择器之前；客户 `00-client-answers.md` 已明确"存在列表语义座位就优先用它"。开发者在 P13 已经读到 `right` 是 list，却仍把它写成"容差妥协"并上抛。这是"该自查却上抛"的唯一一条，但正好命中 P0 判据二。 |
| A2 `@` 引用 | 自查可解 | 正确；有 `{text, references}` 语义化草稿作依据，且有降级。 |
| A3 20 项清单 | 自查可解 | 正确；不改变验收结构。 |
| A4 编辑门 | 自查可解 | 正确；取最保守解释。 |
| A5 即时生效是否含刷新 | 自查可解 | 正确；与"每次请求重读"自洽。 |
| A6 切走是否含刷新/关闭 | 自查可解 | 正确；与"不做重启回放"自洽。 |
| A7 发送后晚到结果 | 自查可解 | 正确；避免"幽灵草稿"。 |
| A8 固定模型被删 | 自查可解 | 正确；同类降级。 |
| A9 待重试形态 | 自查可解 | 正确；B13 已钉死语义。 |
| A10 最多四颗 | 自查可解 | 正确；与"取消勾选不丢预设"合读唯一。 |
| A11 词条语言 | 自查可解 | 正确；实现约定。 |
| A12 空改写稿 | 自查可解 | 正确；与"原稿不丢"一致。 |

**判据二结论：不通过。** A1 是"自查可解却上抛"，且 `00-client-answers.md` 已答复后，`01-requirements.md` §8 仍写"待客户裁定"、`02-plan.md` §1 仍写"A1 待客户确认容差"，没有回填。客户答复还明确"列表座位优先，这是第一优先，不是备选"，01/02 都没有把这句话落进判据。

### 1.3 判据三："不做"清单

`01-requirements.md` §6 有 10 条，具体、可核对（不自动发送、不多轮改写、不做模板库、不做历史记录、不重启回放、不改宿主输入框、不新增 Remote 命名空间、只做 Web、不做计费、P0/P1 不安装）。**通过。**

### 1.4 P0 判定

**不通过。** 判据一、判据二未满足；判据三满足。返工只涉及文档条目，不涉及代码。

---

## 2. P1 判定：不通过

### 2.1 判据一：依赖清单没有留到实施期再验的项

**形式面：合格。** D1–D18 每条都有"我依赖什么 / 为什么非它不可 / 探测结论 / 不成立时怎么降级"，没有一条是空的。D1/D3/D4/D5/D10/D12/D13/D16 有源码级证据；D6/D7/D8/D11/D14 有契约级证据；D15 有 round1 先例；D2 的"标准 props 到达插槽组件"我也复核了渲染端（`renderer/client.js` 806–816 的 `SessionEntry` 用 session binding 组装 `standardKit`，`uiSession.provide` 公布的 `inputActions` 会进入 session 标准 props），这一条站得住。

**但有三处实质缺口：**

- **D1 漏掉 list 座位的硬注册契约。** `conversation.input.right` 是 `kind:"list"`，运行时 `register()` 对 list 的要求是 **必须给 `options.id`**，否则直接抛 `list slot "..." requires options.id`；同一 `id` + 同一 priority 才冲突。计划只写"`conversation.input.right`（list，会话域）"，S5 只写"注册"，没有写"每颗按钮一个不同 `id`、用 `order` 排稳定顺序"。实现者若按 `single` 的习惯写（不给 id），客户端半会在渲染时抛错；D1 的"不成立时怎么降级"也覆盖不到这个失败模式。
- **D1 没覆盖"无 sessionId 时不渲染"和"activity 展开时 `standardControls` 被 hidden"。** 源码里 `right` 的渲染条件是 `input !== undefined && sessionId !== undefined`；且 `standardControls` 的 `hidden: activity`，一旦有 activity 占位者展开，`right` 和 `model` 一起被隐藏。新会话首帧、activity 展开态下按钮是否出现，属于 B1 的可达性前提，计划未列为待验项。
- **D9 的"第三方客户端半能否调用 `ctx.remote.commands.execute`"没有被显式标成 UNVERIFIED。** P9 的证据来自第一方 `ctx.fileUpload.uploadImage(sessionId,…)` 的调用形态，不是第三方 bundle 的运行时。U2 的 selftest 实际会覆盖它，但依赖清单的"探测结论"写成了"已验(契约+源码)"，把"第一方先例"当成了"第三方可用"。这是"二手结论当前提"的边界情况。

**时序面：不合格（关键）。** §3 开头写"**P2 开工前必须清零或选定降级**"，但同表里：

| # | 补探时刻 |
|---|---|
| U1 | **P2 第 1 步**，页面在线时 |
| U2 | **P2 安装后第 1 小时** |
| U3 | 同 U2 |
| U4 | 仅当 U2/U3 失败时 |
| U5 | **P2 打包时** |
| U6 | **P2 安装后** |
| U7 | **P2 安装后** |
| U8 | **P2 走查** |

U2/U3/U5/U6/U7 全部落在 P2 **开始之后**，与"P2 开工前必须清零"直接冲突；规格 P2 的入口又写"P1 计划 + **已清零的探测结论**"。计划自己在 §6 把 gate 条件降成了"U1–U8 的补探方法经复核可执行"，等于承认带着未清零的探测进 P2。按 P1 判据一"没有留到实施期再验的项"的字面，这属于留到实施期再验；按规格 P2 入口，这是入口条件不成立。

**判据一结论：不通过。** 依赖条目本身写得比多数计划扎实，但 U2/U3/U5/U6/U7 的补探时序与 P2 入口冲突，且 D1 漏了 list 的硬注册契约。

### 2.2 判据二：每步都有完成标志

S0–S8 **都有**"完成标志"，且多数是可复跑命令或可核对事实（`node scripts/check-syntax.mjs`、`node --test`、三方差集、红→绿记录、04-selfcheck 判定表）。**形式通过**，但有两处内容问题：

- **S5 的完成标志写"现场走查，每条记录三态与证据（截图+日志）"，与 `01-requirements.md` §4 冲突。** §4 明说"截图或逐步复述不算，需现场重放同一操作"，且 P3 规格要求证据是"文件:行 / 命令输出"。S5 把截图当完成证据，P3 会不认。
- **B8/B9/B10/B17/B20 没有明确归属的现场走查步骤。** S5 只列 B1/B3/B4/B11–B16/B21；S6 列 B6/B7/B18/B19；S7 列降级；S8 是"总表"。B8/B9/B10（模型与强度）和 B17（超时）、B20（设置不可用）没有一步的完成标志明确写着"现场验这条"，只能靠 S8 兜底。这不是"没有完成标志"，而是"验收覆盖映射"不完整。

**判据二结论：通过（有保留）。** 每步有标志；但 S5 的证据口径必须改，B8/B9/B10/B17/B20 的归属要补。

### 2.3 判据三：最大风险有应对方案

R1 被明确标为"最大风险"（命令通道不是为数据管道设计：分钟级 unary / 行长度 / `/` 菜单可见副作用），应对写了 4 条：S1 探针先做二值结论、降级 A/B 藏在 S4 接口后、A/B 都不行的回退形态、`/` 菜单副作用不接受的替代。**通过。** R2–R7 也各有应对。

### 2.4 P1 其他问题

- **A1/C1 状态未回填。** `02-plan.md` §1 仍写"A1 待客户确认容差"，§6 checklist 第一项未勾；但 `00-client-answers.md` 已明确"接受 + 列表座位优先"。计划进入 P2 前应把 C1 标为已结案，并把落点写成"`conversation.input.right` list，非容差"。
- **S6 的"20 项表单"与 #20 只读冲突**（承接 P0 M-3）。
- **R 清单没有"list 注册缺 id 会抛错"和"activity 展开隐藏 right"两条**；它们不是最大风险，但应在 U1 的判定口径里。

### 2.5 P1 判定

**不通过。** 依赖矩阵和最大风险应对本体合格；失败点是补探时序与 P2 入口的冲突、D1 的 list 注册契约缺口、S5 证据口径，以及 A1/C1 未回填。

---

## 3. C1 断言核查（独立核实，不采信产物说法）

### 3.1 断言原文与任务转述

- 任务转述：**"发送键左侧只有「活动区」这一个单占位插槽，放不下 1–4 颗并列按钮"**。
- 开发者 C1 原文（`01-requirements.md` §8）："'发送键与模型选择器之间'只有一个单占位插槽（活动区……），放不下 1–4 颗并列按钮。能容纳多颗的最近位置在模型选择器之前（仍属发送区左侧），其次是最左侧。"

两者范围不同：转述说的是"发送键左侧"，原文说的是"发送键与模型选择器之间"。下面的证据分别判。

### 3.2 探测方法与边界

1. **Client Inspect**：`cordis_inspect_query(platform=client, provider=Slots, method=listSubTree)`。带 `{root:"conversation.composer.bar"}` 的调用被工具层以 `"input" must be an object` 拒绝（两次）；不带 input 的调用 **10s 超时**（与 `probes.md` P3 一致）。因此**运行时座位树未验**。
2. **只读源码**：用 `probe-tools/asar-probe.ps1` 从本机安装包 `C:\Users\Administrator\AppData\Local\Programs\DeepSeek Harness\resources\app.asar` 抽取 `dsh/node_modules/@deepseek-ai/dsh-client-ui-conversation/lib/client.js`，得到 **940214 字节**，与 `probes.md` P16 记录一致；另抽 `dsh-client-ui-renderer/lib/client.js` 与 `dsh-web-frontend/dist/assets/index-BgUyXZcc.js`（Slots 运行时）。全部落在 `%TEMP%`，未写安装目录、未写 `$DSH_HOME`。
3. 源码是**已安装、页面实际加载的那一份**；座位声明由 `conversation.composer.bar` 的 owner 固定，第三方插件不能重声明（`registerFactory` 对已声明座位直接抛错），所以静态声明足以裁决"座位语义"这类断言。运行时只影响"当前是否渲染"，不影响"kind 是什么、允不允许 1–4 个"。

### 3.3 证据

**（a）座位声明表** — `dsh-client-ui-conversation/lib/client.js` 22958–22997：

```js
const registerComposerBar = () => slots.register({
  name: "conversation.composer.bar",
  children: {
    "conversation.input.attachments": { kind: "single", scope: "session-maybe" },
    "conversation.input.overlay":     { kind: "list",   scope: "session" },
    "conversation.input.permission":  { kind: "single", scope: "session" },
    "conversation.input.left":        { kind: "list",   scope: "session" },
    "conversation.input.plan":        { kind: "single", scope: "session" },
    "conversation.input.right":       { kind: "list",   scope: "session" },
    "conversation.input.model":       { kind: "single", scope: "session" },
    "conversation.input.activity":    { kind: "single", scope: "session" },
    "conversation.composer.dock":     { kind: "list",   scope: "session" }
  }
});
```

`conversation.input.right` 和 `conversation.input.left` 都是 **list**；`activity` 是 single；`model` 是 single。

**（b）渲染顺序** — 同文件 22104–22118：

```js
// trailing 容器
children: [
  jsxs("div", { className: "standardControls", hidden: activity, children: [
      renderSlot("conversation.input.right", {}),
      renderSlot("conversation.input.model", { locked })
  ]}),
  jsx("div", { className: activity ? "activityExpanded" : "activity",
      children: renderSlot("conversation.input.activity", { locked, onActiveChange: setActivity }) }),
  // 随后是 Stop 按钮（22119+）与 Send/primary 按钮（22149+）
]
```

所以右簇的实际顺序是 **`[right] [model] [activity] [Stop] [Send]`**。`right` 在 `model` 之前，当然也在 Stop/Send 左侧。

**（c）list 座位允许多个 id** — `dsh-web-frontend/dist/assets/index-BgUyXZcc.js`，`SlotCore.register` 的 `case "list"`（字符偏移约 492065）：

```js
case "list": {
  if (e.id === void 0) throw new Error(`list slot "${e.name}" requires options.id`);
  const f = r.entries.find(h => h.options.id === e.id && (h.options.priority ?? 0) === n);
  if (f) throw new Error(`list slot "${e.name}" already has an entry with id "${e.id}" ...`);
  break;
}
```

只有 **同 id + 同 priority** 才冲突；不同 id 可以并存。`entriesOfSlot()`（同文件，约 495049 起）对 list 按 `options.id` 去重后返回全部项。渲染端 `dsh-client-ui-renderer/lib/client.js` 1203–1221 把 list 的所有 rows 按 `order` 排序后 **全部 map 成元素**（single 才只取 `[0]`，见 1173–1177）。

**（d）结论所需的最小事实**

- `conversation.input.right` = list，位置在模型选择器之前、Stop/Send 左侧；
- list 允许 1–4 个不同 `id` 的注册项并存；
- 渲染端确实全部渲染；
- `activity` = single，位于 model 与 Stop 之间，语义是单个可展开控制。

### 3.4 判定

- **按任务转述的强命题（"发送键左侧只有活动区"）：不成立。** 发送键左侧有 `conversation.input.right`（list）和 `conversation.input.left`（list）；`right` 还在模型选择器之前。它天然能并排容纳 1–4 颗按钮。
- **按开发者 C1 原文的窄命题（"发送键与模型选择器之间只有活动区；能容纳多颗的最近位置在模型选择器之前"）：成立。** 这一段与源码一致；`activity` 确实 single，`right` 确实在 model 前。
- **但开发者的"因此"是错的定性。** 他们把 `right` 说成"容差妥协"，把 A1 标成「客户裁定」；实际上 `right` 就是客户答复里"列表语义座位，优先用它"的那个座位，且正好在客户接受的"模型选择器之前"。**不需要容差，也不需要客户裁定**。客户答复的"接受"是无害的，但它回答的是一个被错误构造的二选一（activity vs 模型选择器之前），漏掉了"模型选择器之前本来就是 list"这一事实。
- **正确做法（只给结论）：** 在 `conversation.input.right` 注册 1–4 个条目，每颗一个**不同 `id`**（如预设 id），用 `order` 固定顺序；不碰 `activity`；A1 改为「自查可解」，在 01/02 回填 `00-client-answers.md` 的"列表优先"；U1 补验三件事：`right` 的占用者、无 `sessionId` 首帧是否渲染、activity 展开时 `standardControls` 被 hidden 的影响。

> 附注（不是选择 activity 的理由）：`standardControls` 带 `hidden: activity`。如果将来有 activity 占位者展开，`right` 会与 `model` 一起被隐藏。这是 `right` 方案的一个条件性风险，应在 U1 里记录；不影响"activity 放不下 1–4 颗"的判断。

---

## 4. 缺陷清单

### BLOCKER（不修不能过 P0/P1 门）

| # | 缺陷 | 证据 | 修法（只给结论） |
|---|---|---|---|
| **B-1** | **B5 是"靠人看"的验收**：通过条件含"人工按预设意图判读'方向对'"，不可复跑；"两两不完全相同"受模型随机性影响。 | `01-requirements.md` 66–70 | 为每套预设定义可观察特征（翻译=目标语言特征、编程=编号步骤/代码块、写作=保留段落与语气标记、通用=结构化清单），并把"两两不同"改为"请求体中的模板标识不同 + 输出含对应特征"；必要时固定温度/模型做确定性对照。 |
| **B-2** | **A1 误标「客户裁定」且技术前提按任务转述不成立；客户答复未回填。** `right` 是 list，位于发送键左侧、模型选择器之前；客户已答复"列表座位优先"。 | 01 §7 A1、§8；00-client-answers C1；源码 22982–22985、22110 | A1 改为「自查可解」；落点写 `conversation.input.right`（list，多 id）；回填 00 答复；删掉"需要客户接受容差"的表述，保留"客户已确认位置在发送区左侧"作为记录。 |

### MAJOR（会改变验收结果或阻断实施，必须在 P2 前修）

| # | 缺陷 | 证据 | 修法 |
|---|---|---|---|
| **M-1** | B1 的 `1 ≤ N ≤ 4` 未排除总开关关闭。 | 01 45 行 vs §5 #1 | 加"总开关开时"；总开关关时单列一条"0 颗"验收。 |
| **M-2** | B17/B18 用"1 秒"超时，违反 §5 #17 的 30–600 秒。 | 01 137、143 行 vs 198 行 | 改用 30 秒；或加"测试专用覆盖"并写清只对测试生效。 |
| **M-3** | B18"20 项逐项可改"与 §5 #20"只读展示"冲突。 | 01 144 行 vs 201 行；02 S6 | 改成"19 项可改 + 第 20 项只读展示"；S6 同步。 |
| **M-4** | B8/B9 的证据源不成立：`command/run`/`command/done` 不保证记录 provider/model/reasoningEffort；`CommandInvocation` 只有 `rawInput` 等。 | 宿主 `commands` 契约；01 §4 171 行 | 让宿主半在命令结果里回传解析后的 `{provider,model,reasoningEffort,presetId}`（B8/B9 用结果元数据判），`command/run` 只用于证明请求次数/取消；§4 改口径。 |
| **M-5** | U2/U3/U5/U6/U7 的补探时刻落在 P2 内，与"P2 开工前必须清零"及规格 P2 入口"已清零的探测结论"冲突。 | 02 §3 表 vs §3 首句、§6；spec 31 行 | 把 S1 明确定义为"P1→P2 的探针门"（安装批准后只许探针，不许功能代码），或在 P2 入口前完成清零/选定降级并留痕；§6 checklist 改成"已清零或已选定降级"。 |
| **M-6** | D1 漏掉 list 座位的硬注册契约：必须给不同 `id`；`order` 排序；无 sessionId 不渲染；activity 展开会 hidden。 | 运行时 `case "list"`；renderer 1173–1221；conversation 22110 | D1 补"每颗一个 id + order"；U1 补"无 sessionId 首帧、activity 占用与展开、right 现有占用者"三项判定口径；S5 的注册步骤写明 id。 |
| **M-7** | S5 完成标志用"截图+日志"作证据，与 01 §4"截图不算"、P3"文件:行/命令输出"冲突。 | 02 104 行 vs 01 170 行；spec 46 行 | S5 改成"宿主日志 `command/run|done` 条数与结果 + 现场重放步骤 + 必要截图仅作辅助"；P3 证据表按文件:行/命令输出组织。 |
| **M-8** | A1/C1 状态未回填：02 §1 仍"A1 待客户确认容差"，§6 第一项未勾；客户已答复。 | 02 15、142 行；00 C1 | 标"已结案"；落点写 list；§6 勾选并附答复文件。 |

### MINOR（不阻断，但应在 P2 前顺手修）

| # | 缺陷 | 证据 |
|---|---|---|
| m-1 | B19"未保存 N 项"的 N 计数单位未定义（字段/套/跨套合计）。 | 01 149 行 |
| m-2 | B15"可读原因"含主观词；建议删"可读"或固定字段（类别码 + 中文文案）。 | 01 127 行 |
| m-3 | B21"半损坏芯片"需补判定动作（引用节点仍可点、references 偏移不变）。 | 01 163 行 |
| m-4 | B16"对'编程'的操作"未说明操作对象（已无回退控件）。 | 01 132–134 行 |
| m-5 | B10"选一个不支持 S3 的模型"未必在目录中存在，需给确定性构造。 | 01 98 行 |
| m-6 | D17 把"Theme Inspect Provider 存在"写成"已验(契约)"，但令牌清单实际取不到；应标 UNVERIFIED 或降为源码级。 | 02 53 行；U1 |
| m-7 | D9 用第一方 `uploadImage` 先例推断第三方可用，未显式标 UNVERIFIED；U2 实际覆盖，但依赖结论写得过满。 | 02 45 行；P9 |
| m-8 | U1 未列"activity 展开时 standardControls hidden"与"新会话无 sessionId"两项；这两项直接影响 B1 可达性。 | 02 64 行；源码 22109 |
| m-9 | S6 写"20 项表单"，与 M-3 同源；应为 19 项可编辑 + 1 项只读回显。 | 02 108 行 |

---

## 5. 放行意见

**不能进入 P2。**

理由按阶段门规则：P0 门未通过，P1 作为下游不得开工；P1 自身也有入口时序与依赖契约缺口。P2 的第一步本应是"探针闭环"，但按规格 P2 入口要求"已清零的探测结论"，当前计划不能既宣称 P2 开工、又把 U2/U3/U5/U6/U7 的结论留到安装后再补。

### 返工顺序（建议，不替开发者执行）

1. **P0 返工**：B-1（B5 可判定化）、B-2（A1 自查可解 + 回填 00 答复）、M-1～M-4（B1/B17/B18/B8-B9 的契约冲突）、m-1～m-5。
2. **P1 返工**：M-5（把 S1 定义为 P1→P2 探针门，或把 U2/U3/U5/U6/U7 清零写进入口）、M-6（D1 的 list 注册契约 + U1 三项）、M-7（S5 证据口径）、M-8（C1 结案）、m-6～m-9。
3. **重门**：P0/P1 各按本规格再判一次；P0 通过后才允许 P1 重门；P1 通过后才允许 P2 S1。
4. **P2 S1 的边界**：安装批准后只许探针件（selftest 命令 + 最小插槽组件），U1/U2/U3 结论写回 `probes.md`；U5/U6/U7 在打包/安装后、S3 主体代码前清零或选定降级。未清零前不得写 S2 之后的业务代码。

### 本次审查未做/不能做

- 未安装插件，未跑任何页面级验证；U1 的"运行时是否存在"仍是 `UNVERIFIED`。
- 未改开发者产物；本文件只记录判定与证据。
- Client Inspect 的带参调用被工具层拒绝、无参调用 10s 超时；若 P2 页面在线后 `Slots.listSubTree` 可用，应以运行时 `occupants` 再复核一次 `right` 的现有占用者与 `activity` 占用情况（这不改变本节的座位语义结论）。
