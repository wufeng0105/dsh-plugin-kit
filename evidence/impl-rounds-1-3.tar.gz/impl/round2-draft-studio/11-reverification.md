# 11 复验（P3.5 → P4 门禁）

> 复验者：P3.5（不是修复者、不是上一轮 P3）。日期：2026-11-08。
> 对象：`bundle-lab/`（`@local/lab-draft-studio`）+ `10-fix-report.md`。
> 纪律：**本文件不引用 `10` 的结论作为证据**。所有 `文件:行`、命令、stdout 都是本轮自己跑出来的；凡是我的复跑与自述不一致，以我的输出为准并标注。
> 未做：未安装、未碰 `$DSH_HOME`、未修改 `bundle-lab/` 任何文件（复跑前后的 28 个文件 SHA-256 逐一相同，无 `.mutation-aside` 残留；所有破坏性实验都在 `%TEMP%` 的副本上做）。

---

## 0. 一句话结论

**不可进 P4。**

`10` 的主要工作是真的：174 条测试、9 个变异、内联生成器、`--check` 我都独立复跑过，全绿且可证；D-06/D-07/D-08/D-09 四条我逐条核实**成立**。上一轮 D-01 的核心指控（`writeback.js`/`run-store.js` 不在产品 import 链、点击立即回 idle）**在代码层面已经解决**：内联区就是 `lib/*.js` 原文，点击后确实离开 `idle`。

但这一版**仍然不能点出一次成功的改写**，原因不在状态机，而在**状态机外面的两条传输接缝**，两条都是静态可证、不是"等真机"：

1. **`client.js` 的 inject 少了 `remote.commands`**，而点击路径读 `ctx.remote.commands.execute`。用**安装包里那份 cordis 4.1.0** + 与 `dsh-api-gateway` 同形的服务拓扑复跑，读这一下直接抛 `cannot get property "remote.commands" without inject`。后果不是"失败态"，是 `runRequest` 变成未处理拒绝、按钮**永远停在 running**。
2. **答案信封读错了一层**。`ctx.remote.commands.execute` 返回 `{ok, value:{commandId, result:{kind,text}}}`（gateway `invoke()` 的返回，安装包里三个官方调用方都按这个解），而 `client.js:2017` 读 `answer?.text` → `undefined` → `decodeResult` 判 `empty-result-text` → 每次点击都落到 `failed / provider-error`。

另有一处**方向反了**的修复：**D-05 的"修法"把原本正确的 id 改错了**（详见 §2.3），并由此让设置页永远 `unavailable`、四颗按钮全渲染。

外加背景前提核对：**D-02 / D-03 在我的复跑里仍然复现**（见 §4），与"修复轮开始前就已修好"的前提不符；修复者确实没动它们（代码与描述一致），但描述里的修法不足以消掉缺陷。

---

## 1. 独立复跑（全部我自己跑）

### 1.1 测试

```text
cd bundle-lab
node --test "test/*.test.js"
ℹ tests 174
ℹ pass 174
ℹ fail 0
（exit=0）
```

### 1.2 语法

```text
node scripts/check-syntax.mjs
20 file(s) checked, 0 failure(s)
（exit=0）
```

### 1.3 内联区一致性

```text
node scripts/build-client.mjs --check
ok   client.js kernel region matches lib/*.js
（exit=0）
```

**手工改一处内联，确认它会红**（在 `%TEMP%\p35-copy` 的副本上做，不动 `bundle-lab`）：

```text
# 把内联区里 lib/run-store.js 的 seatState 一行
#   return { state: SEAT_STATES.running, … }  →  SEAT_STATES.idle
node scripts/build-client.mjs --check
FAIL client.js kernel region is stale — run: node scripts/build-client.mjs
（exit=1）

node --test --test-name-pattern="kernel region is current" "test/*.test.js"
→ AssertionError: client.js kernel region drifted from lib/*.js
（exit=1）
```

### 1.4 变异

```text
node scripts/mutate.mjs
=== D-01a … RESULT : red → green proven
=== D-01b … RESULT : red → green proven
=== D-01c … RESULT : red → green proven
=== D-04  … RESULT : red → green proven
=== D-05  … RESULT : red → green proven
=== D-06  … RESULT : red → green proven
=== D-07  … RESULT : red → green proven
=== D-08  … RESULT : red → green proven
=== D-09  … RESULT : red → green proven
ALL MUTATIONS PROVEN (9 run)
（exit=0）
```

> 复跑前后 `bundle-lab/` 28 个文件的 SHA-256 全部一致（`client.js` = `779D7C65…`、`lib/host.js` = `A83DD9CD…`），无 `.mutation-aside` 残留。

### 1.5 宿主契约（只读 Inspect）

```text
cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})
→ 15 个方法：observeSession / searchSessions / searchEvents / listSessions / readSession /
  filterSessions / readTitle / readTitleSnapshot / readTitleSnapshots / listEvents /
  filterEvents / readSurface / traceSession / traceEvent / readEvent
  **无 modelSelection**
```

```text
cordis_inspect_query(host, Config, listConfigs, {offset:0,limit:12})
→ {"id":"include:ui-settings","patchId":"ui-settings","name":"@deepseek-ai/dsh-client-ui-settings"}
   … 每一条都是 id === "include:" + patchId（total: 229）
```

```text
cordis_inspect_query(client, Service, listService, {service:"configForms"})
→ Error: … timed out after 10000ms
```

Client Inspect 本轮**仍然超时**（与 `09` §3.0 相同）。因此本报告里所有客户端/宿主契约事实都改从**安装包 `app.asar` 的原文**取证（`probe-tools/asar-grep.ps1`、`asar-probe.ps1`，只读、只往 `%TEMP%` 写）。

---

## 2. 逐条核实（D-01 / 04 / 05 / 06 / 07 / 08 / 09）

### 2.1 D-01（BLOCKER）：产品没接线 → **部分成立**

**成立的部分（机制是真的）**

| 项 | 证据 |
|---|---|
| 内联区就是 `lib/*.js` 原文 | `node scripts/build-client.mjs --check` → `ok`；手改一行 → `FAIL … stale`（§1.3） |
| 七个内核模块都在 | `client.js:50` prompt、`:275` boundary、`:376` seats、`:446` run-store、`:681` writeback、`:903` wire、`:1128` settings |
| 客户端不 import 它们 | `client.js` 无 `^\s*import\s`、无 `from '…/lib/'`（测试「every kernel module is inlined…」也在跑） |
| 点击路径确实经过四个函数 | `startRun` → `store.start`（`client.js:2051`）→ `runRequest` → `execute`（`:2007`）→ `decodeResult`（`:2017`）→ `settle`/`applyOutcome` → `decideWriteBack`（`:1942`） |
| 点击离开 `idle` | 我用 `new Function(client.js)` 走页面同一条求值路径实测：点击后 `data-state=running`、`data-elapsed-ms=0`、`aria-disabled=true`、子节点 `["cancel"]`（`%TEMP%\p35-probe\probe-envelope.mjs`） |
| 状态机/写回/回退/重试都在产品代码里 | `store.finish`（`:1958`）、`store.fail`（`:1937/:1961/:1973`）、`store.cancel`（`:1976/:2198`）、`store.record`+`decideRevert`（`:2203-2213`）、`store.clear`（`:2218`） |

**不成立的部分（真实页面上点不出结果）**

**（a）`inject` 少了 `remote.commands` —— 读一下就抛，按钮永久 running。**

- `client.js:1815`：`inject: ['slots', 'locale', 'configForms', 'remote']`
- `client.js:1988-1989`：`const remote = ctx.remote; const execute = remote?.commands?.execute;`
- 用**安装包里的 cordis 4.1.0**（从 `app.asar` 只读取出）+ 与 `dsh-api-gateway` 同形的拓扑（`remote` 由 gateway 插件 fiber 提供，`remote.commands` 由它 `createNamespace` 的**子 fiber** 提供）复跑：

```text
inject: [remote]                    → THREW: cannot get property "remote.commands" without inject
inject: [remote, remote.commands]   → resolved to a function
```

- 这不是我编的规则：**本仓库里已安装的产品** `dsh-draft-studio/client.js:2598-2600` 自己写着
  "`remote.session` must be DECLARED here, not merely present: the client guard rejects `scope.remote.session` with 'cannot get property "remote.session" without inject' when the sub-path is not in the list."
- 所有官方调用方都声明了子路径：`dsh-client-ui-plan`（`inject = ["slots","remote","remote.commands",…]`）、`dsh-client-ui-commands`（`["inputTriggers","sessions","remote","remote.commands","locale"]`）、`dsh-api-session-controller`（`["…","remote","remote.commands","remote.session","remote.subagents"]`）、`dsh-client-ui-settings`（`["remote","remote.settings"]`）。
- 后果：`ctx.remote` 本身可以拿到（`remote` 在 inject 里），`.commands` 这一下抛在 `runRequest` 里、**在 `try` 之外**（`try` 从 `:2006` 才开始），于是变成 `void runRequest(job)` 的未处理拒绝；store 停在 `running`，秒表一直涨。我实测：点击后 `data-state=running`，420 ms 后仍 `running`、`elapsed` 从 21 涨到 445，`unhandledRejection: cannot get property "remote.commands" without inject`。
- 顺带：`test/client.test.js:161` 把 inject 断言成 `['slots','locale','configForms','remote']`——**这条测试把缺陷锁死了**，修的时候要一起改。

**（b）答案信封读错一层 —— 每次点击必然 `failed / provider-error`。**

- 官方 gateway 的 `invoke()` 返回 `{ ok: true, value }`（`dsh-api-gateway/lib/types/client/index.js`，`return { ok: true, value };`）；`commands/execute` 的 result 是 `{ commandId, result: { kind: 'success'|'error', text? } }`（`dsh-api-remotes/lib/client.js:1211-1221`）。
- 官方调用方按这个解：`dsh-client-ui-commands/lib/client.js:1669` 起 `const result = await this.ctx.remote.commands.execute(…); if (!result.ok) throw …; if (result.value === void 0) return {kind:"error",…}; … result.value.result.kind`。
- 本插件 `client.js:2017` 只有 `decodeResult(answer?.text)`；`client.js` 全文没有 `answer.ok` / `answer.value`（我实测正则 `answer\??\.(value|ok)\b` = false）。
- 实测（把四种可能的答案形状喂给真实 `decodeResult`）：

```text
裸 Host payload（测试里 fake 的形状）          → ok:true, payload:{ok:true,text:"改写稿"}
{ok,value:{commandId,result:{kind,text}}}     → ok:false, error:"empty-result-text"
{ok,value:{kind,text}}                        → ok:false, error:"empty-result-text"
{ok,value:{commandId,result:{kind:"error"}}}  → ok:false, error:"empty-result-text"
```

- 端到端实测（用真 client.js + 真 gateway 形状的 `execute`）：`written = null`、`data-state = failed`、`data-reason-code = "provider-error"`、`data-detail = "command result was not JSON: empty-result-text"`。
- 根因：`test/client.test.js:742-747` 的"端到端"fake 返回 `{ text: encodeResult(result) }`——**这个形状真实的 gateway 从来不会产生**。测试测的是"payload 过一遍 encode/decode"，不是"transport 信封"。这正是上一轮 P3 说的"测试路径与产品路径断层"在**新一层**重演。

**判定：D-01 部分成立。** 内联架构 + 状态机接线是真的、可证的；但产品路径在 transport 边界上仍然走不通，且是**两条独立的静态缺陷**。`10` 的「D-01 真的接线了」只在"代码里有调用链"这个意义上成立，在"点一下能改写"这个意义上不成立。

### 2.2 D-04（MAJOR）：B20 三处判据相反 → **部分成立**

**成立的部分**

- `client.js:2168` 确实改用 `seatFor(presetId, settings, settingsAvailable !== false)`。
- `lib/seats.js:46-52` 的降级规则正确，实测 `seatPlan(settings, false)` → `{visible:["general"], degraded:true, presetId:null}`；`seatFor("translate", settings, false)` → `{show:false, degraded:true, requestPresetId:null}`。
- 降级请求确实 `presetId: null`，且 `system` 不含标记：实测 `dispatch({action:'dump-request', presetId:null})` → `presetId:null`、`hasMarker:false`；对照 `general` → `marker:"general"`。

**不成立的部分：触发条件在真实页面上不可达**

- `client.js:2168` 的第三个实参是 `settingsAvailable !== false`，而 `settingsAvailable` 来自 `readSettings()`（`client.js:1674-1684`）：
  - 只要 `configForms.get()` 返回了一个对象（**它对任何 id 都会返回一个 controller，从不抛**），`readSettings` 就返回 `settingsAvailable: true`，哪怕 `snapshot.value` 是 `undefined` → `{settingsAvailable: true, settings: null}`。
- 我用真实 `ConfigFormController` 的行为复现（namespace 不在 describe 里 → `status:'unavailable'`、无 `value`）：`readSettings` → `{settingsAvailable:true, settings:null}`；四颗座位全部渲染，**没有降级、也没有横幅**。
- 而 `seatPlan(null, true)` → 四颗全可见（`visibleSeats(null)` 把 `settings?.enabled === false` 判为 false，ticked 回落成四个预设）。所以真实页面上的"设置读不到"会渲染**四颗按钮 + 空白设置页**，而不是 B20 要的一颗。
- 降级分支只在**发布全局缺失**（`readPublished()` 为 null）或 `configForms` 缺失/抛错时才可达；"命名空间找不到"这条最常见的故障形态反而**不会**触发它。
- 结论：规则改对了，但"设置不可用"这个**信号**没有从 Host 的 `status` 传进来。B20 在真实页面上仍然判红。

### 2.3 D-05（MAJOR）：Config entryId 形态 → **不成立（方向反了，且引入回归）**

**修复做了什么**：`lib/host.js:886` 加 `ENTRY_ID_PREFIX='include:'`，`:906-918` 把 `entryId` 统一成 `include:<patchId>`；`client.js` 把发布值原样喂 `configForms.get()`。

**我的核对**（全部来自安装包原文）：

| # | 事实 | 出处 |
|---|---|---|
| 1 | 设置命名空间 `ns` = **`entry.options.id`**（patchId），不是 Loader 目录 id | `dsh-settings/lib/index.js`：`this.revisions.set(entry.id, { … ns: entry.options.id … })`；返回行 `ns: entry.options.id` |
| 2 | `entry.id` 才是 `include:<patchId>`，`entry.options.id` 是裸 patchId | `dsh-tool-cordis/lib/types/config.js:4-6`：`const { id, name } = entry.options; const listed = { id: entry.id, patchId: id, name };` |
| 3 | 现场 Inspect 印证：`{"id":"include:ui-settings","patchId":"ui-settings"}` | §1.5 |
| 4 | `configForms.get(entryId)` 把参数当 **namespace** 用，并按 `candidate.ns === spec.namespace` 匹配 | `dsh-client-ui-settings/lib/client.js:1297`：`new ConfigFormController(this.owner, { namespace: entryId }, …)`；`:1214`：`candidate.ns === this.spec.namespace` |
| 5 | 官方调用方全部传**裸 patchId** | `get("ui-settings")`（ui-agent-preset:2872、ui-settings-general:1364）、`get("ui-chat")`、`get("web")`、`get("cot-translation")`、`get(CONVERSATION_SETTINGS_NAMESPACE="ui-conversation")`、`get(AGENT_LOOP_NS="agent-loop")`、`get("locale")` |
| 6 | 写路径同样按裸 patchId 找 entry | `dsh-settings/lib/index.js`：`entries().find((row) => row.options.id === ns)` |

**结论**：`configForms.get()` 要的是 **patchId**（`lab-draft-studio`），不是目录 id（`include:lab-draft-studio`）。上一轮 P3 的 D-05 本身是**误判**（它拿 `Config.listConfigs.id` 当成了设置命名空间）；`10` 照着这个误判把**原本正确的值改成了错的**。

**后果（真实页面）**：`configForms.get('include:lab-draft-studio')` 会返回一个 namespace 永不匹配的 controller → `status:'unavailable'`、无 `value` → `readSettings` 给出 `{settingsAvailable:true, settings:null}` → 设置页 19 行全是空串、无横幅；座位拿到 `settings:null` → `visibleSeats(null)` → **四颗全渲染**，总开关关不掉任何一颗（B1-b / B1-c 在真机上会被这条带红）；B18/B19 也不可能通过。

> 这条是**本轮引入的回归**，不是上一轮遗留。修法：`entryId` 回到裸 patchId（`ctx.fiber.entry.options.id` 原值），并回写 `01 §9` / `02 D18` / `06 U7` 里"预期 `include:lab-draft-studio`"的表述——那三处把**两套 id**（Loader 目录 id vs 设置命名空间）混为一谈。

### 2.4 D-06（MAJOR）：`sessionQuery.modelSelection` 不是宿主方法 → **成立**

| 核对项 | 结果 |
|---|---|
| `sessionQuery` 有没有 `observeSession` | 有（15 个方法之一，签名 `observeSession(sessionId, options): Promise<SessionObservation>`） |
| 有没有 `modelSelection` 方法 | **没有**（方法表 15 项逐条核对） |
| `SessionObservation` 有没有 `projections` | 有：`projections?: ProjectionSnapshot`，`ProjectionSnapshot { asOfSeq, values: Partial<SessionProjectionMap> }`；`SessionObservationOptions { signal?, projectionMode?: 'all'|'none' }` |
| `values.modelSelection` 的形状 | `{ lastUsed, next }`，每项 `{provider, model, reasoningEffort?}|null`（`dsh-agent/lib/index.js` 的 `modelSelectionProjectionDefinition.wire.viewSchema`；`dsh-api-remotes/lib/client.js:20032` 的 zod 同形） |
| `sessionProjections.snapshot()` 的返回 | `{ asOfSeq, values }`，`values[def.key] = viewCell(...)`（`dsh-session-projection/lib/types/index.js:266`） |
| 代码是否按此读 | `lib/host.js:614` `observeSession(sessionId, { projectionMode: 'all' })`；`:621-622` `observation?.projections?.values?.modelSelection` → `pickSelection`（`next ?? lastUsed`，与宿主自己的 composer `ui-conversation-client.js:16157` 同选择） |
| 旧方法名是否已消失 | `lib/host.js` 里只剩注释提到它（`:582/:585`），无 `sessionQuery.modelSelection(` 调用 |

**一处小瑕疵（MINOR，不阻断）**：`lib/host.js:624` 用 `typeof observation?.dispose === 'function'` 释放租约，但 `session-query` 的 lease 只有 `[Symbol.dispose]` 和 `retain()`，**没有 `.dispose()` 方法**。所以这个 `finally` 实际是空操作：live 会话的 dispose 本来也无副作用，但 **cold/prepared 会话的 `entry.refs` 不会被减回去**，缓存条目永远不淘汰。属资源泄漏，不是功能缺陷。

### 2.5 D-07（MAJOR）：最外层 catch 吞掉宿主错误文本 → **成立（Host 面）**

实测（真实 `dispatch`，fake `llm.prepareCall` 抛宿主拒绝原文）：

```text
dump-request --prepare --negative=model
→ { ok:false, reason:"provider-error", prepared:null,
    detail:"Model '__lab_draft_nonexistent_model__' is not routable",
    detailHasModelId:true }

dump-request --prepare（正常）
→ { ok:true, options:{provider:"p",model:"m",reasoningEffort:"low"},
    prepared:{provider:"p",model:"m",reasoningEffort:"low"}, detail:null }
```

- `lib/wire.js:183-185`：`detail` 只在失败时非空、成功恒 `null`。
- `lib/host.js:339-350` `describeError`；`:405`（compose 抛错）、`:434`（llm 缺失）、`:553`（最外层 catch）、`:322`（prepare 拒绝）四处都写 `detail`。
- `runRefine` 的 `catch` 也保留原文（`lib/host.js:543-557`）。
- `client.js:1766` 有 `data-detail`，由 `details` map 写入（`:1936` 等）。

**但**：客户端那一半要等 `decodeResult` 成功才会把 `payload.detail` 放进 `details`（`:2031`）。由于 §2.1(b) 的信封缺陷，真实页面上 `data-detail` 永远是 `"command result was not JSON: empty-result-text"`，**不是**宿主的原文。所以 D-07 在 Host→JSON 这一段成立；在"用户悬停能看到"这一段被 D-01 挡住。

### 2.6 D-08（MAJOR）：guard 对两个 fetch 元数据头都缺失时放行 → **成立**

实测 `guardRequest`：

```text
两头都缺（只有 token）           → {allowed:false, status:403, reason:"fetch-metadata-missing"}
两头齐全（site=same-origin+origin+token） → {allowed:true,  status:200, reason:"ok"}
只有 site、无 origin             → {allowed:true,  status:200, reason:"ok"}
有 origin+site、无 token         → {allowed:false, status:403, reason:"token-mismatch"}
```

`lib/guard.js:133-140` 的 `fetch-metadata-missing` / `origin-unconfigured` 分支与同文件 `:21-24` 的注释现在一致。

**残余（不阻断）**：只带 `Sec-Fetch-Site: same-origin`、不带 `Origin` 的请求仍然放行（本地进程可以伪造这一个头），"三闸独立"在裸 HTTP 场景下实际仍是"token 一闸硬 + 两闸软"。token 是每进程 UUID，强度够，所以不是放行障碍；但对外不要说"三闸独立"。

### 2.7 D-09（MAJOR）：`scripts/assert-preset.mjs` 缺失 → **成立**

我自己跑了三种输入：

```text
node scripts/assert-preset.mjs <pass.json>
PASS general / coding / writing / translate … B5 判据 2: PASS (4/4 套通过)     exit=0

node scripts/assert-preset.mjs <fail.json>
FAIL general / coding / writing / translate … B5 判据 2: FAIL (0/4 套通过)     exit=1

node scripts/assert-preset.mjs <missing.json>
cannot read … ENOENT                                                          exit=2
```

文件存在（`bundle-lab/scripts/assert-preset.mjs`，240 行），变异 `D-09`（移走文件）→ 红、放回 → 绿。**成立。**

---

## 3. 验收对照（只判受本轮修复影响的条目）

三态口径同 `08`/`09`：**VERIFIED** = 离线可复现二值结论且产品代码有该路径；**UNVERIFIABLE** = 判据已就位、只差运行时；**FAIL-GAP** = 与判据不符、被证伪、或产品里没有可达路径。

| # | 本轮变化 | 三态 | 证据 |
|---|---|---|---|
| **B3** | D-01 的点击路径有了，但接缝断 | **FAIL-GAP** | 真实页面上 `ctx.remote.commands` 抛错 → 永停 running（§2.1a）；即便修好 inject，信封读错 → `failed/provider-error`（§2.1b）。`messageCount` 空真通道仍在（§4） |
| **B4** | 回退代码已在产品里 | **FAIL-GAP** | `store.finish(…, revertible)` + `decideRevert` + `store.clear` 都在（`client.js:1958/2203-2213`），但**没有任何一次成功写回**，`revertible` 在真机上不可达。离线用裸 `{text}` 答案喂，能到 `revertible` 且 `actions=["revert"]`——证明缺的是 transport，不是回退逻辑 |
| **B11** | 状态机/秒表/取消都在 | **部分成立（且有假绿风险）** | 离线：点击后 `data-state=running`、`elapsed` 递增（21→445 ms）、`actions=["cancel"]`、其余三颗 `aria-disabled=true`——三条观察都成立。但真实页面上它之所以"成立"，是因为请求根本没发出去、永远不结束。**B11 会假通过**，必须在 D-01 修好后重判 |
| **B12** | 取消路径完整 | **成立（离线）** | 实测：running → 点 cancel → `data-state=idle`、`elapsed=null`；`onCancel` 先 `controller.abort()` 再 `store.cancel`（`client.js:2194-2201`）；草稿不被触碰 |
| **B13** | `decideWriteBack` 进入产品路径 | **部分成立** | 决策函数在路径上（`client.js:1942`），`draftRev`/`text`/`references` 三项比对齐全（`lib/writeback.js:102-137`），离线测试通过；但真实页面上没有结果到达，红线无法被真正行使。**代码在、端到端不可达** |
| **B14** | 切会话/发送的宽容逻辑有了 | **FAIL-GAP** | `settle` 的 deferred（`client.js:1916-1925`）、`abortOnSend`（`:2155-2163`）都在；但 B14 的判据是 `command/run` 恰好 +1——请求根本没到宿主，计数不会增加 |
| **B15** | 失败态/悬停/重试都在 | **FAIL-GAP** | `REASON_TEXT` 八键齐全、`data-hover-text`/`data-reason-code` 都有（`client.js:1704-1766`）；但真机上唯一能到的"失败"是 §2.1(b) 的假失败（`provider-error` + `empty-result-text` 的 detail），而 inject 缺陷下连失败都到不了（永停 running） |
| **B16** | 回退/重试按 preset 隔离 | **部分成立** | `store.record(presetId)`/`store.clear(presetId)` + `kept` map（`client.js:2203-2227`）逻辑正确、离线可证；但同样因为一次成功写回都没有，端到端不可达 |
| **B8** | D-07 修好，`prepared.config` 与 `detail` 可得 | **UNVERIFIABLE（判据就位）** | 离线：`--prepare` 现在真的调 `llm.prepareCall`，`prepared.config` 来自宿主、与 `options` 一致；负向对照 `detail` 含毒化的 model 名。跟随模式的会话三元组现在走 `observeSession(...).projections`（D-06 成立）。剩下的只是"真实会话的 M1/S1" |
| **B9** | 同上 | **成立（离线判据）/ 仍需真机一次** | 实测固定模式：`options` 与 `prepared` 两处都是 `pinned-provider/pinned-model`，不出现会话值；负向对照同 B8 |
| **B10** | 强度回退可观察 | **部分成立** | 实测固定 `high` + 模型只支持 `low/medium`：`options.reasoningEffort=low`、`prepared.config.reasoningEffort=low`、`effortRequested=high`、`effortUsed=low`、`effortFallback=true`——B10 的前两个观察点现在都拿得到。但 `effortFallback` 来自 `previewEffort()`（宿主物化之前的预览），不是 `prepared.config` 的实测差；"随后真实改写成功一次"仍需运行时 |
| **B18** | 无变化（设置页仍只读） | **FAIL-GAP** | 设置页 19 个可改行渲染成 `h('span', {'data-settings-input':…}, …)`（`client.js:1799`），全文 `h('input')`=0、`onChange`=0、`onBlur`=0、`contentEditable`=0、`save-settings`=0；#20 回显读 `settings?.lastResult?.text`（`:2087`），而 `lastResult` 恒 `null`（`lib/settings.js:379` 只透传，`lib/host.js` 无写入点） |
| **B19** | 无变化 | **FAIL-GAP** | `countUnsaved` 在内联内核里存在（`client.js:1562`）但**没有任何调用点**；`unsavedCount` / `data-edit-gate` / `restore-default` 在 `client.js` 中均为 0 次 |
| **B20** | D-04 的规则修对，但触发条件不可达 | **部分成立 / 真机判红** | `seatPlan(false)` 正确（§2.2），但"设置不可用"在客户端被 `readSettings` 映射成 `settingsAvailable:true, settings:null` → 四颗全渲染。叠加 D-05 回归后，命名空间永远不匹配，真机上**必然**是这个态 |

**三态小结（本轮受影响的 14 个单元）**：成立 2（B12 离线；B9 离线判据，仍需真机确认一次）/ 部分成立 5（B11、B13、B16、B10、B20）/ UNVERIFIABLE 1（B8）/ FAIL-GAP 6（B3、B4、B14、B15、B18、B19）。

---

## 4. 背景前提核对（不计入本轮缺陷编号）

负责人给的背景是"D-02 / D-03 在修复轮开始前就已修好，修复者被告知不要动它们，确认它确实没动"。**"没动"成立**（代码与 `10` §4 描述一致、`lib/host.js:116-141` 逐字段 merge、`:743-746` `messageCount` 从 `null` 起步）；**"已修好"在我的复跑里不成立**：

**D-02（数据丢失）仍然复现**——走真实的 `resolveSettings`：

```text
config = { temperature: 0.3, timeoutMs: 90000 }
dispatch save-settings { timeoutMs: 60000 }
→ ok:true
→ overlay = { …, timeoutMs:60000, temperature:null, … }   # cloneSettings(null) 出的默认值
→ after: temperature = null, timeoutMs = 60000            # 0.3 丢了
```

`mergeSettings` 是逐字段的（`:116-141`），但 `save-settings` 的基线仍是 `state.overlay()`，而它初始是 `null`（`createHost` 的 `let overlay = options.overlay ?? null`）→ `mergeSettings(null, patch)` = 默认值 + patch → 再盖到 config 上。**根因没变**。

**D-03（`messageCount` 空真）仍然复现**：

```text
readSurface → {}（畸形快照）
→ readEvents 返回 []（lib/host.js:573 `Array.isArray(snapshot?.events) ? snapshot.events : []`）
→ Array.isArray([]) 为真 → messageCount = 0
实测：malformed → 0；正常 events:[{},{}] → 2
```

`messageCount` 从 `null` 起步只挡住了"没有 sessionId"这一支；"返回畸形"仍然给 `0`。

> 这两条按指示**不当新缺陷记**，但它们是 B3 证据链的一部分，且 D-02 是数据丢失级。请负责人重新裁定"已修"这个前提。

---

## 5. 未修项的判断

| 项 | 是否阻断进 P4 | 理由 |
|---|---|---|
| **D-15 / D-16**（#20 `lastResult` 恒 `null`） | **单独不阻断，但被 B18 吞掉** | #20 回显永远空是 B18 的一个观察点；但 B18 还有更大的缺口——19 个可改项根本没有输入控件、没有保存调用。所以"先修 #20"不足以让 B18 通过；反过来，只要 B18 整体不实现，D-15/16 修不修都不改变 P4 结论。**它需要的是"回显归属"的设计裁定 + 写路径，不是一行代码** |
| **D-12**（`01 §4` 的 E2 命令清单与真实形态不符） | **不构成代码阻断，但构成 P4 走查的操作阻断** | P4 是操作者按文档跑命令。现在 `/draft-studio dump-request …` 跑不通，唯一能跑的是手算 `/lab-draft <base64url>`。建议二选一：回写 `01 §4`，或给 `decodeLine` 加短形态；并在 P4 脚本里附一个可直接复制的命令生成器 |
| **D-11**（"设置只从本插件 Config 读"需真机） | **已不是"需真机"，而是静态坏了** | D-05 的回归把 `configForms.get` 的 id 改成了 `include:`，设置命名空间永远匹配不上（§2.3）。这条不能留到 P4——真机第一次打开设置页就会看到空值 |
| **B18 / B19 整体**（设置页编辑） | **阻断** | 不是"差一次实测"，是"还没写"：没有输入控件、没有保存、没有未保存计数、没有恢复默认。P4 走查这两条必然全红 |

---

## 6. 放行意见

### **不可进 P4。**

理由不是"测试不够绿"（174 条全绿是真的、9 个变异是真的），而是**产品路径上还有两条静态可证的传输缺陷 + 一处反向修复**，它们会让 P4 窗口再次空转：

1. 点一下按钮 → `ctx.remote.commands` 抛错 → 按钮永远 running（B3/B4/B11–B16 全部不可判）；
2. 就算修好 inject → 答案信封读错 → 每次点击假失败（B3/B4 仍然不可判）；
3. 设置命名空间 id 被改错 → 设置页永远空、四颗按钮全渲染、总开关失效（B1-b/B1-c/B18/B19/B20 全部带红）。

### 修完这四条就能改判（都不是大改）

1. **inject 补子路径**：`client.js:1815` 改成 `inject: ['slots','locale','configForms','remote','remote.commands']`（或把点击路径包进 `ctx.inject(['remote.commands'], …)`）；同时改 `test/client.test.js:161` 的断言，否则测试会把缺陷钉死。
2. **按 gateway 信封解答案**（`client.js:2007-2039`）：
   - `answer?.ok === false` → 用 `answer.error` 落失败；
   - `answer?.value === undefined` → `unknown-or-malformed-command`；
   - `answer.value.result.kind === 'error'` → 用 `result.text` 落失败；
   - `decodeResult(answer.value.result.text)` 才是成功路径。
   并把 `test/client.test.js:742-747` 的 fake 改成真实信封形状（否则"端到端"测试继续自证）。
3. **D-05 回退**：`entryId` 回到裸 patchId；回写 `01 §9` / `02 D18` / `06 U7` 的错误预期。
4. **让降级可触发**：`readSettings` 把 `snapshot.status !== 'ready'` 也判成 `settingsAvailable: false`，这样 B20 的"一颗按钮"才会在真实页面上出现。

### 条件（具体到用户行为）

- **用户不得安装本轮产物**：点按钮会永久转圈（不报错、不结束），设置页打开是空的。
- **在 1、2 修好前，不得安排任何人做 B3/B4/B11–B16 的现场走查**——走查必然全红，且 B11 会假绿，浪费一次 P4 窗口。
- **在 3 修好前，不得让任何人打开设置页**——看到的是 19 行空值 + 没有横幅，会被误记成"插件坏了"。
- **B18/B19 需要一个明确裁定**：要么在进 P4 前实现设置编辑，要么在 `01 §9` 里正式降级为 P4 之外的范围，并写进签收单。不要带着"未实现"进 P4 再记两条红。
- **B1-e / 页面几何仍必须真机走查一次**（Client Inspect 本轮再次 10 秒超时），不影响放行判定，但 P4 签收要写明"activity 展开态未验"。

### 可以带进 P4 的部分（这些是真实的）

- 内联 + 生成器 + `--check` 的架构（手改会红、`lib` 改动会红）；
- `lib/run-store.js` 的状态机（idle/running/revertible/retry-pending/failed、单活跃 run、token 防迟到、取消回 idle）；
- `lib/writeback.js` 的写回决策（rev/text/reference 三重守卫、revert 安全判定）；
- D-06 的 `observeSession` 投影读取、D-07 的 `detail` 透出（Host 面）、D-08 的两头缺失拒绝、D-09 的 `assert-preset.mjs`；
- 174 条测试与 9 个变异装置本身（这是本轮最扎实的资产，下一轮继续用）。

---

## 7. 附：本轮我跑过的命令与证据文件

```text
# 独立复跑（bundle-lab/，复跑前后 28 个文件 SHA-256 一致）
cd bundle-lab
node --test "test/*.test.js"                  # 174/174
node scripts/check-syntax.mjs                 # 20 files, 0 failure
node scripts/build-client.mjs --check         # ok
node scripts/mutate.mjs                       # 9/9 red → green

# 手工改内联区（%TEMP%\p35-copy 副本，不动 bundle-lab）
node scripts/build-client.mjs --check         # FAIL … stale (exit=1)
node --test --test-name-pattern="kernel region is current" …   # 红

# 行为探针（只 import bundle-lab 的公开导出 / 只读 app.asar）
node %TEMP%\p35-probe\probe-envelope.mjs      # 点击离开 idle；真实信封 → failed/provider-error
node %TEMP%\p35-probe\probe-envelope2.mjs     # 四种答案形状喂真实 decodeResult
node %TEMP%\p35-probe\probe-behaviour.mjs     # D-07 detail / B20 null preset / D-02 / D-03 / D-08 / D-04 / D-06
node %TEMP%\p35-probe\probe-more.mjs          # D-02 走真实 resolveSettings；cancel 回 idle；B19 符号计数
node %TEMP%\p35-probe\probe-settings.mjs      # readSettings 对 unavailable namespace 的映射
node %TEMP%\p35-probe\probe-b9b10.mjs         # B9/B10：pinned + effort 回退
node %TEMP%\p35-probe\probe-seams.mjs         # inject 抛错后按钮永停 running；四颗全渲染
node %TEMP%\p35-rt\probe-inject4.mjs          # 用安装包里的 cordis 4.1.0 复现 "without inject"

# 宿主契约（只读）
cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})    # 15 方法，无 modelSelection
cordis_inspect_query(host, Config, listConfigs, {offset:0,limit:12})         # id=include:<patchId>, patchId=<patchId>
cordis_inspect_query(client, Service, listService, {service:"configForms"})  # 超时 10s

# 安装包原文（只读，只往 %TEMP% 写）
probe-tools\asar-grep.ps1  -Pattern … -Prefix dsh/node_modules/@deepseek-ai/… 
probe-tools\asar-probe.ps1 -Get … -OutDir %TEMP%\…
```

**未做**：未安装、未写 `$DSH_HOME`、未修改 `bundle-lab/` 任何文件。
