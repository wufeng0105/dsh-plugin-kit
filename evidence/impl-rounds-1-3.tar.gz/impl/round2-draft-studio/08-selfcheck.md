# 08 自检 — P2 最小切片（`bundle-lab/`）

> 版本：2026-11-08。对象：`bundle-lab/`（138 条测试）+ `01`/`02`/`probes.md` 的回写。
> 纪律：**本文件严格区分「已离线证」「需运行时验」「未做」，不把离线结果写成运行时结论。** 本轮未安装、未碰 `$DSH_HOME`、未写真实 profile，因此**没有一条验收是运行时已验**。
> 三态定义：
> - **已离线证** = 逻辑在本机命令下可复现二值结果（`node --test` / `node --check` / 源码比对）；
> - **需运行时验** = 判据已就位、代码路径存在，但必须装到真实 Host/页面才能观测；
> - **未做** = 本轮切片明确不做（见 `07` §2）。

---

## 1. 测试原文

### 1.1 语法检查

```powershell
cd bundle-lab
node scripts/check-syntax.mjs
```

```text
ok   client.js (classic script)
ok   index.js (module)
ok   lib/boundary.js (module)
ok   lib/context.js (module)
ok   lib/guard.js (module)
ok   lib/host.js (module)
ok   lib/llm-options.js (module)
ok   lib/prompt.js (module)
ok   lib/request.js (module)
ok   lib/run-store.js (module)
ok   lib/schema.js (module)
ok   lib/settings.js (module)
ok   lib/sha256.js (module)
ok   lib/wire.js (module)
ok   lib/writeback.js (module)
ok   scripts/check-syntax.mjs (module)

16 file(s) checked, 0 failure(s)
```

等价的原生命令（要求里点名的 `node --check`）：

```powershell
node --check index.js          # exit 0
node --check client.js         # exit 0
Get-ChildItem -Recurse -Filter *.js | ForEach-Object { node --check $_.FullName }   # 全部 exit 0
```

> `client.js` 用 `node --check` 也过，但它是 **classic script**（`window.__ModuleLoader__.load(...)`），页面用脚本方式求值。`scripts/check-syntax.mjs` 按 `new Function(source)` 再验一次，避免"模块能解析、脚本不能"的盲区。

### 1.2 测试（完整输出）

```powershell
node --test "test/*.test.js"
```

```text
✔ client.js registers one factory under the lab package name (1.2453ms)
✔ the factory declares the three services it uses and exposes apply() (0.879ms)
✔ apply registers four seats into conversation.input.right with distinct lab ids (B1-a) (0.5775ms)
✔ apply registers the settings page under the lab id (0.3342ms)
✔ every registration carries a locale namespace (0.2794ms)
✔ the seat publishes every attribute the acceptance fragment reads (0.8476ms)
✔ an empty or whitespace-only draft renders no seat at all (B1-d, B2) (0.2621ms)
✔ the master switch off hides every seat even though all four are ticked (B1-c) (0.1899ms)
✔ an unticked preset renders no seat, while the ticked ones do (B1-b) (0.4725ms)
✔ an unreadable settings service still renders one usable seat (B20) (0.285ms)
✔ the client draft predicate agrees with lib/boundary.js on every case (B2) (0.224ms)
✔ the client placeholder counter agrees with lib/boundary.js (B21) (0.2262ms)
✔ the client label validator agrees with lib/settings.js (B7) (0.2668ms)
✔ the client visible-seat rule agrees with lib/request.js (B1-b, B1-c, B6) (0.2399ms)
✔ the client write-back verdict table agrees with lib/writeback.js (B13, B21) (0.3342ms)
✔ the client and kernel agree that a discarded run is not a failure (0.1641ms)
✔ the client code-point counter agrees with lib/settings.js (0.1145ms)
✔ the settings page renders 20 rows: 19 editable plus one read-only readout (B18) (0.4007ms)
✔ the settings row keys match the kernel spec, one for one (0.2336ms)
✔ the spec counts the kernel reports and the page renders agree (0.1586ms)
✔ the settings page says so when the Host settings are unreachable (B20) (0.1981ms)
✔ the client declares zh and en baselines for the title and the seat actions (0.2386ms)
✔ the client locale files on disk carry the same title as the runtime baseline (0.3322ms)
✔ the client reads its entry id from the published global, never from a package name (0.1433ms)
✔ reason hover text covers every reason code the kernel can emit (B15) (0.1555ms)
✔ sha256 matches the FIPS-180-4 vectors (B5 depends on this) (0.9224ms)
✔ sha256 hashes UTF-8, so a Chinese preset body hashes like the bytes the Host sends (0.2457ms)
✔ sha256 accepts raw bytes and mixes long inputs across many blocks (0.2868ms)
✔ the four preset ids are exactly the ones 01 §2 fixes (0.1875ms)
✔ each structure block is copied verbatim from 01 §3-B5 (B5-a) (0.3534ms)
✔ every built system prompt contains its own structure block (B5-a) (0.2197ms)
✔ the four system prompts hash pairwise differently (B5-b) (0.2275ms)
✔ the marker line names the preset the request asked for (B5-c, catches a crossed table) (0.1962ms)
✔ a user-edited prompt body replaces the built-in body but keeps the structure block (0.1724ms)
✔ an empty or whitespace prompt body means "restore the built-in" (01 §5 #6–#9) (0.2195ms)
✔ buildSystemPrompt refuses an unknown preset instead of guessing (0.1142ms)
✔ resolvePresetId degrades an unknown id to general and says it did (0.1242ms)
✔ a rename changes the display name but never the system prompt (B7) (0.2507ms)
✔ flattenEvent keeps conversational text and drops tool traffic (0.1448ms)
✔ assembleContext keeps the newest N rounds and reports how many it dropped (0.2415ms)
✔ assembleContext drops from the oldest end to satisfy the character budget (0.3277ms)
✔ assembleContext keeps at least the newest message even when it alone overflows (0.2353ms)
✔ assembleContext explains every empty result instead of returning bare [] (0.3077ms)
✔ clampBudget clamps into range and reports the move (0.1967ms)
✔ renderContextSection is empty when there is nothing to send (0.6202ms)
✔ readout reports rounds, chars and the reason for the readout row (§5 #20) (0.2351ms)
✔ a whitespace-only draft is empty, including the full-width space (B2) (0.2928ms)
✔ reference placeholders are counted across the Host sentinel range (B21) (0.2573ms)
✔ a leading slash command is detected, a mid-text slash is not (B21) (0.1416ms)
✔ classifyDraft returns the raw draft untouched (B4 needs the untrimmed text) (0.1519ms)
✔ a clean run writes the result back and lands in revertible (0.2332ms)
✔ a draft that moved during the wait is never overwritten (B13, second red line) (0.3352ms)
✔ a sent draft discards the late result instead of writing (B14, A7) (0.2507ms)
✔ an empty result is a failure, never a silent erase (A12) (0.213ms)
✔ a result that lost a reference placeholder is held back (B21) (0.2101ms)
✔ spanStillValid refuses a span the draft has moved around (0.1878ms)
✔ revert restores only our own write (B4, B16) (0.1952ms)
✔ the spec is 20 items: 19 editable plus one read-only readout (B18, A13) (0.1372ms)
✔ writing the read-only readout is rejected, not ignored (B18 negative case) (0.1283ms)
✔ an unknown settings key is rejected so a typo cannot pass silently (0.0989ms)
✔ a timeout below 30 seconds is refused and the old value survives (B17 negative) (0.1703ms)
✔ one invalid field rejects the whole patch (all-or-nothing) (0.1286ms)
✔ a display name is limited to 12 code points (B7) (0.1779ms)
✔ an empty prompt means "restore the built-in", not "store an empty string" (0.1723ms)
✔ a nested preset patch and its flattened form accept the same thing (0.1707ms)
✔ an unknown preset id in a patch is rejected (0.1246ms)
✔ visible presets are stored in canonical seat order and de-duplicated (B1-b) (0.1384ms)
✔ unsaved count is the number of changed fields across 4 presets, de-duplicated (B19) (0.163ms)
✔ a pinned model with a missing half does not count as usable (§7-A8) (0.1258ms)
✔ a whitespace-only draft is refused at the request boundary (B2) (0.1678ms)
✔ a non-string draft is refused rather than coerced (0.1053ms)
✔ an unknown preset id falls back to general with a soft notice (B15 fallback) (0.1472ms)
✔ a draft longer than the wire cap is refused with a typed reason (0.0992ms)
✔ the master switch hides every seat; the ticked set survives for later (B1-c, B6) (0.1448ms)
✔ an unreachable settings service degrades to exactly one general seat (B20) (0.1394ms)
✔ follow mode uses the session triple verbatim (B8) (0.1721ms)
✔ pinned mode ignores the session selection entirely (B9) (0.1442ms)
✔ a pinned model that is gone degrades to follow instead of failing (§7-A8) (0.1199ms)
✔ composeLlmOptions throws rather than inventing a route when nothing is readable (0.1013ms)
✔ temperature and maxTokens ride along only when they are set (§5 #18/#19) (0.1242ms)
✔ normalizeRoute drops empty efforts and rejects half routes (0.1104ms)
✔ an unsupported effort falls back to the model default before I/O (B10) (0.1421ms)
✔ an unrequested effort is left alone and is not reported as a fallback (0.1119ms)
✔ makeConfigure rewrites the controls the way resolveEffort decided (B10) (0.1586ms)
✔ only one run is active at a time; a second start is refused (B11) (0.1427ms)
✔ elapsed time grows from the caller clock, so the seat shows real seconds (B11) (0.1041ms)
✔ a late result whose token is stale is ignored (B13/B16 race guard) (0.1018ms)
✔ cancel returns to idle and keeps nothing (B12) (0.0904ms)
✔ sending the draft stops the run and drops its result (B14 / A7) (0.1101ms)
✔ a finished run shows on its own seat only, and other seats are blocked (B11/B16) (0.1336ms)
✔ a run in another session does not block this session seat (B14) (0.1088ms)
✔ a failure settles with one of the six documented reason codes (B15) (0.1246ms)
✔ the running seat reports elapsed ms and only that seat is running (B11) (0.1108ms)
✔ a line round-trips any draft, including newlines and chip placeholders (0.4468ms)
✔ an 8000-character draft survives the wire unchanged (U3) (0.7163ms)
✔ decodeLine reports typed errors instead of throwing (0.2343ms)
✔ base64url round-trips arbitrary bytes without padding or +/ (0.1324ms)
✔ a result round-trips through CommandResult.text (0.2004ms)
✔ a failed result reports ok:false and keeps its reason code (0.0835ms)
✔ the guard accepts exactly a same-origin POST with the token (0.1691ms)
✔ the guard refuses a request with no token — the exact hole 06 §4 found (0.1013ms)
✔ the guard refuses a wrong method, a wrong path and a wrong origin (0.0906ms)
✔ the guard refuses a cross-site browser request even with a stolen token (0.0857ms)
✔ the guard fails closed when no token was ever armed (0.0782ms)
✔ the guard treats an absent fetch metadata block as not-same-origin-verified (0.1043ms)
✔ refusals are silent: no reason leaks into a response body (0.0833ms)
✔ readHeader works with a Headers-like object and with a plain map (0.0877ms)
✔ a generated token is non-empty and unique per call (0.0943ms)
✔ dump-request carries the system, its hash, and the marker for that preset (B5) (0.2381ms)
✔ the four dump-request payloads hash pairwise differently (B5-b) (0.2336ms)
✔ dump-request reports the composed route for follow and pinned (B8/B9) (0.1977ms)
✔ the negative switches poison the field so the Host has to prove it arrived (0.1758ms)
✔ dump-request reports effortFallback when the model rejects the effort (B10) (0.1703ms)
✔ an unknown preset in dump-request degrades to general and says so (0.1669ms)
✔ readConfig tolerates plain and volatile fields, and unset sentinels (0.2503ms)
✔ resolveSettings clamps a hand-edited config instead of refusing to load (0.2336ms)
✔ a hand-edited config keeps the fields that are fine (clamping is per field, not all-or-nothing) (0.1631ms)
✔ a settings overlay is applied after the config and before validation (0.1547ms)
✔ the self-test env channel is off unless explicitly enabled (B17) (0.2129ms)
✔ the effective timeout reports its source so dump-settings can prove it (B17) (0.1859ms)
✔ dispatch(dump-settings) reports the settings, the visible seats and the timeout source (0.4915ms)
✔ dispatch(refine) with an empty draft fails with empty-result and does not call the model (0.2917ms)
✔ dispatch(dump-draft) counts placeholders and reads messageCount from the surface (B3/B21) (0.2317ms)
✔ dump-draft reports messageCount null when the surface cannot be read (B3 → 无法判定) (0.2141ms)
✔ dispatch(save-settings) refuses honestly when no write path is wired (0.2383ms)
✔ dispatch(save-settings) refuses an invalid patch before it reaches the write path (0.1857ms)
✔ dispatch(save-settings) applies the patch after a successful persist and keeps it for the next read (0.2779ms)
✔ dispatch(unknown action) is a typed failure (0.1738ms)
✔ runRefine returns the text and metadata when the model answers (0.9634ms)
✔ runRefine classifies an empty model answer as empty-result (A12) (0.2955ms)
✔ runRefine classifies a provider error chunk as provider-error (B15) (0.2923ms)
✔ runRefine times out on its own clock and reports the timeout source (B17) (75.8571ms)
✔ runRefine reports settings-unavailable when no route can be composed (B20) (0.3087ms)
✔ runRefine honours the caller abort signal as aborted, not as a timeout (B12) (0.8897ms)
✔ runRefine includes the assembled context in the user turn (0.7978ms)
✔ runRefine without context sends just the draft (0.4217ms)
✔ createConfigSchema marks every editable field volatile (0.4231ms)
✔ createConfigSchema refuses a z that lacks the builders it needs (0.2217ms)

ℹ tests 138
ℹ suites 0
ℹ pass 138
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 244.4167
```

> 说明：每个用例后的 `(x.xxms)` 是**某一次运行**的耗时，随机器波动（复跑时 `duration_ms` 在 240–260ms 之间）；用例名与 pass/fail 计数是稳定的。复跑核对方式：把上面 138 个 `✔` 名字与本文档逐条比对（本轮已用脚本核对：`doc missing actual names: 0`）。

### 1.3 分文件计数

```text
node --test test/core.test.js    → tests 113 / pass 113 / fail 0
node --test test/client.test.js  → tests  25 / pass  25 / fail 0
```

---

## 2. 本轮实跑的其他证据（非测试）

| # | 命令 | 输出 | 用于 |
|---|---|---|---|
| E-1 | `Get-NetTCPConnection -State Listen \| ? LocalPort -in 6727,6728,6729,8326,8314` | `127.0.0.1 6727/6728/6729/8326 → pid 17760`；**8314 无行** | `02` §3-U4 的"端口不许写死"（P29-1） |
| E-2 | `Invoke-WebRequest` 打 6727 的 `/`、`/api/nope`、`/__probe_no_route__` | `401 len=68` / `401 len=12` / `404 len=0` | 鉴权层正常应答 ⇒ **Client Inspect 超时不是"页面没开"**（P3 归因修正） |
| E-3 | `cordis_inspect_query(client, Slots, listSubTree, {root:"conversation.input.right"})` | `timed out after 10000ms` | 累计第 9 次零成功；不再重试同形态 |
| E-4 | `cordis_inspect_query(host, Service, listService, {service:"commands"})` | `execute(agent, line, submittedAttachments, signal)`；`CommandInvocation` 无模型字段；`CommandResult = success{text?} \| error{text}` | `lib/host.js` 的命令注册与结果编码形状 |
| E-5 | `cordis_inspect_query(host, Service, listService, {service:"llm"})` | `prepareCall(config, signal?, configure?) → PreparedLlmCall{config, stream()}`；`ConfigureCall = (controls, model) => LlmCallControls`；`GenerateOptions{provider,model,reasoningEffort?,messages,system?,temperature?,maxTokens?,signal?,sessionId?}` | `lib/host.js` 的 `runRefine` 与 `lib/llm-options.js` 的 `makeConfigure` |
| E-6 | `cordis_inspect_query(host, Service, listService, {service:"webServer"})` | `register(route) → disposer`；`WebRoute{kind:'exact'\|'prefix', path, handler(req,res)}` | 降级 A 的 `mountRoute` 形状 |
| E-7 | 只读读 `profiles/desktop/node_modules/dsh-draft-studio/{client.js,index.js}` | `client.js` 114,275 B，座位 `id:'dsh-draft-studio'`/`order:60`，设置页同 id；`index.js` 有 `webServer.register`（偏移 39,671）、**0 处 `commands.register`** | 并存裁定必须改名（P29-5） |
| E-8 | 源码级座位复核（`probe-tools/dump/ui-conversation-client.js`，921,756 字符） | `"conversation.input.right": { kind:"list", scope:"session" }`（偏移 915,959）；`standardControls { hidden: activity }` 内 `right` 在 `model` 之前（≈883,6xx）；`uiSession.provide({hooks, props:["inputActions"]})`（909,686）；`insertText` 的 `draftRev` 守卫（533,5xx）；`data-composer-dock`(887,851) / `data-composer-input`(824,861) | `lib/host.js`/`client.js` 的插槽与写回契约（P29-4） |

---

## 3. 改坏 → 红 → 改回 → 绿（原始输出）

三组，覆盖三条不同的红线。命令都在 `bundle-lab/` 下执行。

### 3.1 B5 串台：`lib/prompt.js` 的 coding 结构块首行改成 `preset=translate`

```text
ℹ tests 113
ℹ pass 110
ℹ fail 3
✖ each structure block is copied verbatim from 01 §3-B5 (B5-a)
✖ the marker line names the preset the request asked for (B5-c, catches a crossed table)
✖ dump-request carries the system, its hash, and the marker for that preset (B5)
```

改回后：`ℹ tests 113 / ℹ pass 113 / ℹ fail 0`。

### 3.2 B13 守卫：`lib/writeback.js` 把 `revChanged` 写死 `false`

```text
ℹ tests 138
ℹ pass 136
ℹ fail 2
✖ a draft that moved during the wait is never overwritten (B13, second red line)
✖ the client write-back verdict table agrees with lib/writeback.js (B13, B21)
```

改回后：`ℹ tests 138 / ℹ pass 138 / ℹ fail 0`。

> 这条同时证明了镜像一致性测试的价值：改动内核后**客户端那份镜像也被追平**（它抽的是客户端源码文本，与内核行为比对），所以 B13 的红是双份的。

### 3.3 R10 守卫：`lib/guard.js` 删掉 token 比对（等价于 `06` §4 实测的洞）

```text
ℹ tests 113
ℹ pass 111
ℹ fail 2
✖ the guard refuses a request with no token — the exact hole 06 §4 found
✖ the guard treats an absent fetch metadata block as not-same-origin-verified
```

改回后：`ℹ tests 113 / ℹ pass 113 / ℹ fail 0`。

---

## 4. B1–B21 逐条三态

> 口径：**已离线证**只覆盖"逻辑/结构"，不等于验收通过。凡判据含"页面上看到…"的一律是**需运行时验**。
> "离线证据"列给测试用例名（`test/core.test.js` 或 `test/client.test.js`）或 `文件:行`。

| # | 验收条目 | 三态 | 离线证据 | 运行时还差什么 |
|---|---|---|---|---|
| **B1-a** | 总开关开、四套全勾、非空草稿 → `count === 4`、`ids` 四个 | **已离线证（结构面）/ 需运行时验（页面面）** | `apply registers four seats … distinct lab ids (B1-a)`：注册 4 条、id 全等 `lab-draft-<presetId>`、order 0–3、互异；`an unticked preset renders no seat…` 证可见集 | 页面上 `count===4`、`ids` 集合相等需 §4 片段 |
| **B1-b** | 勾选数决定颗数 | **已离线证** | `visible presets are stored in canonical seat order…`、`an unticked preset renders no seat, while the ticked ones do` | 同上（`count===2`） |
| **B1-c** | 总开关关 → `count === 0` | **已离线证** | `the master switch hides every seat…`、`the master switch off hides every seat even though all four are ticked` | 同上 |
| **B1-d** | 草稿空 → `count === 0` | **已离线证** | `an empty or whitespace-only draft renders no seat at all` | 同上 |
| **B1-e** | 位置：模型左侧、行内、不在 dock、不压编辑区 | **需运行时验**（几何量） | 无（几何只能从页面取）；代码路径不涉及布局 | **全部**：`seatRects`/`rowRects`/`modelFound`/`inDock`/`visible`/`hiddenByActivity`/`editorOverlap` |
| **B2** | 纯空白草稿不反应（含 `\u3000`） | **已离线证** | `a whitespace-only draft is empty, including the full-width space (B2)`、`a whitespace-only draft is refused at the request boundary (B2)`、`client draft predicate agrees with lib/boundary.js on every case (B2)` | 页面 `count===0` |
| **B3** | 点按钮 → 写回、不发送 | **需运行时验** | 部分：`runRefine returns the text and metadata…`（装配与分类）、`dispatch(dump-draft) … messageCount`（证据源就位）、`dump-draft reports messageCount null …`（无法判定通道） | **全部**：真实 `insertText`、`messageCount` 前后相等、`editorPhase` 不含 `submitting/sending` |
| **B4** | 回退逐字还原 | **需运行时验** | 部分：`revert restores only our own write (B4, B16)`、`classifyDraft returns the raw draft untouched (B4 needs the untrimmed text)` | 真实 `setDraft`/撤销栈；Ctrl+Z 附加观察 |
| **B5** | 四套预设各自生效（请求侧 3 条 + 输出侧谓词） | **已离线证（判据 1 全部）/ 需运行时验（判据 2、3）** | 判据 1(a)(b)(c) 各有测试：`each structure block is copied verbatim…`、`the four system prompts hash pairwise differently (B5-b)`、`the marker line names the preset…(B5-c)`、`dump-request … (B5)`、`the four dump-request payloads hash pairwise differently (B5-b)` | 真实 `dump-request` 四段输出的**命令+输出**；判据 2 需真实模型改写稿 + `scripts/assert-preset.mjs`（**本轮未写该脚本**，属 S4/P3） |
| **B6** | 取消勾选不丢预设 | **已离线证（语义）/ 需运行时验（持久化）** | `the master switch hides every seat; the ticked set survives for later (B1-c, B6)`（隐藏不删预设） | 保存-重读往返（需 Config 写路径，见 `07` S-3） |
| **B7** | 改名只改显示 | **已离线证** | `a rename changes the display name but never the system prompt (B7)`、`a display name is limited to 12 code points (B7)`、`client label validator agrees with lib/settings.js (B7)` | 页面 `labels` 字段变化；`dump-request` 两次 sha256 相同（需活体） |
| **B8** | 跟随模式用会话模型 | **已离线证（装配）/ 需运行时验（物化）** | `follow mode uses the session triple verbatim (B8)`、`dump-request reports the composed route for follow and pinned (B8/B9)`、`the negative switches poison the field…` | `prepared.config`（宿主物化）+ 负向对照的宿主错误文本 |
| **B9** | 固定模式用固定值 | **已离线证（装配）/ 需运行时验（物化）** | `pinned mode ignores the session selection entirely (B9)`、同上 dump-request 用例 | 同上 |
| **B10** | 不支持强度自动退回 | **已离线证（决策）/ 需运行时验（真实模型）** | `an unsupported effort falls back to the model default before I/O (B10)`、`makeConfigure rewrites the controls…(B10)`、`an unrequested effort is left alone…`、`dump-request reports effortFallback…(B10)` | `modelCatalog` 差集证明 + `prepared.config.reasoningEffort === defaultEffort` |
| **B11** | 一颗在跑其余置灰、秒表递增、有取消 | **已离线证（状态机）/ 需运行时验（DOM）** | `only one run is active at a time…(B11)`、`elapsed time grows from the caller clock…(B11)`、`the running seat reports elapsed ms and only that seat is running (B11)`、`a finished run shows on its own seat only…(B11/B16)` | `ariaDisabled`/`elapsedMs` 两次采样差 ≥900ms/`actions` 含 `cancel` |
| **B12** | 运行中可取消、草稿不变 | **已离线证（状态）/ 需运行时验（真实取消）** | `cancel returns to idle and keeps nothing (B12)`、`runRefine honours the caller abort signal as aborted, not as a timeout (B12)` | 2 秒内回 idle；abort 是否真传到 `invocation.signal`（U2 未测） |
| **B13** | 结果绝不覆盖新输入 | **已离线证（决策）/ 需运行时验（端到端）** | `a draft that moved during the wait is never overwritten (B13, second red line)`、`spanStillValid refuses a span the draft has moved around`、`a late result whose token is stale is ignored (B13/B16 race guard)`、`client write-back verdict table agrees…(B13, B21)` | 真实"等待期打字"竞态 |
| **B14** | 切会话/发送的并发宽容 | **已离线证（状态）/ 需运行时验（端到端）** | `a run in another session does not block this session seat (B14)`、`sending the draft stops the run and drops its result (B14 / A7)` | `command/run` 计数 +1；发送后晚到结果不写回 |
| **B15** | 失败态：悬停原因、可重试、六值枚举 | **已离线证（枚举与文案）/ 需运行时验（真实失败）** | `a failure settles with one of the six documented reason codes (B15)`、`reason hover text covers every reason code…(B15)`、`runRefine classifies a provider error chunk as provider-error (B15)`、`an unknown preset id falls back to general with a soft notice (B15 fallback)` | `hoverText` 非空且等于对应文案、无英文栈；`command/run` +1 |
| **B16** | 回退/重试只作用于自己那次 | **已离线证（记录隔离）/ 需运行时验（DOM）** | `a finished run shows on its own seat only…(B11/B16)`、`revert restores only our own write (B4, B16)` | `actions` 有无 `revert`；点击瞬间文本不变 |
| **B17** | 超时 | **已离线证（路径与来源）/ 需运行时验（真实验收路径）** | `runRefine times out on its own clock and reports the timeout source (B17)`、`the self-test env channel is off unless explicitly enabled (B17)`、`the effective timeout reports its source…(B17)`、`a timeout below 30 seconds is refused…(B17 negative)` | 30 秒慢请求路径；`command/done` 与 `command/run` 成对；`dump-settings` 的 `timeoutMs: 480000` |
| **B18** | 设置页 19 可改 + #20 只读 + 改完即时生效 | **已离线证（结构）/ 需运行时验（生效）** | `the spec is 20 items…(B18, A13)`、`the settings page renders 20 rows…(B18)`、`writing the read-only readout is rejected…(B18 negative case)`、`the settings row keys match the kernel spec…`、`dispatch(save-settings) applies the patch after a successful persist…`（即时生效的机制面） | 逐项保存后 `dump-settings` 反映新值；不重启不刷新 |
| **B19** | 预设编辑门 + 未保存计数 | **已离线证（计数）/ 未做（编辑门）** | `unsaved count is the number of changed fields across 4 presets, de-duplicated (B19)` | 编辑门（默认只读/解锁/自动上锁）属 S6 交互，本轮**未做**；计数语义已验证 |
| **B20** | 设置不可用时降级一颗按钮、不报错 | **已离线证** | `an unreachable settings service degrades to exactly one general seat (B20)`、`an unreadable settings service still renders one usable seat (B20)`、`the settings page says so when the Host settings are unreachable (B20)`、`runRefine reports settings-unavailable when no route can be composed (B20)` | 页面无红色报错；点击仍能改写（需活体） |
| **B21** | 芯片边界（`/` 与 `@`） | **已离线证（判定与降级）/ 需运行时验（重建）** | `reference placeholders are counted…(B21)`、`a result that lost a reference placeholder is held back (B21)`、`a leading slash command is detected…(B21)`、`an 8000-character draft survives the wire unchanged (U3)`、`client placeholder counter agrees with lib/boundary.js (B21)` | 引用节点仍可点；`dump-draft` 的 `references` 前后一致；`/` 芯片不被破坏 |

### 4.1 三态分布

| 态 | 条数 | 条目 |
|---|---|---|
| **已离线证（判定/结构层）** | **3** | B2、B7、B20 |
| **已离线证（部分面）+ 需运行时验** | **17** | B1-a、B1-b、B1-c、B1-d、B3、B4、B5、B6、B8、B9、B10、B11、B12、B13、B14、B15、B16、B17、B18、B21（其中 B5/B8/B9/B10/B17 的"请求侧"面已完全离线证） |
| **需运行时验（无非离线面）** | **1** | B1-e（纯几何） |
| **未做** | **1**（B19 的编辑门交互子项） | B19 |

> 计数说明：B1 拆成 a–e 五条后，B1-a～d 各计一条、B1-e 单列，所以上表有 21 行整（3 + 17 + 1 = 21 行含 B19 子项标注）。**没有一条是「运行时已验」**——这是本轮"不许安装"的直接后果，不是遗漏。

### 4.2 因"不许安装"而无法离线证的（明示清单）

1. **B1-e 的全部几何字段**（`modelRect`/`rowRects`/`inDock`/`visible`/`hiddenByActivity`/`editorOverlap`/`leftOfModel`）——只能从真实 DOM 取。
2. **`command/run|done` 的条数**（B11 置灰时"点击后不增加"、B14 的"+1"、B15 的重试"+1"、B16 的"+1"）——需要真实命令通道日志。
3. **B8/B9/B10 的 `prepared.config`**——需要真实 `llm.prepareCall` 物化。
4. **B3 的 `messageCount` 前后相等**——需要真实 `sessionQuery.readSurface`。
5. **B12 的"2 秒内回 idle"**——需要真实传输与取消传播（U2 运行时项）。
6. **B17 的 30 秒路径与 `command/done` 成对**——需要真实超时。
7. **B18 的"改完即时生效"**——需要真实 Config 写路径（本轮 `save-settings` 在没有写路径时**返回失败**，不是假装成功）。
8. **B21 的引用节点仍可点**——需要真实芯片 DOM。
9. **U1-② 的 activity 展开态现场记录**——Client Inspect 累计 9 次超时、无浏览器控制；已按 `01` §8.5 记客户知情项，待 P4 签收。
10. **U2/U3 的运行时部分**（60s 长 unary、abort 传播、8000 字符回显）——本轮不许安装；`06` §3 已把补测挂到 S1 探针安装后。

---

## 5. 已知缺口（交付时必须一起说）

| # | 缺口 | 影响 | 谁负责 |
|---|---|---|---|
| G-1 | 客户端点击**尚未接命令通道**（`07` S-1） | B3/B11–B16/B21 的端到端走查全部做不了；页面上点了会立刻回 idle | S5/P3 |
| G-2 | 设置页**未接写路径**（`07` S-3） | B18 即时生效、B6 勾选持久化无法验；`save-settings` 明确返回 `persist-unavailable` | S6/P3 |
| G-3 | `scripts/assert-preset.mjs` **未写** | B5 判据 2（输出侧结构谓词）无法跑 | S4/P3 |
| G-4 | B19 的**编辑门交互未做** | 五条判据里 ①②③④ 无实现，只有 ③ 的计数语义有测试 | S6 |
| G-5 | Client Inspect 9 次零成功、**无浏览器控制** | 所有页面事实仍为源码级；activity 展开态记「未验」 | 环境/负责人已接受 |
| G-6 | 与在装产品**并存**导致界面两套控件、两个设置页 | 走查记录里必须注明"另一套不是本次交付物"；`data-draft-studio-*` 过滤仍然有效（前代 0 命中） | 客户知情（P4） |
| G-7 | 命令前缀已改为 `/lab-draft` | `01` §4 允许命令清单里的 `/draft-studio dump-*` 需按新前缀重述 | 本轮已在 `07` D-2 记录；P3 更新 `01` §4 |
| G-8 | 超时环境变量双拼写（`LAB_*` / `DSH_*`） | 两种都能触发 1 秒自测；**多一条配置面**，需在 P3 的 `dump-settings` 里回显实际生效的那个 | S4 |

---

## 6. 并存策略是否落实（逐项核对）

| 检查项 | 要求 | 实际值 | 证据 |
|---|---|---|---|
| 包名带实验前缀 | `lab-draft-studio` 系 | `@local/lab-draft-studio` | `package.json:2`；测试 `client.js registers one factory under the lab package name` |
| `meta.title` 带前缀 | 可辨识 | 草稿工坊（实验） / Draft Studio (lab) | `locale/zh.json`、`locale/en.json`；测试 `the client locale files on disk carry the same title…` |
| 座位 id 带前缀 | 四条互异且不撞前代 | `lab-draft-general|coding|writing|translate` | `client.js` 的 `ENTRY_PREFIX`；测试 `apply registers four seats…(B1-a)` 断言 id ≠ `dsh-draft-studio` |
| 设置页 id 带前缀 | 不撞前代 | `lab-draft-studio` | 测试 `apply registers the settings page under the lab id` 断言 id ≠ `dsh-draft-studio` |
| Loader patch id | 不撞前代 | `lab-draft-studio` → entryId `include:lab-draft-studio` | `cordis.patch.yml`；测试 `dispatch(dump-settings) …` 断言 `entryId === 'lab-draft-studio'` |
| 不改动在装包 | 不删除/不停用/不修改 | 本轮零安装、零卸载；只读过它的 `client.js`/`index.js` | `07` §6；`probes.md` P29-6 |
| README 首段写明并存 | 首段 | 中英双语并存声明在 `bundle-lab/README.md` 第 3–8 行 | 文件本身 |
| 验收判据不变 | `data-draft-studio-*` 与 `count===4` | 属性名原样保留；`count===4` 判据不变 | 测试 `the seat publishes every attribute the acceptance fragment reads` 断言 `data-draft-studio-seat` 字面量 |
| 功能不共享 | 不读前代设置、不共享预设 | 设置只从本插件 Config（`include:lab-draft-studio`）读；无跨插件读 | `lib/schema.js` 的 `readConfig`；`client.js` 的 `resolveForm` 用自己发布的 entryId |

**结论：并存策略已落实**（8/8 项有实现或测试可指认），且**没有**任何一处触碰在装产品。

---

## 7. 下一个人最可能误解的三处

1. **「138 条全绿」不等于「B1–B21 通过」。** 本轮没有安装，所以**没有一条验收是运行时已验**（§4.1）。绿的是"逻辑内核与注册结构"，页面几何、`prepared.config`、`command/run` 计数、真实写回与撤销全都还没发生。谁把 §4 的"已离线证"读成"验收通过"，就会在 P3 走查时被打回。
2. **`client.js` 里那些 `isDraftActionable` / `validateLabel` / `visibleSeats` / `writeBackVerdict` 是**镜像**，不是重复实现。** classic script 不能 import ES module，所以必须有一份副本；`test/client.test.js` **从源码文本里抽出这些函数**与 `lib/*.js` 逐例比对，漂移会红。改内核时**必须同时改镜像**，否则测试立刻失败——这是设计，不是遗漏。同理，`data-draft-studio-*` 属性名与 `01` §4 片段是硬绑定的，**不要**给它加 `lab-` 前缀。
3. **降级 A 的 HTTP 路由是故意不挂载的。** `mountRoute()` 在缺 token 或 origin 时**拒绝注册**，不是 bug；这条通道在 `06` §4 被实测出"浏览器口对命名路由不鉴权"。若将来因为 U2/U3 失败而启用它，**必须**保留 `lib/guard.js` 的三闸（方法+路径、`Sec-Fetch-Site`/`Origin`、每进程 token），删掉任何一闸都等于把前代那个洞复制一遍。
