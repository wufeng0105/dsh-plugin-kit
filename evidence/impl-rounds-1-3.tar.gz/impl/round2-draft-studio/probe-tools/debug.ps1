$ErrorActionPreference='Stop'
$path='C:\Users\Administrator\AppData\Local\Programs\DeepSeek Harness\resources\app.asar'
$fs=[System.IO.File]::OpenRead($path)
$sizeBuf=New-Object byte[] 8
[void]$fs.Read($sizeBuf,0,8)
$headerSize=[BitConverter]::ToUInt32($sizeBuf,4)
"headerSize=$headerSize"
$headerBuf=New-Object byte[] $headerSize
$read=0
while($read -lt $headerSize){ $n=$fs.Read($headerBuf,$read,$headerSize-$read); if($n -le 0){break}; $read+=$n }
"read=$read"
$text=[System.Text.Encoding]::UTF8.GetString($headerBuf)
"head=$($text.Substring(0,40))"
$start=$text.IndexOf('{'); $end=$text.LastIndexOf('}')
"start=$start end=$end"
$json=$text.Substring($start,$end-$start+1)
$h=$json | ConvertFrom-Json
"root props: " + (($h.PSObject.Properties | ForEach-Object Name) -join ',')
"files props: " + (($h.files.PSObject.Properties | ForEach-Object Name) -join ',')
$fs.Dispose()
