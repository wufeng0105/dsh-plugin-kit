<#
  asar-grep.ps1 — read-only regex search inside the installed DSH app.asar.

  Why this exists: Client inspect times out on this machine (probes.md P3/P195 and
  this round), so client-side facts have to be read from the shipped bundles.
  Extracting a whole package tree just to grep it is wasteful; this script walks
  the asar header, reads only matching files by offset, and prints
  `path:line:col  snippet` lines. Nothing is written anywhere.

  Usage:
    pwsh -NoProfile -NonInteractive -File asar-grep.ps1 -Pattern 'conversation\.input\.right' -Prefix 'dsh/node_modules/@deepseek-ai' -Include 'client.js'
    pwsh -NoProfile -NonInteractive -File asar-grep.ps1 -Pattern 'maxPayload|requestTimeout' -Prefix 'dsh/node_modules/@deepseek-ai/dsh-api-gateway'
#>
[CmdletBinding()]
param(
  [string]$Asar = 'C:\Users\Administrator\AppData\Local\Programs\DeepSeek Harness\resources\app.asar',
  [Parameter(Mandatory = $true)][string]$Pattern,
  [string]$Prefix = 'dsh/node_modules',
  [string]$Include = '*',
  [int]$Context = 70,
  [int]$Max = 200,
  [int]$MaxFileBytes = 8000000
)

$ErrorActionPreference = 'Stop'

function Read-Header([string]$path) {
  $fs = [System.IO.File]::OpenRead($path)
  $sizeBuf = New-Object byte[] 8
  [void]$fs.Read($sizeBuf, 0, 8)
  $headerSize = [BitConverter]::ToUInt32($sizeBuf, 4)
  $headerBuf = New-Object byte[] $headerSize
  $read = 0
  while ($read -lt $headerSize) {
    $n = $fs.Read($headerBuf, $read, $headerSize - $read)
    if ($n -le 0) { break }
    $read += $n
  }
  $text = [System.Text.Encoding]::UTF8.GetString($headerBuf)
  $start = $text.IndexOf('{')
  $end = $text.LastIndexOf('}')
  $json = $text.Substring($start, $end - $start + 1)
  return @{ File = $fs; Header = ($json | ConvertFrom-Json); Base = (8 + $headerSize) }
}

function Walk-Tree($node, [string]$prefix, $acc) {
  if ($null -eq $node -or $null -eq $node.files) { return }
  foreach ($p in $node.files.PSObject.Properties) {
    $child = $p.Value
    $rel = if ($prefix) { "$prefix/$($p.Name)" } else { $p.Name }
    if ($child.files) { Walk-Tree $child $rel $acc }
    else { $acc.Add([pscustomobject]@{ Path = $rel; Size = [int64]$child.size; Offset = [int64]$child.offset }) | Out-Null }
  }
}

$h = Read-Header $Asar
try {
  $all = New-Object System.Collections.Generic.List[object]
  $prefixNorm = $Prefix.Trim('/')
  $node = $h.Header
  $ok = $true
  foreach ($seg in ($prefixNorm -split '/')) {
    if ($null -eq $node.files) { $ok = $false; break }
    $next = $node.files.PSObject.Properties[$seg]
    if ($null -eq $next) { $ok = $false; break }
    $node = $next.Value
  }
  if (-not $ok) { Write-Output "NOT FOUND: $prefixNorm"; exit 4 }
  Walk-Tree $node $prefixNorm $all

  $files = $all | Where-Object { $_.Path -like $Include -and $_.Size -le $MaxFileBytes } | Sort-Object Path
  Write-Output ("# candidates: {0} files under {1} (include={2})" -f $files.Count, $prefixNorm, $Include)

  $re = [regex]::new($Pattern, [System.Text.RegularExpressions.RegexOptions]::Multiline)
  $total = 0
  $hitFiles = 0
  foreach ($f in $files) {
    if ($total -ge $Max) { break }
    $bytes = New-Object byte[] ([int]$f.Size)
    [void]$h.File.Seek(($h.Base + $f.Offset), [System.IO.SeekOrigin]::Begin)
    $read = 0
    while ($read -lt $bytes.Length) {
      $n = $h.File.Read($bytes, $read, $bytes.Length - $read)
      if ($n -le 0) { break }
      $read += $n
    }
    if ($read -le 0) { continue }
    $text = [System.Text.Encoding]::UTF8.GetString($bytes, 0, $read)
    $fileHit = $false
    foreach ($m in $re.Matches($text)) {
      if ($total -ge $Max) { break }
      $lineNo = ($text.Substring(0, $m.Index) -split "`n").Count
      $lineStart = $text.LastIndexOf("`n", [Math]::Max(0, $m.Index - 1))
      if ($lineStart -lt 0) { $lineStart = 0 }
      $col = $m.Index - $lineStart
      $from = [Math]::Max(0, $m.Index - $Context)
      $to = [Math]::Min($text.Length, $m.Index + $m.Length + $Context)
      $snip = ($text.Substring($from, $to - $from) -replace "\r?\n", ' \u21B5 ')
      Write-Output ("{0}:{1}:{2}  {3}" -f $f.Path, $lineNo, $col, $snip.Trim())
      $total++
      $fileHit = $true
    }
    if ($fileHit) { $hitFiles++ }
  }
  Write-Output ("# matches: {0} in {1} files" -f $total, $hitFiles)
}
finally {
  $h.File.Dispose()
}
