<#
  asar-probe.ps1 — read-only probe of the installed DSH app.asar.

  Why this exists: the Client inspect provider times out on this machine, and
  native tools (rg/glob/node fs) cannot open a path inside app.asar. The Host's
  own file reader can, so declared package metadata (README.md, package.json)
  was read through the read tool; this script fills the remaining need: listing
  and extracting files from the archive without installing or modifying
  anything.

  Nothing is written outside -OutDir. No file in the DSH installation is
  modified.

  Usage:
    pwsh -NoProfile -NonInteractive -File asar-probe.ps1 -List 'node_modules/@deepseek-ai/dsh-client-ui-conversation/lib/types'
    pwsh -NoProfile -NonInteractive -File asar-probe.ps1 -Get 'node_modules/@deepseek-ai/x/lib/types/a.d.ts' -OutDir .\dump
#>
[CmdletBinding()]
param(
  [string]$Asar = 'C:\Users\Administrator\AppData\Local\Programs\DeepSeek Harness\resources\app.asar',
  [string]$List,
  [string]$Get,
  [string]$OutDir = '.'
)

$ErrorActionPreference = 'Stop'

function Read-Header([string]$path) {
  $fs = [System.IO.File]::OpenRead($path)
  try {
    $sizeBuf = New-Object byte[] 8
    [void]$fs.Read($sizeBuf, 0, 8)
    $headerSize = [BitConverter]::ToUInt32($sizeBuf, 4)
    $headerBuf = New-Object byte[] $headerSize
    $read = 0
    while ($read -lt $headerSize) {
      $n = $fs.Read($headerBuf, $read, $headerSize - $read)
      if ($n -le 0) { break }
      $read += $n
    }
    $text = [System.Text.Encoding]::UTF8.GetString($headerBuf)
    $start = $text.IndexOf('{')
    $end = $text.LastIndexOf('}')
    $json = $text.Substring($start, $end - $start + 1)
    return @{ File = $fs; Header = ($json | ConvertFrom-Json); Base = (8 + $headerSize) }
  } catch {
    $fs.Dispose()
    throw
  }
}

function Walk-Tree($node, [string]$prefix) {
  if ($null -eq $node -or $null -eq $node.files) { return }
  $props = $node.files.PSObject.Properties
  if ($null -eq $props) { return }
  foreach ($p in $props) {
    $child = $p.Value
    $rel = if ($prefix) { "$prefix/$($p.Name)" } else { $p.Name }
    if ($child.files) {
      Walk-Tree $child $rel
    } else {
      [pscustomobject]@{ Path = $rel; Size = [int64]$child.offset; Offset = [int64]$child.offset }
    }
  }
}

$h = Read-Header $Asar
try {
  if ($List) {
    $norm = $List.TrimEnd('/')
    $results = New-Object System.Collections.Generic.List[object]
    # walk to the prefix node, then list below it
    $node = $h.Header
    $segments = $norm -split '/'
    $ok = $true
    foreach ($seg in $segments) {
      if ($null -eq $node.files) { $ok = $false; break }
      $next = $node.files.PSObject.Properties[$seg]
      if ($null -eq $next) { $ok = $false; break }
      $node = $next.Value
    }
    if (-not $ok) { Write-Output "NOT FOUND: $norm"; exit 4 }
    Walk-Tree $node $norm | Sort-Object Path | ForEach-Object { '{0,10}  {1}' -f $_.Size, $_.Path }
  }
  elseif ($Get) {
    $norm = $Get.Replace('\', '/').TrimStart('/')
    $node = $h.Header
    $segments = $norm -split '/'
    $last = $segments[-1]
    $ok = $true
    foreach ($seg in $segments) {
      if ($null -eq $node.files) { $ok = $false; break }
      $next = $node.files.PSObject.Properties[$seg]
      if ($null -eq $next) { $ok = $false; break }
      $node = $next.Value
    }
    if (-not $ok -or $node.files) { Write-Output "NOT FOUND: $norm"; exit 4 }
    $bytes = New-Object byte[] ([int64]$node.size)
    [void]$h.File.Seek(($h.Base + [int64]$node.offset), [System.IO.SeekOrigin]::Begin)
    $read = 0
    while ($read -lt $bytes.Length) {
      $n = $h.File.Read($bytes, $read, $bytes.Length - $read)
      if ($n -le 0) { break }
      $read += $n
    }
    $text = [System.Text.Encoding]::UTF8.GetString($bytes[0..($read - 1)])
    $name = ($last -replace '[^A-Za-z0-9._-]', '_')
    $dest = Join-Path $OutDir $name
    [System.IO.File]::WriteAllText($dest, $text, (New-Object System.Text.UTF8Encoding($false)))
    Write-Output "WROTE $dest ($read bytes)"
  }
  else {
    Write-Output 'nothing to do: pass -List <prefix> or -Get <path>'
    exit 2
  }
}
finally {
  $h.File.Dispose()
}
