# 01 需求（P0）— dsh-draft-studio / 草稿工坊（返工版 v3）

> 输入：`requirements/REQ-02-dsh-draft-studio.md`（客户原文，下称"原文"）、`00-client-answers.md`（客户第 2 轮答复）、`03-gate-P0P1.md`（上一轮审查意见）、`04-regate-P0P1.md`（本轮复审）、`process-lab/spec/process-v2.md`（流程规格 v2）。
> 本文件只做三件事：把原文翻成**能判真假**的验收条目；把歧义逐条裁定（**本版无"待裁定"项**）；把每条验收的证据口径钉死。
> 版本说明：v2 回应 `03-gate-P0P1.md` 的 B-1、B-2、M-1～M-4、m-1～m-5，并回填客户答复 C1；**v3 只回应 `04-regate-P0P1.md` 的 3 项（N-1 观测字段与判定、N-2 片段字段来源、C-1 客户知情 + N-9 措辞），并顺手修 N-3～N-8**，不改座位、架构、探针门。逐条对照见 `02-plan.md` §7.2「针对 04 报告的逐条回应」。**v3.1（05 复审定点修订，仅文档）**：B3 的 `messageCount` 来源改为 `readSurface`、`editorPhase` 选择器改为 `[data-composer-input]` 并统一键名、B1-e 补 activity 三态前置（`hiddenByActivity`）；顺带修 N-3 措辞与两处索引，见 `02-plan.md` §7.3。**v3.2（P2 开工回写，仅 §9 与本行）**：按 `06-p1.5-probes.md` 与 `06-lead-decision.md` 更新 §9 三态表的 11 行状态，并新增"与在装 `dsh-draft-studio@1.2.2` 的关系 = 显式并存"一行；**B1–B21 判据一字未改**，见 `02-plan.md` §7.4。

---

## 0. 本版改动速查（审查员先看这里）

| # | 改动 | 位置 |
|---|---|---|
| 1 | A1 从「客户裁定」改为「自查可解·已结案」，落点 = `conversation.input.right`（list，**主座位**），删掉全部"容差/待裁定" | §7-A1、§8 |
| 2 | B5 去掉"人工判读方向对"，改为「system 段逐字包含结构块 + 输出结构正则断言 + 请求 sha256 两两不同」 | §3-B5 |
| 3 | B1 拆成 B1-a/b/c/d，总开关关闭时单列"0 颗"，位置判据改为几何可判 | §3-B1 |
| 4 | B17/B18 统一超时口径：设置值 30–600 秒（默认 480），1 秒只存在于自测注入通道 | §3-B17、§3-B18、§5 |
| 5 | B18 改为「19 项可改 + 第 20 项只读回显」，并新增 A13 记录该口径 | §3-B18、§5、§7-A13 |
| 6 | B8/B9 证据源改为「请求装配纯函数的命令输出 + 宿主 `llm.prepareCall` 物化后的 config + 负向对照的宿主错误文本」，明确 `command/run` 不证明模型/强度 | §3-B8、§3-B9、§4 |
| 7 | B10/B15/B16/B19/B21 判据收紧为可机判字段 | §3 |
| 8 | 证据口径只保留「文件:行」与「命令 + 输出」，截图/日志降为辅助 | §4 |
| 9 | 三态表更新：运行时插槽、长请求上限、即时生效三项转入 `02-plan.md` §3 的 P1.5 探针门 | §9 |
| 10 | **B1-e 补可观察字段**：`modelFound` / `rowRects` / `visible` / `inDock`；模型选择器缺失时整条记「无法判定」（原 `leftOfModel` 返回 `true` 的空真通道已删），dock 负例必红 | §3-B1-e、§4 |
| 11 | **§4 片段改为「基线模板 + 按条扩展」**：B3/B11/B15/B16 的追加键与来源逐条列出；`data-elapsed-ms` / `data-hover-text` / `aria-disabled` 进 S5 属性清单 | §4、§4.1；`02` S5 |
| 12 | **activity 展开态补客户知情记录（C-1）**：触发条件/表现/恢复方式/影响/签收人写进 §8.5；走查规程"全程保持活动面板收起"进 §3.0 与 `02` S5/S8 | §3.0、§8.5 |
| 13 | MINOR 顺手修：B5 删「四套互斥/主判据」并加 writing 谓词、D1 降级座位同受 activity 隐藏、U1 探法、一致性表补 4 行、B17「三条」改「四条」 | §3-B5、§3-B17；`02` D1/U1/§6.2 |
| 14 | **05 复审定点修订（v3.1，仅文档）**：`messageCount` 来源改 `readSurface`（`events.length`）、`editorPhase` 选择器改 `[data-composer-input]` 并统一键名、B1-e 补 activity 三态前置（新增 `hiddenByActivity` 字段） | §3-B3、§3-B1-e、§4、§4.1；`02` §7.3 |
| 15 | **P2 开工回写（v3.2，仅 §9 + 版本行）**：§9 三态表 11 行按 `06-p1.5-probes.md` 更新；新增「与在装 `dsh-draft-studio@1.2.2` 的关系 = 显式并存（`lab-draft-` 前缀，不动前代）」；**B1–B21 判据一字未改** | §9；`02` §1/§5-R11/§7.4 |

---

## 1. 需求理解

在 DSH Web 的输入框（composer）里，草稿非空时，发送区左侧出现最多四颗按钮（通用 / 编程 / 写作 / 翻译）。点一颗，就把当前草稿交给模型改写成"AI 能照着执行的提示词"，结果**写回同一个输入框**，不发送、不弹窗、不换页面，且可以一键还原。按钮有四种可见状态（空闲 / 运行中可取消 / 可回退 / 失败可重试），一次只跑一颗，结果绝不覆盖等待期间的新输入。设置页可改四套预设、显示哪几颗、模型来源（跟随会话含思考强度，或固定模型+强度）、总开关、读上下文开关等 20 项（**19 项可改，第 20 项"上次改写回显"按语义只读**），改完下一次请求就生效。

产品边界由客户给定：不做自动发送、多轮改写、模板库、历史记录、重启后上下文回放；`/` 命令芯片草稿允许写不回（原稿不丢、结果留待重试）；`@` 引用不受影响；固定模型不支持所选强度时自动退回该模型默认强度；超时上限约 8 分钟，超时后草稿不变、可重试；设置服务不可用时降级为一颗按钮且不报错。

**位置（本版结案）**：按钮注册到 `conversation.input.right`——宿主声明的 **list** 座位，渲染顺序在模型选择器之前、Stop/Send 左侧，天然可并排 1–4 颗。客户 `00-client-answers.md` 追加提醒已明确"存在列表语义的座位就优先用它，这是第一优先"。因此 A1 **不需要客户接受容差**，见 §7-A1 与 §8。

**一句话的判定基准**：用户全程只做两件事——点按钮、看输入框。输入框里的字变了、能还原、没发出去，就是成立；任何需要用户离开输入框才能看到结果的设计都不成立。

---

## 2. 术语（本文件内固定含义）

| 术语 | 含义 |
|---|---|
| 草稿 | 当前会话输入框里的可编辑文本（不含附件） |
| 改写稿 | 模型返回、准备写回输入框的文本 |
| 芯片 | 输入框内的原子节点：`/命令` 芯片、`@引用`/文件引用芯片、引用块 |
| 预设 | 四套按钮各自携带的改写指令模板（通用/编程/写作/翻译），记 `presetId ∈ {general, coding, writing, translate}` |
| **结构块** | 每套预设 system 段里一段**逐字固定**的文本，以 `【结构要求 preset=<id>】` 开头，写明该预设要求输出具备的结构（§3-B5 给出四段原文） |
| **结构判据** | 作用在改写稿文本上的正则/计数谓词，四套预设**各有独立谓词、只作部分区分**（§3-B5 表；translate 追加"无 `^-\s` 要点行"排除 general 形态；writing 与 translate 在"英文输入、段落保持"时结构同形，故显式声明**不靠文本谓词反推 presetId**） |
| **请求转储** | `/draft-studio dump-request <presetId>` 命令的输出 JSON：包含将要发出的 `provider/model/reasoningEffort/system/systemSha256/presetId`，以及宿主 `llm.prepareCall` 物化后的 `prepared.config`。不发起流式调用 |
| 会话模型选择 | 该会话当前生效的 `provider + model + reasoningEffort`，界面上的模型选择器即其显示值 |
| 跟随模式 | 改写请求使用会话模型选择 |
| 固定模式 | 改写请求使用设置里写死的一组 `provider + model + 强度` |
| 座位 / 条目 | 宿主 Slot 的容器（`conversation.input.right`）与其中的一条注册（一颗按钮 = 一条 list 条目，必须带 `id`） |
| 一次改写 | 从点按钮到按钮回到空闲/可回退/失败的整个过程，含其取消与重试 |

---

## 3. 逐条行为验收（可判真假）

> 记法：每条给出 **操作 → 观察 → 判定**，并附一条**必须变红的负例**（构造它若不红，说明这条验收是空真）。
> "会话 A/B"指两个已存在的会话；"非空草稿"指 `trim()` 后长度 > 0。
> 本轮起，**全部观察都必须落成「命令 + 输出」或「文件:行」**（§4）。页面事实由 §4 的 console **基线片段**输出 JSON（含 `modelFound`/`visible`/`inDock` 等），B3/B11/B15/B16 再按 §4.1 的**按条扩展表**追加键；所有追加键的来源都在该表里写明（选择器或命令），不接受临时发明字段。截图仅作辅助。

### 3.0 观察前提（对所有 B 条生效，来自宿主渲染条件）

| 前提 | 事实 | 出处 |
|---|---|---|
| P1 | 按钮仅在 `input !== undefined && sessionId !== undefined` 时渲染 | `dsh-client-ui-conversation/lib/client.js:22110` |
| P2 | `standardControls`（含 `right` 与 `model`）带 `hidden: activity`；activity 展开时二者一起隐藏 | 同文件 `22107–22111` |
| P3 | 一颗按钮 = 一条 list 条目，**必须带不同 `id`**，否则注册时抛错 | `dsh-web-frontend/dist/assets/index-BgUyXZcc.js` 字符偏移 492065–492300（`requires options.id` @492133、同 id 冲突 @492275）；`dsh-client-ui-renderer/lib/client.js:1203–1221` |

**判定口径**：B1/B2 的"按钮出现"一律指 **P1 成立（已有会话）且 P2 未触发（activity 未展开）的默认态**。新会话首帧无按钮、或用户展开了活动面板期间无按钮，**不判失败**，记为宿主条件限制（写进 P4 已知问题）。这条是验收可达性前提，不是宽容。该前提的**客户知情记录见 §8.5**（写明触发条件、影响、签收人）。

**走查规程（本版新增，回应 N-8）**：现场走查（S5/S8）**全程保持活动面板收起**；若某条走查中途用户/操作者展开了活动面板，该条记「无法判定/未验」，**不记通过**，收起面板后重跑该条并把两次片段 JSON 都留档。activity 展开期间 `count` 仍为 4（DOM 节点在，只是 `hidden`），**不得因 `count===4` 记通过**——`visible` 全 `false` **且 `hiddenByActivity === true`**（座位父级链带 `hidden` 属性，即宿主 `hidden: activity` 的落点）才是该态。若面板已收起仍 `visible` 全 `false`（`hiddenByActivity === false`），那是按钮被插件自己藏了，按**「不通过」**处理，不得记「未验」。字段定义见 §4。

### B1 按钮出现与消失

- **B1-a 总开关开、勾选 4、非空草稿**
  - 操作：设置总开关=开，四个预设全勾选；会话 A 输入 `你好`。
  - 观察：按 §4 的布局片段输出 JSON：`count` = 4，`ids` = `["general","coding","writing","translate"]`（按 `order` 升序）。
  - 判定：`count === 4` 且 `ids` 集合相等 = 通过。
- **B1-b 勾选数决定颗数**
  - 操作：只勾"通用""翻译"。
  - 观察：`count === 2`，`ids === ["general","translate"]`。
  - 判定：相等 = 通过；出现未勾选的预设 = 不通过。
- **B1-c 总开关关闭**
  - 操作：总开关=关，四个预设仍全勾选，草稿非空。
  - 观察：`count === 0`。
  - 判定：0 颗 = 通过。**（本版修正：上一版写"1 ≤ N ≤ 4"，在总开关关闭的配置下会误判失败。）**
- **B1-d 草稿为空**
  - 操作：清空输入框（`trim()` 后为空）。
  - 观察：`count === 0`。
  - 判定：0 颗 = 通过（与 B2 同源，B2 保留为独立负例）。
- **B1-e 位置**（本版重写，回应 N-1）
  - 操作：同 B1-a，且确认活动面板收起（§3.0 走查规程）。
  - 观察：§4 基线片段一次输出 JSON，本条的判定只用这些字段——`count`、`modelFound`、`seatRects[i]`、`rowRects[i]`、`visible[i]`、`inDock[i]`、`hiddenByActivity`、`modelRect`、`editorRect`、`editorOverlap`、`leftOfModel`。
    - `rowRects[i]` 的定义：**第 i 颗按钮与模型选择器的最近公共祖先的 rect**（正常态即宿主 `standardControls` 行，源码 `ui-conversation-client.js:22107–22111`）。宿主 DOM 不给我们加属性，所以不靠 class 名定位，靠"共同祖先"自证。
    - `visible[i]` 的定义：`offsetParent !== null && rect.width > 0 && rect.height > 0`（`display:none` 的祖先会让它取 false）。
    - `inDock[i]` 的定义：`seats[i].closest('[data-composer-dock]') !== null`（该属性在宿主源码 `ui-conversation-client.js:22216–22218` 硬编码，可作稳定选择器）。
    - `hiddenByActivity` 的定义：`seats[0].parentElement?.closest('[hidden]') != null`（宿主 `standardControls` 在 activity 展开时带 `hidden` 属性，源码 `ui-conversation-client.js:22107–22111`；`hidden: activity` 为 false 时 React 不渲染该属性）。**只看座位的父级链、不看座位自身**：插件若给座位自己加 `hidden`，这里必须仍是 `false`，否则会把插件缺陷误记成「未验」。它只用于把「面板展开导致不可见」与「按钮被插件自己藏了」分开，不单独作为通过判据。
  - **前置（不满足即整条不判）**：`count === 4`（B1-a 成立）；**`modelFound === false` → 整条记「无法判定」**，不记通过、不记失败（原片段 `!model || …` 返回 `true` 的空真通道已删除）。
    - **三态分流（v3.1，回应 05 §5.2 第 3 项）**：`count === 4` 且 `visible` 全为 `false` 且 **`hiddenByActivity === true`**（活动面板确实展开）→ 整条记「无法判定/未验」，**不进入下面四条判据**；面板收起后 `hiddenByActivity === false` 而 `visible` 仍全 `false` → 判**「不通过」**（按钮被藏，属插件缺陷，不是宿主条件）。
  - 判定四条同时满足 = 通过：
    1. `modelFound === true`；
    2. `visible` 四项全为 `true`，且 `inDock` 四项全为 `false`；
    3. 每颗按钮 `seatRects[i].right <= modelRect.left`（`leftOfModel === true`）；
    4. 每颗按钮的 rect **垂直落在 `rowRects[i]` 内**（`top >= rowRects[i].top - 1 && bottom <= rowRects[i].bottom + 1`），且 `editorOverlap === 0`。
  - 负例 1（必须红）：按钮渲染到 `conversation.composer.dock`（工具行下方整行）→ `inDock[i] === true`，判据 2 红。**注意它为什么能逃过其余判据**：dock 里按钮的 `editorOverlap` 仍为 0、`leftOfModel` 也可能为 `true`（dock 在工具行下方，水平位置仍在模型选择器左侧），而 `rowRects[i]`（与模型的最近公共祖先）会退化成更外层容器、垂直包含也就成立——所以**只有 `inDock` 抓得住它**。
  - 负例 2（必须"无法判定"，不得变绿）：把模型选择器摘掉/找不到（或宿主未渲染 `conversation.input.model`）→ `modelFound === false` → 整条记「无法判定」。
  - 负例 3（空真排除，不得假通过）：activity 展开时跑片段 → `count === 4`、`visible` 全 `false`、`hiddenByActivity === true`。**按前置的三态分流，整条记「未验」，不进入四条判据**；若只看 `count`，这个态会假通过。契约上的分界：面板展开 → 「未验」；面板收起（`hiddenByActivity === false`）仍 `visible` 全 `false` → 「不通过」，由判据 2 接住。**插件把座位 `display:none` 的负例（`hiddenByActivity === false`）必须仍然判红**，不得被误记为「未验」。

### B2 对不起作用的草稿不反应

- 操作：草稿只有空白字符（空格/换行/制表符）。
- 观察：`count === 0`。
- 判定：按 `trim()` 后为空处理；有按钮 = 不通过。
- 负例：输入一个全角空格 `\u3000` 后仍出按钮 → 必须红（`trim()` 覆盖全角空格，见 `lib/boundary.js` 单测）。

### B3 点按钮 → 写回，不发送

- 操作：草稿 `帮我写个登录`，点"编程"。
- 观察：①按钮进入运行中；②结束后输入框内容变为改写稿；③会话消息列表**没有新增任何消息**（用户/系统/助手都不新增）；④页面 URL/视图不变。
- 判定：四条同时满足 = 通过。任一不满足 = 不通过。
- 证据（本版按 §4.1 钉死来源）：写回前后各跑一次 `/draft-studio dump-draft`，取 `text` 与 **`messageCount`**（前后相等；`messageCount` = 宿主半 `ctx.sessionQuery.readSurface(sessionId).events.length`，计数对象见 §4.1）；写回期间跑 §4 基线片段，取 **`editorPhase`**（编辑区根节点 `[data-composer-input]` 上的 `data-phase`），全程不得出现 `submitting`/`sending`。**选择器必须是 `[data-composer-input]`，不能用基于 `contenteditable` 的查询**：宿主在 `submitting`/`sending` 时把该 div 的 `contenteditable` 置为 `"false"`（`ui-conversation-client.js:21829`/`:21833`/`:20976`），旧选择器会取不到元素、把相位读成 `null`，等于给 B3 开一条空真通道。
- 负例：把改写稿当成用户消息发出去 → 必须判不通过（**这是本需求的第一红线**）。

### B4 回退还原原文

- 操作：B3 完成后，触发该按钮的"回退"。
- 观察：输入框逐字回到点击前的原文（含换行与首尾空格）。
- 判定：`after === before`（逐字节比较，`lib/run-store.js` 存快照）= 通过。
- 负例：回退后残留改写稿的一部分，或回退把输入框清空 → 不通过。
- 附加（不单独计分，但必须记录实测）：写回后按 Ctrl+Z 是否等同于回退。**已知机制**：宿主 `setDraft` 并入历史、不产生独立撤销步；`insertText` 按区间插入是独立撤销步。以"自带回退按钮"为验收口径，Ctrl+Z 只作附加观察。

### B5 四套预设各自生效（可机判版）

> 上一版的通过条件含"人工按预设意图判读方向对"，不可复跑，本版删除。改为三层判据，全部可用命令复跑。

**判据 1｜请求侧（完全确定性，不含模型输出）**
对四个 `presetId` 各跑一次 `/draft-studio dump-request <presetId>`，对输出 JSON 断言：

- (a) `system` **逐字包含**该预设的结构块原文（下表"结构块"列，`system.includes(STRUCTURE[presetId]) === true`）；
- (b) 四个 `systemSha256` **两两不同**；
- (c) `system` 内出现标记行 `【结构要求 preset=<presetId>】`，且与该次请求的 `presetId` 一致（防串台）。

**结构块原文（实现里逐字照抄，单测 `test/prompt.test.js` 钉死）**

| presetId | 结构块（system 段内逐字存在） |
|---|---|
| general | `【结构要求 preset=general】`<br>`- 输出 3–7 条以 "- " 开头的要点；`<br>`- 不使用编号步骤，不使用代码围栏。` |
| coding | `【结构要求 preset=coding】`<br>`- 输出有序步骤，至少 3 步，每步以 "1." "2." 这样的编号开头；`<br>`- 含代码时使用三反引号围栏。` |
| writing | `【结构要求 preset=writing】`<br>`- 保留输入的段落划分，不合并段落；`<br>`- 不使用编号步骤，不使用代码围栏；`<br>`- 输出语言与输入一致。` |
| translate | `【结构要求 preset=translate】`<br>`- 输出译为英文；`<br>`- 不保留中文正文（专有名词可保留原名）；`<br>`- 不添加解释或编号步骤。` |

**判据 2｜输出侧（结构断言，可机判）**
把四次改写稿交给 `node scripts/assert-preset.mjs <outputs.json>`，逐套断言（四个谓词**各有独立判据、只作部分区分**；本版回应 N-3——原表述"四套互斥"与"两两区分"均不成立：general 的输出在没有要点行限制时也能满足 writing 谓词，故给 writing 补第 4 条；translate 的输出又能满足 writing 谓词、general 的英文要点又能满足 translate 谓词，故给 translate 补第 4 条，并**明确 writing↔translate 在「英文输入、段落保持」时结构同形，文本谓词无法区分**。因此本判据只用于"每套断言自己的输出"，不用于反推 presetId）：

| presetId | 谓词（对改写稿全文） |
|---|---|
| general | `^-\s` 行数 ≥ 3；编号步骤行数 = 0；无三反引号围栏 |
| coding | 编号步骤行 `^\s*\d+[.、)]\s` 行数 ≥ 3 |
| writing | 编号步骤行数 = 0；段落数（空行切分的非空块）≥ 输入段落数；无三反引号围栏；**`^-\s` 行数 < 3**（第 4 条，排除 general 形态） |
| translate | CJK 字符占比 ≤ 5%；含 ≥ 1 个 `[A-Za-z]{2,}` 词；编号步骤行数 = 0；**`^-\s` 行数 < 3**（第 4 条，排除 general 形态） |

**判据 3｜随机性控制**
验收时把温度设为 0（§5 #18），模型来源用固定模式且固定同一 `provider/model/强度`（§5 #14–16）；每套最多重跑 2 次并记录两次输出，**任一次满足判据 2 即算该套通过**；两次都不满足 = 不通过（写"不通过"，不写"方向不对"）。

**判定**：判据 1 三条全过 **且** 四套的判据 2 全过 = 通过（两条是"且"关系，判据 2 可一票否决；判据 1 完全确定性、不含模型输出，判据 2 依赖模型输出，故不再称"主判据/辅助判据"——本版回应 N-3 的措辞矛盾）。判据 2 两次都失败时，两次原始输出整段进 `04-selfcheck`，作为"预设本身不达标"的失败样本留档（不是人工判读，是可复核的原始证据）。

**负例（必须红）**
1. 把四颗按钮的模板映射写死成同一套（构造：**四套模板整表指向同一常量**，即 `prompt.js` 的四套模板共用一个常量对象——只改 `preset.structure` 一个字段时其余文案仍可能不同，sha256 不必然相同；本版回应 N-3 的构造括注）→ 判据 1(b) 的 sha256 相同 → 红。
2. 把 `coding` 的结构块换成 `translate` 的 → 判据 1(a)/(c) 红。
3. 让 `coding` 输出只有段落没有编号步骤 → 判据 2 红。

**证据**：`/draft-studio dump-request` 的四段 JSON（命令 + 输出）、`node --test test/prompt.test.js`、`node scripts/assert-preset.mjs` 的逐套结论。**不采信**"看起来像翻译"这类人工判读。

### B6 隐藏与恢复

- 操作：设置里取消勾选"翻译"并保存。
- 观察：`count === 3`，`ids` 不含 `translate`；设置页"翻译"预设文本仍可读。
- 操作：重新勾选并保存。
- 观察：第 4 颗回来，`dump-settings` 输出里 `translate` 模板的 sha256 与取消前一致（未被重置）。
- 判定：两条都满足 = 通过。取消勾选导致预设丢失 = 不通过。

### B7 改名只改显示

- 操作：设置页把"写作"就地改名为"文案"，保存。
- 观察：①按钮显示"文案"（布局片段 `labels` 字段）；②`/draft-studio dump-request writing` 的 `system` 与改名前的 `writing` 请求 `system` **逐字相同**（sha256 相同）；③改回"写作"后显示复原。
- 判定：①③显示变化 + ②请求不变 = 通过；改名后 `system` 变化 = 不通过。
- 约束：名字长度上限 12 个**Unicode 码位**（`[...name].length <= 12`），超限不可保存并给出提示；负例：输入 13 个汉字 → 保存被拒且设置值不变。

### B8 跟随模式用会话的模型与强度

- 前提：会话 A 的模型选择器显示 `M1/S1`（界面读值，作为**独立于插件的**来源）。
- 操作：设置=跟随；执行 `/draft-studio dump-request coding --prepare`。
- 观察 JSON 两处一致：
  - `options.provider/model/reasoningEffort` = `M1/S1`（插件装配的请求）；
  - `prepared.config.provider/model/reasoningEffort` = `M1/S1`（宿主 `llm.prepareCall` 物化/校验后的调用配置）。
- 操作：把会话 A 切到 `M2/S2`，重复一次。
- 观察：两处同步变为 `M2/S2`。
- 判定：两次都一致 = 通过；仍用 `M1/S1` = 不通过。
- **负向对照（证明这两个字段真的到达宿主，而非插件自说自话）**：`/draft-studio dump-request coding --prepare --negative=model` 把一个不存在的 model 名塞进装配结果；预期宿主 `llm.prepareCall` 以错误拒绝，错误文本里含该 model 名。宿主不拒绝 → 该证据链不成立，B8 记「无法判定」并报缺陷（不写成通过）。
- 证据：`dump-request` 输出、宿主错误文本、`lib/llm-options.js` 的 `composeLlmOptions(config, selection)`（文件:行）+ `test/llm-options.test.js`。
- **明确不用的证据**：`command/run` / `command/done`。契约里 `CommandInvocation` 只有 `{commandId, agent, rawInput, attachments, signal}`，日志是同一次调用的 log-only 追加，**没有字段承载 provider/model/reasoningEffort**（出处见 §4）。

### B9 固定模式用固定值

- 操作：设置=固定 `M3/S3`；会话 A 当前 `M1/S1`；执行 `/draft-studio dump-request coding --prepare`。
- 观察：`options` 与 `prepared.config` 两处均为 `M3/S3`，不出现 `M1/S1`。
- 判定：一致 = 通过；用了会话的 `M1/S1` = 不通过。
- 负向对照同 B8（`--negative=effort`：把 S3 换成一个不在该模型 `efforts` 里的合法 id，宿主应拒绝且错误文本含该 id）。

### B10 强度不被支持时自动退回

- **确定性构造（替代"选一个不支持 S3 的模型"这种不保证存在的条件）**：
  1. 执行 `cordis_inspect_query(host, Service, listService, {service:"sessionController"})` 同源的 `modelCatalog`，取得固定模型 M 的 `reasoning.efforts`；
  2. 取一个**出现在别的模型 efforts 里、但不在 M 的 efforts 里**的合法 `ReasoningEffortId` E（跨模型差集，可用 `dump-catalog` 输出证明差集非空）；若差集为空，退用 `--force-effort=<不存在的字符串>`，宿主按"未知强度"拒绝，同样构成"不支持"。
- 操作：固定模式 M + E；`/draft-studio dump-request coding --prepare --force-effort=E`。
- 观察：输出 `effortFallback === true`，`prepared.config.reasoningEffort === M.reasoning.defaultEffort`；随后真实改写成功一次（输入框出现改写稿）。
- 判定：两条都满足 = 通过；弹出错误或永久失败 = 不通过。
- 证据：`modelCatalog` 输出（证明 E 不在 M 的 efforts）、`dump-request` 输出（证明退回值与 `defaultEffort` 相等）。实现走 `llm.prepareCall(config, signal, configure)`：`configure` 拿到模型元数据后，若请求强度不在 `efforts` 内则改用 `defaultEffort`，并把 `effortFallback` 记进回显。

### B11 一颗在跑，其余置灰

- 操作：点"编程"，运行中观察其余三颗。
- 观察（§4 基线片段输出 JSON，字段名照抄）：
  - ①其余三颗 `ariaDisabled[i] === "true"` 且 `disabled` 生效（点击后 `command/run` 计数不增加）；
  - ②正在跑的那颗 `states[i] === "running"` 且 `elapsedMs[i]` 递增——`elapsedMs` 取组件根上的 `data-elapsed-ms`，**连续两次采样（间隔 ≥ 1 秒，由操作者计时并记两次片段的时间戳）差值 ≥ 900ms**；
  - ③该颗的 `actions[i]` 含 `"cancel"`（`data-action="cancel"` 子节点存在）。
- 判定：三条都满足 = 通过。
- 来源声明：`ariaDisabled`/`elapsedMs`/`actions` 三个键都在 §4 基线片段里，来源分别是 `aria-disabled` 属性、`data-elapsed-ms` 属性、`[data-action]` 子节点——它们进 S5 的组件属性清单（`02-plan.md` S5），不是临时约定。

### B12 运行中可取消

- 操作：B11 状态下点取消。
- 观察：①2 秒内该按钮 `data-state` 回到 `idle`；②输入框文本与点击前逐字相同；③未出现改写稿；④不残留"可回退"（`data-state` 不含 `revertible`）。
- 判定：四条同时满足 = 通过。

### B13 结果绝不覆盖等待期间的新输入

- 操作：点按钮（慢请求），在等待中把输入框改成 `新的输入`；等请求结束。
- 观察：①输入框仍是 `新的输入`；②改写稿没有写进去；③该按钮进入"待重试"（`data-state="retry-pending"`，悬停显示"结果已生成，未写入：草稿已变更"）。
- 判定：三条同时满足 = 通过。
- 负例：改写稿覆盖了 `新的输入` → 必须判不通过（**第二红线**）。

### B14 并发宽容：切会话、发送

- 操作：在会话 A 发起改写，立刻切到会话 B，等请求结束，再切回 A。
- 观察：B 的输入框不受影响；回到 A 时，A 的输入框是改写稿（若 A 的草稿期间未变），或处于待重试（若变了）；`command/run` 的条数恰好 +1（证明切换没有触发第二次请求）。
- 操作：在会话 A 改写运行中，直接点发送（发送原草稿）。
- 观察：消息正常发出；该按钮的"运行中"在发送后停止（`data-state` 不含 `running`）；晚到的结果不写回输入框，不产生第二条消息。
- 判定：两条都满足 = 通过。
- 证据：`command/run` 条数（只证明请求次数与取消，不证明模型字段）。

### B15 失败态：悬停看原因、可重试

- 操作：让请求失败（断网 / 无效模型 / 超时）。
- 观察（§4 基线片段输出 JSON）：按钮 `states[i] === "failed"`，`reasonCodes[i]` ∈ `{timeout, provider-error, aborted, empty-result, unsupported-effort, settings-unavailable}`；**悬停文案取 `hoverText[i]`**（组件根上的 `data-hover-text`，即真的会显示的那段文字）——要求非空、等于该 `data-reason-code` 对应的中文文案、且不含 `at ` 行、不含 `Error:` 前缀的英文栈；点重试只重跑这颗自己那次（`command/run` 计数 +1，其他颗状态不变）。
- 来源声明：`hoverText` 是 §4 基线片段里的键（回应 N-2），属性 `data-hover-text` 进 S5 的组件属性清单；**不允许用"截图里看着有一行提示"当证据**。
- 判定：三条都满足 = 通过。
- 负例：`data-reason-code` 缺失或悬停只有 `undefined` → 不通过。

### B16 回退与重试只作用于自己那次

- 操作：先改写"编程"成功并回退；再点"写作"改写成功；然后观察"编程"。
- 观察：①"编程"按钮 `states[i]` 不含 `revertible`，且 `actions[i]` 不含 `"revert"`（`data-action="revert"` 子节点不出现）；②对"编程"的点击只发起新改写（`command/run` +1），输入框文本在点击瞬间不变（仍是"写作"的改写稿）；③"写作"的回退仍只还原"写作"那次（`dump-draft` 回到写作改写前的原文）。
- 来源声明：`actions` = 每颗按钮下 `[data-action]` 子节点的属性值集合，取自 §4 基线片段（回应 N-2）；`data-action` 进 S5 的组件属性清单。
- 判定：三条互不影响 = 通过。

### B17 超时

- **口径（本版统一）**：设置项 #17 的取值域是 **30–600 秒，默认 480 秒**；1 秒**不是**可配置值，只存在于**自测注入通道**（环境变量 `DSH_DRAFT_STUDIO_TIMEOUT_MS=1000`，仅当 `DSH_DRAFT_STUDIO_SELFTEST=1` 时读取，且 `dump-settings` 会标 `timeoutSource: "selftest"`）。
- 操作（验收路径一，正常路径）：设置超时 = 30 秒（下限），构造一次慢于 30 秒的请求（本机代理注入 35 秒延迟，或让宿主半 `sleep` 后再调 `llm.stream`）。
- 操作（验收路径二，自测注入）：`DSH_DRAFT_STUDIO_SELFTEST=1 DSH_DRAFT_STUDIO_TIMEOUT_MS=1000` 再发一次请求。
- 观察（四条，逐条留证据）：
  1. 超过上限后请求被取消：命令结果 `kind: "error"` 且 `text` 含 `timeout`，`command/done` 与该次 `command/run` 成对出现；
  2. 输入框文本不变（`dump-draft` 前后逐字相同）；
  3. 按钮 `states[i] === "failed"` 且 `reasonCodes[i] === "timeout"`，可重试（`actions[i]` 含 `"retry"`）；
  4. 默认上限 = 480 秒且可配置：`dump-settings` 输出 `timeoutMs: 480000`，且在设置页可改（§5#17）。
- 判定：**四条**都满足 = 通过（本版回应 N-7：原写"三条"却列了四项，计数与判据不符）。
- 负例：把 `timeoutMs` 设成 5 秒 → 设置页拒绝保存（低于 30 秒下限），`dump-settings` 仍为旧值。

### B18 设置页与"改完即时生效"

> **本轮状态（v3.3，2026-11-08）**：B18 已正式降级出 P4 范围（理由与签收要求见 §9 表末行）。本节判据保留，作为 P4 之后单独立项的验收依据，不在本轮签收。

- 操作：打开设置页。
- 观察：可改的是 §5 的 **19 项**（#1–#19）；第 **20 项"上次改写回显"只读展示**（`data-readonly="true"`，无输入控件，值来自最近一次改写的 `readRounds/readChars/reason`）。
- 操作：把超时从 480 秒改成 30 秒并保存（不重启 DSH、不刷新页面），随后执行 `/draft-studio dump-request coding`。
- 观察：输出的 `timeoutMs` 变为 `30000`；再把温度从"不设置"改成 0，`dump-request` 的 `temperature` 变为 `0`。
- 判定：19 项逐项可改（逐项保存后 `dump-settings` 反映新值）+ 第 20 项只读 + 改后下一次请求生效 = 通过。
- 负例：需要重启 DSH 才生效 → 不通过；第 20 项出现可编辑控件 → 不通过。"页面刷新是否算生效边界"见 §7-A5。

### B19 预设编辑有门、有未保存计数

> **本轮状态（v3.3，2026-11-08）**：B19 已正式降级出 P4 范围（理由与签收要求见 §9 表末行）。本节判据保留，作为 P4 之后单独立项的验收依据，不在本轮签收。

- 操作：进入预设编辑。
- 观察：①默认只读（四套都是 `data-readonly="true"`）；②点"编辑"后仅该套可改（其他套仍只读）；③改动后出现"未保存 N 项"，**N 的定义 = 被改动的配置项个数**（计数对象为 §5 的 #6–#13 这 8 个字段，跨四套合计，同一字段多次改动只计 1）；④点"放弃"回到最后保存值；⑤点"保存"落盘且计数归零。
- 判定：五条都满足 = 通过。负例：改 2 个字段显示"未保存 3 项" → 不通过。
- 约束："恢复内置默认"只影响当前这一套，且需要二次确认。

### B20 设置不可用时的降级

- 操作：模拟设置不可用（把插件设置文件内容改成非法 JSON，或让读取命令返回 `error`）。
- 观察：①输入框仍出现**一颗**按钮（通用）；②点击仍能改写；③`dump-request` 的 `presetId` 为 `null`（请求不带预设 id）且 `system` 不含结构块标记；④界面无红色报错（`data-reason-code` 不出现）。
- 判定：四条都满足 = 通过。

### B21 芯片边界

- 草稿含 `/` 命令芯片（如 `/plan 帮我改`）：
  - 观察：允许发起改写；写回时**不得**破坏原草稿——要么正常写回，要么保留原稿并把结果置为待重试；任何情况下原稿不丢、无半截芯片。
- 草稿含 `@` 引用芯片：
  - 观察：改写与写回后，引用仍可见、可点（点击弹出引用预览）；`snapshotDraft()` 的 `references.length` 与每个 `offset` 与改写前**完全相同**（除非改写稿本身丢掉了引用标记，此时按"原稿不丢、结果待重试"处理，并在按钮上给出原因 `reference-lost`）。
- **判定动作（本版补全）**：
  1. `dump-draft` 输出 `{text, references:[{offset,length}], messageCount}`（`messageCount` 见 §4.1，本条不用）；
  2. 失败态定义为：`text` 中仍出现占位符字符（`[\uE100-\uE11D\uFFFC]`）但 `references.length` 比改写前少 → "半损坏芯片" = 不通过；
  3. 引用节点仍可点 = 通过；退化为纯文本但仍完整 = 不算半损坏（记已知限制），退化为纯文本且占位符残留 = 不通过。

---

## 4. 判定用的"可观察证据"来源（本版收紧）

**只承认两类，且必须能复跑；截图、宿主日志、口头复述都不能单独作为通过依据。**

| 类别 | 形态 | 用于 |
|---|---|---|
| E1 文件:行 | 本机安装包 / 仓库源码的精确行号，带可复跑的提取命令 | 宿主能力断言（"只有/必须/不支持"） |
| E2 命令 + 输出 | 命令原文 + 完整 stdout/stderr（含退出码），别人可原样重跑 | 一切行为判定与契约核对 |

**允许的 E2 命令清单（本轮已实跑或 P2 起可用）**

| 命令 | 作用 | 现已可跑 |
|---|---|---|
| `cordis_inspect_query(host, Service, listService, {service:"llm"\|"commands"\|"webServer"\|"sessionQuery"\|"sessionController"})` | 宿主契约 | 是 |
| `cordis_inspect_query(host, Config, listConfigs, {name, offset, limit})` | 配置目录与 entryId 形态 | 是 |
| `pwsh -File probe-tools/asar-probe.ps1 -Get '<asar 内路径>' -OutDir dump` + `Select-String` | 安装包源码行号 | 是 |
| `pnpm view @deepseek-ai/schemastery version` | 依赖是否可安装 | 是（本机返回 3.19.0） |
| `node --test "test/*.test.js"` | 纯逻辑红绿 | P2 起 |
| `node scripts/assert-preset.mjs <outputs.json>` | B5 结构判据 | P2 起 |
| `/draft-studio dump-request <preset> [--prepare] [--negative=model\|effort] [--force-effort=E]` | 请求转储（B5/B8/B9/B10/B18/B20） | P2 起 |
| `/draft-studio dump-settings` / `dump-draft` | 设置快照 / 草稿+引用+`messageCount` 快照（B3/B4/B6/B7/B17/B19/B21） | P2 起 |

**页面事实的"命令"形态**：在 Web 页面的 console 执行下面这段，输出一行 JSON（这就是 E2，不是截图）。**这段是基线模板**，覆盖 B1/B2/B12/B13/B21 与 B1-e 的全部字段；B3/B11/B15/B16 的追加键见 §4.1。

```js
(() => {
  const seats = [...document.querySelectorAll('[data-draft-studio-seat="conversation.input.right"]')];
  // 模型选择器是宿主元素（不给插件加探针属性）：只能按 aria-label / 文案定位
  const model = document.querySelector('[aria-label*="模型"], [aria-label*="Model"], [aria-label*="model"]')
    || [...document.querySelectorAll('button')].find(b => /模型|Model/i.test(b.textContent || ''));
  const editor = document.querySelector('[data-composer-input]'); // 编辑区根节点；不能用基于 contenteditable 的查询（submitting/sending 时它变 "false"，见 §4.1）
  const modelFound = model != null;
  const R = (el) => { if (!el) return null; const b = el.getBoundingClientRect();
    return { left: b.left, top: b.top, right: b.right, bottom: b.bottom, width: b.width, height: b.height }; };
  // rowRect = 座位与模型选择器的最近公共祖先（正常态即宿主 standardControls 行）；模型缺失时为 null
  const lca = (a, b) => {
    if (!a || !b) return null;
    const anc = new Set(); for (let n = a; n; n = n.parentElement) anc.add(n);
    for (let n = b; n; n = n.parentElement) if (anc.has(n)) return n;
    return null;
  };
  const visible = (el) => { if (!el) return false; const b = el.getBoundingClientRect();
    return el.offsetParent !== null && b.width > 0 && b.height > 0; };
  const inDock = (el) => el.closest('[data-composer-dock]') !== null; // 该属性在宿主源码里硬编码
  const inter = (a, b) => !a || !b ? 0 : Math.max(0, Math.min(a.right,b.right)-Math.max(a.left,b.left)) * Math.max(0, Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
  const eRect = R(editor);
  return JSON.stringify({
    count: seats.length,
    modelFound,                                     // false → B1-e 整条"无法判定"，不是通过
    ids: seats.map(e => e.getAttribute('data-preset-id')),
    order: seats.map(e => +e.getAttribute('data-order')),
    states: seats.map(e => e.getAttribute('data-state')),
    reasonCodes: seats.map(e => e.getAttribute('data-reason-code')),
    labels: seats.map(e => e.textContent),
    ariaDisabled: seats.map(e => e.getAttribute('aria-disabled')),
    elapsedMs: seats.map(e => { const v = e.getAttribute('data-elapsed-ms'); return v == null ? null : +v; }),
    hoverText: seats.map(e => e.getAttribute('data-hover-text')),
    actions: seats.map(e => [...e.querySelectorAll('[data-action]')].map(n => n.getAttribute('data-action'))),
    visible: seats.map(visible),                    // activity 展开 → false（count 仍是 4）
    inDock: seats.map(inDock),                      // 渲染到 dock → true，B1-e 必红
    hiddenByActivity: seats.length ? !!(seats[0].parentElement && seats[0].parentElement.closest('[hidden]')) : null, // 只看父级链：activity 展开 → true（standardControls 的 hidden 属性）
    seatRects: seats.map(R),
    rowRects: seats.map(e => R(lca(e, model))),     // 每颗按钮各自的"工具行"
    modelRect: R(model),
    editorRect: eRect,
    editorPhase: editor ? editor.getAttribute('data-phase') : null,
    editorOverlap: seats.reduce((s, e) => s + inter(R(e), eRect), 0),
    leftOfModel: !modelFound || seats.length === 0 ? null : seats.every(e => R(e).right <= R(model).left)
  });
})()
```

**片段字段口径**：`R()` 把 `DOMRect` 转成普通对象——直接 `JSON.stringify(getBoundingClientRect())` 会得到 `{}`（DOMRect 的属性在原型上），上一版片段写的就是这个错，本版一并修正。`leftOfModel` 在 `modelFound === false` 或没有座位时返回 `null`（**不是 `true`**）；`rowRects[i]` 在模型缺失时同为 `null`。`editorPhase` 取 `[data-composer-input]` 这个 div 上的 `data-phase`（`ui-conversation-client.js:20974–20981` 渲染该 div、`:21031` 传入 `data-phase`）；**不能用基于 `contenteditable` 的选择器**——`:21829`/`:21833`/`:20976` 使 `submitting`/`sending` 时该 div 的 `contenteditable` 变为 `"false"`，选择器匹配不到、相位读成 `null`（v3.1 修正，回应 05 §3.2）。`hiddenByActivity` 用座位**父级链**上的 `hidden` 属性（`standardControls` 的 `hidden: activity`，`:22107–22111`；不含座位自身），面板收起后为 `false`。

### 4.1 按条扩展表（基线片段 + 逐条追加键，回应 N-2）

> 规则：§4 片段是**基线**；某条验收需要的键不在基线里时，按本表追加，**来源必须是下表列出的选择器或命令**。表里没有的键不允许临场发明，缺就记"无法判定"。

| 验收条 | 追加键 | 来源（选择器 / 命令） | 用途 |
|---|---|---|---|
| **B3** | `messageCount` | **命令**：`/draft-studio dump-draft` 输出里的 `messageCount`；宿主半取数 = **`ctx.sessionQuery.readSurface(sessionId).events.length`**（`SessionSurfaceSnapshot.events: SurfaceEvent[]`，宿主 Inspect 契约，P7）。**计数对象写死**：当前 surface 的全部事件（类型表 `SurfaceEventType` = `system/developer/user/assistant message` + `tool/result`，含 `tool/result`）；**不含** `command/run\|done`、`turn/*`、`step/*`、`request/*` 与 shadowed/log-only 事件——所以 `dump-draft` 自身的命令不会污染计数；`readSurface` 抛错 → `messageCount: null` → B3 记「无法判定」，不得跳过。宿主消息列表没有稳定的 DOM 属性，故不走片段 | 写回前后相等 = 没新增消息（含 `tool/result` 在内都不新增，判据偏严不会空真通过） |
| **B3** | `editorPhase` | **片段**：编辑区根节点 `[data-composer-input]` 上的 `data-phase`（宿主源码 `ui-conversation-client.js:20974–20981` 渲染该 div、`:21031` 传入 `data-phase`；**不要用基于 `contenteditable` 的选择器**——`:21829`/`:21833`/`:20976` 使 `submitting`/`sending` 时它变为 `"false"`，选择器取不到元素）。取值：`plain/claimed/adjudicating/submitting/sending`（`SubmitMachine`，`:5285`–`:5385`） | 全程不得出现 `submitting`/`sending`；**负例**：构造 `input.phase="submitting"` 跑片段，`editorPhase` 必须等于 `"submitting"`（不是 `null`），否则该负例记红 |
| **B11** | `ariaDisabled` | **片段**：座位根上的 `aria-disabled` | 其余三颗置灰 |
| **B11** | `elapsedMs` | **片段**：座位根上的 `data-elapsed-ms`（毫秒整数） | 两次采样差 ≥ 900ms |
| **B15** | `hoverText` | **片段**：座位根上的 `data-hover-text`（组件把**真正会显示的悬停文案**原样写到该属性） | 判据是文案内容，不靠"看着有提示" |
| **B16** | `actions` | **片段**：座位内 `[data-action]` 子节点的属性值集合 | `revert`/`retry`/`cancel` 的有无 |

**属性清单的落点**：`data-elapsed-ms`、`data-hover-text` 与既有的 `data-draft-studio-seat`/`data-preset-id`/`data-order`/`data-state`/`data-reason-code`/`data-action` 一起进 `02-plan.md` S5 的组件属性清单（N-2 要求的那一半）。

**明确不接受的证据（上一版的错误，本版删除）**

1. **`command/run` / `command/done` 不能证明模型与强度。** 契约 `CommandInvocation` 只有 `{commandId, agent, rawInput, attachments, signal}`；`command/run` 是 handler 调用前的 log-only 追加，`command/done` 是结算后的追加，二者都是围绕同一次调用的记录，字段里没有 `provider/model/reasoningEffort`。它们只证明：请求次数、发起时点、取消/错误类别。
2. 截图、录屏、逐步复述：只能做辅助说明。
3. 插件自己打印的"我用了 M3/S3"单独不算；必须叠加宿主 `llm.prepareCall` 的物化结果或宿主的拒绝错误文本（B8/B9 的负向对照）。

---

## 5. 配置项契约（20 项 = 19 项可改 + 1 项只读）

> 说明：原文只说"约 20 个配置项"，没给清单。这里定 20 项覆盖原文第 6、7 条提到的全部能力，作为实现与验收的唯一口径。
> **可改/只读口径（本版定案）**：原文第 7 条"约 20 个配置项可改"与第 12 条"上次改写回显"按语义取最保守解释——**回显是展示项，不是可改项**，因此 #1–#19 可改、#20 只读。该判定记入 §7-A13，客户若要"20 项全可改"，需先把 #20 改名成另一项能力（只改本表，不推翻验收结构）。

| # | 配置项 | 取值 | 默认 | 作用点 |
|---|---|---|---|---|
| 1 | 总开关 | 开/关 | 开 | 关 = 一颗按钮都不出现（B1-c） |
| 2 | 读上下文 | 开/关 | 开 | 关 = 请求不带会话历史 |
| 3 | 上下文轮数上限 | 1–20 | 6 | 读几轮 |
| 4 | 上下文字符上限 | 200–8000 | 2000 | 超出截断 |
| 5 | 显示哪几颗 | 四个勾选 | 全选 | 取消不丢预设（B6） |
| 6 | 预设 通用 | 文本 | 内置 | 提示词模板 + 结构块（B5） |
| 7 | 预设 编程 | 文本 | 内置 | 同上 |
| 8 | 预设 写作 | 文本 | 内置 | 同上 |
| 9 | 预设 翻译 | 文本 | 内置 | 同上 |
| 10 | 预设显示名 通用 | ≤12 码位 | 通用 | 只影响显示（B7） |
| 11 | 预设显示名 编程 | ≤12 码位 | 编程 | 只影响显示 |
| 12 | 预设显示名 写作 | ≤12 码位 | 写作 | 只影响显示 |
| 13 | 预设显示名 翻译 | ≤12 码位 | 翻译 | 只影响显示 |
| 14 | 模型来源 | 跟随会话 / 固定 | 跟随会话 | B8/B9 |
| 15 | 固定模型 | provider/model | 空 | 固定模式下必填 |
| 16 | 固定强度 | 该模型支持的 effort | 该模型默认 | 不支持时按 B10 退回 |
| 17 | 超时上限 | **30–600 秒** | **480 秒** | B17；<30 秒拒绝保存 |
| 18 | 温度 | 0–1 | 不设置（用宿主默认） | B5 稳定性控制；不改宿主默认 |
| 19 | 输出长度上限 | 256–8192 tokens | 不设置（用宿主默认） | 不改宿主默认 |
| 20 | 上次改写回显 | **只读展示** | 空 | 读了几轮几字 / 没读的原因；无输入控件 |

**"改完即时生效"的判定**：保存后不重启、不刷新页面，下一次点按钮（或一次 `dump-request`）就使用新值（B18）。

---

## 6. 不做清单（明确排除）

1. **不自动发送**：任何路径都不调用发送/提交接口。
2. **不做多轮改写**：一次改写只读草稿（+可选历史），不读上一次改写稿，不串联。
3. **不做模板库**：除四套预设外，不提供自定义模板集合、不提供导入导出。
4. **不做历史记录**：不保存改写历史、不提供撤销面板；只保留"最近一次改写"的回显信息。
5. **不做重启后上下文回放**：进程重启后不恢复任何进行中的改写。
6. **不改宿主输入框的既有行为**：不接管 Enter/发送、不接管 `/` 与 `@` 的解析、不写宿主 DOM、不追加第二个 app。
7. **不新增 Remote 命名空间**：宿主的 Remote 端点表是构建期固定的，本插件不试图注册新端点。
8. **不做多语言以外的平台适配**：只做 Web（Desktop 内嵌 Web 视同 Web）。
9. **不做模型请求的计费/配额管理**：不拦截、不统计、不限额。
10. **不在 P0/P1/P1.5 写功能代码**：P1.5 只允许探针件（selftest 命令 + 最小插槽组件），不含业务逻辑。

---

## 7. 歧义清单（A1–A13，全部「自查可解」）

> 规则：能用原文自洽解释 + 有技术依据的，必须"自查可解"，不上抛；只有原文本身**互相冲突或指向两种不可兼容的实现承诺**时，才"客户裁定"。本版经复核，13 条全部满足自查条件，**没有"待裁定"项**。

| 编号 | 歧义 | 判定 | 类型 | 依据 |
|---|---|---|---|---|
| A1 | "发送键左侧"的确切位置 | 注册到 `conversation.input.right`（**list**，会话域），每颗按钮一条、带不同 `id`（= presetId）与 `order` 0–3；渲染顺序在模型选择器之前、Stop/Send 左侧，仍属发送区左侧。不占用 `activity`（single，语义是单个可展开控制）。 | **自查可解（已结案）** | ①座位声明：`dsh-client-ui-conversation/lib/client.js:22982–22985`（`kind:"list"`, `scope:"session"`）；②渲染顺序：同文件 `22110`（`[right]` 在 `[model]` 之前）；③list 允许多条并存：`dsh-web-frontend/dist/assets/index-BgUyXZcc.js` 字符偏移 492065–492300（缺 `id` 抛错 @492133、同 `id`+同 priority 冲突检查 @492275）；④客户答复：`00-client-answers.md` C1 + 追加提醒"列表座位优先，是第一优先，不是备选"。 |
| A2 | `@` 引用"不受影响"到什么程度 | 改写后按"原引用标记还在改写稿里"把引用芯片**原位重建**；模型丢掉标记时按"原稿不丢、结果待重试"处理并给原因 `reference-lost`。不允许引用退化成纯文本后静默写回。 | 自查可解 | 宿主草稿是可语义化的（`{text, references:[{offset,length,clipboardText,…}]}`），占位符正则 `[\uE100-\uE11D\uFFFC]`；重建失败有明确降级（B21）。 |
| A3 | "约 20 个配置项"的清单 | 由 §5 的 20 项固定；增删只改本表，不改验收结构。 | 自查可解 | 原文第 6、7 条已列出全部能力面，20 项是其最小完备覆盖。 |
| A4 | "编辑门防误改"是什么门 | 每套预设默认只读；点该套的"编辑"解锁该套；切换/保存/失焦后自动上锁；"恢复默认"二次确认。 | 自查可解 | 原文括号内三项描述的是同一处交互，取最保守解释即可判真假（B19/B7）。 |
| A5 | "改完即时生效"是否包含刷新页面 | 不包含。口径是**不重启、不刷新页面**即生效；刷新后仍生效当然更好，但不作为验收。 | 自查可解 | 原文强调"每次请求重读"，指向持久化后的读取时机；把刷新算进去会把"持久化失败"误判成"未生效"。 |
| A6 | "切走再切回请求不断"里"切走"是否含刷新/关闭页面 | 不含。切换会话/切视图算切走；刷新/关闭页面不保证（且与"不做重启后回放"一致）。 | 自查可解 | 原文非目标里明确排除重启回放。 |
| A7 | "发送后转圈自停"后，晚到的结果怎么办 | 丢弃结果、停止转圈、不写回、不提示成功；按钮回到空闲。 | 自查可解 | 用户已经用原草稿发出去了，此刻写回会制造"幽灵草稿"；B14 按此判定。 |
| A8 | 固定模型被删/不可用时 | 视为"设置不可用"同类降级：退回跟随会话，按钮上不报错，设置页给一次提示。 | 自查可解 | 原文对"固定模型不支持所选强度"已要求自动退回，删除模型是同类更强情形。 |
| A9 | "结果保留待重试"的可见形态 | 按钮进入"待重试"态（`data-state="retry-pending"`，与失败态同视觉族、文案区分），悬停显示"结果已生成/未写入原因"，点击重试 = 用**当前**草稿重跑。 | 自查可解 | 原文只要求"保留待重试"+可重试；B13 已把语义钉死。 |
| A10 | 四颗按钮同时可见 vs "最多四颗" | 上限 4 是配置上限；实际显示 = 勾选数（且总开关关闭时为 0）。 | 自查可解 | 原文"最多四颗"+"显示哪几颗（取消勾选不丢预设）"两句合读唯一。 |
| A11 | 词条语言 | 中文为主，按钮名取预设显示名；界面文案随宿主 locale（中/英）。 | 自查可解 | 宿主有 locale 服务，属实现约定，不影响判真假。 |
| A12 | 改写稿为空/只有空白 | 视为失败，`data-reason-code="empty-result"`，原稿不动。 | 自查可解 | 空结果写回等于清空用户草稿，与"原稿不丢"直接冲突。 |
| A13 | "约 20 个配置项可改"与"上次改写回显"是否冲突 | 不冲突：回显是展示项。定 19 项可改 + 第 20 项只读。 | 自查可解 | 原文第 7 条说"配置项可改"，第 12 条列的是"回显"（读了几轮几字/没读的原因），语义上只能读；两项合读取最保守解释。B18 按 19+1 判定。 |

---

## 8. 客户答复回填（C1 已结案，无待裁定项）

**客户原话（`00-client-answers.md`）**

> C1 位置容差：**接受**：按钮放在模型选择器之前（仍属发送区左侧），允许与发送键之间隔一个模型选择器的距离。**不接受**占用「活动区」。
>
> 追加提醒：「发送键左侧」在我这边指的是**发送区左侧**，不是"紧贴发送键"。如果存在**列表语义**的座位能容纳多颗按钮，优先用它；只有在确实没有列表座位时，才走 C1 的妥协方案。请把这条当成位置判定的第一优先，而不是备选。

**回填结果**

1. **座位 = `conversation.input.right`（list）**，属于客户说的"列表语义座位"，且渲染在模型选择器之前、Stop/Send 左侧，**同时满足**客户两条要求。**不需要容差**，也不占用 activity。
2. 上一版把它写成"容差妥协"并上抛客户，是误判：`right` 的 `kind` 在宿主源码里就是 `list`（`client.js:22982–22985`），且 list 允许 1–4 条不同 `id` 并存（`index-BgUyXZcc.js:492065–492300`：缺 `id` 抛 `requires options.id` @492133；同 `id` 冲突检查 @492275）。该误判已删除。
3. **残余事实（不是裁定项，写进验收前提，客户知情记录见 §8.5）**：宿主 `standardControls` 带 `hidden: activity`（`client.js:22107–22111`），activity 展开时 `right` 会被隐藏；新会话无 `sessionId` 时也不渲染。二者进入 §3.0 观察前提与 `02-plan.md` 的 D1/U1，影响 B1 的可达性判定，不影响座位选择。
4. **状态复核（可复跑）**：A1 的类型字段为「自查可解（已结案）」，§8 标题为「客户答复回填（C1 已结案）」；`02-plan.md` §6.1 第一项已勾选。复核命令与期望输出见 `02-plan.md` §6.2 第 9 行。

### 8.5 activity 展开态的客户知情记录（本轮 C-1，补 `04` 报告 §5.3 的缺口）

> 性质：**这不是歧义裁定，也不是"待裁定"项**——座位已定、判据已定，本条只是把"宿主限制导致某个显示态观测不到"这件事写成客户可签收的知情记录。开发者不得单方把它记成"客户已接受"。

| 项 | 内容 |
|---|---|
| 触发条件 | 用户展开输入框右侧的**活动面板**（宿主 `conversation.input.activity` 占位者调用 `onActiveChange(true)`；`ui-conversation-client.js:22112–22116`，activity 默认 `false` @`:21767`）。 |
| 表现（源码事实） | 同一时刻宿主只显示"工具行"或"活动面板"：`standardControls` 整行 `hidden: activity`（`:22107–22111`），因此 `conversation.input.right` 里的**四颗按钮**与**宿主自己的模型选择器**一起不可见；DOM 节点仍在，§4 片段会得到 `count === 4`、`visible` 全 `false`、`inDock` 全 `false`、`hiddenByActivity === true`。 |
| 恢复方式 | 收起活动面板即恢复（activity 回到 `false`），按钮与模型选择器同时回来；会话切换也会把它重置为 `false`（`:21769`）。 |
| 影响（写清边界） | ①B1-e 在该态记「无法判定/未验」，**不判失败、也不判通过**（`visible=false` 且 `hiddenByActivity=true` 已使"计数为 4"不可能假通过；面板收起后仍 `visible=false` 则判「不通过」）；②B1-a～d、B2 的判定只在"activity 未展开"的默认态成立（§3.0）；③其余验收（B3～B21）不受影响——它们都在改写运行态观察，不依赖 activity 展开；④**不影响座位选择**：`left` 同在 `hidden: activity` 的 `tools` 容器（`:22071`），换座不解除；`dock` 虽保可见但正是 B1-e 判红的落点。 |
| 由谁接受 | **客户**在 P4 交付时随"已知问题清单"签收（同批含 Ctrl+Z 附加观察、`@` 引用退化等）。开发者（本文件作者）负责把记录写清并在 P4 复述；**未签收前状态 = 「已告知、待签收」，不得写成"客户已接受"**。 |
| 当前状态 | 记录已成文（本小节）；客户回执未取得（本轮不接触客户、不改 `00-client-answers.md`）。`02-plan.md` §6.1 与 R9 同步指向本条。 |
| 若客户不接受 | 只剩两条路：换到 `conversation.composer.dock`（B1-e 负例直接判红，等于推翻位置验收）或放弃"activity 展开时按钮仍可见"这条隐含期望（客户原文未要求）。两者都要回到 C1 位置裁定，属**上抛客户**，不在本轮自行决定。 |

**与"验收退化"的界线（复述 `04` §5.3）**：默认态判据一条不少；被排除的只是宿主自有的一个显示模式，且要求记"未验"而不是记"通过"。若写成"activity 展开 = 通过"，那才是退化——本文件不这样写。

---

## 9. 三态与不可判定项（P0 阶段声明，P1.5 清零，P2 开工时按 `06-p1.5-probes.md` 回写）

> **v3.2（P2 开工回写，2026-11-08）**：本表按 `06-p1.5-probes.md` §3/§6/§7 与 `06-lead-decision.md` 更新状态列；**验收判据 B1–B21 一字未改**，变的只是"这条依赖现在是什么状态、谁在何时清"。
>
> **v3.3（修复轮 v2 回写，2026-11-08）**：①设置命名空间按 `12-lead-decision-v4.md` D-05 回退为**裸 patchId**（`include:<patchId>` 只是 `Config.listConfigs.id` 的显示形态）；②**B18/B19 正式降级出 P4 范围**，理由与签收要求见本表末行。其余判据不变。

| 项 | 当前状态 | 谁在何时清零 | 说明 |
|---|---|---|---|
| 宿主插槽 `conversation.input.right` 的**静态声明**（kind/渲染顺序/多条目） | **已验(源码)** | 已清零 | 见 §7-A1 出处；已足够裁决座位语义 |
| 该座位的**运行时占用者** | **已验（源码 + 安装态）**（P1.5 U1-①） | 已清零 | 运行时已有 **2 条**他人条目且都在跑（`status:"schema"`）：前代 `dsh-draft-studio`（order 60）与 `@wufeng0105/dsh-teammate-model-picker`（order 10）。B1 判据不变（§4 片段按 `data-draft-studio-seat` 过滤，前代与 picker 该属性 0 命中），但界面会并排；见 `02` §5-R11 |
| 该座位的 **activity 展开态与无 `sessionId` 首帧的实际渲染** | **无法判定（运行时）**，静态链已闭环（P1.5 U1-②） | **负责人已接受**（`06-lead-decision.md` §2）；客户在 **P4** 随已知问题签收（§8.5）；开发者在本项目探针安装后立即补跑 | 本机 Client Inspect **累计 9 次全超时**（含本轮 1 次），无浏览器控制 → `01` §4 片段一次未跑。**超时不是"页面没开"**（GUI 在线、鉴权层正常应答 401），真实原因未查明（`probes.md` P3 归因修正）。B1-e 在该态记「未验」不记通过 |
| Theme 令牌清单（D17） | **已定降级（源码级清单）**（P1.5 U1-③） | 已清零 | Client Inspect 取不到运行时清单，改读已发布包：414 个 `--dsw-*` 全部有定义，其中 `--dsw-alias-*` 114 个。样式只用 `--dsw-alias-*`，**禁止写死字面色**；验收不含像素级比对，**验收不变** |
| 命令通道的**分钟级长调用**与取消传播 | **无法判定（运行时）**，源码链完整（P1.5 U2） | 负责人已接受"暂不实测"（`06-lead-decision.md` §3）；开发者 S1 装探针后立即补测 | 客户端 unary 无超时、传输上限 300 MiB、abort 贯通到 handler（均源码级）；网关行为未跑。降级链已写死在 `02` §3-U2，P2 不再议 |
| 命令行的**长度上限**（草稿可能数千字） | **已验（源码级）**，运行时回显待补（P1.5 U3） | 同上（S1 补测成本≈0） | `parseCommand` 尾部原样保留、无 `maxLength`；8000 字符 ≈ 8–24 KiB，距 300 MiB 差 4 个数量级 |
| 插件自建 HTTP 路由的鉴权行为（U4，条件项） | **已验（运行时）→ 降级 A 可用** | 已清零 | `POST /dsh-draft-studio/refine` 在**浏览器口无凭证返回 200 + 业务 JSON**；根与 `/api/*` 401、未知路径 404。根因：命名路由绕过 `connection.admit()`。**已转入 §3.0 之外的已知风险**：若本插件走降级 A，handler 必须自带守卫（`02` §5-R10） |
| workspace bundle 能否解析 `@deepseek-ai/schemastery` | **已验（运行时等价形态）**（P1.5 U5） | 已清零 | profile 已装 3.19.0 且显式声明依赖；在装包的 `Config` 投影在运行中成功，宿主 `isNativeConfigSchema` 认同一份协议 → **走 Config，不走文件降级** |
| 易变字段 `volatile()` 的**实际读取语义** | **已验（源码 + 运行时投影旁证）**（P1.5 U6） | 已清零 | volatile-only 变更走原地引用更新、不重载插件；`get()` 读同一引用 → 下一次必见新值。代码里仍按设计 `config.field.get()`，非 volatile 字段一律不用 |
| 本插件设置命名空间（Config 寻址） | **已裁定（源码 + 运行时形态）**；本插件具体值待安装后复核（P1.5 U7） | 安装后复核一次 | **两个 id 必须分开**：`Config.listConfigs.id` 是显示 id `include:<patchId>`（目录 229 条无一例外），而设置命名空间是**裸 patchId** `entry.options.id`（`dsh-settings` 以 `ns: entry.options.id` 存取；官方调用方一律 `configForms.get("ui-settings")` 等裸 id）。本插件 patch 行 `id: lab-draft-studio` → 浏览器应传 **`lab-draft-studio`**，不是 `include:lab-draft-studio`。依据：`12-lead-decision-v4.md` D-05、`11-reverification.md` §2.3 |
| **与在装 `dsh-draft-studio@1.2.2` 的关系** | **已裁定 = 显式并存（方案 B）** | 已结案（负责人，`06-lead-decision.md` §1） | 包名 `@local/lab-draft-studio`、`meta.title`、座位 id `lab-draft-<presetId>`、设置页 id `lab-draft-studio` 全部加实验前缀；**不删除、不停用、不改动**前代及其数据。**探针属性名 `data-draft-studio-*` 保持不变**（§4 片段与前代 0 命中的实测都建立在它上）。界面后果：工具行最多 6 个控件、设置页两个草稿工坊（`02` §5-R11） |
| 其余（按钮/写回/回退/取消/四态/超时/降级） | **可判定** | P2 起按 §3 逐条判 | 判据已写死，证据口径见 §4。**离线可验的部分已在 `bundle-lab/` 的纯逻辑内核里跑成红绿**（见 `07-implementation.md`/`08-selfcheck.md`）；运行时部分留 P3 |
| **B18 / B19（设置页 19 项编辑 + 预设编辑门）** | **已定降级：移出 P4 范围** | P4 之后单独立项（不进本轮签收） | 设置页当前把 19 个可改行渲染成 `span`（`client.js:1799`，`data-settings-input` 只是标记），全文无 `input` / `onChange` / `save-settings`；`countUnsaved` 在内核里有定义但**无调用点**，`unsavedCount` / `data-edit-gate` / `restore-default` 均未实现。**降级理由**：①工作量——19 项控件 + 每类校验回填 + 编辑门 + 未保存计数 + 恢复默认二次确认，是一整块页面交互，不是补一行接线；②依赖未接——写路径 `persist` 在 P4 宿主侧未接（`save-settings` 现在诚实返回 `persist-unavailable`），#20 回显依赖 `lastResult` 写入点（当前恒 `null`）。**P4 签收单必须写明 B18/B19 不在本轮范围**；B1–B17、B20、B21 判据不变 |
