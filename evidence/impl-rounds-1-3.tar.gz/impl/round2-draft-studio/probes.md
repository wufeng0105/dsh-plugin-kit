# probes.md — 宿主探测记录（dsh-draft-studio，P1）

> 记录格式：探测了什么 / 怎么探 / 结论（三态）/ 时间点。所有"已验"都指**本机这次会话亲测**；二手结论（文档、round1 产物、README 转述）一律标注来源并单独列"来源"行。
> 本机 Client Inspect 全部超时（P3），所以客户端侧事实全部来自**读本机已安装 app.asar 内的源码**（P16 的工具），这不是猜测，但也不是运行时验证——标 `已验(源码)`。

时间基准：会话本地时区 Asia/Shanghai（UTC+8）。P0/P1 探测窗口：2026-11-08 01:30 – 01:45。

---

## P1. Inspect Provider 目录（宿主侧可用面）

- 探测：`cordis_inspect_list`（只读）。
- 结论：`已验`。宿主侧 4 个 Provider：Service / Event / Config / Tool；客户端侧 5 个：Service / Event / Builtin / Slots / Theme。
- 时间点：2026-11-08 01:30。
- 用途：确定后续探测的合法入口（不得猜 Provider/方法名）。

## P2. 插件打包契约与宿主实践红线（二手，已复核出处）

- 探测：读取本机安装的 `@deepseek-ai/dsh-agent-preset/skills/cordis-plugin-development/` 下 `SKILL.md`、`references/host-plugin.md`、`references/ui-plugin.md`、`references/practices.md`、`references/user-actions.md` 与 `templates/decoration/{package.json,client.js}`（宿主自身的读文件能力可开 app.asar 路径；shell/glob 不行）。
- 结论：`已验(契约文档)`。要点：bundle=`package.json` 声明 `dsh.bundle.patch` + patch 插行；客户端入口 `dsh.client {platform:'web', immediately, inject}` + `./client` 导出；`window.__ModuleLoader__.load({id, factory})`；slot 注册 `ctx.slots.inject(ownerKey, () => ctx.slots.register(...))`；插件 UI 必须用宿主主题令牌、不得 require 宿主 primitive 包、不得写 DOM/加第二个 app；Config 用 schemastery，易变字段 `.volatile()` 原地更新、`config.field.get()` 读取；安装走 `plugin_manager install_bundle`（需批准，本轮禁装）。
- 时间点：2026-11-08 01:31–01:33。
- 来源：宿主自带 skill 文档（一手合同文本，非他人转述）。

## P3. 客户端侧 Inspect：本机不可用

- 探测：`cordis_inspect_query(platform=client, …)` 三连：`Slots.listSubTree {}`、`Builtin.listBuiltins {}`、`Service.listService {}`。
- 结论：`未验（超时）`。三次全部 `Client inspect query … timed out after 10000ms. Open or reconnect the Harness page, then retry.`
- 时间点：2026-11-08 01:30–01:32。
- 处置：客户端事实改走 P16 的源码读取；运行时补探列入 02-plan U1（页面在线时）。

> **归因修正（2026-11-08 07:3x，`06-p1.5-probes.md` §1.1 实测后回写；对应 `06` §9 的定点）**
>
> **本条上一版写的归因「无有效页面响应 / 页面没开」是错的，必须划掉。**
>
> 证据：①同一时刻 `GET http://127.0.0.1:6727/` → **401**（`dsh web authentication required; …`，68 字节），`GET /api/nope` → **401**，`GET /__probe_no_route__` → **404** —— 鉴权层在正常应答，**进程活着、监听在、路由表在**；②运行上下文里的 GUI URL 就是 `http://127.0.0.1:6727`，页面确实在线；③本轮（P2 开工）再打一次 `Slots.listSubTree {root:"conversation.input.right"}`，**仍然 `timed out after 10000ms`**，与 `06` §1.1 的两次、P24 的一次同形。
>
> 也就是说：**Client Inspect 超时的原因不是"页面没开"**，而是另一个**尚未查明**的原因（候选：Provider 侧没有可应答的页面会话、runner 与页面之间的应答通道未建立、或 provider 只对特定页面状态应答——本轮**没有**证据裁决其中任一个）。
>
> 影响与处置：①计数以 `06-p1.5-probes.md` §1.1 为准（该节记"历史累计 8 次、零成功"，并列出 P3 的 3 次、P24 的 1 次、07:00 的 2 次）；**本轮（P2 开工）再加 1 次 = 累计 9 次零成功**。按 `04`/`06` 的规则**不再重试同一形态**；②客户端事实继续全部走源码级（P16/P24），运行时结论记「无法判定」或「未验」，**不得因为"页面在线"就把它写成已验**；③`06-p1.5-probes.md` §7 已把 U1-② 的风险交负责人接受、客户在 P4 签收。

## P4. 宿主 `llm` 服务精确契约

- 探测：`cordis_inspect_query(host, Service, listService, {service:"llm"})`。
- 结论：`已验(契约)`。关键点：
  - `stream(options: GenerateOptions): AsyncIterable<StreamChunk>`；GenerateOptions 含 `provider/model/reasoningEffort?/messages/system?/signal?/sessionId?`（可独立一次性调用，不依赖 agent）。
  - `resolveCallConfig`："Unsupported explicit efforts reject before provider I/O; no clamping or aliasing"——B10 退回默认强度的宿主级依据。
  - `StreamChunk` 有 `text-delta / finish{reason: 'stop'|'error'|'aborted', failure}`——超时与失败分类的来源。
  - 访问方式：`inject:['llm']`（硬依赖）或 `ctx.get('llm')`（可选）。
- 时间点：2026-11-08 01:33。
- 依赖项：02-plan D7/D8。

## P5. 宿主 `commands` 服务精确契约（D9/D10 主通道）

- 探测：`cordis_inspect_query(host, Service, listService, {service:"commands"})`。
- 结论：`已验(契约)`。`register(definition)`（全局命令，含 `input.hint`）；`@Remote execute(agent, line, submittedAttachments, signal)`：完整解析执行、`command/run`/`command/done` 为 log-only 追加（不进对话流）；`CommandResult = success{text?} | error{text}`。
- 时间点：2026-11-08 01:33。
- 已知副作用：命令会出现在 `/` 菜单（用户可见）——列入风险 R1。

## P6. 宿主 `webServer` 服务契约（降级通道 A 的可行性面）

- 探测：`cordis_inspect_query(host, Service, listService, {service:"webServer"})`。
- 结论：`已验(契约)`。`register(route)` 支持 exact/prefix 资源路由，返回 disposer；`WebResource = (request, peer?) => Promise<Response>`，peer 带 Principal。
- 时间点：2026-11-08 01:34。
- 鉴权行为未验 → U4（仅降级 A 需要时补探）。

## P7. 会话读取服务（上下文折叠）

- 探测：`cordis_inspect_query(host, Service, listService)` 全量目录 + 精读 `sessionQuery` 段。
- 结论：`已验(契约)`。`sessionQuery.readSurface(sessionId)` / `listEvents(sessionId)` / `listSessions()` 均为公开签名（一次性读取，非订阅）。**05 复审修订（2026-11-08）**：本轮 `cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})` 实读 15 个方法；`readSurface` 返回 `SessionSurfaceSnapshot{events: SurfaceEvent[]}`（`SurfaceEventType` = 四类 message + `tool/result`），`listEvents` 返回 `SessionEventRecord[]`（含 `surface: current/shadowed/log-only`）。**旧记录里的方法名已不在方法表中**，`messageCount` 取数口径按 `01` §4.1 钉死为 `readSurface(sessionId).events.length`。
- 时间点：2026-11-08 01:31。
- 依赖项：D11。

## P8. Config 投影（Config entryId 寻址 + 已安装包示例）

- 探测：`cordis_inspect_query(host, Config, listConfigs, {limit:25})` 与 `{name:"@deepseek-ai/dsh-client-ui-conversation", limit:10}`；再查 `entry:"include:ui-conversation"`。
- 结论：`已验(契约)`。目录条目含 `id/patchId/name/status`；单条查询返回 `packageDir`（可直接读 README）；`ui-conversation` 的 schema 形态为 anyOf + `$defs.loaderExpression`。
- 时间点：2026-11-08 01:34。
- 依赖项：D18；U7 补探本插件安装后的 id。

## P9. Remote wire 契约（客户端怎么传 SessionId）

- 探测：asar 内提取 `dsh-commands/lib/typert.remote-client.js` 与 `dsh-api-remotes/lib/client.js`（P16 工具），grep `lookup: "agent"`。
- 结论：`已验(源码)`。`commands/execute` 的 wire 参数：`agentId: string`（lookup=agent）、`line: string`、`submittedAttachments: array`、`signal`；客户端侧全部以 SessionId 字符串传 lookup 参数（`ctx.remote.commands.execute(sessionId, line, attachments, signal)` 形态成立）。
- 时间点：2026-11-08 01:36–01:37。
- 依赖项：D9。

## P10. 草稿编辑器事实（客户端 bundle 源码级）

- 探测：asar 提取 `dsh-client-ui-conversation/lib/client.js`（940KB）并精读以下实现：
  - `SessionInputShell.actions`（=标准 prop `inputActions`）：`insertQuote / captureInsertion / insertText(text, span) / setDraft / persistDraft / addAttachments / removeAttachment / pruneAttachments / submit`。
  - `insertText`：`frozen(phase) || disposed → false`；`span.draftRev !== this.rev → false`；落到 `draftEditor.insertAsyncText(span, text)`（**"一次独立撤销操作"**）。
  - `setDraft(text)`：整段替换、并入历史（**不是独立撤销步**）。
  - `InputState.compose()`：`{draft, attachmentIds, draftRev, phase, claim?, occurrences, queue}`；`phase ∈ plain/claimed/submitting/sending/adjudicating…`。
  - `snapshotDraft(text, occurrences, commandToken, quotes)` → `{text, references:[{source,ref,offset,length,label,clipboardText,appearance?,invalid?}], command?, quotes?}`；占位符正则 `[\uE100-\uE11D\uFFFC]`；`resolveDraftInput`/`restoreDraft` 支持带引用恢复。
  - Lexical 撤销栈存在（`undoStack/redoStack`），粘贴是独立历史边界。
- 结论：`已验(源码)`。B3/B4/B13/B21 的机制面成立：写回用 `insertText`（带 rev 守卫）→ 原生撤销；整段替换用 `setDraft`（无独立撤销）；覆盖保护由 `draftRev` 守卫承担。
- 时间点：2026-11-08 01:36–01:40。
- 依赖项：D2/D3/D4。

## P11. 标准插槽 props 与会话钩子的公布方式

- 探测：同一 bundle 内精读 `ctx.uiSession.provide({hooks:["conversation","input"], props:["inputActions"], resolve})` 与 `InputBar` 组件的 props 接收。
- 结论：`已验(源码)`。任何注入 `conversation.composer.bar` children 的组件都拿得到 `useInput`/`inputActions`（Provider 机制，与具体插槽无关）。
- 时间点：2026-11-08 01:37。
- 依赖项：D2。

## P12. 设置体系（持久化与页面插槽）

- 探测：asar 提取并精读 `dsh-client-ui-settings/README.md` + `lib/client.js`，`dsh-client-ui-settings-general/lib/client.js`（设置壳）与 README。
- 结论：`已验(源码+文档)`。要点：
  - 客户端 `ctx.configForms.get(entryId)`：值/继承/原始/revision/可写性，`set/unset/mutate` 原子写、冲突保护。
  - `ctx.configForms.whileServed(namespaces, register)`：命名空间未被服务时页面自动不出现（官方页均用此模式）。
  - 设置壳以 `settings.section`（list, root）台账渲染导航与页面：注册形如 `{name:'settings.section', id, order, label:()=>t(), locale, children}`；页面组件收到 `{ close }`；`settings.section.icon` 用同 id 配图标。
  - `settings/describe` mirror + `settings/document-updated` 转发事件 → 跨页一致。
- 时间点：2026-11-08 01:39–01:41。
- 依赖项：D12/D13/D18。

## P13. 输入框工具行插槽拓扑（客户端 bundle 源码级）

- 探测：同一 bundle 精读 `conversation.composer.bar` 的 children 声明与 `InputBar` 渲染调用。
- 结论：`已验(源码)`。children：`conversation.input.attachments(single) / overlay(list) / permission(single) / left(list) / plan(single) / right(list) / model(single) / activity(single) / composer.dock(list)`；`conversation.input.dock(list, session)`、`conversation.composer(chain)` 同域。
- 渲染顺序（右簇）：`[right] [model] [activity] [Stop] [Send]`；activity 是**单占位**且语义是"一个可展开控制"（放不下 1–4 颗并列按钮）。
- 其他插槽：`conversation.composer.dock` 在工具行**下方**整行（README 亦如此描述），`main.conversation / conversation.header / session.header.*` 等同录。
- 时间点：2026-11-08 01:38。
- 依赖项：D1/D13；A1 的"位置容差"事实基础。

## P14. 第三方插件能否新增 Remote 端点（负向结论）

- 探测：`dsh-api-remotes/README.md` 精读（asar 提取）+ Client bundle 粗查。
- 结论：`已验(源码+文档)`。Remote 端点表是**构建期固定**的显式值导入（`src/remote-events.ts` 的 allowlist + 显式 `/remote` 值导入并 `ctx.remote.$mount()`）；"Additional capabilities require an explicit `/remote` value import and mount in this assembly"；Client 不在运行时发现宿主服务。
- 推论：本插件**不可能**注册新 Remote 命名空间；数据通道只能复用既有端点（commands/session/…）或宿主 `webServer` 路由。这直接否掉了"插件自带干净 RPC"的第一直觉。
- 时间点：2026-11-08 01:39。
- 依赖项：D9 的"为什么非它不可"。

## P15. 动态 Cordis 包的生命周期（被否掉的形态）

- 探测：asar 提取精读 `dsh-cordis-host-runner/README.md` + `dsh-cordis-client-runner/README.md`。
- 结论：`已验(文档)`。定义会话级、进程内、重启消失；浏览器半 run 需人工批准；`host.call` 只达自己宿主半；Client Inspect 超时=无有效页面（10s 默认）。
- 推论：与"常驻按钮"需求冲突 → 不采用（02-plan §1）。
- 时间点：2026-11-08 01:39。

## P16. asar 只读探测工具（本探测的手段，可复跑）

- 探测：写 `probe-tools/asar-probe.ps1`（纯 .NET 流式读 header + 按偏移取文件），验证：
  - `pwsh -NoProfile -NonInteractive -File asar-probe.ps1 -List 'dsh/node_modules/@deepseek-ai'` → 10721 行文件清单；
  - `-Get '…/dsh-client-ui-conversation/lib/client.js'` → 940214 字节，与宿主 read 工具直读同名文件字节一致（抽查头部/尾部）。
- 结论：`已验(命令可复跑)`。只读：不写 DSH 安装目录、不解包到 DSH 目录（产物全部落在 `probe-tools/dump/`）。
- 修正记录：首次 Walk-Tree 误把目录节点当文件（列出 `files` 尾缀），已修复并复跑通过；header 解析先跑了 debug.ps1 确认 `{"files":{dsh,node_modules,lib,package.json,renderer}}` 顶层结构。
- 时间点：2026-11-08 01:35–01:37。
- 复跑方式：见本文件底部命令块。

## P17. 撤销语义的宿主级事实（B4 的"Ctrl+Z 附加观察"依据）

- 探测：P10 的 bundle 内 `insertAsyncText` 注释与 Lexical history 集成；`setDraft` 的 `{discrete:true, tag:xo}`（并入种子）。
- 结论：`已验(源码)`。"按区间插入=独立撤销步；整段替换=并入历史"成立 → 回退按钮必须自带原文快照，Ctrl+Z 只能作附加观察。
- 时间点：2026-11-08 01:37。
- 依赖项：D3。

## P18. 草稿持久化（会话切换不丢草稿）

- 探测：`ui-conversation` README"Drafts retain plain text and file, folder, and Session reference chips across Session switching and reload"；bundle 内 `persistDraft/pendingCommand` 实现。
- 结论：`已验(源码+文档)`。切会话草稿自动保留 → B14 的"切走再切回"只需管自己的 run 状态。
- 时间点：2026-11-08 01:38。
- 依赖项：R6。

## P19. 会话模型选择投影（跟随模式）

- 探测：同一 bundle 内 grep `faceOf("modelSelection")`。
- 结论：`已验(源码)`。宿主 UI 自身读取会话模型+强度的路径：`session.projections.faceOf("modelSelection")` → `{provider, model, reasoningEffort?}`。
- 时间点：2026-11-08 01:40。
- 依赖项：D5。

## P20. schemastery `.volatile()` 存在性（Config 即时生效的机制面）

- 探测：asar 提取 `@deepseek-ai/schemastery/src/index.ts`，grep `volatile`。
- 结论：`已验(源码)`。`Schema.prototype.volatile` 存在（meta.volatile 包装，`'volatile'`/`'volatile-defined'` 模式）。
- 时间点：2026-11-08 01:41。
- 依赖项：D12；实际语义仍属 U6。

## P21. 已安装同类 bundle 的形态先例（打包可行性）

- 探测：asar 提取 `@deepseek-ai/dsh-llm-retry/lib/index.js`（官方持久插件）：`import z from '@deepseek-ai/schemastery'` + `const Config = z.object({})` + `export const inject=[...]` + `export function apply(ctx, config)`；workspace 内 round1 的 `bundle/`（同构 `dsh.client`/exports/files，已在本机流程跑过一轮打包）。
- 结论：`已验(先例)`。宿主半 + 客户端半 + Config 的 bundle 形态在本机有双重先例。
- 时间点：2026-11-08 01:41。
- 依赖项：D15。

## P22. HTTP 面的鉴权观测（仅作 U4 的基线，不是通道结论）

- 探测：`Invoke-WebRequest http://127.0.0.1:8314/`（401）、`/__probe_no_route__`（404）、`/api/nope`（401）。
  > ⚠️ **本行的端口是历史记录，不要照抄复跑**：8314 在当前实例上无监听。**正确做法见下方 v3.2 回写**——先取当前实例端口。
- 结论：`已验(观测)`：根与 `/api/*` 需鉴权（401），完全未知路径 404。**未验**的是"插件注册的路由落在鉴权层的哪一侧"——不猜，U4 才定。
- 时间点：2026-11-08 01:38。
- 依赖项：U4。

> **v3.2 回写（2026-11-08，P2 开工；对应 `06` §9 的定点）**
>
> 1. **端口不许写死。** 上文的 `8314` 在本机当前实例上**没有监听**（连接被拒）。实际监听口是 **6727（浏览器口）/ 6728 / 6729 / 8326（Bearer 口）**，同一 pid 17760。复跑方式：
>
>    ```powershell
>    Get-NetTCPConnection -State Listen | Where-Object { $_.LocalPort -in 6727,6728,6729,8326,8314 } |
>      Select-Object LocalAddress,LocalPort,OwningProcess | Sort-Object LocalPort
>    # 本轮输出：127.0.0.1 6727/6728/6729/8326 → pid 17760（8314 无行）
>    ```
>
>    后续一切 HTTP 探测都**先取当前实例的端口**（或宿主半用 `webServer.getOrigin()` 取），文本里不再出现写死的端口。
> 2. **补上"插件路由无鉴权"这条实际观测**（U4 运行时实测，完整输出见 `06` §4）：`POST /dsh-draft-studio/refine`（无任何凭证）→ **200 + 业务 JSON**；对照 `GET /` → 401、`GET /api/nope` → 401、`GET /__probe_no_route__` → 404。同一路由在 **Bearer 口**（6728/6729/8326）→ **401**。即：**鉴权是按监听口 × 按路径前缀分层的**；命名路由（`dsh-host-webserver/lib/index.js:459-472` 直接调 `responder.handler`，不走 `connection.admit()`）落在浏览器口的鉴权层**之外**。
> 3. 后果：**若本项目走降级 A（自建 HTTP 路由），handler 必须自带守卫**（固定 token 或 `Sec-Fetch-Site`/`Origin` 检查）；暴露面限于本机 + 浏览器口（`webServer` 拒绝绑定通配地址，`dsh-host-webserver/lib/index.js:301-307`），不是 LAN/公网。这条同时作为**已知问题**留档（前代的 `/dsh-draft-studio/refine` 现在就如此），不属于本流程实验的缺陷。落点：`02-plan.md` §3-U4、§5-R10。

## P23. 环境边界确认

- 探测：任务约束复核 + 实际操作对照。
- 结论：本轮**未安装**任何插件、**未改** `$DSH_HOME`、**未读**其他插件业务目录（读取范围 = DSH 安装内已发布的 `@deepseek-ai/*` 包与宿主 skill 文档、process-lab 本任务文件）。`plugin_manager` 未调用。探测产物只写在 `process-lab/impl/round2-draft-studio/`。
- 时间点：贯穿。

---

## P24. 返工轮：安装包源码复核（只读，2026-11-08 02:04–02:16）

- 探测（全部只读，写入 `probe-tools/dump/`，未碰安装目录与 `$DSH_HOME`）：
  0. `cordis_inspect_query(platform=client, provider=Slots, method=listSubTree, input={root:"conversation.input.right"})` → `timed out after 10000ms`（第二次实测，第一次见 P3 的 01:30）。U1 运行时仍未验；本次**未**出现工具层报错，说明带参调用本身合法，失败原因是页面无有效响应。
  1. `asar-probe.ps1 -Get 'dsh/node_modules/@deepseek-ai/dsh-web-frontend/dist/assets/index-BgUyXZcc.js'` → **970770 字节**；`Select-String`/`IndexOf` 定位 `case"list"`（字符偏移 **492065**）、`requires options.id`（**492133**）、`already has an entry with id`（**492275**）。
  2. `-Get 'dsh/node_modules/@deepseek-ai/dsh-client-ui-renderer/lib/client.js'` → **78299 字节**；`1173–1177` 是 `single` 只取 `entriesOfSlot(...)[0]`，`1203–1221` 是 `list` 全量 rows 按 `order` 排序后全部 map。
  3. 重读 `ui-conversation-client.js`（940214 字节，与 P16 一致）：`22107–22111`（`standardControls` `hidden: activity`；`input === void 0 || sessionId === void 0 ? null : renderSlot("conversation.input.right", {})`）、`22982–22985`（`right: {kind:"list", scope:"session"}`）、`22990–22993`（`activity: {kind:"single"}`）。
- 结论：`已验(源码)`。四条事实复现：list 必须带 `id`、不同 `id` 并存、`right` 在 `model` 之前渲染、无 sessionId / activity 展开时不渲染。
- 用途：`02-plan.md` D1（list 硬注册契约）与 `01` §3.0/§7-A1 的出处；风险 R8/R9。
- 时间点：2026-11-08 02:06–02:12。

## P25. 返工轮：`llm` 与 `commands` 契约复核（2026-11-08 02:10）

- 探测：`cordis_inspect_query(host, Service, listService, {service:"llm"})` 与 `{service:"commands"}`。
- 结论：`已验(契约)`。
  - `llm.prepareCall(config, signal?, configure?) → PreparedLlmCall{config, stream()}`："Resolve one call under its current adapter registration…keeps that registration across header logging and dispatch"；`ConfigureCall = (controls, model: LlmResolvedModelInfo) => LlmCallControls`；`LlmResolvedModelInfo.reasoning = {efforts, defaultEffort?}`。
  - `CommandInvocation = {commandId, agent, rawInput, attachments, signal}`，**没有** provider/model/reasoningEffort；`command/run`/`command/done` 为 log-only 追加。
- 推论：模型/强度不能靠命令日志证明（`01` §4 的"不接受的证据"）；B8/B9/B10 的证据源改为 `dump-request` + `prepared.config` + 宿主拒绝错误文本。
- 时间点：2026-11-08 02:10。

## P26. 返工轮：Config 目录形态（2026-11-08 02:12）

- 探测：`cordis_inspect_query(host, Config, listConfigs, {limit:100})` 与 `{limit:100, offset:100}`。
- 结论：`已验(契约)`。目录 `total = 229`；抽样的 200 条 id **一律** `include:<patchId>`，`name` 精确等于包名（含 `@deepseek-ai/dsh-plugin-manager/tools` 这种子路径 name）；无 `@local/*` 条目（本轮未安装任何插件）。
- 用途：D18/U7——本插件 patch 自定 `id: draft-studio`，预期 entryId `include:draft-studio`；U7 只需复核这一个值。
- 时间点：2026-11-08 02:12。

## P27. 返工轮：schemastery 是否可安装（2026-11-08 02:14）

- 探测：`$env:HTTPS_PROXY='http://127.0.0.1:7897'; pnpm view '@deepseek-ai/schemastery' version`。
- 输出：`3.19.0`，退出码 0。
- 结论：`已验(命令)`。该包在 registry 可取——workspace bundle 把它声明成依赖在**安装**层面可行；剩下的"本机运行时能否 import 并由宿主投影 schema"仍属 U5，需探针安装后验。
- 时间点：2026-11-08 02:14。

## P28. 环境边界确认（返工轮）

- 本轮（02:04–02:16）：未安装任何插件、未调用 `plugin_manager`、未读写 `$DSH_HOME`、未改 DSH 安装目录；新增产物只有 `probe-tools/dump/index-BgUyXZcc.js`、`probe-tools/dump/client.js`（renderer）与本文件/01/02 的文档改动。
- 探测产物全部落在 `process-lab/impl/round2-draft-studio/`。
- 时间点：贯穿。

---

## P29. P2 开工轮：端口/鉴权复核 + Client Inspect 再超时 + 源码级座位复核（只读，2026-11-08 07:30–07:45）

> 性质：**不是新一轮探针门**，只是 P2 开工时对 `06` §9 定点的复核。全部只读，未安装、未调用 `plugin_manager`、未碰 `$DSH_HOME`。

1. **端口复核**（`02` §3-U4 的"不许写死"落地）：

   ```powershell
   Get-NetTCPConnection -State Listen | Where-Object { $_.LocalPort -in 6727,6728,6729,8326,8314 } |
     Select-Object LocalAddress,LocalPort,OwningProcess | Sort-Object LocalPort
   # → 127.0.0.1 6727 17760 / 127.0.0.1 6728 17760 / 127.0.0.1 6729 17760 / 127.0.0.1 8326 17760
   #   8314 无行（无监听）
   ```

2. **鉴权分层复核**（浏览器口 6727）：

   ```powershell
   foreach($u in 'http://127.0.0.1:6727/','http://127.0.0.1:6727/api/nope','http://127.0.0.1:6727/__probe_no_route__'){ … }
   # → /  -> 401 len=68   ；/api/nope -> 401 len=12   ；/__probe_no_route__ -> 404 len=0
   ```

   与 `06` §4 的输出一致：**鉴权层在正常应答**，不是进程死了、也不是页面没开。

3. **Client Inspect 再打一次**（第三次同形态调用，仍失败 → 按 `04` 规则不再重试）：

   ```text
   cordis_inspect_query(client, Slots, listSubTree, {root:"conversation.input.right"})
   → Error: Slots.listSubTree: Client inspect query Slots.listSubTree timed out after 10000ms.
   ```

   累计 **9 次零成功**。**归因结论已写进 P3 的修正段：超时不是"页面没开"。**

4. **源码级座位复核**（对着 `probe-tools/dump/ui-conversation-client.js`，921,756 字符 / 23,145 行）：

   | 事实 | 位置（字符偏移 → 行号归属） | 原文片段 |
   |---|---|---|
   | `right` 是 `list`、`scope:"session"` | 偏移 `915,959` | `"conversation.input.right": { kind: "list", scope: "session" }` |
   | `right` 与 `model` 同在一个带 `hidden: activity` 的容器里，且 `right` 在 `model` 之前 | 偏移约 `883,600` | `className: standardControls, hidden: activity, children: [input===void 0||sessionId===void 0 ? null : renderSlot("conversation.input.right",{}), sessionId===void 0 ? null : renderSlot("conversation.input.model", {locked:…})]` |
   | 标准 props 由 `uiSession.provide` 公布 | 偏移 `909,686` | `ctx.uiSession.provide({ hooks:["conversation","input"], props:["inputActions"], resolve: … })` |
   | `insertText` 有 `draftRev` 守卫；`frozen(phase)` 时直接拒 | 偏移 `533,500` 起 | `insertText: (text, span) => { if (frozen(this.snapshot.phase) \|\| this.disposed) return false; if (span.draftRev !== this.rev) return false; return this.draftEditor.insertAsyncText(span, text); }` |
   | `setDraft` 是整段替换、并入历史（非独立撤销步） | 偏移 `535,835` | `setDraft(text) { const clean = text.replace(REFERENCE_PLACEHOLDER_RE,""); … this.editor.update(…, {discrete:true, tag:xo}); }` |
   | `insertAsyncText` 是**独立撤销操作** | 偏移 `538,731` | `insertAsyncText(span, text) { … this.applyEdit(() => { applied = $replaceDetectSpanWithText(span, clean); }, Co); return applied; }` |
   | `data-composer-dock` / `data-composer-input` 在宿主 DOM 里硬编码 | 偏移 `887,851` / `824,861` | 供 §4 片段的 `inDock` / `editorPhase` 使用 |

   **结论**：`02` D1/D2/D3 与 `01` §3.0/§4 的源码级出处**全部复现**；这些是 P2 骨架能写下去的依据，但它们**仍然不是运行时证据**。

5. **在装产品复核**（只读 `~/.dsh/profiles/desktop/node_modules/dsh-draft-studio/{client.js,index.js}`）：`client.js` 114,275 字节，`ctx.slots.inject('conversation.input.right', () => ctx.slots.register({name:'conversation.input.right', id:'dsh-draft-studio', order:60, locale:'dsh-draft-studio', inject:()=>({presets})}, RefineControl))`；`settings.section` 同 id、`order:60`；宿主半在 `index.js` 偏移 `39,671` 调 `webServer.register` 挂 `/dsh-draft-studio/refine`，**全文件 0 处 `commands.register`**（确认前代走 HTTP 路由、不走命令通道）。
   → 这就是并存裁定必须改名的直接理由：**id 相同会落进前代的 cell 并替换它**。

6. **环境边界**：本轮未安装、未卸载、未调用 `plugin_manager`、未写入 `$DSH_HOME`；新增文件只有 `bundle-lab/**`、`07-implementation.md`、`08-selfcheck.md` 与对 `01`/`02`/`probes.md` 的回写。

---

## UNVERIFIED 汇总（v2 口径：本表对应 `02-plan.md` §3 的 P1.5 探针门；U8 已移到 S8 验收走查）

> **v3.2 回写（P2 开工）**：本表的"现状"列已按 `06-p1.5-probes.md` §3/§6 更新；**"探针门动作"列保留为历史口径**（它描述的是当时打算怎么探）。

| # | 内容 | 探针门动作 | 现状（v3.2） |
|---|---|---|---|
| U1 | 客户端插槽运行时拓扑/占用者/props + 主题令牌 | client Inspect `Slots.listSubTree`/`Theme.listTokens`；超时则最小探针 bundle 裁决 | ①占用者 **已验（安装态）**：前代 + teammate-picker 两条在跑；②首帧/activity 态 **无法判定（运行时）**，累计 9 次超时；③令牌 **已定降级（源码级 114 个 alias）** |
| U2 | 命令通道分钟级长调用 + 取消传播（第三方运行时可用性） | 探针命令 selftest（sleep 60s / abort 时间戳） | 契约已验、源码链完整；**运行时仍 UNVERIFIED**，负责人已接受，S1 装探针后补测 |
| U3 | 命令行长度上限（8000 字符载荷） | 同一探针回显 | **已验（源码级）**（解析端无截断、上限 300 MiB）；运行时回显仍待补 |
| U4 | 插件 HTTP 路由鉴权（仅降级 A 需要，条件项） | 临时 `/draft-studio/ping` 对照 401/404（基线 P22） | **已验（运行时）**：浏览器口无凭证 200；Bearer 口 401；**若走降级 A，handler 必须自带守卫**（`02` §5-R10） |
| U5 | workspace bundle 解析 `@deepseek-ai/schemastery` | 探针 bundle 声明 Config + `Config.listConfigs` 投影 | **已验（运行时等价形态）**（`06` §3-U5）→ 走 Config，不走文件降级 |
| U6 | 易变字段+默认值实测语义 | selftest volatile（改一项→立即 `config.field.get()` 回显） | **已验（源码 + 运行时投影旁证）** |
| U7 | 本插件 Config entryId 形态 | `Config.listConfigs(name=…)` | **已验（运行时形态）**：229 条无一例外 `include:<patchId>`；本插件预期 **`include:lab-draft-studio`**（并存裁定后改名），安装后复核一次 |
| U8 | 01 §3 B1–B21 现场走查 | （不属于探针门）02-plan §4 S8 | 待 P2/P3；P2 只做**离线可验**部分（见 `08-selfcheck.md`） |

## 复跑命令（第二个人可原样执行）

```powershell
# 插件清单与文件抽取（全部只读）
$s = 'C:\Users\Administrator\Documents\ProgramFilesCode\DshBundle\process-lab\impl\round2-draft-studio\probe-tools\asar-probe.ps1'
pwsh -NoProfile -NonInteractive -File $s -List 'dsh/node_modules/@deepseek-ai'
pwsh -NoProfile -NonInteractive -File $s -Get 'dsh/node_modules/@deepseek-ai/dsh-client-ui-conversation/lib/client.js' -OutDir <dump>

# 宿主契约（只读 Inspect）
#   cordis_inspect_query host Service listService {service:"llm"|"commands"|"webServer"|"sessionQuery"|"sessionController"}
#   cordis_inspect_query host Config listConfigs {name:"@deepseek-ai/dsh-client-ui-conversation", limit:10}
#   cordis_inspect_query host Config listConfigs {limit:100} / {limit:100, offset:100}   # P26：目录 id 形态

# 返工轮新增（P24/P25/P27）
pwsh -NoProfile -NonInteractive -File $s -Get 'dsh/node_modules/@deepseek-ai/dsh-web-frontend/dist/assets/index-BgUyXZcc.js' -OutDir <dump>
#   上述产物内定位：IndexOf 'case"list"' -> 492065；'requires options.id' -> 492133
pwsh -NoProfile -NonInteractive -File $s -Get 'dsh/node_modules/@deepseek-ai/dsh-client-ui-renderer/lib/client.js' -OutDir <dump>
#   渲染端行号：1173-1177 single 取 [0]；1203-1221 list 全量按 order 渲染
$env:HTTPS_PROXY='http://127.0.0.1:7897'; pnpm view '@deepseek-ai/schemastery' version   # -> 3.19.0

# 客户端运行时（当前不可用，补探用）
#   cordis_inspect_query client Slots listSubTree {root:"conversation.composer.bar"}
```

```powershell
# P29（P2 开工轮）：端口**每个实例现取**，不要写死 8314
Get-NetTCPConnection -State Listen | Where-Object { $_.LocalPort -in 6727,6728,6729,8326,8314 } |
  Select-Object LocalAddress,LocalPort,OwningProcess | Sort-Object LocalPort
foreach($u in 'http://127.0.0.1:6727/','http://127.0.0.1:6727/api/nope','http://127.0.0.1:6727/__probe_no_route__'){
  $r = Invoke-WebRequest -Uri $u -TimeoutSec 5 -SkipHttpErrorCheck -NoProxy; "$u -> $($r.StatusCode)"
}
# → 401 / 401 / 404   （鉴权层在正常应答；Client Inspect 超时**不是**"页面没开"）

# 源码级座位复核（对照 probe-tools/dump/ui-conversation-client.js，字符偏移）
#   915,959  "conversation.input.right": { kind: "list", scope: "session" }
#   883,6xx  standardControls { hidden: activity } 内，right 在 model 之前
#   909,686  ctx.uiSession.provide({hooks:["conversation","input"], props:["inputActions"]})
#   533,5xx  insertText: 先 frozen(phase) 再 span.draftRev !== this.rev → false
#   538,731  insertAsyncText（独立撤销步）  ；535,835 setDraft（并入历史）
#   887,851  data-composer-dock         824,861  data-composer-input

# 在装产品复核（只读）
Select-String -LiteralPath "$env:USERPROFILE\.dsh\profiles\desktop\node_modules\dsh-draft-studio\client.js" `
  -Pattern "conversation.input.right|settings.section|id: 'dsh-draft-studio'|order: 60"
Select-String -LiteralPath "$env:USERPROFILE\.dsh\profiles\desktop\node_modules\dsh-draft-studio\index.js" `
  -Pattern "commands.register|webServer.register|/dsh-draft-studio/refine"
# → index.js 有 webServer.register（偏移 39,671），**0 处 commands.register**
```

```powershell
# P2 离线自验（bundle-lab，零第三方依赖；不安装、不碰 $DSH_HOME）
cd bundle-lab
node --check index.js; node --check client.js
Get-ChildItem -Recurse -Filter *.js | ForEach-Object { node --check $_.FullName }
node --test "test/*.test.js"
```
