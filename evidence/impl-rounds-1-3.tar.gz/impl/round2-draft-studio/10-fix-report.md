# 10 修复报告（P3 → P3.5）

> 修复者：本轮实现者。日期：2026-11-08。
> 对象：`bundle-lab/`。输入：`09-verification.md` 的 D-01～D-16。
> 纪律：**本文件不引用 `09` 的判定作为证据**——每一条的「证据」都是本轮自己跑出来的 `文件:行` 与命令输出；凡是我没能修到位的，在 §3 明写「未修及原因」，不改成"已修"。
> 未做：不改 `09-verification.md`；未安装；未碰 `$DSH_HOME`；未重修 `D-02`/`D-03`（负责人已复核为已修，见 §4）。

---

## 0. 一句话结论

**D-01 真的接线了**：`lib/run-store.js` 与 `lib/writeback.js` 现在以**逐字内联**的方式存在于 `client.js`（生成器保证，测试守护），点击路径经 `store.start` → `ctx.remote.commands.execute` → `decideWriteBack` → `store.finish/fail/cancel` 走完整状态机；`data-state` 在点击后离开 `idle`（专门测试 + 变异实证）。D-04/D-05/D-06/D-07/D-08/D-09 六条 MAJOR 全部修好，各配了「改坏→红→改回→绿」的实证（`node scripts/mutate.mjs`，9 个变异全过）。

**测试：174 条全绿**（原 138 → 174，新增 36 条，无一条被删除式"修绿"：4 条镜像期测试被**等价替换**为新口径，理由见 §5.1）。`node scripts/check-syntax.mjs`：20 个文件 0 失败。

---

## 1. 逐条修复

### D-01（BLOCKER）：产品没接线 → 已修

**问题**：`lib/writeback.js` / `lib/run-store.js` 零产品 import，只出现在注释里；按钮点击后立即回 `idle`。

**为什么不能直接 `import`**：`client.js` 是 classic script（首语句 `window.__ModuleLoader__.load({...})`，页面用 script 标签求值），`import` 在那里是语法错误；`factory(require)` 的 `require` 是宿主的模块表（React / cordis），取不到本包 `lib/*.js`。这正是上一轮只能「手抄镜像」的原因，也是 D-01/D-10 的共同根因。

**修法（架构选择，替代手抄）**：

1. 新增 `scripts/build-client.mjs`：把下列模块的**原文**粘进 `client.js` 的 `// <lab-kernel:begin>` / `// <lab-kernel:end>` 之间，只去掉模块语法（`export ` 前缀，以及指向内联集合内、且已先内联的 `import` 行；其他 import 直接报错，不会静默产出页面解析不了的脚本）：
   `lib/prompt.js`、`lib/boundary.js`、`lib/seats.js`、`lib/run-store.js`、`lib/writeback.js`、`lib/wire.js`、`lib/settings.js`。
2. `scripts/build-client.mjs --check` 是**测试守护**：`test/client.test.js`「the inlined kernel region is current…」重算 region 并与磁盘比对，漂移即红。
3. 点击路径接上真实状态机与真实通道：
   - `client.js:2051` `store.start({ sessionId, presetId, draft, draftRev, references, now })`
   - `client.js:1988` `const remote = ctx.remote;`、`client.js:1989` `const execute = remote?.commands?.execute;`
   - `client.js:1997` `const line = encodeLine({ action:'refine', presetId, draft, sessionId })`
   - `client.js:2017` `const decoded = decodeResult(answer?.text);`
   - `client.js:1942` `const decision = decideWriteBack({ result, capture, current })`
   - 落地：`client.js:1958`（`store.finish(..., revertible)`）、`1965`（`retry-pending`）、`1937`/`1961`/`1973`（`store.fail`）、`1976`（`discard` → `store.cancel`）；失败文本写进 `details`（`1936`/`1960`/`1972`/`1991`）
   - 取消：`client.js:2198`；回退：`client.js:2203-2213`（`store.record` + `decideRevert` + `store.clear`）；重试：`client.js:2218`
   - 渲染读数：`client.js:2175` `const seat = store.seatState({ presetId, sessionId, now })` → `client.js:1759` `'data-state': state`、`client.js:1761` `'data-elapsed-ms'`、`client.js:1766` `'data-detail'`（宿主错误文本，见 D-07）
   - 秒表驱动：`client.js:1886` `startTicker()`（250 ms interval）+ `client.js:2129` `useStore(subscribe, snapshotVersion)`（`useSyncExternalStore`，无则同步读快照）
4. 顺手修掉上一轮「点了没反应」的两个必然触发点：`sessionId` 早先取自 slot props（`renderSlot("conversation.input.right", {})` 传空 props，实际取不到），现在仍以 props 为准（`client.js:2124` `props.sessionId ?? ''`）但**不再用它决定是否发请求**；写回用 `inputActions.setDraft`（`insertText` 需要 span），并在写回前用 `decideWriteBack` 自行守住 `draftRev`（`lib/writeback.js` 头部注释记录了这个取舍）。

**证据**：

| 项 | 证据 |
|---|---|
| import/内联行号 | `client.js:50` `lib/prompt.js`、`:275` `lib/boundary.js`、`:376` `lib/seats.js`、`:446` `lib/run-store.js`、`:681` `lib/writeback.js`、`:903` `lib/wire.js`、`:1128` `lib/settings.js`（每行全文为 `// ─── lib/<name>.js (verbatim, module syntax stripped) ───`） |
| 零 import 校验 | `client.js` 全文无 `^\s*import\s`，也无 `from '..\/lib/'`；测试「every kernel module is inlined, and the client imports none of them (D-01)」 |
| 专门测试（点击离开 idle） | `node --test --test-name-pattern="a click leaves idle" test/client.test.js` → `tests 1 / pass 1`；未改坏前该测试断言 `data-state === 'running'`、`data-elapsed-ms !== null`、`[data-action]` 含 `cancel`、其余三颗 `aria-disabled='true'` |
| 端到端（客户端 → 宿主） | 测试「the click path and the Host half agree across the command seam (D-01)」：客户端发的 line 由**真实** `decodeLine`/`dispatch` 解，宿主 `buildResult` 的 JSON 回到座位，断言 `data-state=failed`、`data-reason-code=provider-error`、`data-detail` 含 `llm service unavailable` |
| 变异 | `node scripts/mutate.mjs D-01a`：把 `startRun` 改回"立刻 `store.cancel`" → **红**（`D-01: the click must leave idle`），改回 → 绿 |
| 变异（内联漂移） | `node scripts/mutate.mjs D-01b`：手改 `client.js` 内联区一行 → **红**（`client.js kernel region drifted from lib/*.js`），改回 → 绿 |
| 变异（hook 顺序） | `node scripts/mutate.mjs D-01c`：把早退移到 hook 之前 → **红**（`the empty-draft path must not skip hooks`），改回 → 绿 |
| 真机等价启动 | 用 `new Function(源码)` 走页面同一条求值路径（不借助测试替身）：`factory id=@local/lab-draft-studio`、`inject=slots,locale,configForms,remote`、5 条注册（1 页 + 4 座，order 60/0/1/2/3）、空草稿渲染 `null`、无异常 |

**副作用（正面）**：`lib/request.js` 的 `seatPlan` 不再零调用（D-04）；`lib/writeback.js` 的 `decideWriteBack`/`decideRevert` 进入产品路径（D-01/B13/B16）；`lib/run-store.js` 的 `seatState`/`finish`/`fail`/`cancel`/`abortOnSend` 全部有调用点（B11/B12/B14/B15）。

---

### D-04（MAJOR）：B20 三处判据相反 → 已修

**要求**：设置不可用时只渲染一颗（general）、请求 `presetId` 为 `null`、`system` **不含**结构块。

**修法**：
1. `client.js:2168` 的座位组件改用 `seatFor(presetId, settings, settingsAvailable !== false)`，实现落在 `lib/seats.js:46` `seatPlan` / `:62` `seatFor`（已内联进 client，`client.js:376` 起）。降级时 `visible=['general']`，非 general 的座位 `show=false`。
2. 请求侧：降级座位把 `requestPresetId = null` 传给 `startRun`，`encodeLine` 里 `presetId: null`（`client.js:1997` 的 payload 构造）。
3. 宿主侧：`lib/prompt.js` 新增 `buildDegradedSystemPrompt`，`buildSystemPrompt(null, body)` 走它——**不含** `【结构要求 preset=…】`、不含结构块，只留 standing rules；`lib/prompt.js` 新增 `resolveRequestPreset`，把 `null`（降级）与「未知 id」（回落 general）分成两条路。
4. `lib/request.js:32` 的 `ACTIONS` 补上漏掉的 `dump-request`（原 D-13 的死常量问题顺手对齐，见 §2）。

**证据**：
- `test/client.test.js`「an unreadable settings service renders exactly one general seat (B20)」→ 断言渲染数 1、`data-preset-id='general'`、`data-reason-code=''`。
- `test/client.test.js`「the degraded request carries presetId null and no structure block (B20③)」→ 解码客户端真正发出的 line，断言 `payload.presetId === null`。
- `test/core.test.js`「a null presetId yields presetId null and no structure block (B20③)」+「a null preset runs the degraded request end to end (B20③)」→ 端到端 `runRefine` 的 `result.system` 不含标记。
- `test/core.test.js`「an unknown (non-null) preset still falls back to general with its block (B15)」→ 区分降级与回落。
- 变异 `D-04`：`lib/seats.js` 的 `['general']` 改回 `PRESET_IDS` → **红**（`B20①: exactly one button…`），改回 → 绿。

---

### D-05（MAJOR）：Config entryId 形态不符 → 已修

**修法**：`lib/host.js:886` 新增 `ENTRY_ID_PREFIX='include:'`，`:906` `readEntryId` 与 `:916` `normalizeEntryId` 统一成宿主目录形态；`createHost` 在 `lib/host.js:799` 用它归一化（`options.entryId` 与 fiber 读值都过这一道），因此 `webserver/index-inject` 下发的 `entryId` 就是 `include:lab-draft-studio`。客户端无需改动（它本来就把这个值直接喂 `configForms.get`）。

**证据**：
- 本轮实跑 `cordis_inspect_query(host, Config, listConfigs, {offset:0,limit:12})`：`{id:"include", patchId:"include", name:"cordis:include"}`、`{id:"include:ui-settings", patchId:"ui-settings", name:"@deepseek-ai/dsh-client-ui-settings"}`、`{id:"include:ui-conversation", patchId:"ui-conversation", …}`——`id === "include:" + patchId` 再次成立（`total: 229`）。
- `test/core.test.js`「readEntryId returns include:<patchId>…」、「createHost publishes the directory id and keeps it distinct from the installed product」、「the published index-injection row carries the directory id」。
- `test/client.test.js`「the settings page reads the Host directory id, not the bare patch id (D-05)」：fake `configForms.get` 断言收到的唯一参数是 `'include:lab-draft-studio'`。
- 变异 `D-05`：`normalizeEntryId` 改为原样返回 → **红**，改回 → 绿。

---

### D-06（MAJOR）：`sessionQuery.modelSelection` 不是宿主方法 → 已修

**先确认契约（按要求）**：本轮跑了
`cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})` — 方法表 15 项：
`observeSession`、`searchSessions`、`searchEvents`、`listSessions`、`readSession`、`filterSessions`、`readTitle`、`readTitleSnapshot`、`readTitleSnapshots`、`listEvents`、`filterEvents`、`readSurface`、`traceSession`、`traceEvent`、`readEvent`。
**无 `modelSelection`**。同轮读了 `sessionQuery.observeSession` 的返回类型：`SessionObservation { projections?: ProjectionSnapshot }`，`ProjectionSnapshot { asOfSeq, values }`；`values.modelSelection` 的 zod 形状（`probe-tools/dump/api-remotes/client.js:20030-20040`）为 `{ lastUsed: {provider,model,reasoningEffort?}|null, next: …|null }`。宿主自己的输入壳取的是 `model?.next ?? model?.lastUsed`（`probe-tools/dump/ui-conversation-client.js:16157`），本实现照此。

**修法**：删掉 `sessionQuery.modelSelection`，改为
`lib/host.js:614` `observation = await sessionQuery.observeSession(sessionId, { projectionMode: 'all' })` → `pickSelection(observation.projections.values.modelSelection)`（`lib/host.js:621-622`，`pickSelection` 在 `:640` 起，`next ?? lastUsed`，逐个字段校验）；读到后 `finally` 里 `dispose()` 归还租约（`:623-631`）。读不到（冷会话 / 服务缺失 / 投影为空）返回 `null`，由 `composeLlmOptions` 决定后果。

**证据**：
- `test/core.test.js`「follow mode reads the session triple through observeSession().projections (D-06)」：断言 `dump.options.provider/model/reasoningEffort` 来自投影，且 `observeSession` 收到的 `projectionMode === 'all'`。
- 「a projection with lastUsed but no next still yields a route (D-06)」「a cold session makes dump-request answer with a reason instead of throwing (D-06)」。
- 「the old invented method name is gone from the host half (D-06)」：剥注释后全文无 `sessionQuery.modelSelection`。
- 变异 `D-06`：把 `sessionQuery.modelSelection` 读法加回去 → **红**（`D-06: sessionQuery.modelSelection is not on the Host contract`），改回 → 绿。

---

### D-07（MAJOR）：最外层 catch 吞掉宿主错误文本 → 已修

**修法**：
1. `lib/wire.js:183` `buildResult` 增加 `detail` 字段（仅失败时非 `null`；成功恒 `null`，避免把成功误读成拒绝）。
2. `lib/host.js:339` 新增 `describeError(error)`（`message` → `String(error)` → `'unknown error'` 三道兜底）。
3. 四个会丢文本的地方都写入 `detail`：`runRefine` 最外层 catch（`lib/host.js:553`）、`composeLlmOptions` 抛错分支（`:405`）、`llm === null` 分支、`prepareDumpRequest` 的 Host 拒绝分支（`:322`）。
4. `B8/B9` 的第二个观察点真正可得了：`dump-request --prepare` 现在会 `llm.prepareCall(...)` 并把宿主物化的 `prepared.config` 放进 `prepared`（`lib/host.js:298-323`）；被拒绝时 `ok:false` + `detail` 携带宿主原文。
5. `lib/host.js:320` 的笔误 `timeSource` 删除（原 D-14）。

**证据**：
- `test/core.test.js`「a Host rejection keeps its text in `detail` (B8/B9 negative control, D-07)」：`prepareCall` 抛 `Model '__lab_draft_nonexistent_model__' is not routable` → `dump.detail` 匹配该 model 名、`prepared === null`。
- 「`dump-request --prepare` fills prepared.config from the Host (B8/B9, D-07)」→ `prepared.provider/model/reasoningEffort` 与 `options.*` 一致（B8 的"两处一致"）。
- 「without --prepare nothing is materialized…」→ `prepared === null` 且 `detail === null`（不伪造）。
- 「runRefine keeps the thrown text…」→ `detail` 含 `effort ultra`。
- 「buildResult puts detail in the payload only for a failure (D-07)」。
- 客户端侧：`client.js:1766` `data-detail`，由 `client.js` 的 `details` map 写入（`1936` 的 `details.set(job.presetId, outcome.detail ?? outcome.reason)`，及 `1960`/`1972`/`1991` 的本地失败原因）。
- 变异 `D-07`：`lib/wire.js` 的 `detail` 改回 `null` → **红**，改回 → 绿。

---

### D-08（MAJOR）：guard 对两个 fetch 元数据头都缺失时放行 → 已修

**修法**：`lib/guard.js:123-140`：两个头都 `null` → `403 fetch-metadata-missing`（与同文件 `:21-22` 注释一致）；另加 `origin-unconfigured`（有 `Sec-Fetch-Site` 但没配 origin 时无法验证另一半，仍然拒绝）。文件头注释同步改成"缺失=拒绝"，避免注释与代码再次相反。

**证据**：
- `test/core.test.js`「the guard refuses a request that carries neither fetch-metadata header (D-08)」：只有 token、无两头的请求 → `allowed:false / 403 / fetch-metadata-missing`；**负向对照**同一请求加 `GOOD_HEADERS` → `allowed:true`（证明不是一刀切 403）；另断言"有 site 无 token"仍是 `token-mismatch`、"origin 错"仍是 `origin-rejected`。
- `node scripts/mutate.mjs D-08`：删掉该分支 → **红**（`a raw HTTP client must not reach the handler`），改回 → 绿。

**注**：这条会改变 `mountRoute` 的行为（裸 HTTP 现在 403 而非 200）。因为 `index.js` 从不调用 `mountRoute`（降级 A 仍是死代码），对产品路径零影响；对"三闸"的说法现在成立。

---

### D-09（MAJOR）：`scripts/assert-preset.mjs` 缺失 → 已补

**修法**：新增 `scripts/assert-preset.mjs`，按 `01` §3-B5 判据 2 的四条谓词逐套断言（general/coding/writing/translate），实现 `01` 表格原文的度量为纯函数导出（`countNumberedSteps`/`countBullets`/`hasFence`/`countParagraphs`/`cjkRatio`），并支持判据 3 的"最多两次、任一次通过即算通过"。输入形态 `{ "<presetId>": "text" | {text} | {outputs:[…]} }`，可选 `inputs` 供 writing 比较段落数。退出码：0 全过 / 1 有失败 / 2 文件不可用。

**证据**（本轮实跑）：

```text
=== PASS case
PASS  general    第 1 次: PASS — 要点行 3（要求 ≥3）; 编号步骤行 0（要求 =0）; 代码围栏 无（要求无）
PASS  coding     第 1 次: FAIL — 编号步骤行 0（要求 ≥3）
                 第 2 次: PASS — 编号步骤行 3（要求 ≥3）
PASS  writing    第 1 次: PASS — 编号步骤行 0; 段落 2（要求 ≥ 输入 2）; 代码围栏 无; 要点行 0（要求 <3）
PASS  translate  第 1 次: PASS — CJK 占比 0.00%（要求 ≤5%）; 含英文词 是; 编号步骤行 0; 要点行 0
B5 判据 2: PASS (4/4 套通过)     exit=0
=== FAIL case
FAIL general / FAIL coding / FAIL writing   → B5 判据 2: FAIL (0/4 套通过)   exit=1
=== missing file → exit=2
```

- `test/core.test.js` 四组：判据通过、三条可构造红（coding 无编号步骤、结构块串台）、第二次尝试通过、缺预设报 `missing` 而不是静默跳过；另有度量口径的单测（`- ` 必须行首、`3、c` 不算编号步骤、CJK 占比）。
- 变异 `D-09`：把文件移走 → **红**，放回 → 绿。

---

## 2. 顺手一起修掉的（都在必须修的路径上，不涉及 D-02/D-03）

| 编号 | 原判 | 本轮处理 | 证据 |
|---|---|---|---|
| D-10 | MINOR（镜像常量盲区） | **根因被 D-01 的生成器消掉**：不再有"手抄常量"，内联区就是原文；`test/client.test.js` 的 `inlined()` 不再由测试提供闭包常量，而是直接从内联区求值 | 测试「the inlined visible-seat rule agrees with lib/seats.js」「…write-back verdict table…」「…run store matches…」；变异 D-01b 证明漂移会红 |
| D-13 | MINOR（`ACTIONS` 死常量） | `lib/request.js:32` 补 `dump-request`，与 `dispatch` 实际分支对齐 | 该常量仍无调用点（它是文档性常量），但不再与实现相反 |
| D-14 | MINOR（`timeSource` 笔误） | 原 `llm === null` 分支里的 `timeSource` 已删除，改为 `detail: 'llm service unavailable'` | `Select-String -Path lib/host.js -Pattern 'timeSource'` → **0 命中** |
| D-15/D-16 | MINOR（`lastResult` 恒 null） | **未修**，见 §3 | — |
| D-11/D-12 | MINOR | **未修**，见 §3 | — |

---

## 3. 未修的及原因

| 编号 | 状态 | 原因（具体到哪一步断的） |
|---|---|---|
| **D-15 / D-16** `#20 lastResult` 恒 `null` | **未修（有意）** | 回显该由谁写是一个**协议选择**，`09` §5-D16 自己写了"要一次选定，否则会重演 D-02 那类 overlay 覆盖问题"。本轮 `save-settings` 的持久化通道仍未接（`index.js` 不注入 `persist`，Host 设置文档属 `ui-settings` provider），在写路径不存在时决定回显归属只会再造一个假接口。B18 的 #20 观察项因此仍为空——这条**仍需一次设计裁定**，不属于"照缺陷清单改代码"能收口的范围。 |
| **D-12** `01` §4 的 E2 命令清单与实际命令形态不符 | **未修（文档面）** | 修它要改 `01-requirements.md`（把 `/draft-studio …` 回写成 `/lab-draft <base64url>`，或给 `decodeLine` 加人手可打的短形态）。本轮约束是"不改 `09`"，`01` 不在可改范围内；且加短形态会让 `decodeLine` 多一条解析分支，属于需求变更而非缺陷修复。**建议**：由负责人决定是回写文档还是加短形态；两者都只影响"人能否原样重跑"，不影响 B 判据。 |
| **D-11** 「设置只从本插件 Config 读」的措辞 | **随之部分成立** | D-05 修好后 entryId 形态对了，但"读得到"还要真机确认一次（`configForms.get('include:lab-draft-studio')` 的运行时结果）。本轮只能用 fake 证明**传对了 id**，不能证明宿主真的返回表单——这条留给 P4 走查，`10` 不冒充已验证。 |
| **D-02 / D-03** | **按要求未动** | 负责人已复核为已修（`lib/host.js:116-130` 逐字段 read-modify-write；`lib/host.js:551-555` 从 `null` 起步）。本轮只确认它们仍在：`mergeSettings` 逐字段、`messageCount` 从 `null` 起。**未改一行**。 |

---

## 4. 已复核为「已修」的两条：本轮只确认、未改

| 编号 | 确认方式 | 结论 |
|---|---|---|
| D-02 | 读 `lib/host.js` 的 `mergeSettings`（本轮行号 **`:116-141`**）：逐字段 `if (typeof overlay.x === 'number') next.x = overlay.x`，没有整对象替换；`save-settings` 分支是 `state.setOverlay(mergeSettings(state.overlay(), payload.patch))` | 与负责人复核一致，**已修**，本轮未改 |
| D-03 | 读 `lib/host.js` 的 `dump-draft` 分支（**:740-753**）：`let messageCount = null;`（`:743`）起步，仅 `Array.isArray(events)` 时赋值（`:746`） | 与负责人复核一致，**已修**，本轮未改 |

---

## 5. 验证（全部本轮实跑）

### 5.1 测试

```text
node --test "test/*.test.js"
ℹ tests 174
ℹ pass 174
ℹ fail 0
ℹ duration_ms 248.6162        (exit=0)

node --test test/core.test.js    → tests 133 / pass 133 / fail 0
node --test test/client.test.js  → tests  41 / pass  41 / fail 0
```

从 138 → 174（+36；core 113→133，client 25→41）。**没有为了让旧测试变绿而放宽断言**；4 条旧测试被等价替换，逐条说明：

| 旧测试 | 处理 | 理由 |
|---|---|---|
| `the factory declares the three services…` | 改为断言 `['slots','locale','configForms','remote']` | 座位必须能发命令，`remote` 是 D-01 的通道；断言更强而非更弱 |
| `the client draft predicate agrees with lib/boundary.js…` | 改为从**内联内核区**求值后比对 | 旧测试用 `extract()` + 测试自带的闭包常量（D-10 的盲区），新测试用页面真正会跑的文本 |
| `the client write-back verdict table agrees…` | 同上，且改成比较**完整返回对象**（原来只比 verdict 字符串） | 更强：把 `state`/`reason`/`keepResult` 一起钉住 |
| `the client and kernel agree that a discarded run is not a failure` | 同上，并额外断言 `state === 'idle'` | 更强 |

### 5.2 语法

```text
node scripts/check-syntax.mjs
ok   client.js (classic script)
ok   index.js (module)
… （19 行 ok）
20 file(s) checked, 0 failure(s)      (exit=0)
```

（`09` §1.1 记录的是 16 个文件；本轮新增 `lib/seats.js`、`scripts/build-client.mjs`、`scripts/assert-preset.mjs`，`scripts/mutate.mjs` 也在内 → 20。）

### 5.3 改坏→红→改回→绿（逐条）

```text
node scripts/mutate.mjs
=== D-01a: client click path returns to idle immediately (the pre-fix behaviour)
  broken  : tests=2 pass=1 fail=1 exit=1
  reason  : AssertionError: D-01: the click must leave idle
  restored: tests=2 pass=2 fail=0 exit=0
  RESULT  : red → green proven
=== D-01b: somebody hand-edits the inlined client kernel without regenerating it
  reason  : AssertionError: client.js kernel region drifted from lib/*.js — run: node scripts/build-client.mjs
  RESULT  : red → green proven
=== D-01c: an early return is moved above the hooks, so the hook count changes per render
  reason  : AssertionError: the empty-draft path must not skip hooks
  RESULT  : red → green proven
=== D-04: degraded settings render all four seats again (the pre-fix plan)
  reason  : AssertionError: B20①: exactly one button when settings are unreachable
  RESULT  : red → green proven
=== D-05: the published entryId drops the include: directory prefix
  reason  : AssertionError: Expected values to be strictly equal
  RESULT  : red → green proven
=== D-06: the session triple is read from the invented sessionQuery.modelSelection again
  reason  : AssertionError: D-06: `sessionQuery.modelSelection` is not on the Host contract
  RESULT  : red → green proven
=== D-07: buildResult drops the Host failure text again
  RESULT  : red → green proven
=== D-08: the guard lets a request with neither fetch-metadata header through again
  reason  : AssertionError: a raw HTTP client must not reach the handler
  RESULT  : red → green proven
=== D-09: scripts/assert-preset.mjs is absent again
  RESULT  : red → green proven

ALL MUTATIONS PROVEN (9 run)      (exit=0)
```

### 5.4 D-01 的专门测试（任务硬要求）

```text
node --test --test-name-pattern="a click leaves idle" test/client.test.js
✔ a click leaves idle: the seat publishes running while the command is in flight (D-01)
ℹ tests 1 / pass 1 / fail 0
```

断言链（`test/client.test.js`）：
1. 点击前 `data-state === 'idle'`、`data-elapsed-ms === null`；
2. `onClick()` 后重渲染 **`data-state === 'running'`**（这就是"离开 idle"）；
3. `data-elapsed-ms !== null`（B11 秒表有读数）；
4. `aria-disabled === 'true'`、`[data-action] === ['cancel']`（B11③/B12）；
5. 其余三颗 `data-state='idle'` 且 `aria-disabled='true'`（B11①）；
6. 恰好一次 `commands.execute`，且解码后的 payload 是 `{action:'refine', presetId:'general', draft:'你好'}`。

### 5.5 浏览器等价启动（不经测试替身）

```text
new Function(client.js 源码)()                       → entry 捕获成功
entry.factory(require)                               → inject = slots,locale,configForms,remote
apply(ctx)                                           → 5 条注册：settings.section#lab-draft-studio@60,
                                                       conversation.input.right#lab-draft-{general@0,coding@1,writing@2,translate@3}
空草稿 + 设置不可用渲染                                → null（不抛）
exit=0
```

---

## 6. 改动文件清单

| 文件 | 动作 | 说明 |
|---|---|---|
| `client.js` | 重写 | 内联内核区（生成）+ 真实点击路径 + 座位/设置页 |
| `lib/seats.js` | 新增 | `visibleSeats`/`seatPlan`/`seatFor`（无 import，可内联） |
| `lib/request.js` | 改 | 座位规则移出并 re-export；`validateRefineRequest` 支持降级 `presetId:null`；`ACTIONS` 补 `dump-request` |
| `lib/prompt.js` | 改 | `resolveRequestPreset`（区分 `null` 与未知）、`buildDegradedSystemPrompt`、`buildSystemPrompt(null, …)` |
| `lib/host.js` | 改 | D-05 entryId、D-06 `observeSession`、D-07 `detail`/`describeError`/`prepareDumpRequest`、B20 `dumpRequest`、删 `timeSource` |
| `lib/wire.js` | 改 | `buildResult` 增加 `detail` |
| `lib/guard.js` | 改 | D-08 双向缺失拒绝 + `origin-unconfigured`；注释同步 |
| `index.js` | 改 | 注明 D-06 的契约来源与 `persist` 缺席的原因（行为未变） |
| `scripts/build-client.mjs` | 新增 | 内联生成器 + `--check` |
| `scripts/assert-preset.mjs` | 新增 | D-09 |
| `scripts/mutate.mjs` | 新增 | 改坏→红→改回→绿 的可复跑装置（不随包发布） |
| `test/client.test.js` | 重写 | 41 条（原 25） |
| `test/core.test.js` | 增补 | 133 条（原 113） |
| `package.json` | 改 | 加 `build:client` / `check:client` / `mutate` 脚本 |
| `09-verification.md` | **未动** | — |

---

## 7. 给下一轮（P4）的交接

1. **B1-e / 页面几何仍需真机走查**：`09` §3.0 的 Client Inspect 超时问题本轮未复测（不在修复范围），`data-state` 的运行时取证也仍需要一次真页面。
2. **`configForms.get('include:lab-draft-studio')` 的返回值**：本轮只证"传对了 id"，未证"宿主返回表单"。装上去后第一件事就是跑一次 `dump-settings` 看 `entryId`，并在设置页确认横幅不出现。
3. **B8/B9 的负向对照现在有输出可取**：`/lab-draft <base64url({action:'dump-request',presetId:'coding',sessionId:'…',prepare:true,negative:'model'})>` 的 `detail` 里应能看到宿主的拒绝原文。命令仍要手算 base64（D-12 未修）。
4. **B20 的降级现在真的只在设置不可用时出现一颗**：真机验证时把插件 Config 改成非法 JSON，应看到 1 颗按钮且 `dump-request` 的 `presetId` 为 `null`。
5. **`save-settings` 仍恒 `persist-unavailable`**（`index.js` 无 `persist`）——D-02 的修复在**这条路径打通后**才真正保护用户数据；在那之前"用户不得通过设置页保存"这条约束仍然有效。
