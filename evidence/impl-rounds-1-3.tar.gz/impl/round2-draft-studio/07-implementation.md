# 07 实现（P2 最小切片）— 草稿工坊（实验） / `@local/lab-draft-studio`

> 版本：2026-11-08。输入：`02-plan.md` v3.2（P2 开工回写版）、`06-p1.5-probes.md`、`06-lead-decision.md`。
> 本文件回答三件事：**实现了什么**（能跑的与不能跑的分别是什么）、**空壳在哪且为什么**、**怎么跑测试**。最后一节列与计划的偏差。
> 纪律：本轮**没有安装任何插件、没有碰 `$DSH_HOME`、没有写真实 Config 到 profile**。所有"通过"都是**离线**结论；需要页面/宿主才能观测的，一律在 `08-selfcheck.md` 标「需运行时验」。

---

## 1. 实现了什么

### 1.1 目录

```text
bundle-lab/
  index.js                 宿主入口：导出 Config + apply()
  client.js                客户端半（classic script，注册 4 座位 + 设置页）
  cordis.patch.yml         一行 insert，id: lab-draft-studio
  package.json             包名 @local/lab-draft-studio，dsh.bundle / dsh.client
  locale/{zh,en}.json      meta.title/description + 全部界面文案
  icon.svg                 原创图标
  README.md                并存声明（首段）
  lib/
    prompt.js              四套预设 + 结构块逐字常量 + system 路由
    context.js             上下文折叠（轮数/字符双预算）+ 回显
    boundary.js            空草稿/`/`芯片/`@`占位符判定
    writeback.js           写回决策（draftRev 守卫、引用丢失、空结果）
    settings.js            20 项 spec + 校验 + 生效值解析（名称 ≤12 码位、提示词空=默认）
    request.js             请求体校验（草稿非空、presetId 合法性回落、座位可见性）
    llm-options.js         跟随/固定装配 + 强度回落（B8/B9/B10）
    run-store.js           按会话的运行状态机（四态、单跑、token 守卫）
    wire.js                命令载荷编解码（base64url + JSON）与结果编解码
    guard.js               降级 A 的 HTTP 守卫（三闸）
    schema.js              Config 声明 + 容错读取（volatile 解引用）
    host.js                宿主装配：命令 handler、dispatch、runRefine、降级路由
    sha256.js              零依赖 SHA-256（B5/B7 的哈希基元）
  scripts/check-syntax.mjs 逐文件语法检查（区分 module / classic script）
  test/core.test.js        113 条纯逻辑测试
  test/client.test.js      25 条客户端半测试（含与内核的镜像一致性）
```

总计 **138 条测试**，`node --test` 全绿；`node --check` 全量通过（16 个文件，见 `scripts/check-syntax.mjs`）。

### 1.2 纯逻辑内核（本轮的主要交付面）

要求里点名的五块，全部落成**无 IO、无全局、无 Host 依赖**的纯函数，并有测试：

| 要求 | 模块 | 关键导出 |
|---|---|---|
| 预设解析与路由（四套预设 → system 段） | `lib/prompt.js` | `STRUCTURE_BLOCKS`（逐字照抄 `01` §3-B5）、`buildSystemPrompt`、`resolvePresetId`、`readPresetMarker` |
| 上下文装配（条数与字符预算裁剪） | `lib/context.js` | `assembleContext`（先裁轮数、再**从最旧**裁字符）、`renderContextSection`、`readout` |
| 文本写回决策（draftRev 守卫） | `lib/writeback.js` | `decideWriteBack`（write / retry-pending / failed / discard 四态）、`decideRevert`、`spanStillValid` |
| 请求体校验（草稿非空、presetId 回落） | `lib/request.js` | `validateRefineRequest`、`visibleSeats`、`seatPlan` |
| 设置项读写与校验 | `lib/settings.js` | `SETTINGS_SPEC`（20 项 = 19 可改 + #20 只读）、`validatePatch`、`resolvePrompt`/`resolveLabel`、`countUnsaved` |

另外三块是上面这些的必要支撑，也都在内核里：`lib/llm-options.js`（跟随/固定 + 强度回落）、`lib/run-store.js`（运行状态机）、`lib/wire.js` + `lib/guard.js`（传输与降级通道的安全）。

**几处刻意的设计选择**（都有测试钉住，防止后来者"顺手简化"）：

1. **结构块逐字照抄，且显示名绝不进 system 段。** B5 断言 `system.includes(结构块)`、B7 断言改名后 `systemSha256` 不变。所以 `buildSystemPrompt` 的签名里**没有** label 参数——这是结构性保证，不是纪律。
2. **字符预算从最旧的消息开始裁。** 改写针对的是最新一稿，裁最旧的才保得住它。同时"永远至少留最新一条"——空上下文比截断的上下文更没用，溢出由回显说明。
3. **`decideWriteBack` 在"相同时刻"检查 text 和 rev 两个量。** 只信 `draftRev` 不够：宿主 `insertText` 的守卫是 `span.draftRev !== this.rev`，但**先做本地判定**能在不发请求的前提下区分"可以写回"和"要进入待重试"，而 B13 要求知道**为什么**没写回。
4. **`spanStillValid` 连覆盖区内的文本一起比。** 用户如果在 span 内部打字，rev 可能还没变，写回会把他的字吃掉。
5. **`retry-pending` 与 `failed` 分开。** A9 要求"结果保留待重试"有独立可见态；`discard`（发送/取消）又是第三种——它**不保留**任何东西。
6. **`null` 表示"没有覆盖值"，不存空字符串。** 这是"提示词空 = 恢复默认"能工作的原因：`resolvePrompt` 读不到覆盖就回内置，永远不会返回空串。
7. **强度回落区分"元数据未知"与"不支持"。** `efforts === undefined` 时保持请求原样（不知道就别猜），`efforts` 是非空列表但不含请求、或列表为空（模型声明不支持任何强度）时才回落并记 `effortFallback`。原实现把两者混为一谈，被测试抓出（见 §5.2）。

### 1.3 Host 半

**主通道 = 官方命令通道。** `createHost()` 用 `ctx.commands.register({ name: 'lab-draft', handler })` 注册；客户端侧将来经 `ctx.remote.commands.execute(sessionId, '/lab-draft <base64url>', [], signal)` 调它。契约依据（本轮实读，见 `08-selfcheck.md` §2）：

- `CommandInvocation = { commandId, agent, rawInput, attachments, signal }`——**没有** provider/model 字段，所以模型/强度不能靠命令日志证明；
- `CommandResult = success{text?} | error{text}`——所以结果走 `text` 里的 JSON；
- `signal` 由 UI 请求持有，abort 会贯通到 handler（`06` §3-U2 源码级）。

**为什么不直接实现降级 A 为主通道**：没有依据认为命令通道不可用（`06` §3-U2 判定的是"运行时待补"而非"不可用"）。降级 A 反而有**实测的鉴权缺口**（`06` §4：浏览器口对命名路由不鉴权，无凭证 200）。所以本轮把 `mountRoute()` 写成**默认不挂载**，且拒绝在缺少 token 或 origin 时注册（`token-missing` / `origin-missing`），route handler 内置三闸守卫（方法+路径、`Sec-Fetch-Site`/`Origin`、每进程 token），拒绝时不回细节。

**设置存储走插件 Config**（U5/U6 已验，不走文件降级）。`lib/schema.js` 的可改字段全部 `.volatile()`；`readConfig()` 负责把 volatile 引用解成普通值，并把 `temperature: -1` / `maxTokens: 0` 两个哨兵翻回 `null`（"不设置 = 用宿主默认"）。

**超时是宿主自建的**，不是等宿主超时：`runRefine` 起 480 秒（可配 30–600 秒）计时器并 abort；自测注入通道 `DSH_DRAFT_STUDIO_SELFTEST=1` + `DSH_DRAFT_STUDIO_TIMEOUT_MS`（也接受 `LAB_*` 拼写），结果标 `timeoutSource: "selftest"`，这是 B17 要求"可证明来源"的落点。

### 1.4 Client 半

`client.js` 是 classic script（`window.__ModuleLoader__.load({ id, factory })`），注册：

- **`conversation.input.right` 四条**，`id = lab-draft-<presetId>`、`order = 0..3`。四态渲染，根节点带 `data-draft-studio-seat` / `data-preset-id` / `data-order` / `data-state` / `data-reason-code` / `aria-disabled` / `data-elapsed-ms` / `data-hover-text`，回退/重试/取消子节点带 `data-action`。
- **`settings.section` 一页**，`id = lab-draft-studio`、带 `label()`，渲染 20 行（19 可改 + `data-readonly="true"` 的 #20）。

三条行为要点已由测试钉住：草稿非空才出按钮（`trim()` 覆盖 `\u3000`）、总开关关 = 0 颗、设置不可用 = 一颗通用按钮。

---

## 2. 空壳及原因（哪些是"骨架"而不是"实现"）

> 判断标准：**离线能不能给出二值结论**。能，就实现 + 测试；不能，就写成带明确返回值的骨架，并在失败路径上**诚实报错**，不伪造成功。

| # | 空壳 | 现状 | 为什么 | 谁来补 |
|---|---|---|---|---|
| S-1 | **客户端点按钮 → 真发命令** | 点击只走本地状态机，**当场回到 idle**，不发请求 | 需要会话 id 与 `ctx.remote` 的活体接线；本切片拿不到页面（Client Inspect 累计 9 次超时、无浏览器控制），任何接线都只能靠猜。**故意做成"点了没反应"而不是"假装在跑"**：后者会让 B11/B13 的走查看到假状态 | S5/P3（页面在线时） |
| S-2 | **`inputActions.insertText` 的真实写回** | 回退路径写了 `setDraft`（带"当前文本必须等于我写进去的"前置判定）；写回本身未接 | 同上：`insertText(text, span)` 需要真实 `captureInsertion()` 的 span，而 span 只能从活体编辑器取 | S5/P3 |
| S-3 | **设置页的写入** | 页面只渲染；保存命令在**没有写路径时返回 `{ok:false, error:'persist-unavailable'}`** | Config 的写路径是宿主 settings 文档（`configForms`），需要活体连接与 revision；离线无法验"改完即时生效"（B18 的证据只能在运行时取）。**明确不返回成功** | S6/P3 |
| S-4 | **`prepareCall` 的真实调用参数** | `runRefine` 已按 `prepareCall(config, signal, configure)` 调用并读 `prepared.config`，但只在假 `llm` 上跑过 | 真实适配器/凭证只在宿主侧；离线只能验协议形状 | P3 |
| S-5 | **`/lab-draft` 命令的真实往返** | 命令已注册、编解码与 dispatch 已单测；**第三方 bundle 能否调 `execute` 未实测** | `06` §3-U2 的判定：契约已验、源码链完整、**运行时未跑**（本轮不许安装）；负责人已接受该风险，S1 装探针后补测 | S1/P3 |
| S-6 | **降级 A 的 HTTP 路由** | 已实现（带三闸守卫），但**默认不挂载** | 主通道没坏，没必要启用一个实测有鉴权缺口的通道。留着是为了 U2/U3 万一失败时有现成台阶 | 条件触发 |
| S-7 | **`@` 引用芯片的重建** | 只做了判定与降级（`reference-lost` → 待重试，原稿不动） | 按 A2/B21 的写死口径：**重建失败就"原稿不丢、结果待重试"**，不做静默退化。真正的 `restoreDraft(...)` 恢复属 S5 | S5/P3 |
| S-8 | **设置页的 19 个真实控件** | 渲染为带 `data-settings-input` 的只读展示行 | 写路径未通（S-3），先渲染成"可读"比渲染成"可点但没反应"诚实 | S6 |

**不在"空壳"之列的三件容易被误认为空壳的东西**：①`dump-request` / `dump-settings` / `dump-draft` / `save-settings` 四个命令的 dispatch 是**真实现**（含 `messageCount`、`systemSha256`、`effortFallback`、`timeoutSource`），只差活体 `llm`/`sessionQuery`；②`runRefine` 的超时、取消、分类（timeout/aborted/provider-error/empty-result/settings-unavailable）是**真实现**，用假 llm 跑过；③HTTP 守卫是**真实现**，6 条测试覆盖各个拒绝面。

---

## 3. 怎么跑

```powershell
cd bundle-lab

# 1) 语法全量（区分 module 与 classic script；client.js 必须按 script 解析）
node scripts/check-syntax.mjs
# → 16 file(s) checked, 0 failure(s)

# 2) 测试（零第三方依赖，不需要 npm install）
node --test "test/*.test.js"
# → tests 138 / pass 138 / fail 0

# 3) 单文件跑
node --test test/core.test.js      # 113
node --test test/client.test.js    # 25
```

Node 版本：本机 `v24.22.2`。`test/*.test.js` 的 glob 由 node 自己展开（`--test` 支持），Windows 下用双引号包住。

**不安装**：`package.json` 里的 `dsh` 段与 `cordis.patch.yml` 只为将来 `plugin_manager install_bundle` 准备；本轮**没有**运行任何安装命令，也没有写 profile。

---

## 4. 与计划的偏差

| # | 计划写的 | 实际做的 | 原因 |
|---|---|---|---|
| D-1 | 包名 `@local/dsh-draft-studio`、patch `id: draft-studio`、座位 `id = presetId`、设置页 `id: draft-studio` | `@local/lab-draft-studio` / `lab-draft-studio` / `lab-draft-<presetId>` / `lab-draft-studio` | `06-lead-decision.md` §1 的并存裁定（方案 B）。**探针属性名 `data-draft-studio-*` 不变**——`01` §4 片段与前代 0 命中的实测都建立在它上 |
| D-2 | 命令族 `/draft-studio <sub>` | `/lab-draft <base64url(JSON)>` | 前缀随 D-1；子命令改单行 JSON 是因为草稿可能数千字带换行与引号（U3 已证传输不限长），一次 `JSON.parse` 比多段语法更不容易半解析。`01` §4 允许的命令清单里写的 `/draft-studio dump-*` 需在 P3 按新前缀重述 |
| D-3 | 超时环境变量 `DSH_DRAFT_STUDIO_*` | 两者都接受（`LAB_*` 优先） | 让 `01` §3-B17 里写死的验收命令**不用改**就能跑，同时新名字与包名前缀一致 |
| D-4 | 计划 §4-S3 列的模块名 `lib/config-schema.js` / `lib/wire.js` / `lib/prompt.js` 等 | 略作合并：`settings.js`（含 schema 的 spec 表）、`schema.js`（Config 声明与读取）、`guard.js`（新增）、`sha256.js`（新增） | `settings.js` 与 `schema.js` 拆开是因为一个管"值对不对"、一个管"怎么从 Config 读出来"，混在一起会让 U6 的 volatile 语义测试没法单独注入。`sha256.js` 必须有：Host 与 Client 都要算同一个 `systemSha256`，用 `node:crypto` 会让浏览器半没法复用 |
| D-5 | 计划说"温度 0–1，默认不设置" | Config 里用 `-1` 作"未设置"哨兵，`readConfig` 翻回 `null` | schemastery 投影可空数字不顺手；哨兵是**内容决策**，写在 `lib/schema.js` 头部，并有测试钉住 `0` 是合法温度、`-1` 才是未设置 |
| D-6 | 计划 S4 写"注册 `/draft-studio` 命令族（dump-request/dump-settings/dump-draft/save-settings）" | 同一入口 `dispatch()` 按 `payload.action` 分派这四类 + `refine` | 单入口让"未知 action"成为一个可测的失败态，也让线格式只有一个版本号 |
| D-7 | 计划未规定 `Message` 形状 | 上下文以**文本段**塞进 `user` turn，而不是多条带角色的消息 | 改写是单轮变换；给模型看见 `assistant:` 历史会诱导它"接着回答历史"而不是"改写草稿" |
| D-8 | `02` §4-S5 写"每颗按钮 `data-hover-text` = 真正会显示的文案" | 已实现；`REASON_TEXT` 覆盖 8 个 code（6 个 B15 枚举 + `draft-changed` + `reference-lost`） | B15 的 6 个是失败原因，后两个是"结果保留待重试"的原因（A9），用户同样需要看到 |
| D-9 | 计划未提 | `client.js` 的镜像函数（`isDraftActionable` / `countReferencePlaceholders` / `validateLabel` / `visibleSeats` / `writeBackVerdict` / `codePointLength`）由 `test/client.test.js` **从源码文本里抽出来**与内核逐例比对 | classic script 不能 import ES module；镜像不可避免，但漂移必须失败而不是悄悄上线 |

---

## 5. 本轮修掉的实现缺陷（诚实记录）

### 5.1 首轮 9 红

写完内核后第一次跑测试，**113 条里 9 条红**。逐条都是实现错、不是测试错：

| 红 | 根因 | 修法 |
|---|---|---|
| `spanStillValid` | 只比了 span 外的文本，没比 span **内**的 | 覆盖区也是"用户可能改过的地方"，一并比较 |
| 全部 or nothing | `validatePatch` 边校验边写 `next`，最后一个字段失败时前面的已经写进去了 | 校验写到 `next`，**只有零错误才提交** |
| 12 码位 | 测试字符串少写一个字（13 个汉字写成 12 个） | 改用 `'一'.repeat(12)` / `'😀'.repeat(12)`，不手数 |
| `abortOnSend` | `active = null` 之后又读 `active.presetId` | 先取 `presetId` 再清 `active` |
| base64url 空体 | `''` 解出 0 字节，被当成"合法空 JSON" | 空体返回 `null`，让错误码停在 `empty-payload` |
| `decodeResult` 错误码 | 数组被当作合法对象 | 排除 `Array.isArray` |
| `resolveEffort` | `efforts` 缺失被当成"不支持" | 区分"元数据未知"（保持原样）与"明确不支持"（回落） |
| `clampSettings` | 复用 all-or-nothing 的 `validatePatch`，一个坏字段把整份配置打回默认 | 改成逐字段 clamp（保存仍用 all-or-nothing） |
| `runRefine` 用例 | 用例没给路由，被 `settings-unavailable` 先接住 | 用例改用 pinned 路由；"无路由"由它自己的用例覆盖 |

### 5.2 客户端半首轮 13 红

`client.js` 写完第一次跑 13 条红，其中 **3 条是真缺陷**、其余是测试脚手架写错（假的 `ctx.slots.inject` 没被触发、假 React 不调用函数组件）：

| 真缺陷 | 现象 | 修法 |
|---|---|---|
| 设置页缺 `label` | 设置导航里这一行没有名字（页面本身能渲染） | 补 `label: () => SELF_LABEL` |
| 设置页把 children 塞进一个数组 | React 把它当**单个** child，20 行变成 1 个 | 改成 varargs |
| `REASON_TEXT` 的 `timeout` 键没加引号 | 会被 ESLint/某些解析器当作标签用法，且与其它 7 个键的写法不一致 | 统一加引号 |

### 5.3 改坏 → 红 → 改回 → 绿（三组，实跑）

要求"至少演示一次"。做了三组，覆盖三条不同的红线，原始输出见 `08-selfcheck.md` §3。

| # | 改坏的位置 | 变红的测试 | 改回后 |
|---|---|---|---|
| 1 | `lib/prompt.js`：把 `coding` 的结构块首行换成 `preset=translate`（B5 的"串台"负例） | 3 条：`structure block verbatim (B5-a)`、`marker line (B5-c)`、`dump-request … marker for that preset (B5)` | 113/113 绿 |
| 2 | `lib/writeback.js`：把 `revChanged` 写死 `false`（拆掉 B13 的守卫） | 2 条：`a draft that moved during the wait is never overwritten (B13)`、`client write-back verdict table agrees (B13/B21)` | 138/138 绿 |
| 3 | `lib/guard.js`：删掉 token 比对（等价于 `06` §4 实测的那个洞） | 2 条：`guard refuses a request with no token`、`guard treats an absent fetch metadata block …` | 113/113 绿 |

---

## 6. 明确没做

- **没有安装**（`plugin_manager` 一次未调用）、**没有碰 `$DSH_HOME`**、**没有写任何真实 Config**。
- **没有运行时验证**：没有一条 B 验收是"运行时已验"。B1–B21 的三态见 `08-selfcheck.md`。
- **没有改在装的 `dsh-draft-studio@1.2.2`**（只读读过它的 `client.js`/`index.js` 用于并存判定，见 `probes.md` P29-5）。
- **没有接页面**：Client Inspect 本轮又超时一次（累计 9 次零成功），没有浏览器控制。
- **没有动 `01`/`02` 的验收判据**：回写只改状态列与并存决策，B1–B21 一字未改（§7.4 有对照）。
