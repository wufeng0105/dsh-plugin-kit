# 13 修复报告 v2（按 `12-lead-decision-v4.md` 四条必修 + D-02/D-03 + B18/B19 降级）

> 修复者：本轮（不是复验者）。日期：2026-11-08。工作目录：`round2-draft-studio`。
> 对象：`bundle-lab/`（`@local/lab-draft-studio`）+ 三处文档回写。
> 纪律：**只修裁定清单上的条目，不扩大范围**。未安装、未碰 `$DSH_HOME`、未改 `09-verification.md` / `11-reverification.md` / `12-lead-decision-v4.md`。
> 所有命令均在 `bundle-lab/` 下实跑，输出为当轮原文（节选）。

## 0. 一句话结论

**四条必修全部修完，D-02/D-03 先复现再修，B18/B19 正式降级出 P4。**
测试 **178/178 通过**（原 174 + 新增 4 条）、语法 20 文件 0 失败、内联区 `--check` 通过、变异装置 **14/14 red → green**（原 9 + 新增 5 条，覆盖本轮每一条修复）。

---

## 1. 逐条修复

### 1. D-01a：`inject` 补 `remote.commands` —— **已修**

**修法**：`client.js` 工厂返回值（`client.js:1863`）改为
`inject: ['slots', 'locale', 'configForms', 'remote', 'remote.commands']`，并留注释说明子路径服务必须显式声明。

**证据**：
- 安装包官方调用方原文（本轮 `probe-tools/asar-grep.ps1` 实跑）：
  `dsh-client-ui-commands/lib/client.js:1669-1676` — `const result = await this.ctx.remote.commands.execute(...); if (!result.ok) throw ...; if (result.value === void 0) return { kind:"error", ... }`。
- 用安装包同款 cordis 4.1.0 复跑 `%TEMP%\p35-rt\probe-inject4.mjs`（复验者同一探针，本轮重跑）：

```text
inject: [remote]                  → THREW: cannot get property "remote.commands" without inject
inject: [remote, remote.commands] → resolved to a function
```

- 测试：`test/client.test.js:159`「the factory declares the services it uses and exposes apply()」断言改为五项数组。
- 变异：`scripts/mutate.mjs` 新增 **D-01a-inject**（把第五项拿掉）→ 红（`D-01a: remote.commands is a sub-path service and must be declared`）→ 还原 → 绿。

### 2. D-01b：按 gateway 信封解答案 —— **已修**

**修法**：
- `client.js` 新增 `readCommandAnswer(answer)`（`client.js:1609`，内核区之后，客户端自有代码）：按官方解法处理 `{ok, value:{commandId, result:{kind,text}}}` —— `ok !== true` 时取 `error`（兼容网关 `{error:{code,message}}` 对象形态与本轮 fake 的字符串形态）、`value === undefined/null` → `command-value-missing`、`result.kind === 'error'` → 携带 `result.text` 落失败。
- 点击路径 `client.js:2065` 起：先过信封，信封失败时**仍解码 `result.text` 里的 Host 类型化失败负载**（Host handler 把 `reason/detail` 编码在 `text` 里），保留真实原因码；成功路径才 `decodeResult(envelope.text)`。
- `test/client.test.js` 三处 fake 换成真实信封：B3/B4（`{ok:true, value:{commandId, result:{kind:'success', text}}}`）、B13 release、B15（`kind:'error'` + Host 失败文本）。
- 「端到端」测试（`client.test.js:766`）的 `execute` 现在按真实 gateway 形状返回（`{ok:true, value:{commandId, result:{kind, text: encodeResult(result)}}}`），不再返回裸 `{text}`。

**证据**：
- 新增测试「the click path unwraps the gateway envelope and reports transport failures (D-01b)」覆盖四种形状：`{ok:false, error:'gateway offline'}` → provider-error + 原文、`{ok:false, error:{code,message}}` → `unavailable: gateway offline`、`{ok:true, value:undefined}` → `command-value-missing`、`kind:'error'` + `reason:'timeout'` → timeout + 原文 detail。
- 变异 **D-01b-envelope**（把信封读法改回 `answer?.text`）→ 红（`B3: the result is written back …`）→ 还原 → 绿。

### 3. D-05：设置命名空间回退到裸 patchId —— **已修（含三处文档回写）**

**修法**：
- `lib/host.js`：`readEntryId` / `normalizeEntryId`（`:957/:967`）从「强制加 `include:` 前缀」改为「**剥掉** `include:` 前缀」；`ENTRY_ID_PREFIX` 保留但只用于剥离。`createHost` 发布到 `webserver/index-inject` 的 `entryId` 因此回到裸 `lab-draft-studio`。
- `client.js` `resolveForm` 注释同步改写（裸 patchId = 命名空间，`include:` 只是显示 id）。
- `bundle-lab/cordis.patch.yml` 头注释同步改写。
- 文档回写：`01-requirements.md §9` 表行改写为「两个 id 必须分开」；`02-plan.md` D18、§3-U7、§1 并存行均改为「设置命名空间 = 裸 patchId」；`06-p1.5-probes.md` U7 行同步改写。三处均引用 `12-lead-decision-v4.md` D-05 / `11-reverification.md` §2.3 作为依据。

**证据**：
- `test/core.test.js:1686`「readEntryId returns the bare patchId, the settings namespace (D-05)」：裸入裸出、`include:` 入剥前缀；`:1699`「createHost publishes the bare patchId」；`:1711`「the published index-injection row carries the settings namespace」断言 `table[0].value.entryId === 'lab-draft-studio'`。
- `test/client.test.js:905`「the settings page reads the bare patch id, the settings namespace (D-05)」断言 `configForms.get` 收到的唯一参数是 `'lab-draft-studio'`。
- 变异 **D-05**（改回强制加前缀，即复验前的回归形态）→ 红 → 还原 → 绿。

### 4. D-04：`readSettings` 把非 ready 判成不可用 —— **已修**

**修法**：`client.js:1713` `readSettings`：`snapshot?.status !== 'ready'` → `{ settingsAvailable: false, settings: null }`；`value` 非 object 也判 false。安装包证据（本轮 asar-grep）：`dsh-client-ui-settings/lib/client.js:1217` 命名空间不匹配时 `draft.status = "unavailable"`，`:1229` 命中且解码成功才 `draft.status = "ready"; draft.value = decoded` —— 只有 `ready` 才带 `value`。

**证据**：
- 新增测试「an unavailable form status is unavailable, not "available but empty" (D-04)」（`test/client.test.js:771`）：fake controller 返回 `{status:'unavailable'}` → 设置页横幅出现（`settingsAvailable:false`）+ **四颗座位只剩一颗 general**（B20 在客户端可达）。
- 变异 **D-04-status**（把映射改回 `settingsAvailable:true`）→ 红（`the settings page must show the banner`）→ 还原 → 绿。

### 5. D-02：save-settings 不再以默认值填满的 overlay 反向覆盖 config —— **先复现，后修**

**复现（修复前实跑，`%TEMP%\fix2-probe\probe-d02-d03.mjs`）**：

```text
D-02 config          : {"temperature":0.3,"timeoutMs":90000}
D-02 before          : temperature= 0.3 timeoutMs= 90000
D-02 save-settings   : {"ok":true}
D-02 overlay keys    : enabled,readContext,contextMaxRounds,…,temperature,maxTokens,lastResult   ← cloneSettings(null) 的完整默认对象
D-02 after           : temperature= null timeoutMs= 60000
D-02 verdict         : REPRODUCED (temperature lost)
```

**修法（裁定推荐的 (a)：overlay 只存显式字段）**：`lib/host.js` 新增 `mergePatch(base, patch)`（`:132`）——把保存补丁按**稀疏**对象累积进 overlay（支持 `{presets:{id:{field}}}` 与扁平 `'presets.id.field'` 两种形态）；`save-settings`（`:787`）改用它。`resolveSettings` 的合并顺序不变（config 为底、overlay 覆盖、clamp 收尾），但 overlay 从此只含用户显式保存的字段，`cloneSettings(null)` 的默认值不再进 overlay。

**修复后同探针**：

```text
D-02 overlay keys    : timeoutMs
D-02 after           : temperature= 0.3 timeoutMs= 60000
D-02 verdict         : not reproduced
```

**证据**：新增测试「dispatch(save-settings) does not overwrite config fields the patch did not name (D-02)」（`test/core.test.js`，即裁定要求的 `resolveSettings({temperature:0.3, timeoutMs:90000}, overlayFromSaveOnly({timeoutMs:60000}))` → temperature 仍 0.3，另断言 overlay 稀疏）。变异 **D-02-overlay**（改回 `mergeSettings(state.overlay(), patch)`）→ 红（`D-02: an unnamed config field must survive the save`）→ 还原 → 绿。

### 6. D-03：畸形快照 → `messageCount` 为 null 而非 0 —— **先复现，后修**

**复现（修复前同探针）**：

```text
D-03 readSurface {}  : messageCount= 0        ← 空真
D-03 events [2]      : messageCount= 2
D-03 throws          : messageCount= null
D-03 verdict         : REPRODUCED (malformed reads as 0)
```

**修法**：`lib/host.js:620` `readEvents` 的 `snapshot.events` 非数组分支由 `[]` 改为 `null`（"读不到"），注释写明 `0` 会让 B3 的空档假通过。

**修复后同探针**：

```text
D-03 readSurface {}  : messageCount= null
D-03 verdict         : not reproduced
```

**证据**：新增测试「dispatch(dump-draft) reports messageCount null for a malformed surface snapshot (D-03)」（`readSurface → {}` → `messageCount === null`，即裁定要求的第二条专门测试）。变异 **D-03-events**（改回 `[]`）→ 红（`a snapshot without an events array is "unreadable", not "0 messages"`）→ 还原 → 绿。

### 7. B18/B19 正式降级（文档）—— **已写入**

- `01-requirements.md §3-B18/B19` 各加「本轮状态」引言：已正式降级出 P4 范围，判据保留供 P4 后单独立项。
- `01-requirements.md §9` 新增表末行「**B18 / B19 已定降级：移出 P4 范围**」，写明理由：①工作量——19 项控件 + 校验回填 + 编辑门 + 未保存计数 + 恢复默认二次确认是一整块页面交互；②依赖未接——写路径 `persist` 当前诚实返回 `persist-unavailable`，#20 回显依赖的 `lastResult` 写入点不存在（恒 `null`）。P4 签收单必须写明二者不在本轮范围；B1–B17、B20、B21 判据不变。
- `02-plan.md` 头部加 v3.3 回写说明，指向 `01 §9` 末行。

---

## 2. 全量验证输出（全部实跑）

```text
node --test "test/*.test.js"
ℹ tests 178
ℹ pass 178
ℹ fail 0
（exit=0；原 174 + 新增 4：D-01b 信封、D-04 状态、D-02 稀疏 overlay、D-03 畸形快照）

node scripts/check-syntax.mjs
20 file(s) checked, 0 failure(s)
（exit=0）

node scripts/build-client.mjs --check
ok   client.js kernel region matches lib/*.js
（exit=0）

node scripts/mutate.mjs
=== D-01a / D-01b / D-01c / D-04 / D-01a-inject / D-01b-envelope / D-02-overlay /
    D-03-events / D-04-status / D-05 / D-06 / D-07 / D-08 / D-09
… 14 条全部 RESULT : red → green proven
ALL MUTATIONS PROVEN (14 run)
（exit=0）

node %TEMP%\fix2-probe\probe-d02-d03.mjs   （修复后）
D-02 verdict : not reproduced（overlay keys = timeoutMs，temperature=0.3 保留）
D-03 verdict : not reproduced（readSurface {} → messageCount= null）
```

复跑前后无 `.mutation-aside` 残留（计数 0）；`bundle-lab/` 仍为 28 个文件。
每条修复的「改坏 → 红 → 改回 → 绿」由 `scripts/mutate.mjs` 的对应条目实跑给出（见 §1 各条「变异」），不再手工重复。

---

## 3. 未修项及原因

| 项 | 状态 | 原因 |
|---|---|---|
| B18 / B19 实现 | **按裁定降级，不实现** | `12-lead-decision-v4.md`「本轮不要求实现」，理由已写入 `01 §9`（工作量 + `persist` 写路径未接） |
| D-15/D-16（#20 `lastResult` 恒 null） | 未动 | 复验 §5 已判「单独不阻断，被 B18 吞掉」；随 B18 立项一并做，本轮不扩大范围 |
| D-12（`01 §4` E2 命令清单与真实形态不符） | 未动 | 复验判「不构成代码阻断」；属于 P4 操作文档回写，不在本轮四条 + 一项降级的清单内 |
| D-06 附带的 `Symbol.dispose` 泄漏（复验 §2.4 MINOR） | 未动 | 复验自己标注「不阻断」；且 `dispose()` 空操作对 live 会话无副作用 |
| D-08 残余（仅 same-site 无 Origin 放行） | 未动 | 复验标注「不阻断，不要对外说三闸独立」；改 guard 语义超出本轮范围 |

---

## 4. 约束遵守

- 未改 `09-verification.md`、`11-reverification.md`、`12-lead-decision-v4.md`（本轮只新增本文件，并回写 `01`/`02`/`06` 被点名的三处）。
- 未安装任何插件、未写 `$DSH_HOME`；asar 取证只走只读 `probe-tools/asar-grep.ps1`，破坏性探针全部在 `%TEMP%` 副本上。
- 未扩大范围：`lib/` 仅动 `host.js`；`client.js` 仅动裁定点（inject、信封、readSettings、resolveForm 注释）；测试与变异装置只新增/改写与本轮条目对应的条目。
