# 05 复审二轮（P0 / P1 返工门）— dsh-draft-studio

> 第二轮复查审查员独立判定。只读 `01-requirements.md`、`02-plan.md`、`00-client-answers.md`、`probes.md`、`04-regate-P0P1.md` 与本机安装包源码；**未改任何产物、未安装任何插件、未读写 `$DSH_HOME`**。本文件是唯一新增。
> 依据：`process-lab/spec/process-v2.md`；`04-regate-P0P1.md`（上一轮判定与 3 项最小集合）；`03-gate-P0P1.md`（历史记录）；v3 的 `01`/`02`；`probe-tools/dump/`（本机安装包抽取）。
> 时间：2026-11-08（Asia/Shanghai）。行号为 v3 最终行号；源码行号以 `probe-tools/dump/ui-conversation-client.js` 为准，字符偏移以 `probe-tools/dump/index-BgUyXZcc.js` 为准。

## 0. 结论摘要

| 项 | 判定 | 一句话 |
|---|---|---|
| **N-1**（B1-e 观测与空真） | **已清（核心 4/4）** | 四个字段、`leftOfModel` 返回 `null`、模型缺失记「无法判定」、dock 负例靠 `inDock` 变红，全部落地；我另跑了一个假 DOM 复现四态。**留一条三态衔接**：activity 展开时四条判据会判「不通过」，与 §3.0「不判失败」不一致，见 §3.3。 |
| **N-2**（片段字段覆盖） | **未清（部分落地，阻断）** | B11/B15/B16 与 S5 属性清单已落地；但 B3 的 `messageCount` 来源 `ctx.sessionQuery.readEvents` 在当前宿主 `sessionQuery` 方法表里**不存在**（只有 `listEvents` / `readSurface` / `readSession` 等），`editorPhase` 的 `[contenteditable="true"]` 选择器在 `submitting`/`sending` 时**取不到元素**，两个 B3 来源都是空真。 |
| **C-1 / N-8 / N-9**（activity 知情与措辞） | **已清（记录在案）** | §8.5 触发条件/表现/恢复/影响/签收人齐全，状态诚实写「客户回执未取得」；N-9 措辞已改；N-8 走查规程进 §3.0/S5/S8。客户实际签收是 P4 动作，不是本轮伪造。 |
| **N-3**（B5 互斥/主判据） | **部分清（非阻断）** | writing 第 4 条谓词已加、「四套互斥/主判据」已删、负例 1 已改；但「四个谓词两两区分」仍不严格成立（translate 与 writing、general 与 translate 仍有交集），见 §1.4。 |
| **N-4 / N-5 / N-6 / N-7** | **6/6 已清** | D1 的 `left` 同在 `tools` 与偏移 492300、U1 的 schema-first 与 ①②③ 分列、一致性表 13–17 行、B17「四条」均已找到原文。 |
| **专项裁定（activity 前提）** | **可接受，不是打回理由** | 源码事实不变：`right` 与宿主模型选择器同在 `hidden: activity` 的 `standardControls`；`left` 同在 `tools`；`dock` 保可见但正是 B1-e 判红点。换座无收益，C-1 知情记录已补。 |
| **P0 三判据** | **不通过（窄口）** | 判据二、三通过；判据一因 N-2 的 B3 两个来源未成立而不满足。 |
| **P1 三判据** | **不通过（窄口）** | 依赖清单形式齐全，但 D11 的 `readEvents` 是当前宿主契约里不存在的**方法名**，「已验(契约)」不成立；其余 D1、P1.5 门、风险、S5 字段均通过。 |
| **放行意见** | **不通过** | 最小返工 3 项，全部是文档级：B3 `messageCount` 方法名、B3 `editorPhase` 选择器（含 `composerPhase` 键名）、B1-e 的 activity 三态一行。**不涉及**座位、架构、依赖矩阵、探针门、上一轮 19 条已清账项。 |

> **一句话**：N-1 的“返回 true → 返回 null/无法判定”确实改了，假 DOM 也复现了；N-2 确实补了字段/声明，但 B3 的两个字段一个引用了不存在的宿主方法、一个在选择器层面永远看不到 `submitting`/`sending`。**不是“没改”，是“改了但证据链空转”**，按规格铁律 2「空真排除」不能放行。

---

## 1. 逐条清账（N-1、N-2、C-1、N-3..N-9）

### 1.1 N-1（MAJOR）：B1-e 观测字段与空真通道

**04 的要求（§7.2 第 1 项）**：`01` §4 增加 `modelFound`、`rowRect`（工具行）、`visible`、`inDock`；`leftOfModel` 在 `model` 为空时返回 `null` 而不是 `true`；B1-e 的 ③ 改成可判形式；模型选择器找不到时整条记「无法判定」。

**v3 落点与原文**

| 要求 | 落点 | 我读到的原文 | 判定 |
|---|---|---|---|
| 四个字段 | `01:98`（观察字段清单）、`01:99`（`rowRects` 定义）、`01:100`（`visible`）、`01:101`（`inDock`） | `rowRects[i]` = 第 i 颗按钮与模型选择器的**最近公共祖先**的 rect；`visible` = `offsetParent !== null && rect.width > 0 && rect.height > 0`；`inDock` = `seats[i].closest('[data-composer-dock]') !== null` | **已落地** |
| `leftOfModel` 缺失时 `null` | `01:384`、`01:389` | `leftOfModel: !modelFound \|\| seats.length === 0 ? null : seats.every(...)`；正文写明「在 `modelFound === false` 或没有座位时返回 `null`（**不是 `true`**）」 | **已落地** |
| 模型缺失 → 无法判定 | `01:102`、`01:109` | 前置：`count === 4`；**`modelFound === false` → 整条记「无法判定」**，不记通过、不记失败（原 `!model \|\| …` 返回 `true` 的空真通道已删除） | **已落地** |
| ③ 可判 + dock 负例 | `01:103–107`、`01:108`、`01:110` | 四条判据：`modelFound`、`visible` 全真且 `inDock` 全假、`seatRects[i].right <= modelRect.left`、每颗 rect 垂直落在 `rowRects[i]` 内且 `editorOverlap === 0`；负例 1 = dock → `inDock[i] === true` 判据 2 红；负例 3 = activity 展开 → `count===4` 但 `visible` 全 false，记「未验」 | **已落地（核心）** |

**源码核对（不是转述）**

- `data-composer-dock` 在宿主源码 `ui-conversation-client.js:22218` 硬编码，`conversation.composer.dock` 的 `renderSlot` 在 `:22219`，确实是 dock 容器；`inDock` 的 `closest` 能抓到它。
- `standardControls` 的 `hidden: activity` 在 `:22109`，`right` 与 `model` 在同一容器 `:22110`；`tools` 的 `hidden: activity` 在 `:22071`。04 §5.1 的事实仍然成立。
- `data-phase` 在 `:21031` 由 `ComposerContentEditable` 接收，最终落在带 `data-composer-input` 的 div 上（`:20974–20981`）。这一点在 N-2 的 B3 检查里还会用到，见 §3.2。

**假 DOM 实跑（额外抽查，不是 10 条命令之一）**

我把 `01` §4 的代码块原样抽出，用最小假 DOM 跑了四态；命令与结果：

```text
node %TEMP%\b1e-check.js 01-requirements.md   → exit 0
normal:          count=4, modelFound=true,  leftOfModel=true,  visible=[true×4],  inDock=[false×4], rowRects 非空
model missing:   count=4, modelFound=false, leftOfModel=null,  visible=[true×4],  inDock=[false×4], rowRects=[null×4]
dock seat:       count=4, modelFound=true,  leftOfModel=true,  visible=[true×4],  inDock=[true×4], editorOverlap=0
activity open:   count=4, modelFound=true,  leftOfModel=true,  visible=[false×4], inDock=[false×4], editorPhase="active"
```

结论：04 要求的四条都真的落地了——`leftOfModel` 在模型缺失时是 `null`；dock 态下 `leftOfModel` 仍为 `true`、`editorOverlap` 仍为 0，**只有 `inDock` 能抓住它**，与 B1-e 负例 1 的说明一致；activity 态下 `count` 仍是 4、`visible` 全 false，不会假通过。

**N-1 的残留（不单独打回，但下一轮会被问）**：上面的 activity 行显示，四条判据在 activity 展开时会给「不通过」（判据 2 的 `visible` 不全真），而 `01:74` 的 §3.0 说该态「不判失败」、`01:110` 又说记「未验」。**仪器能识别 `visible=false`，但没有把它分流到「无法判定」**。建议在 B1-e 前置加一句：`count===4` 且 `visible` 全 false 且活动面板确实展开 → 整条记「无法判定/未验」；面板收起后仍 `visible=false` 才是「不通过」。这是一行文档，见 §5.2 第 3 项。

### 1.2 N-2（MAJOR）：片段字段覆盖与来源

**04 的要求（§7.2 第 2 项）**：二选一——(a) 扩展片段补 `messageCount`、`composerPhase`、`aria-disabled`、`elapsedMs`、`data-action`、悬停文案；或 (b) 明确写「§4 片段是基线模板，B3/B11/B15/B16 按各自条文列出的键扩展」，并把 `data-elapsed-ms` 加进 S5 的组件属性清单。

**v3 选择了 (b)，并补了表**：`01:64` 声明「§4 片段是基线模板，B3/B11/B15/B16 再按 §4.1 的按条扩展表追加键；表里没有的键不允许临场发明，缺就记无法判定」；`01:391–404` 是 §4.1 表；`02:107–109` 是 S5 属性清单与走查完成标志。

**逐项清账**

| 子项 | 04 要求 | v3 落点 / 原文 | 判定 |
|---|---|---|---|
| **B11** `ariaDisabled` / `elapsedMs` | 补字段与来源 | `01:228–231` 用 `ariaDisabled[i]`、`elapsedMs[i]`、`actions[i]`；`01:372–375` 基线片段输出三个键；`01:399–400` §4.1 来源 = 座位根 `aria-disabled` / `data-elapsed-ms`；`02:108` S5 属性清单含 `aria-disabled`、`data-elapsed-ms` | **已清** |
| **B15** 悬停文案 | 补字段与来源 | `01:258–259` 用 `hoverText[i]`；`01:374` 基线输出；`01:401` §4.1 来源 = 座位根 `data-hover-text`；`02:108` S5 清单含 `data-hover-text` | **已清** |
| **B16** `data-action="revert"` | 补字段与来源 | `01:265–267` 用 `actions[i]`；`01:375` 基线输出；`01:402` §4.1 来源 = 座位内 `[data-action]` 子节点；`02:108` S5 清单含 `data-action` | **已清** |
| **B3** `messageCount` | 补字段与来源 | `01:124` B3 证据、`01:397` §4.1：来源写「宿主半 `ctx.sessionQuery.readEvents(sessionId)` 计数」；`02:103` S4 同样写 `sessionQuery.readEvents` | **未清（阻断）**：当前宿主 `sessionQuery` 方法表没有 `readEvents`，见 §3.3 |
| **B3** `composerPhase` | 补字段与来源 | `01:398` §4.1 的「追加键」写 `composerPhase`，来源写「`editorPhase` = 编辑区 `[contenteditable="true"]` 上的 `data-phase`」；`01:124` B3 正文实际取 `editorPhase`；`01:382` 片段输出的键也是 `editorPhase` | **未清（阻断）**：键名不一致是次要的；**选择器在 `submitting`/`sending` 时取不到元素**，见 §3.2 |

**为什么 `editorPhase` 是空真（源码链）**

1. `01:348` 的片段：`const editor = document.querySelector('[contenteditable="true"]');`
2. 宿主 `ui-conversation-client.js:21829`：`machineBusy = input?.phase === "adjudicating" || input?.phase === "submitting" || input?.phase === "sending"`。
3. `:21833`：`editable = live && !locked && !machineBusy`。
4. `:20976`：`ComposerContentEditable` 渲染 `contentEditable: editor !== null && editable`。
5. 因此 `submitting`/`sending` 时该 div 的 `contenteditable` 变为 `"false"`，**不再匹配 `[contenteditable="true"]`**；`data-phase` 属性仍在（`:21031` + `:20974–20981` 的 `...rest`），但片段找不到元素。
6. 结果：`editorPhase` 在这两个最该被抓住的相位返回 `null`，B3 的「全程不得出现 `submitting`/`sending`」变成「全程没看见」——**空真通过**。正确选择器是同一 div 上稳定的 `[data-composer-input]`（`:20980`）。

这不是“字段没补”，而是“补的字段在目标相位不可观测”。04 的 N-2 要求的是“有来源”；当前来源在源码上不成立，属于 N-2 的残留。

### 1.3 C-1 / N-9 / N-8（activity 前提的知情与措辞）

| 项 | 落点 / 原文 | 判定 |
|---|---|---|
| **C-1 客户知情** | `01:498–512` §8.5：触发条件（`onActiveChange(true)`，`:22112–22116`）、表现（`standardControls` 整行 `hidden`，按钮与宿主模型选择器一起不可见，`count===4` 而 `visible` 全 false）、恢复方式（收起面板；会话切换重置 `:21769`）、影响（只减该态覆盖，其余 20 条不受影响）、**由谁接受 = 客户，P4 随已知问题签收**、当前状态「记录已成文、客户回执未取得」；`01:495` §8 第 3 条指向 §8.5；`02:158` §6.1 第二项只标「记录在案」，`02:121–122` S8 的 known gaps 由客户 P4 签收，`02:149` R9 同步 | **已清（记录）**；客户实际签收 = P4，非本轮伪造。04 的「或并入 P4 已知问题由客户签收」这半边已落地。 |
| **N-9 措辞** | `02:72` U1 ② 改为「**判据不变，但覆盖范围减 activity 展开态、记已知限制**」；影响面列同步「口径 = 判据不变、覆盖范围减该态」 | **已清** |
| **N-8 走查规程** | `01:76` §3.0：全程保持活动面板收起；中途展开该条记「无法判定/未验」、不记通过；收起后重跑并留两次片段 JSON；不得因 `count===4` 记通过；`02:109` S5、`02:121` S8 同步 | **已清** |

> 我只把 C-1 判为「已清（记录）」，不判「客户已接受」：`00-client-answers.md` 没有新增客户回执，`01` §8.5 也明确写「未取得」。这符合 04 的「知情留痕」要求，但 P4 的签收动作仍未发生。

### 1.4 N-3～N-7（顺手修项）

| 编号 | 04 的判定 | v3 落点 / 我读到的原文 | 判定 |
|---|---|---|---|
| **N-3** | “四套互斥”不成立；writing 谓词太弱；“主判据”与“且”矛盾；负例 1 构造不必然同 sha256 | `01:50` 术语改为「四套预设的判据**两两区分**」；`01:156–162` writing 补第 4 条 `^-\s` 行数 < 3；`01:168` 明写「两条是且关系，判据 2 可一票否决，不再称主判据/辅助判据」；`01:170–171` 负例 1 改为「四套模板整表指向同一常量」并解释只改 `preset.structure` 不够 | **部分清（非阻断）**：writing 与 general 的交集被排除了，但「两两区分」仍不严格：translate 输出（英文段落、无编号、无围栏、`^-\s` < 3）也满足 writing 谓词；general 输出若是英文要点（≥3 条 `- `、无编号）也满足 translate 谓词（CJK≤5%、有英文词、编号=0）。建议把词改成「各有独立谓词」，或给 translate 加「无 `^-\s` 要点行」、给 writing 加语言/段落约束。 |
| **N-3 索引** | — | `02:297` 写 `01-requirements.md:46` 是「术语『结构判据』」，实际该术语在 `01:50`；`:46` 是「草稿」行。 | **索引小错（非阻断）** |
| **N-4** | D1 降级座位 `left` 同受 activity 隐藏；id 冲突出处 492275 落在所引区间外 | `02:40` D1 出处扩为 **492065–492300**（`requires options.id` @492133、同 id 冲突 @492275）；降级栏明写 `left` 所在 `tools` 同样 `hidden: activity`（`:22071`）；`02:149` R9 同源码事实；`01:467` A1 与 `01:494` §8 第 2 条同步 492300 | **已清** |
| **N-5** | U1 主探法沿用被拒形态；清零判据未分列 | `02:72` U1：先 `cordis_inspect_list` 读 `Slots.listSubTree`/`Theme.listTokens` 的 input schema、按对象传参；如实记两种失败（`"input" must be an object` 两次 + 对象形态 10s 超时）；同一形态不重试第三次，失败即装最小探针；清零判据按 ①②③ 分列 | **已清** |
| **N-6** | 一致性表未覆盖 `#19`、默认值、900ms、B19 8 字段 | `02:182–186` 新增 #13–#17：256–8192、默认 6/2000、`elapsedMs` 差 ≥900ms、B19 #6–#13 共 8 字段、B1-e 字段；#12 补「activity 展开 count 仍 4、visible 全 false」 | **已清** |
| **N-7** | B17 写“三条”却列四项 | `01:270–281` 观察改为编号 1–4，判定写「**四条**都满足 = 通过」并注明 N-7 | **已清** |

---

## 2. 专项裁定复核（B1 的“观察前提 P2”）

04 §5 的三段论我复核后**维持原判**：这是宿主限制声明，不是验收退化。

1. **是不是宿主限制**：是。`right` 与宿主自己的模型选择器同在 `standardControls`（`:22107–22111`，`hidden: activity` @`:22109`）；activity 展开时两者一起隐藏，DOM 节点仍在。
2. **能不能换座规避**：不能免费规避。`left` 所在 `tools` 也带 `hidden: activity`（`:22071`）；`dock` 虽保可见（`:22216–22223`，`data-composer-dock` @`:22218`），但正是 B1-e 负例 1 判红的落点。要“展开时仍可见”只能放弃“发送区左侧、模型选择器之前”的客户要求，代价更大。
3. **是不是验收退化**：不是。默认态 B1-a～e 全判；activity 态要求记「未验」而不是「通过」；§8.5 已把触发/表现/恢复/签收人写清。只要不写成“activity 展开 = 通过”，就不是退化。

**本轮补上的**：C-1 知情记录（§8.5）、C-2 的 `visible`/`inDock`（§4 片段）、C-3 的 N-9 措辞与 N-8 走查规程。**仍未闭合的**：B1-e 的四条判据没有把 `visible=false` 分流到「无法判定」；如 §3.3 的假 DOM 结果，activity 态会得到「不通过」。这不是 04 的打回理由，但建议同轮补一行。

---

## 3. 抽查 3 处

### 3.1 抽查 A：B1-e 片段在四种状态下的行为（假 DOM）

- 方法：从 `01-requirements.md` 抽出 §4 的 `js` 代码块（`01:342–387`），用最小假 DOM 提供 `document.querySelector/querySelectorAll`、座位/模型/编辑区的 `getBoundingClientRect`、`offsetParent`、`closest`，原样 `eval`；不引第三方库，不改产物。
- 结果：`node %TEMP%\b1e-check.js 01-requirements.md` → exit 0；四态见 §1.1 表。
- **结论**：`leftOfModel` 在模型缺失时为 `null`；dock 态 `inDock=true` 而 `leftOfModel=true`/`editorOverlap=0`，确实只有 `inDock` 抓得住；activity 态 `count=4`、`visible` 全 false。**N-1 的核心修复是真的，不是口头。**
- 附带：activity 态四条判据会判「不通过」，见 §3.3/§5.2 第 3 项。

### 3.2 抽查 B：B3 的 `editorPhase` 选择器与宿主源码

- 断言：`01:348` 用 `[contenteditable="true"]` 找编辑区，再取 `data-phase`。
- 源码：
  - `ui-conversation-client.js:21829` `machineBusy` 含 `adjudicating/submitting/sending`；
  - `:21833` `editable = live && !locked && !machineBusy`；
  - `:20976` `contentEditable: editor !== null && editable`；
  - `:21031` `data-phase` 传给 `ComposerContentEditable`；
  - `:20974–20981` 该组件把 `...rest`（含 `data-phase`）摊到带 `data-composer-input` 的 div 上。
- **结论**：`submitting`/`sending` 时 `contenteditable="false"`，`[contenteditable="true"]` 不匹配，`editorPhase` 为 `null`；B3 的“不得出现 submitting/sending”永远看不到目标相位。**这是一个新发现的空真通道，不是 04 原文指出的那个（04 指的是 `leftOfModel`），但同属“空真排除”铁律。**
- 修复方向：`const editor = document.querySelector('[data-composer-input]')`（同一 div，`:20980`），或 `[data-composer-input][data-phase]`；随后用一个 `submitting` 负例断言 `editorPhase === "submitting"` 而不是 `null`。

### 3.3 抽查 C：B3 的 `messageCount` 来源与当前宿主 `sessionQuery` 契约

- 文档断言：`ctx.sessionQuery.readEvents(sessionId)`（`01:397`、`02:22`、`02:50`、`02:103`、`02:262`；`probes.md:59` 也称已验）。
- 本轮实跑（只读 Host Inspect，E2）：

```text
cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})
→ methods[].signature 含：
   observeSession(sessionId, options): Promise<SessionObservation>
   readSession(sessionId): Promise<SessionLogSnapshot>
   listEvents(sessionId): Promise<SessionEventRecord[]>
   readSurface(sessionId): Promise<SessionSurfaceSnapshot>   // events: SurfaceEvent[]
   readEvent(request, signal): Promise<SessionEventWindow>
   …（共 15 个方法）
→ 没有 readEvents。
```

- **结论**：`readEvents` 不是当前宿主 `sessionQuery` 的公开方法；`probes.md` P7 的 `readEvents` 记录是错的（或已过期）。`dump-draft` 的 `messageCount` 按现文档实现会在运行时失败，B3 的证据源不成立。可用的替代：`readSurface(sessionId).events.length`（`SessionSurfaceSnapshot.events: SurfaceEvent[]`），或 `listEvents(sessionId)` 后按 `SessionEventRecord.type` 过滤 `user/message|assistant/message|system/message|developer/message`；具体取哪种要在文档里写死，不能留给 P2 现场再议。
- **影响面**：N-2 的 B3 一半 + P1 的 D11（`02:50` 写 `readEvents/readSurface` 且标「已验(契约)」）+ `probes.md` P7。三者同一根，必须一起改。

> 三处抽查中，A 是“修复有效”的证据，B/C 是“修复引入/残留空真”的证据。B/C 都属于 N-2，故 N-2 判未清。

---

## 4. 复核命令实跑（§7.2.3 声称的 10 条）

全部在 `round2-draft-studio` 目录、`pwsh -NoProfile -NonInteractive` 下实跑；`Select-String` 退出码均为 0。

| # | 命令（`Select-String -Path … -Pattern …`） | 命中 | 我读到的落点 |
|---|---|---|---|
| 1 | `01-requirements.md` `modelFound\|rowRects\|inDock` | **19** | L22 速查、L64 基线声明、L98 B1-e 观察、L384 `leftOfModel`、L389 口径；**命中** |
| 2 | `01-requirements.md` `无法判定` | **8** | L102 模型缺失、L109 负例 2、L110 负例 3、L76 走查；**命中** |
| 3 | `01-requirements.md` `按条扩展\|messageCount\|composerPhase\|data-elapsed-ms\|data-hover-text` | **17** | L391 §4.1、L397 `messageCount`、L398 `composerPhase`、L400、L401；**命中，但 L398 的 `composerPhase` 恰是键名不一致处** |
| 4 | `01-requirements.md` `activity 展开态的客户知情记录` | **1** | L498 §8.5 标题；**命中** |
| 5 | `02-plan.md` `判据不变，但覆盖范围减 activity 展开态` | **2** | L72 U1 ②、L308 命令清单；**命中** |
| 6 | `02-plan.md` `全程保持活动面板收起` | **4** | L109 S5、L121 S8、L275 N-8 记录、L309 命令清单；**命中** |
| 7 | `01-requirements.md` `行数 < 3` | **1** | L162 writing 第 4 条谓词；**命中** |
| 8 | `02-plan.md` `492065–492300\|tools` 容器同样` | **5** | L40 D1、L149 R9、L285 N-4 记录；**命中** |
| 9 | `02-plan.md` `"input" must be an object` | **3** | L72 U1、L286 N-5 记录、L312 命令清单；**命中** |
| 10 | `01-requirements.md` `四条.*都满足 = 通过` | **2** | L280 B17、L303 B20；**命中** |

**结果**：10/10 命中，没有“命令是摆设”的情况；但“命中”不等于“语义正确”——第 3 条的 `composerPhase` 命中就是反例，必须读原文才能发现键名/来源问题。第 2、5、6、8、9 条的命中有一部分来自变更记录/命令清单本身，我已逐行读过实际落点，不是只看计数。

**另跑 04 §7.4 的两条 A1/C1 复核命令**：

```text
Select-String -Path 01-requirements.md -Pattern '^\| A1 '       → 1 hit（L467，含 自查可解（已结案））
Select-String -Path 02-plan.md -Pattern 'A1/C1 已结案'          → 2 hits（L157、L178）
```

A1/C1 没有回归；`02:178` 自己写的期望是“命中 1 行”，实际 2 行（L157 + L178），这是文字计数的小误差，不影响结论。

**另跑 04 §7.4 的探针门命令**：

```text
Select-String -Path 02-plan.md -Pattern 'P1.5 清零|U1/U2/U3/U5/U6/U7' → 7 hits
```

P1.5 门仍在，U1/U2/U3/U5/U6/U7 仍是常态项，U4 条件项、U8 归 S8 的口径未变。

---

## 5. 放行意见

### 5.1 判定

**不通过（不可进 P2）。** 不是设计问题，也不是上一轮 19 条编号缺陷的回归；是 N-2 的 B3 两个证据来源仍然空转，外加 P1 D11 的同一根 `readEvents` 契约错误。修完 §5.2 的 3 项即可重门；不需要重做座位、架构、依赖矩阵、探针门、风险清单。

### 5.2 最小返工集合（3 项，全部文档级）

1. **N-2 / B3：把 `messageCount` 的来源从 `readEvents` 换成当前宿主真实存在的方法。**
   - 证据：`cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})` 的方法表没有 `readEvents`；有 `listEvents(sessionId): Promise<SessionEventRecord[]>` 与 `readSurface(sessionId): Promise<SessionSurfaceSnapshot>`（`events: SurfaceEvent[]`）。
   - 改动：`01:397`、`02:22`、`02:50`（D11）、`02:103`（S4）、`02:262`（§7.2.1）与 `probes.md:59` 统一改为 `readSurface`（取 `events.length`）或 `listEvents` + message-type 过滤；在 `01` §4.1 写死“`messageCount` 到底数哪类事件”，不要留给 P2。
   - 通过判据：`Select-String -Path 01-requirements.md,02-plan.md -Pattern 'readEvents'` **0 命中**；Host Inspect 的方法名与文档逐字一致。

2. **N-2 / B3：把 `editorPhase` 的选择器从 `[contenteditable="true"]` 换成 `[data-composer-input]`，并对齐键名。**
   - 证据：`ui-conversation-client.js:21829` + `:21833` + `:20976` 使 `submitting`/`sending` 时 `contenteditable="false"`；`data-phase` 仍在 `:20974–20981` 的 `data-composer-input` div 上（`:21031`）。
   - 改动：`01:348` 的 `editor` 查询改为 `[data-composer-input]`；`01:398` 的「追加键」由 `composerPhase` 改为 `editorPhase`（或明写“键名是 `editorPhase`，`composerPhase` 是旧称”）；`01:124`、`02:262` 同步；§4.1 的来源改为 `:20974–20981` + `:21031`。
   - 通过判据：用一个 `input.phase="submitting"` 的负例跑片段，`editorPhase === "submitting"`（不是 `null`）；`composerPhase` 在 01/02 里 0 命中（或只作为旧称说明出现）。

3. **N-1 / C-2：给 B1-e 补一行 activity 三态前置。**
   - 证据：假 DOM 的 activity 态 `count=4`、`visible` 全 false；B1-e 四条判据会判「不通过」，而 `01:74` §3.0 说该态「不判失败」、`01:110` 说记「未验」。
   - 改动：`01:102` 前置加：`count===4` 且 `visible` 全 false 且活动面板确实展开 → 整条记「无法判定/未验」，不进入四条判据；面板收起后仍 `visible=false` → 「不通过」。`01:76` 的「`visible=false` 即该态」改成「`visible=false` **且面板展开** 即该态」，避免把插件 bug（隐藏按钮）误记为「未验」。
   - 通过判据：activity 负例的记录是「未验」，插件把座位 `display:none` 的负例仍然「不通过」；两者不会混。

> 三项都在同一轮改完即可重门；第 1、2 项是阻断，第 3 项是同一块的连体修复（不改也能“判”，但会留下三态不一致）。

### 5.3 非阻断建议（下一轮会被问，不影响本次放行）

- **N-3 的「两两区分」仍不严格**：translate 输出可满足 writing 谓词，general 的英文要点可满足 translate 谓词。建议改成「各有独立谓词」，或给 translate 加“无 `^-\s` 要点行”、给 writing 加语言/段落约束。04 已把它列为“建议顺手修”，本轮仍未完全闭合。
- **`02:297` 的行号**：N-3 的术语落点写 `01:46`，实际是 `01:50`；`:46` 是「草稿」行。小错，下一轮顺手改。
- **`02:178` 的期望命中数**：写“命中 1 行”，实跑 `A1/C1 已结案` 是 2 行（L157 + L178）。建议改成“≥1 行”。
- **C-1 的客户签收**：当前是「记录在案、待 P4 签收」，不是「客户已接受」；P4 交付时要把 §8.5 的五个格逐条给客户看，尤其是“客户不接受时只剩换 dock 或放弃该隐含期望”两条出路。
- **`messageCount` 的语义**：如果选 `listEvents`，必须按 `SessionEventRecord.type` 过滤消息类事件，否则 `command/run|done`、`turn/start|end` 也会计数，B3 的“前后相等”会被 `dump-draft` 自身的命令事件打破；如果选 `readSurface`，要说明 `SurfaceEvent` 是否含 `tool/result`。建议在 `01` §4.1 加一行“计数对象 = …”，并在 `02` §6.2 加一行 B3 键名/计数口径。

### 5.4 放行后的预期

- 修完 §5.2 的 1、2 项，P0 可重门；第 3 项同轮改完，B1-e 三态闭合。
- P1 的 D11 修完后，`02` 的“已验(契约)”才成立；P1 的其余判据（D1、P1.5 门、风险、S5 字段）本轮已过。
- P2 仍不能开工：P1.5 的 U1/U2/U3/U5/U6/U7 清零、S1 探针闭环、安装批准都还没发生；本轮不改变这个顺序。

---

## 6. 本次未做 / 不能做

- **未安装**任何插件，**未读写** `$DSH_HOME`，**未改** `01-requirements.md` / `02-plan.md` / `03-gate-P0P1.md` / `04-regate-P0P1.md` / `00-client-answers.md` / `probes.md`；本文件（`05-regate2-P0P1.md`）是唯一新增。
- **未连 Client Inspect**：activity 展开频率、`right` 的运行时占用者仍是 `UNVERIFIED`，归 P1.5 U1；本报告只裁决静态契约与文档。
- **Host Inspect 只读查询**：本轮用了 `cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})`，输出见 §3.3；没有调用任何业务方法、没有改配置。
- 源码只读自 `probe-tools/dump/`（本机安装包抽取）；字符偏移用 `[IO.File]::ReadAllText` + `IndexOf` 实测：`requires options.id` = 492133，`already has an entry with id` = 492275，`case"list":{` = 492065；`data-composer-dock` 行 22218，`hidden: activity` 行 22071/22109，`data-phase` 行 21031，`data-composer-input` 行 20980，`editable` 行 21833。
- **三态结论**：
  - 宿主隐藏行为、`data-composer-dock`、`data-phase` 落点、`readEvents` **不存在** = **已验(源码/契约)**；
  - activity 展开频率、运行时占用、令牌清单 = **未验**（P1.5 U1）；
  - B1-e 在 activity 展开态的**记录口径** = **无法判定/未验**（需按 §5.2 第 3 项补一行，当前文档的判据会误判为“不通过”）；
  - B3 的 `messageCount` / `editorPhase` 按现文档 = **不可判定（来源不成立）**，不是“通过”，也不是“未验”。

---

### 附：本轮新发现与 04 编号的对应

| 本轮编号 | 来源 | 级别 | 与 04 的关系 |
|---|---|---|---|
| **N-2-a**（`messageCount` 的 `readEvents` 不存在） | 抽查 C / Host Inspect | **MAJOR（阻断）** | N-2 的 B3 一半；同时使 P1 D11 的“已验(契约)”失效 |
| **N-2-b**（`editorPhase` 选择器在 submitting/sending 取不到） | 抽查 B / 源码 | **MAJOR（阻断）** | N-2 的 B3 一半；04 未点名，v3 新增字段引入的空真 |
| **N-2-c**（`composerPhase` vs `editorPhase` 键名） | §4.1 / B3 对读 | MINOR | N-2-b 的同块 |
| **N-1-a**（activity 态四条判据判“不通过” vs §3.0“不判失败”） | 抽查 A / 假 DOM | MINOR（建议同轮） | N-1/C-2 的三态衔接 |
| **N-3-a**（“两两区分”仍不严格） | B5 谓词对读 | MINOR（非阻断） | N-3 的残留 |
| **N-3-b**（`02:297` 行号 46→50） | 落点核对 | MINOR | N-3 索引 |
