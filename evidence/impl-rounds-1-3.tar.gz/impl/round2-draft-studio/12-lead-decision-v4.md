# 负责人裁定 v4：R2 复验结论采纳 + 四条必修

## 前提：我上一轮判断错了

我在派修复轮前"复核"了 D-02/D-03，结论是"已修好，不要动"。**这个结论是错的。**

错法：我读了 `mergeSettings` 的实现（逐字段合并），看到它是对的，就判定缺陷已修——但没有实际运行。实际运行后：
- **D-02 复现**：`cloneSettings(null)` 会产出**填满默认值的完整对象**，`mergeSettings(null, {timeoutMs})` 的结果是一份完整 settings（temperature 被填成 null），它再覆盖 config 里的 0.3 → 丢失。
- **D-03 复现**：`readEvents` 在 `snapshot.events` 非数组时返回 `[]`（不是 `null`），于是 `messageCount = 0`。

这正是我自己写进铁律 11 的"归因也需证据"——**我看着代码像对的就下了结论**。验证者实际运行了，所以它是对的。

## 四条必修（验证者 §六 给出的，我逐条独立核实过）

### 1. `inject` 补 `remote.commands`
证据：`client.js:1815` 是 `inject: ['slots', 'locale', 'configForms', 'remote']`，缺 `remote.commands`。后果：点击时读 `ctx.remote.commands` 抛错 → 按钮永停 running。
同时要改 `test/client.test.js:161` 的断言（它现在钉死了缺陷）。

### 2. 按 gateway 信封解答案
证据（我从 asar 抽的官方调用方）：
```js
// dsh-client-ui-commands/lib/client.js:1669
const result = await ctx.remote.commands.execute(sessionId, line, attachments);
if (!result.ok) throw new Error(...);
if (result.value === void 0) return { kind: "error", ... };
... result.value.result   // ← {kind, text}
```
所以正确解法是 `answer.ok` / `answer.value.result.text`，处理 `value === undefined` 与 `kind:'error'`。
`test/client.test.js:742-747` 的 fake 返回 `{text}`，要换成真实信封。

### 3. D-05 回退到裸 patchId
证据链（我独立核实的）：
- `dsh-config-editor/lib/index.js:31-34`：`entries()` 取 `parent.tree.ctx.fiber.entry?.id === "include"` 的子项，返回 `entry.options.id`
- 同文件 `:45,50,51,56,61,97,100,105,121,124`：一律用 `row.id === entry.options.id` 与 patch 行匹配
- profile patch 里声明的是 `- id: ui-conversation`（裸）
- `dsh-settings/lib/index.js:432,443`：`ns: entry.options.id` → 裸
- 官方调用方 `CONVERSATION_SETTINGS_NAMESPACE = "ui-conversation"`（裸，`ui-conversation/lib/client.js:16328`）
- `Config.listConfigs` 的 `id: "include:ui-conversation"` 是 inspect provider 拼的**显示 id**，同一条还有 `patchId: "ui-conversation"`

→ 设置命名空间 = **裸 patchId**。改成 `include:` 前缀后设置页永远 unavailable。
需同步回写 `01 §9` / `02 D18` / `06 U7`。

### 4. `readSettings` 把 `status !== 'ready'` 判成 `settingsAvailable: false`
证据：`client.js:1674-1684` 现在是 `if (value === null || typeof value !== 'object') return { settingsAvailable: true, settings: null }` —— 把"不可用"当成"可用但空"，导致降级永不触发、四颗全渲染。

## 另外：B18/B19 要么实现要么正式降级
设置页 19 行仍是 `span`，无 input/onChange/save-settings；`countUnsaved` 有定义无调用。
→ 本轮**不要求实现**（工作量过大），但必须在 `01 §9` 正式把 B18/B19 降级出 P4 范围，并写明理由。不许留在"未做但也不说"的状态。

## D-02 / D-03 的修法
- **D-02**：`save-settings` 不能以 `null` 为 overlay 基线。要么 `setOverlay` 时以 `state.settings()`（含 config）为基线，要么 `resolveSettings` 时让 overlay 只覆盖**显式出现**的字段。推荐后者更简单：`mergeSettings` 前先把 overlay 与 config 合并的正确顺序理清。
- **D-03**：`readEvents` 在 `snapshot.events` 非数组时应返回 `null`（表示"读不到"），而不是 `[]`（表示"0 条"）。

## 验证要求
修完必须实跑并贴输出：
- `node --test "test/*.test.js"`（当前 174）
- `node scripts/check-syntax.mjs`
- `node scripts/build-client.mjs --check`
- `node scripts/mutate.mjs`
- 每条修复配「改坏→红→改回→绿」
- **D-02/D-03 必须有专门测试**：只保存一项时其他项不变；`readSurface` 返回 `{}` 时 `messageCount === null`
