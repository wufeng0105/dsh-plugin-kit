# 09 验证（P3，独立复跑与证伪）

> 验证人：P3（不是实现者）。日期：2026-11-08。
> 对象：`bundle-lab/`（`@local/lab-draft-studio`）+ `01`/`02`/`07`/`08` 的自述。
> 纪律：**本文件不引用实现者的任何输出作为证据**。所有 `文件:行`、命令与 stdout 都是我这一轮自己跑出来的；凡是我复跑结果与自述不一致的地方，以我的输出为准并标注。
> 未做：不改 `bundle-lab/`（全部变异实验在 `%TEMP%\p3-drift-lab` 的副本上做）、不安装、不碰 `$DSH_HOME`。

---

## 0. 一句话结论

**不可放行**。138 条纯逻辑测试全绿是真的、并存前缀是落实的、HTTP 守卫三闸是有的；但**产品路径与测试路径之间有系统性断层**：`lib/writeback.js`（写回决策）与 `lib/run-store.js`（运行状态机）**没被任何产品文件 import**，只出现在 `client.js:74/120/187` 的注释里；`lib/boundary.js` 虽被 `lib/request.js:22` import，但只取了 `isDraftActionable` 一个符号，B21 需要的 `classifyDraft`/`hasCommandChip` 在产品代码 **0 次**；`lib/request.js:132` 的 `seatPlan`（B20 降级）同样 **0 次**。而"138 条全绿"恰好主要覆盖这些模块本身。实现者自报的「已离线证 3 条」里，**有 1 条（B20）被我的探针直接证伪**，另 1 条（B7）在产品里没有调用点。

---

## 1. 独立复跑（我自己的输出）

### 1.1 语法

```powershell
cd bundle-lab
node --check（逐文件，17 个 .js 全量）
```
```text
node v24.22.2
checked 17 file(s), failures=0
```

```powershell
node scripts/check-syntax.mjs
```
```text
ok   client.js (classic script)
ok   index.js (module)
ok   lib/boundary.js (module)
ok   lib/context.js (module)
ok   lib/guard.js (module)
ok   lib/host.js (module)
ok   lib/llm-options.js (module)
ok   lib/prompt.js (module)
ok   lib/request.js (module)
ok   lib/run-store.js (module)
ok   lib/schema.js (module)
ok   lib/sha256.js (module)
ok   lib/settings.js (module)
ok   lib/wire.js (module)
ok   lib/writeback.js (module)
ok   scripts/check-syntax.mjs (module)

16 file(s) checked, 0 failure(s)
exit=0
```

> 注：`check-syntax.mjs` 只报 16 个文件，目录里 `.js` 实有 17 个。差集是 `test/client.test.js` 与 `test/core.test.js`——`scripts/check-syntax.mjs:19` 的 `SKIP = new Set(['node_modules', '.git', 'test'])` **有意跳过测试目录**（测试文件语法错在 `node --test` 时必然暴露），不是缺陷。我另外用 `node --check` 对全部 17 个文件逐个跑过，`failures=0`。

### 1.2 测试

```powershell
node --test test/core.test.js
```
```text
ℹ tests 113
ℹ pass 113
ℹ fail 0
```

```powershell
node --test test/client.test.js
```
```text
ℹ tests 25
ℹ pass 25
ℹ fail 0
```

```powershell
node --test "test/*.test.js"
```
```text
ℹ tests 138
ℹ suites 0
ℹ pass 138
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 367.9987
exit=0
```

### 1.3 用例名逐条比对（核对 08 §1.2 是否真贴了原始输出）

用脚本把 `node --test` 实际输出的 138 个 `✔` 名与 `08-selfcheck.md` §1.2 里贴的 138 个名字做集合差：

```text
实际通过用例数: 138
文档声称用例数: 138
文档有但实际没有 (0):
实际有但文档没写 (0):
```

**结论**：`08` §1.2 的测试输出**是真实的**（不是编的），138 个用例名逐条对得上。这一点给实现者信用。

### 1.4 我复跑得到的额外事实

| 项 | 我的输出 |
|---|---|
| `08` §3 声称的三组「改坏→红」涉及的 7 个用例名 | 全部真实存在（逐条 `实际存在: True`） |
| 四个结构块是否逐字等于 `01` §3-B5 表格 | `general/coding/writing/translate` 全部 `逐字相等: true`（脚本从 `01-requirements.md:151-157` 抽表格对比 `lib/prompt.js`） |
| 四个 `systemSha256` 是否两两不同 | 是（`d221e4df…` / `95e524db…` / `4a86df1f…` / `ba0c5035…`，`new Set(...).size === 4`） |
| 命令注册名 | `lab-draft`（`createHost` 真实路径） |
| `host.entryId` | `"lab-draft-studio"` |

---

## 2. B1–B21 逐条三态

三态定义按 `08` §0 同一口径：**VERIFIED** = 离线可复现二值结论且**产品代码有该路径**；**UNVERIFIABLE** = 判据已就位但必须运行时；**FAIL-GAP** = 与判据不符、被证伪，或产品里根本没有这条路径（"测了但没接上"我一律判 FAIL-GAP，不判 UNVERIFIABLE——因为缺口是代码缺陷，不是环境限制）。

| # | 判据要点 | 三态 | 我的证据 |
|---|---|---|---|
| **B1-a** | 注册 4 条、id 互异、order 0–3 | **VERIFIED**（注册面） | `probe2`：`settings.section#lab-draft-studio@60, conversation.input.right#lab-draft-general@0, …#lab-draft-coding@1, …#lab-draft-writing@2, …#lab-draft-translate@3`；`client.js:402-416` |
| **B1-a（页面面）** | `count===4`、`ids` 相等 | **UNVERIFIABLE** | 需 §4 片段；Client Inspect 第 10 次超时（见 §3.0） |
| **B1-b** | 勾选数决定颗数 | **VERIFIED**（渲染面） | `probe2` E 段：四颗在 settings 正常时全部 `data-state=idle`；`client.js:439-441` |
| **B1-c** | 总开关关 → 0 颗 | **VERIFIED** | `client.js:439-441` + `visibleSeats` 的 `enabled===false` 分支；MUT2 变异该分支 → 2 条测试变红，证明判据有牙 |
| **B1-d** | 草稿空 → 0 颗 | **VERIFIED** | `client.js:437` `if (!isDraftActionable(draft)) return null;`；`probe2` B 段实测空草稿返回 `null` |
| **B1-e** | 几何五字段 | **UNVERIFIABLE** | 纯 DOM 几何；无浏览器控制 |
| **B2** | 纯空白（含 `\u3000`）不反应 | **VERIFIED** | `client.js:437` + `lib/boundary.js:65-67`；`probe2` 实测 `'' / '   ' / '\u3000' / '\n'` 均 `null`；MUT 该分支可红 |
| **B3** | 写回、不发送、`messageCount` 不变 | **FAIL-GAP** | ①按钮点击后**立即回 idle**（`client.js:468-478`：`run.presetId = presetId; … run.presetId = null;` 中间无 IO）；`probe2` B 段实测点完仍是 `data-state=idle`、无 `cancel` 子节点；②`messageCount` 有**空真通道**，见 D-03 |
| **B4** | 回退逐字还原 | **FAIL-GAP** | `run.finished` 全文 **`finished.set` = 0 次**（`probe6` 第 4 段），`onRevert` 首行 `const record = run.finished.get(id); if (record === undefined) return;`（`client.js:483-484`）→ 永远 return，回退按钮从不出现（`revertible` 在 client 中**不存在**） |
| **B5** | 判据 1（请求侧） | **VERIFIED** | 四套结构块逐字相等、sha256 两两不同、marker 与 presetId 一致（`probe4` 第 5 段 + `probe6` 第 9 段） |
| **B5** | 判据 2（输出侧） | **FAIL-GAP** | `scripts/assert-preset.mjs` **不存在**（`08` G-3 自认未写）。这不是"需运行时"，是交付物缺失 |
| **B6** | 取消勾选不丢预设 | **VERIFIED**（隐藏语义）/ **FAIL-GAP**（持久化） | 隐藏语义在 `visibleSeats`；持久化**无写路径**——`index.js:36-42` 的 deps 里**没有 `persist`**（`probe9` 第 5 段），故 `save-settings` 恒返回 `persist-unavailable` |
| **B7** | 改名只改显示 | **FAIL-GAP** | **判据 ② 成立**：`validatePatch({'presets.writing.label':'文案'})` → `ok=true`、`resolveLabel` 返回 `文案`，而 `systemSha256` 前后完全相同（`4a86df1f7dd5…`，逐字相同）——「改名不动 system」这条内核保证是真的（`probe10`）。**但 ①③ 的操作前提不存在**：用户在设置页**无法执行改名**——`client.js` 全文无 `h('input')`/`h('textarea')`/`onChange`/`onBlur`/`contentEditable`，可改行渲染成 `h('span')`（`client.js:289-291`），也没有任何触发 `save-settings` 的调用（`probe10`）。B7 是"操作 → 观察 ①显示 ②请求不变 ③改回复原"，①③ 走不通 → 整条不可判通过。另：client 镜像 `validateLabel` **零调用**（`probe7` D 段），但那是"没有输入就没有校验时机"的下游症状，不是独立缺陷 |
| **B8** | 跟随模式两处一致 + 负向对照 | **FAIL-GAP** | ①`dump-request` **不读 `payload.prepare`**（`probe6` 第 1 段：`prepare:true` 时 `prepared` 仍为 `null`），而 B8 的观察对象正是 `prepared.config`；②负向对照的输出里**不含宿主错误文本**（`probe6` 第 2 段：`reason = provider-error`，`detail` 字段不存在，JSON 里搜不到 `__lab_draft_nonexistent_model__`），B8 要求"错误文本里含该 model 名"→ 证据链断；③`sessionQuery` 契约**无 `modelSelection` 方法**（`cordis_inspect_query host/Service {service:"sessionQuery"}` 方法表 14 个方法，无此项），`lib/host.js:465` 却读 `sessionQuery.modelSelection` → 真实环境里恒 `undefined`，follow 模式必走 `composeLlmOptions` 抛错分支（我按真实契约构造 fake 实测：`reason = settings-unavailable`，`probe3` 第 1 段） |
| **B9** | 固定模式用固定值 | **FAIL-GAP** | 同 B8 ③：装配函数本身正确（`probe3` 第 4 段注入 `sessionSelection` 后 `provider/model/effort` 正确透传），但产品路径取不到会话模型时 pinned 分支之外的降级路径会抛错；且 `dump-request` 的 `prepared.config` 恒 `null`，B9 的第二个观察点不可得 |
| **B10** | 强度回退 | **VERIFIED**（决策面）/ **FAIL-GAP**（`prepared.config` 观察面） | `resolveEffort` 三态正确（`lib/llm-options.js:126-149`，`efforts===undefined` 不谎报 fallback）；但 B10 判定要 `prepared.config.reasoningEffort === defaultEffort`，`dump-request` 给不出 |
| **B11** | 其余置灰、秒表递增、有取消 | **FAIL-GAP** | `createRunStore` / `seatState` / `SEAT_STATES` 在产品代码出现 **0 次**（`probe7` C 段），`client.js` 里连 `createRunStore` 字样都没有；`setInterval`/`requestAnimationFrame`/`useState`/`useEffect`/`useSyncExternalStore` 在 `client.js` 各 **0 次**（`probe6` 第 5 段）→ 没有驱动 `elapsedMs` 递增的时钟；`data-elapsed-ms` 恒 `null`（`probe2` A/B 段实测两次都是 `null`） |
| **B12** | 取消 → idle、草稿不变 | **FAIL-GAP** | 无 `running` 态就没有 `cancel` 子节点（`probe2` B 段 `有没有 running 态的 cancel 子节点: false`）；`onCancel` 只是 `run.presetId = null`（`client.js:479-481`），不涉及草稿 |
| **B13** | 结果绝不覆盖新输入 | **FAIL-GAP** | `decideWriteBack` 在产品代码出现 **1 次**，且这 1 次在 `client.js:120` 的**注释**里（`probe5` 实测 `Select-String` 只命中注释）；`lib/writeback.js` **不被任何产品文件 import**（`probe7` A 段：`被产品代码 import: 否`）；`spanStillValid` / `captureInsertion` 在产品代码 **0 次** |
| **B14** | 切会话/发送的并发宽容 | **FAIL-GAP** | 无请求通道（`client.js:474-477` 自认"S5/S6 work"），`onActivate` 不发任何 command；`client.js` 全文无 `remote` |
| **B15** | 失败态悬停原因、可重试 | **FAIL-GAP** | `REASON_TEXT` 8 个键齐全（这点实现得对），但失败态**无法进入**：`run-store` 未接（见 B11），`data-state` 只可能是 `idle`；`data-hover-text` 在 idle 时回落到 `label`（`client.js:201-203`） |
| **B16** | 回退/重试只作用于自己那次 | **FAIL-GAP** | 同 B4：`finished` 从不写入；`onRetry` 也是 `get` 后 `undefined` 直接 return（`client.js:490-494`） |
| **B17** | 超时四条 | **VERIFIED**（`runRefine` 内部）/ **FAIL-GAP**（验收路径） | `runRefine` 自建计时器 + `timeoutSource` 正确（`lib/host.js:297-303`、`89-95`；`probe5`/`probe3` 实测两种拼写都可读）；但 B17 观察项 1「`command/done` 与该次 `command/run` 成对」需真实通道；观察项 3「按钮 `states[i]==='failed'`」在 client 不可达 |
| **B18** | 19 可改 + #20 只读 + 即时生效 | **FAIL-GAP** | ①设 19 行全是只读 `span`（`client.js:289-291`，`probe8` 第 6 段），无输入控件、无保存按钮 → "19 项逐项可改"不成立；②`#20` 的 `lastResult` **在产品里恒为 `null`**（`lib/host.js` 无写入点；`probe9` 第 3 段 `settings.lastResult = null`），B18 要求"值来自最近一次改写的 readRounds/readChars/reason"→ 回显永远空 |
| **B19** | 编辑门五条 + 未保存计数 | **FAIL-GAP** | `countUnsaved` 语义正确（实测改 2 字段 → `2`），但 `client.js` 里 `countUnsaved` / `unsavedCount` / `data-edit-gate` / `restore-default` **全为 false**（`probe9` 第 4 段）→ ①②④⑤ 零实现，③ 也未接 UI |
| **B20** | 降级一颗按钮、`presetId` 为 null、无结构块 | **FAIL-GAP（被证伪）** | 三处不符：①**四颗都渲染**——`probe2` F 段实测 `settingsAvailable=false` 时渲染 `general,coding,writing,translate`，因为 `client.js:439` 传的是 `{enabled:true, visiblePresets:[presetId]}`，每颗都只看见自己；正确的 `seatPlan` 在 `lib/request.js:132-138` 但 **client 调用 0 次**；②`dump-request` 的 `presetId` 是 `"general"` 而非 `null`（`probe6` 第 7 段）；③`system` **含** `【结构要求 preset=general】`（同段）。这三条是 B20 判据的 ①③④ 直接反例 |
| **B21** | 芯片边界（`/`、`@`） | **FAIL-GAP** | `classifyDraft` / `hasCommandChip` 在产品代码 **0 次**（`probe7` C 段）；`countReferencePlaceholders` 镜像的产品常量已漂移且测试看不见（见 D-02）；`RESTORE`/`restoreDraft` 未实现（`07` S-7 自认） |

### 2.1 三态分布（我的判定）

判定单元取"能被单独判真假的最小观察面"，因此把 B1-a 与 B5 各按**两个方面**拆开（它们的前后两半结论相反，合成一格必然说谎）。这样共 **27 个单元**，逐条对齐、不重不漏：

| 态 | 数量 | 单元 |
|---|---|---|
| **VERIFIED**（离线可证 **且** 产品代码有该路径） | **6** | B1-a（注册面：4 条 id/order 互异）、B1-b、B1-c、B1-d、B2、B5-判据 1 |
| **UNVERIFIABLE**（判据就位，确实只差运行时） | **2** | B1-a（页面面 `count===4`/`ids`）、B1-e（几何） |
| **FAIL-GAP**（不符 / 被证伪 / 产品无路径 / 交付物缺失） | **19** | B3、B4、B5-判据 2（缺 `assert-preset.mjs`）、B6、B7、B8、B9、B10、B11、B12、B13、B14、B15、B16、B17、B18、B19、B20、B21 |
| **合计** | **27** | 6 + 2 + 19 |

**按 `01` §3 的 21 个条目粗算**（B1 不拆、跨态取最差）：**VERIFIED 1（B2）/ UNVERIFIABLE 1（B1）/ FAIL-GAP 19**。

> 口径说明（便于复核）：
> - **B5**：判据 1（结构块逐字、四份 sha256 两两不同、marker 与 presetId 一致）我判 VERIFIED——它是纯请求侧的离线二值结论，`probe4` 第 5 段与 `probe6` 第 9 段都实测通过；判据 2 因 `scripts/assert-preset.mjs` **不存在**判 FAIL-GAP——属交付物缺失，不是环境限制（`01` §4 把它列为"P2 起可用"的 E2 命令）。
> - **B6 / B10 / B17**：内核语义正确、但产品接线断或观察点不可得，按最终能否判通过计 FAIL-GAP 各一次，不在两个态里重复占格。

### 2.2 实现者自报分布是否诚实——逐项核对

| 实现者说法 | 我的核对 | 判定 |
|---|---|---|
| 「已离线证 3 条：B2、B7、B20」 | **B2 成立**（`client.js:437` 有真实调用点，`\u3000` 覆盖）；**B7 只有一半成立**——判据 ② 的"改名不动 `systemSha256`"内核实测成立（`probe10`：前后同为 `4a86df1f7dd5…`），但判据 ①③ 需要用户在设置页改名，而设置页**没有可编辑控件**（`client.js:289-291` 全是 `h('span')`，全文无 `h('input')`/`onChange`），所以这条只能算"内核面已证"，不能算"整条已离线证"；**B20 不成立且被证伪**（四颗按钮、`presetId` 非 null、`system` 含结构块，`probe2` F 段 + `probe6` 第 7 段） | **不诚实：3 条里 1 条（B20）被证伪、1 条（B7）只有部分面成立** |
| 「部分+需运行时 17 条」 | **先看算术**：该行列出的条目我数了一遍是 **20 个**（`B1-a、B1-b、B1-c、B1-d、B3、B4、B5、B6、B8、B9、B10、B11、B12、B13、B14、B15、B16、B17、B18、B21`），表头却写 **17**；加上另外两行的 3 和 1，声称"3 + 17 + 1 = 21 行整"，实际是 3 + 20 + 1 = **24**。而且 3 行里**没有 B7 之外任何遗漏项能凑成 21**——B1-a～d 被拆成 4 条、B1-e 单列后，正确分母应是 25 个判定单元（4 + 1 + 20），不是 21。这条自述**自己的算术就是错的**。<br>再看实质：这 20 条里，B3/B4/B11/B12/B13/B14/B15/B16/B21 **不是"差一次实测"，而是产品代码根本没接**（`probe7` A/C 段：`writeback.js`、`run-store.js` 不被任何产品文件 import；`classifyDraft`/`hasCommandChip`/`seatPlan` 零调用）。把它们标成"需运行时验"会把**未实现的缺陷**伪装成**环境限制** | **不诚实：算术错 + 9 条被错误地归到"需运行时"** |
| 「纯运行时 1 条：B1-e」 | 成立 | 诚实 |
| 「未做 1 子项：B19 编辑门」 | 实际未做的子项远不止编辑门：`assert-preset.mjs`（B5 判据 2）、`persist` 注入（B6/B18）、`#20` 回显写入（B18）、`onActivate` 的命令调用（B3/B11–B16）、`RESTORE`（B21） | **严重低估** |
| 「没有一条是运行时已验」 | 成立 | 诚实 |
| `08` §6「并存策略已落实 8/8 项」 | 见 §3.1，**8 项里 7 项成立、1 项措辞过强**（"功能不共享"成立，但"设置只从本插件 Config 读"在真实路径上因 entryId 形态问题读不到） | **基本诚实，有一处过度声明** |

**结论：分布不诚实，但手法不是编造，而是口径混用。** 三类具体问题：

1. **算术自相矛盾**：声称"3 + 17 + 1 = 21"，而中间那行实列 20 条 → 实为 3 + 20 + 1 = 24；而 B1 拆 a–e 后正确分母是 25。一张表里三个数互相对不上。
2. **口径混用掩盖缺口**：把"模块有测试、但产品没接线"统一归入「已离线证（部分面）/需运行时验」。这条口径把 9 条实质缺陷（B3/B4/B11/B12/B13/B14/B15/B16/B21 至少各有"产品零调用"的证据）写成了环境限制。
3. **一条被证伪**：B20 的三处判据我都有相反实测（`probe2` F 段、`probe6` 第 7 段），它不是"需运行时"，是"现在的实现会判红"。

**真正可以称为"离线已证"的是 6 项**：B1-a 注册面、B1-b、B1-c、B1-d、B2、B5 判据 1。**不是 3 条，也不是 20 条。**

**顺带一条正面评价**：`08` §1.2 贴的 138 个用例名与我实跑的输出**逐条一致（差集为 0）**，§3 声称的三组变异涉及的 7 个用例名也全部真实存在。**测试输出没有造假**；问题出在"测试全绿"到"验收结论"之间的那一步推论。

---

## 3. 专项核查四处

### 3.0 前置：Client Inspect（如实记录）

```text
cordis_inspect_query(client, Slots, listSubTree, {root:"conversation.input.right"})
→ Error: Slots.listSubTree: Client inspect query Slots.listSubTree timed out after 10000ms.
  Open or reconnect the Harness page, then retry.
```

这是**累计第 10 次**零成功（`06` 记 9 次）。按任务要求如实记录：**所有页面事实（B1-e 几何、`count`/`ids`、`editorPhase`、`command/run` 计数）本轮仍无法运行时取证**，这一条不影响我对代码缺陷的判定（缺陷是静态可证的），但意味着即使修好代码，B1-e 仍需一次真机走查。

### 3.1 并存策略是否真的落实

| 检查项 | 要求 | 实测 | 结论 |
|---|---|---|---|
| 包名 | 带 `lab-` | `package.json:2` `"@local/lab-draft-studio"` | ✅ |
| `meta.title` | 可辨识 | `locale/zh.json` `"草稿工坊（实验）"`、`en.json` `"Draft Studio (lab)"` | ✅ |
| 座位 id | 带前缀、4 条互异 | `client.js:52` `ENTRY_PREFIX='lab-draft-'`，实测注册 4 条 `lab-draft-{general,coding,writing,translate}` | ✅ |
| 设置页 id | 带前缀 | `client.js:54` `SETTINGS_ID='lab-draft-studio'`，实测 `settings.section#lab-draft-studio@60` | ✅ |
| Loader patch id | 不撞前代 | `cordis.patch.yml` `id: lab-draft-studio` | ✅ |
| `data-draft-studio-*` 保留原样 | **不能加前缀** | `client.js:253` `'data-draft-studio-seat': SEAT`，其余 `data-preset-id`/`data-order`/`data-state`/`data-reason-code`/`data-elapsed-ms`/`data-hover-text`/`data-action` 全部未加前缀 | ✅ **正确**——判据未失效 |
| 有没有误改在装产品 | 零改动 | 本轮无安装/卸载；我另外核对了 `probe-tools/dump/` 里前代的副本，只读 | ✅ |
| 功能不共享 | 不读前代设置 | `client.js:151-163` `resolveForm` 只从自己发布的 `__DSH_LAB_DRAFT_STUDIO__` 取 entryId，无跨插件读 | ✅ |

**但有一处必须指出（D-05）**：`host.entryId` 实测是 `"lab-draft-studio"`（patchId），而 `01` §9 / `02` D18 / `06` U7 三处都写死预期为 **`include:lab-draft-studio`**；`client.js:158` 直接把它喂给 `ctx.configForms.get(entryId)`。宿主 `Config.listConfigs` 的目录 id 一律是 `include:<patchId>`（我实测 `{name:"@deepseek-ai/dsh-client-ui-settings"}` → `"id": "include:ui-settings"`）。**两者形态不一致 → 设置页在真实环境里大概率 `forms.get()` 拿不到表单 → 走 `settingsAvailable=false` → 而 B20 降级又是错的（四颗按钮）**。这是一条独立的、可复现的接缝缺陷。

### 3.2 `client.js` 的「镜像函数」——比对能否发现漂移

**结论：能发现"函数体"漂移，发现不了"常量"漂移和"函数外的行为"漂移。做了 9 组变异实证（全部在 `%TEMP%\p3-drift-lab` 副本上）。**

| # | 变异 | 结果 | 说明 |
|---|---|---|---|
| MUT1 | client `writeBackVerdict` 的 `'retry-pending'` → `'write'` | **红**（1 条） | 函数体漂移会被抓 |
| MUT2 | client `visibleSeats` 忽略总开关 | **红**（2 条） | 同上 |
| MUT3 | 在**镜像函数之外**加一行 `if (settingsAvailable === false && presetId !== 'general') return null;`（即修好 B20） | **全绿 138/138** | **函数外行为无任何测试覆盖** |
| MUT4 | 内核 `lib/settings.js` 的 `> 12` 改成 `>= 12` | **红**（2 条） | 内核漂移会连带红 client 镜像测试 |
| MUT5 | client 顶部 `LABEL_MAX_CODE_POINTS = 12` → `15` | **全绿 138/138** | **常量漂移无人管** |
| MUT6 | client `REFERENCE_PLACEHOLDER_RE` 去掉 `\uFFFC` | **全绿 138/138** | **同上，且直接影响 B21** |
| MUT7 | client `PRESET_IDS` 顺序调换 | 红（1 条，但红在 `apply registers four seats…` 断言 order，不是镜像测试） | 偶然被抓 |
| MUT8 | client `BUILTIN_LABELS.writing` `'写作'` → `'文案'` | **全绿 138/138** | **B7 的显示名常量漂移无人管** |
| MUT9 | 对照：`validateLabel` 函数体漂移 | 红（1 条） | 证明测试本身有牙 |

**根因（`probe8` 实测）**：`test/client.test.js:149-175` 的 `extract()` 用 `new Function('REFERENCE_PLACEHOLDER_RE','PRESET_IDS','LABEL_MAX_CODE_POINTS','BUILTIN_LABELS','codePointLength','countReferencePlaceholders', body)` 重建镜像函数，**这些闭包常量全部由测试自己传进去**（`/[\uE100-\uE11D\uFFFC]/`、`12`、`PRESET_IDS`、`BUILTIN_LABELS`……），**从不读取 `client.js` 顶部的同名常量**。所以：

- 漂移检查只覆盖「函数体文本」，不覆盖「函数依赖的常量」；
- `writeBackVerdict` 内部调用的 `countReferencePlaceholders` 在测试里被替换成 `lib/boundary.js` 的版本，而产品里真实生效的是 `client.js:92` 那一份（用 client 自己的正则）——**这一层差异被闭包遮蔽，永远测不出来**；
- 反过来 MUT4 会红，是因为内核变了、镜像没变 → 说明这套机制只能防"一边动一边不动"，防不了"两边一起错"。

实现者 `08` §7 第 2 条说「漂移会红」——**对函数体成立，对常量不成立**，这个说法需要限定。

### 3.3 降级 A 的 HTTP 路由守卫

**结论：三闸都在，`mountRoute` 的拒绝注册是真的，`06` 实测的那个洞确实被堵住了；但这条通道在产品里根本没被调用过（`mountRoute` 在产品代码出现 2 次，全在 `lib/host.js` 内部定义与注释，`index.js` 从不调用），所以它是"备而未用"的代码。**

我实跑的 `mountRoute` 行为（`probe5` E 段）：

```text
token 空       -> {"mounted":false,"reason":"token-missing"}
origin 空      -> {"mounted":false,"reason":"origin-missing"}
webServer 缺   -> {"mounted":false,"reason":"webserver-unavailable"}
token+origin 齐 -> {"mounted":true,"reason":"ok","path":"/lab-draft/refine","kind":"exact"}
无 token 的 POST -> 403 | body = null
带 token 的 POST -> 200 | body = {"ok":true,"rawInputLen":46}
```

三闸核对（`lib/guard.js:97-132`）：

| 闸 | 实现 | 判定 |
|---|---|---|
| ① 方法 + 路径 | 先比 `path !== expectedPath` → 404，再比 `method !== 'POST'` → 405（`:101-106`） | ✅ 在 |
| ② `Sec-Fetch-Site` + `Origin` | `site !== null && site !== 'same-origin'` → 403（`:112-114`）；`origin !== null && origin !== input.origin` → 403（`:115-120`） | ⚠️ **半开**：两个头**缺失时都放行**（`site === null` 和 `origin === null` 都落到下一闸）。`06` §4 实测的攻击形态正是"本地脚本裸 HTTP、两个头都不发"——此时只剩 token 一闸 |
| ③ 每进程 token | `token !== input.token` → 403；未武装 → 503（`:122-129`） | ✅ 在，且 fail-closed |

**这条闸的真实强度**：`06` 的实测是"无凭证 200"。现在无凭证 → 403，**洞堵住了**。但 `guard.js:112` 的注释自己写着 "A local process speaking raw HTTP usually carries neither"，而代码对"neither"是**放行**——真正的防线只剩 token。token 由 `generateToken()`（UUID）生成，`host.js` 通过 `webserver/index-inject` 下发到页面全局，本地进程读不到页面内存 → **实际上 token 这一闸是够的**。所以：**不构成 BLOCKER，但注释与代码的语义相反，属 MINOR**（见 D-08）。

另确认：`index.js` 从不调用 `mountRoute`，`deps` 里没有 `persist`、没有 `webServer`（`probe9` 第 5 段）→ 降级 A 是死代码，B20 的"降级"与它无关。

### 3.4 R4 类问题：外层 `catch` 兜住导致判据失效

我枚举了产品代码（不含 test）的全部 19 处 `catch`，逐处判断"是否让某个验收判据失效"：

| 位置 | 形态 | 是否 R4 | 说明 |
|---|---|---|---|
| `lib/host.js:279-281` | `try { sessionSelection = await readSessionSelection(...) } catch { sessionSelection = null; }` | **是（MARJOR）** | 会话模型读不到时静默变 `null`，随后 `composeLlmOptions` 抛错、被 `:284-295` 的 catch 转成 `settings-unavailable`。**结果是"读不到会话模型"被报成"设置不可用"**——我实测：`session 正常、只是 modelSelection 缺失` → `reason = settings-unavailable`（`probe3` 第 1 段）。B15 的 `reasonCodes` 判定会因此指向错误原因 |
| `lib/host.js:284-295` | `try { composed = composeLlmOptions(...) } catch { return ... settingsUnavailable }` | **是（MINOR）** | 吞掉了原始错误信息，`buildResult` 也没有 `detail` 字段 → B8 负向对照失去证据 |
| `lib/host.js:429-439` | 最外层 `catch (error)` | **是（MARJOR）** | `isAbort = timedOut \|\| error?.name === 'AbortError'`，其余一律 `provider-error`。**所有真实错误（宿主拒绝无效 model、无效 effort）都在这里被压成 `provider-error`**，`detail` 不写入结果（我实测结果 keys 里没有 `detail`）→ B8/B9/B10 的负向对照全部无法从输出取证 |
| `lib/host.js:456-458` | `readEvents` 的 `catch { return null }` | 否（合理） | 读不到 surface → `null`，装配层会记 `read-failed` |
| `lib/host.js:589-591` | `resolveModelInfo` 的 `catch { return undefined }` | 否（合理） | 缺元数据不是错误 |
| `lib/host.js:752-756` | 路由 body `JSON.parse` 失败 → 400 | 否 | 正确 |
| `lib/host.js:762-766` | 路由 handler 的 catch → 500 空体 | 否 | 正确（不回细节） |
| `lib/schema.js:108-110` | `loadSchemastery` 的 catch → `null` | 否 | 设计如此（U5 降级） |
| `lib/schema.js:127-129` | `unwrapField` 的 catch → `undefined` | 否 | 防御性 |
| `client.js:159-162` | `configForms.get()` 的 catch → `null` | 否 | 正确 |
| `client.js:178-180` | `readSettings` 的 catch → `settingsAvailable:false` | **是（MINOR）** | 把"读设置抛错"和"设置服务不可用"合成一态；配合 D-05 的 entryId 形态问题，这条会把"我读错了 entryId"伪装成"用户设置不可用" |

**核心 R4 结论**：`lib/host.js:429` 这个最外层 catch 就是典型形态——**B8/B9/B10 的负向对照要求"宿主以错误拒绝、错误文本含该值"，而这个 catch 把错误文本丢掉了**。`07` §2 说 `runRefine` 的失败分类是"真实现"，分类本身是实现了，但**取证所需的错误文本没被保留**，导致判据在输出层空转。

另有一条**结构性 R4**（比 catch 更严重）：`dispatch('refine')` 在设置不可用时返回 `{ok:false, reason:'settings-unavailable'}`，而 `handle()` 用 `result?.ok !== false` 决定 `kind`。**没有一条路径会让 `dispatch` 抛错到能在 `handle` 外层 catch 里被看见**——所以 `handle` 的 catch（`:640-646`）实际上是死代码，它写的 `detail` 永远不会出现在 B8 的负向对照里。

---

## 4. 抽查代码（指定六项）

| # | 抽查对象 | 结论 | 证据 |
|---|---|---|---|
| 1 | 预设 → `system` 段映射 | **通过** | `lib/prompt.js:136-150` 的 `buildSystemPrompt` 不接收 label（结构上保证 B7）；四套结构块逐字等于 `01` §3-B5；`readPresetMarker` 正则 `^【结构要求 preset=([a-z]+)】$` 与 `01` 一致（`probe4` 第 5 段全 `true`） |
| 2 | 上下文裁剪 | **FAIL-GAP（MARJOR）** | `lib/context.js:46-61` 的 `flattenEvent` 假设事件形如 `{role, content}`，而宿主契约 `SessionSurfaceSnapshot.events: SurfaceEvent[]` 的形状是 `{type, seq, time, data}`，`role` 在 `data` 里面。**按真实契约构造 3 条事件实测：`flattenEvent` 全部返回 `null` → `assembleContext` 返回 `{rounds:0, reason:'empty'}`**（`probe4` 第 1 段）。对照：扁平形状输入才得到 `rounds:2`。→ 读上下文开关"开着"时实际永远读到空，且回显会显示"empty（没读的原因）"，看起来像正常业务状态 |
| 3 | 写回守卫（`draftRev`） | **FAIL-GAP（BLOCKER 级）** | `lib/writeback.js` 的 `decideWriteBack`/`spanStillValid` 实现正确（`revChanged` + `textChanged` + span 覆盖区比对，`:102-137`、`:169-186`），**但整个模块不被任何产品文件 import**（`probe7` A 段），`client.js` 只有注释提到 `decideWriteBack`；`insertText` 在 client 出现 1 次、**也在注释里**（`probe6` 第 6 段）。→ B13「结果绝不覆盖新输入」这条**第一红线在产品里没有任何代码承载** |
| 4 | 请求体校验 | **通过（有 1 处不一致）** | `lib/request.js:41-82` 校验 draft 类型/空/超长、`sessionId` 形态、presetId 回落（soft error 不阻断）；`dispatch` 在 `refine` 分支调用它（`lib/host.js:485-492`）。**不一致**：`ACTIONS` 常量列了 `revert` 但 `dispatch` 无此分支，`dispatch` 支持 `dump-request` 但 `ACTIONS` 未列（`probe4` 第 4 段）——`ACTIONS` 是死常量，无人引用 |
| 5 | 设置读写校验 | **内核通过 / 产品接线断** | `validatePatch` all-or-nothing 正确（`:195-255`，负例：改 2 个字段不会因一个坏字段丢掉好的）；`validateLabel` 12 码位正确（含 emoji 计数）；`countUnsaved` 语义正确（实测 2）。**但**：①`save-settings` 在产品里恒失败（`index.js` 不注入 `persist`，`probe9` 第 5 段）；②`save-settings` 成功后 `setOverlay(mergeSettings(overlay(), patch))` 会**覆盖未被 patch 的手改配置**——实测 `temperature: 0.3` 在一次只改 `timeoutMs` 的保存后变成 `null`（`probe5` B 段）。这是**数据丢失级缺陷**（用户手改的 `cordis.patch.yml` 被静默重置） |
| 6 | 命令参数编解码 `/lab-draft <base64url(JSON)>` | **通过（可用性有问题）** | `lib/wire.js` 手工 base64url 无 padding，往返正确；8000 字符草稿编成 32078 字符 line，`decodeLine` 正常解出（`probe5` D 段）；空体 / 非 base64url / 非 UTF-8 / 非 JSON 各有独立错误码。**问题**：`01` §4 的 E2 命令清单写的是 `/draft-studio dump-settings` 形态，实测 `decodeLine` 对这些字面量返回 `unknown-command` / `not-base64url`（`probe9` 第 1 段）——**验收文档里写的命令一条都跑不通，操作者必须自己手算 base64**。`07` D-2 已自认前缀变更，但 `01` §4 未回写，`08` G-7 只把它记为"需重述" |

---

## 5. 缺陷清单

### BLOCKER（3 条）

**D-01｜`lib/writeback.js` 与 `lib/run-store.js` 未进入产品 import 链（B13 第一红线无代码承载）**
- 证据：`probe7` A 段 → `lib/writeback.js 被产品代码 import: 否`、`lib/run-store.js 被产品代码 import: 否`；`probe7` C 段 → `createRunStore` 0 次、`decideWriteBack` 1 次（该 1 次是 `client.js:120` 注释）、`spanStillValid` 0 次、`decideRevert` 0 次。
- 后果：B3/B4/B11/B12/B13/B14/B15/B16 全部无实现；`data-state` 永远是 `idle`，`data-elapsed-ms` 永远 `null`。
- `probe2` B 段实测：点击"编程"后立刻 `data-state=idle`、无 `cancel` 子节点，因为 `client.js:468-478` 在 `run.presetId = presetId` 之后紧接着 `run.presetId = null`，中间无任何 IO。

**D-02｜`save-settings` 会把未提交的手改配置静默重置为默认值**
- 证据：`probe5` B 段。输入 config `timeoutMs=90000, temperature=0.3`；只提交 `{timeoutMs:60000}`；保存后 `temperature` 变成 `null`。
- 根因：`lib/host.js:545` `state.setOverlay(mergeSettings(state.overlay(), payload.patch))`——overlay 从 `null` 起步，`mergeSettings(null→cloneSettings(defaults), patch)` 得到的是"默认值 + patch"，把 config 里的用户值覆盖掉；而 `resolveSettings` 是 `clampSettings(mergeSettings(readConfig(config), overlay))`，overlay 一旦非空就整体盖住 config 的同名字段。
- 后果：B18「改完即时生效」一旦接通写路径，用户首次保存任何一项就会丢掉其他所有手改项。属数据丢失。

**D-03｜`dump-draft` 的 `messageCount` 存在空真通道（B3 判据可假通过）**
- 证据：`probe1` 第 2 段。`readSurface` 返回 `{}`（契约漂移/无 `events` 字段）时，`lib/host.js:455` `Array.isArray(snapshot?.events) ? snapshot.events : []` 返回 `[]`，`dispatch` 里 `if (Array.isArray(events)) messageCount = events.length` → **`messageCount: 0`**，不是 `null`。
- 后果：B3 的判据是"写回前后 `messageCount` 相等"。前后都读成 `0` 时判据**通过**，而实际上一条消息都没数。`01` §4.1 明确要求"`readSurface` 抛错 → `messageCount: null` → B3 记「无法判定」，不得跳过"——现在只有**抛错**才 `null`，**返回畸形**却给 `0`。这正是 `01` 反复强调的"空真"形态。

### MAJOR（6 条）

**D-04｜B20 降级实现与判据三处相反**
- 证据：`probe2` F 段 → `settingsAvailable=false` 时四颗全渲染（`general,coding,writing,translate`）；`probe6` 第 7 段 → `presetId="general"`（要求 `null`）、`system` 含 `【结构要求 preset=general】`（要求不含）。
- 根因：`client.js:439` 用 `visibleSeats({enabled:true, visiblePresets:[presetId]})` 代替 `seatPlan`；正确的 `seatPlan`（`lib/request.js:132-138`）在 client 里**调用 0 次**（`probe7` D 段）。
- 后果：B20 判 FAIL-GAP；且用户设置服务异常时会同时看到四颗按钮，其中三颗点了也没有 presetId。

**D-05｜Config entryId 形态与宿主目录不一致**
- 证据：`probe5` A 段 `host.entryId = "lab-draft-studio"`（来自 `ctx.fiber.entry.options.id`，即 patchId）；宿主目录实测 `{"id":"include:ui-settings","patchId":"ui-settings"}`（`cordis_inspect_query host/Config`）。`client.js:158` 把它直接喂 `ctx.configForms.get(entryId)`。
- 参照：`01` §9、`02` D18、`06` U7 三处都预期 `include:lab-draft-studio`。
- 后果：设置页大概率永远 `settingsAvailable=false`，于是叠加 D-04 → 四颗按钮 + 设置页横幅。这条**未经运行时验证**（我无法装），但静态上两边形态明确不一致，属高置信度缺陷。

**D-06｜`sessionQuery.modelSelection` 不是宿主契约里的方法**
- 证据：`cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})` 返回 14 个方法（`observeSession`/`searchSessions`/`searchEvents`/`listSessions`/`readSession`/`filterSessions`/`readTitle`/`readTitleSnapshot`/`readTitleSnapshots`/`listEvents`/`filterEvents`/`readSurface`/`traceSession`/`traceEvent`/`readEvent`），**无 `modelSelection`**。`lib/host.js:465` 读的正是 `sessionQuery.modelSelection`。
- 正确来源：`observeSession(sessionId).projections`（`ProjectionSnapshot.values.modelSelection`）或 `sessionController.projections`。`probes.md` P19/`02` D5 记录的是**客户端** `session.projections.faceOf("modelSelection")`，宿主侧没有对应方法——实现者把客户端事实直接搬到了宿主。
- 后果：`probe3` 第 1 段实测（按真实契约构造 fake）→ follow 模式 `reason = settings-unavailable`，B8/B9 的默认路径不可用。

**D-07｜B8/B9/B10 的负向对照证据链断裂（`catch` 吞掉错误文本）**
- 证据：`probe6` 第 2 段。宿主 `prepareCall` 抛 `Model '__lab_draft_nonexistent_model__' is not routable`，`runRefine` 结果为 `reason: provider-error`，结果 JSON **不含** `detail`，搜不到那个 model 名。
- 根因：`lib/host.js:429-439` 的最外层 catch 只做分类，`buildResult`（`lib/wire.js:161-177`）没有 `detail` 字段位。
- 后果：B8 要求"错误文本里含该 model 名"、B9/B10 同理 → 三条的负向对照都无法从输出取证；实现者的 `--negative=model/effort`（`lib/host.js:220-221`）只改了 `options` 里的字段，没有让宿主真的拒绝并回传文本（`dump-request` 根本不调 `prepareCall`）。

**D-08｜`guard.js` 对"两个 fetch 元数据头都缺失"放行，与注释语义相反**
- 证据：`lib/guard.js:112` `if (site !== null && site !== SAME_ORIGIN)`、`:117` `if (origin !== null && origin !== input.origin)`——`null` 时都跳过；`probe1` 第 3 段实测「只有 token、无 `Sec-Fetch-Site`、无 `Origin`」→ `{"allowed":true,"status":200}`。
- 同文件 `:21-22` 注释写的是 "A local process speaking raw HTTP usually carries neither"——**注释把"没有"当作拒绝理由，代码把"没有"当作放行**。
- 后果：`06` §4 的攻击形态正是裸 HTTP，此时只剩 token 一闸。token 是 UUID 且不下发给本地进程，**实际强度够**，所以不是 BLOCKER；但"三闸独立"的说法不成立，且后来者若把 token 改成可推导值就会开洞。

**D-09｜`scripts/assert-preset.mjs` 缺失（B5 判据 2 无工具）**
- 证据：`bundle-lab/scripts/` 下只有 `check-syntax.mjs`（`Get-ChildItem` 实测）。`01` §4 把它列为"P2 起可用"的 E2 命令，`08` G-3 自认未写。
- 后果：B5 判据 2（四套输出结构谓词）无法执行 → B5 只能判到判据 1。

### MINOR（7 条）

**D-10｜镜像一致性测试的常量盲区（MUT5/MUT6/MUT8 全绿）**
- 证据：§3.2 的变异表。`test/client.test.js:149-175` 的 `extract()` 由测试自己提供 `REFERENCE_PLACEHOLDER_RE` / `LABEL_MAX_CODE_POINTS` / `PRESET_IDS` / `BUILTIN_LABELS` / `countReferencePlaceholders`，不读 `client.js` 顶部常量。
- 后果：`client.js:71-73` 的四个常量任意漂移都不报红。`08` §7 第 2 条「漂移会红」需限定为"函数体漂移"。

**D-11｜`08` §6「并存策略已落实 8/8」中「设置只从本插件 Config 读」在当前形态下不成立**
- 证据：D-05。设置页确实不读前代，但也读不到自己的（entryId 形态不符）。

**D-12｜`01` §4 的 E2 命令清单与实际命令形态不符**
- 证据：`probe9` 第 1 段。`/draft-studio dump-settings` → `unknown-command`；`/lab-draft dump-settings` → `not-base64url`。唯一能跑的是手算 base64url。
- 后果：验收文档里的命令一条都不能原样复跑，违反 `01` §4「别人可原样重跑」。`08` G-7 只记了"需重述"，未回写 `01`。

**D-13｜`lib/request.js` 的 `ACTIONS` 与实际 dispatch 不一致（死常量）**
- 证据：`probe4` 第 4 段。`ACTIONS = ['refine','revert','dump-settings','save-settings','dump-draft']`；`dispatch` 无 `revert` 分支，却有 `dump-request`；`ACTIONS` 在产品/测试里均无引用。

**D-14｜`lib/host.js:320` 有个笔误 `timeSource: timeout.source`**
- 证据：`lib/host.js:315-324`（`llm === null` 分支）里同时写了 `timeSource: timeout.source` 和 `timeoutSource: timeout.source`，前者是拼错的键名。
- 影响：`buildResult`（`lib/wire.js:161-177`）不读 `timeSource`，该键被丢弃，**运行时不产生可观察后果**；但它是同一处同一含义被写了两次的迹象，属可读性缺陷。

**D-15｜`#20 lastResult` 在产品里恒 `null`，回显永远空**
- 证据：`probe9` 第 3 段 `settings.lastResult = null`；`lib/host.js` 无 `lastResult =` 写入点；`lib/context.js:189-198` 的 `readout()` 算出来了但 `runRefine` 只把它塞进结果 JSON 的 `readout`，没有落到 `settings.lastResult`。
- 后果：B18 的 #20 观察项永远显示"还没有改写记录"。

**D-16｜`runRefine` 的 `readout` 只进结果 JSON，不回写 `settings.lastResult`（与 D-15 同源，单列以便修复时对齐）**
- 证据：`lib/host.js:425` 把 `readout` 放进 `buildResult(...)`，但没有任何一条路径把它写回 settings（`lib/settings.js:379` `cloneSettings` 只是 `lastResult: base.lastResult ?? null` 透传）。
- 影响：见 D-15。单列是因为修 D-15 时需要同时决定"回显由谁写"（Host 半写 Config？还是 client 从最近一次 `refine` 的结果里取？）——`protocol` 上两者都可，但要一次选定，否则会重演 D-02 那类 overlay 覆盖问题。

---

## 6. 放行意见

**不可进 P4。** 理由不是"缺运行时验证"（那本就可以留到 P4），而是**交付物里有 3 条 BLOCKER 是代码缺陷、静态可证、且都在本轮的"已离线证"范围之外**：

1. 第一红线（B13 结果不覆盖新输入）在产品里**没有一行代码承载**；
2. 保存设置会**静默丢掉用户其他手改项**；
3. B3 的 `messageCount` 判据**可以空真通过**。

### 进 P4 前必须先做（按顺序）

**第 0 步（会改变后续全部判断，先做）**：把 `writeback.js` / `run-store.js` / `boundary.js` 接进 `client.js` 的座位组件（classic script 不能 import，所以是**把产品逻辑搬进 client**，或者把 client 改成 `dsh.client` 支持的可 import 形态——这是架构选择，需负责人裁定）。接完后 `probe2` 的 B 段必须看到 `data-state=running` + `data-action="cancel"`，否则不算做完。

**第 1 步（3 条 BLOCKER）**：
- D-01：同上；
- D-02：`save-settings` 的 overlay 基线要从 `readConfig(config)` 起，不是从 `defaultSettings()` 起；补一条测试："只 patch `timeoutMs` 时 `temperature` 保持原值"；
- D-03：`readEvents` 区分"抛错"与"快照畸形"，后者返回 `null`；`dispatch` 只在 `Array.isArray(events)` 且 `snapshot.events` 确实存在时才给 `messageCount`，否则 `null`；补一条负例测试（`readSurface` 返回 `{}` → `messageCount === null`）。

**第 2 步（进 P4 的必要条件，3 条 MAJOR）**：
- D-04：`client.js:439` 改用 `seatPlan`；降级时只渲染 `general`；
- D-05：确认 `configForms.get()` 到底要 `patchId` 还是 `include:<patchId>`（`06` U7 记的是后者），改 `readEntryId` 或加一次 `describe()` 按 name 兜底；
- D-06：`readSessionSelection` 改走 `observeSession(...).projections` 或 `sessionController.projections`，删掉 `sessionQuery.modelSelection`。

**第 3 步（补齐"操作者能执行"的部分）**：
- D-09：写 `scripts/assert-preset.mjs`；
- D-12：把 `01` §4 的命令清单回写成 `/lab-draft <base64url>`，或给 `decodeLine` 加一个给人用的短形态（`/lab-draft dump-settings`）；
- D-07：`buildResult` 加 `detail`（仅失败时），让 B8/B9/B10 的负向对照能取到宿主错误文本。

### 条件（具体到用户行为）

- **用户不得安装本轮产物**。B3 写回、B13 覆盖保护、B4 回退在产品里都不存在；装上去会得到一个"点了没反应、也不报错"的按钮，并在保存设置时丢掉手改配置。
- **在 D-02 修好前，用户不得通过设置页保存任何一项**——会丢失 `cordis.patch.yml` 里其他手改项。
- **在 D-01 修好前，不得安排任何人做 B3/B4/B11–B16 的现场走查**——走查必然全红，浪费一次 P4 窗口。
- **B1-e 仍必须在真机走查一次**（Client Inspect 累计 10 次超时），这一条不影响放行判定，但 P4 签收时必须写明"activity 展开态未验"。

### 可以带进 P4 的部分（这些是真实的）

- 并存前缀 8 项里的 7 项（包名/标题/座位 id/设置页 id/patch id/不改前代/`data-draft-studio-*` 保持不变）；
- B5 判据 1（结构块逐字、sha256 两两不同、marker 一致）；
- B1-a～d 的注册与渲染面（4 条 / 勾选数 / 总开关 / 空草稿）；
- B2（`\u3000` 覆盖）；
- 命令编解码往返（8000 字符 → 32078 字符 line 无截断）；
- HTTP 守卫的 token 闸与"缺 token/origin 拒绝注册"。

---

## 7. 是否同意实现者的三处「最易误解」

`08` §7 列了三处。我的意见：**第 1 处同意、第 2 处部分不同意、第 3 处同意但需补一句。**

**第 1 处：「138 条全绿 ≠ B1–B21 通过」——同意，但实现者的措辞还不够重。**
`08` 说"绿的是逻辑内核与注册结构，页面几何、`prepared.config`、`command/run` 计数、真实写回与撤销都还没发生"。这个描述回避了一件事：**有些模块不只没进页面，是根本没进产品代码**。`writeback.js`、`run-store.js` 不被任何产品文件 import，`classifyDraft`/`hasCommandChip`/`seatPlan` 零调用。所以不是"等一次走查"，是"还要写代码"。建议改成："138 条绿的是**库**，不是**产品**；B3/B4/B11–B16/B21 连产品路径都还没有。"

**第 2 处：「镜像函数漂移会红」——部分不同意。**
函数体漂移确实会红（MUT1/MUT2/MUT4/MUT9 实证）。但 `extract()` 由测试**自己提供闭包常量**，所以 `client.js:71-73` 那四个常量（`REFERENCE_PLACEHOLDER_RE` / `LABEL_MAX_CODE_POINTS` / `PRESET_IDS` / `BUILTIN_LABELS`）漂移时全绿（MUT5/MUT6/MUT8）。而且写回决策**在函数体外**的接线（`finished.set` 从不调用、`decideWriteBack` 只出现在注释里）也没有任何测试覆盖（MUT3 实证：在镜像函数外加一行正确修复，138 条依然全绿）。所以准确说法是：**"镜像函数体防漂移有效；镜像函数外的行为与常量不设防。"**

**第 3 处：「降级 A 的路由是故意不挂载的，三闸必须保留」——同意，但要补一句。**
`mountRoute` 的 `token-missing`/`origin-missing` 拒绝我实跑确认了（`probe5` E 段）；三闸的 token 闸确实 fail-closed。但 `guard.js:112/117` 对**缺失** `Sec-Fetch-Site`/`Origin` 是**放行**的，与同文件 `:21-22` 的注释相反。所以"三闸"实际上是"一闸硬（token）+ 两闸软（浏览器场景才生效）"，`06` §4 的裸 HTTP 攻击形态只被 token 挡住。这条不构成放行障碍（token 是每进程 UUID、不下发给本地进程），但**不能对外宣称"三闸独立"**。

---

## 8. 附：本轮我跑过的所有命令

```powershell
# 独立复跑
cd bundle-lab
node scripts/check-syntax.mjs                         # 16 files, 0 failure
Get-ChildItem -Recurse -File -Filter *.js | % { node --check $_.FullName }   # 17 files, 0 failure
node --test test/core.test.js                         # 113/113
node --test test/client.test.js                       # 25/25
node --test "test/*.test.js"                          # 138/138

# 镜像漂移变异（副本 %TEMP%\p3-drift-lab，不动 bundle-lab）
pwsh -File %TEMP%\p3-probes\drift-mutations.ps1       # MUT1–MUT4
pwsh -File %TEMP%\p3-probes\drift2.ps1                # MUT5–MUT9

# 行为探针（只 import bundle-lab 的公开导出）
node %TEMP%\p3-probes\probe1.mjs   # B20 / messageCount 空真 / guard / clampBudget
node %TEMP%\p3-probes\probe2.mjs   # client 运行时：注册、四颗、降级、镜像调用点
node %TEMP%\p3-probes\probe3.mjs   # 按宿主真实 sessionQuery 契约跑 runRefine/dump-request
node %TEMP%\p3-probes\probe4.mjs   # SurfaceEvent 真实形状 / overlay 覆盖 / 结构块逐字
node %TEMP%\p3-probes\probe5.mjs   # createHost / save-settings / mountRoute / 编解码
node %TEMP%\p3-probes\probe6.mjs   # 逐条判据的产品落点（B8/B9/B18/B4/B16/B11/B13/B20/B21）
node %TEMP%\p3-probes\probe7.mjs   # 产品闭包 vs 测试闭包：import 链与符号出现次数
node %TEMP%\p3-probes\probe8.mjs   # 镜像测试 extract() 的常量来源与盲区
node %TEMP%\p3-probes\probe9.mjs   # 命令字面量 / #20 回显 / B19 编辑门 / deps 注入
pwsh -File %TEMP%\p3-probes\name-parity.ps1           # 138 用例名与 08 §1.2 逐条比对

# 宿主契约（只读）
cordis_inspect_query(host, Service, listService, {service:"sessionQuery"})
cordis_inspect_query(host, Service, listService, {service:"sessionController"})
cordis_inspect_query(host, Config, listConfigs, {name:"@deepseek-ai/dsh-client-ui-settings"})
cordis_inspect_query(client, Slots, listSubTree, {root:"conversation.input.right"})   # 超时 10s
```

**未做**：未安装、未写 `$DSH_HOME`、未修改 `bundle-lab/` 任何文件（所有变异在 `%TEMP%` 副本）。
