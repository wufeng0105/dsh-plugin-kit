# 14 终验（P3.5 → P4 门禁，修复轮 v2 后）

> 终验者：本轮（不是修复者、不是复验者）。日期：2026-11-08。
> 对象：`bundle-lab/`（`@local/lab-draft-studio`）+ `13-fix-report-v2.md` + 三处文档回写。
> 纪律：**本文件不引用 `13` 的结论作为证据**。所有 `文件:行`、命令、探针输出都是本轮自己跑出来的；凡是我的复跑与自述不一致，以我的输出为准并标注。
> 未做：未安装、未碰 `$DSH_HOME`、未修改 `bundle-lab/` 任何文件（复跑前后 28 个文件 SHA-256 逐一相同，无 `.mutation-aside` 残留；所有探针只读产品模块或只读 `app.asar`，破坏性实验全在 `%TEMP%`）。

---

## 0. 一句话结论

**带条件可进 P4。**

四条必修 + D-02/D-03 我都独立复现过：**四条修复成立**（不是"代码像对的"，是行为探针跑出来的）；**D-02/D-03 不再复现**，且我做了反向对照证明修复是承重的。B18/B19 降级已成文、理由可核。

但这一版**不能按现在的文档直接开 P4 走查**，原因不是代码，是三件文档/操作面的事（D-12 证据命令跑不通、B18 降级连带废掉了 B1-b/c/B6/B7/B17 的"设置页改/保存"步骤、`02:375` 还留着 `include:` 的错值），外加一条**P4 第 0 步必须验**的首帧竞态（R-1，机制已证、时序未定，命中会把 B1-a 判红）。这些都不需要再改产品代码，但必须写进 P4 脚本。

---

## 1. 独立复跑（全部我自己跑）

```text
cd bundle-lab
node --test "test/*.test.js"
ℹ tests 178
ℹ pass 178
ℹ fail 0
（exit=0；我另数了声明：client.test.js 43 + core.test.js 135 = 178，无少跑）

node scripts/check-syntax.mjs
20 file(s) checked, 0 failure(s)
（exit=0）

node scripts/build-client.mjs --check
ok   client.js kernel region matches lib/*.js
（exit=0）

node scripts/mutate.mjs
… 14 条全部 RESULT : red → green proven
ALL MUTATIONS PROVEN (14 run)
（exit=0）
```

复跑前后 `bundle-lab/` **28 个文件 SHA-256 逐一相同**（`client.js` = `BFCEC5D2…`、`lib/host.js` = `C2703D74…`），`.mutation-aside` 残留 0。

> 与 `13` 自述的差异：无。178/178、20/0、`--check` ok、14/14 全部对得上。这一项它不是编的。

---

## 2. 四条必修逐条核实（每条都自己复现）

### 2.1 D-01a `inject` 补 `remote.commands` —— **成立**

**代码**：`client.js:1863`

```js
inject: ['slots', 'locale', 'configForms', 'remote', 'remote.commands'],
```

**我自己用安装包里的 cordis 4.1.0 造的最小复现**（从 `app.asar` 只读取出 `@deepseek-ai/cordis@4.1.0` + 它的唯一依赖 `@deepseek-ai/cosmokit`，放进 `%TEMP%\final-verify\rt\node_modules`，拓扑照 `dsh-api-gateway` 真实形态：`remote` 是 `Service`，`remote.commands` 是 gateway 在**子 fiber** 上用 `super(ctx, 'remote.commands')` 注册的命名空间服务）：

```text
cordis version : 4.1.0 (extracted from app.asar, read-only)
inject: [remote]                  -> THREW: cannot get property "remote.commands" without inject
inject: [remote, remote.commands] -> resolved to a function ; answer.ok=true value.result.kind=success
```

**再用"真实导出的插件对象"过一遍 cordis**（不是合成插件，是 `client.js` 的 `factory(require)` 返回值直接 `root.plugin(...)`，其余服务用最小 Service 提供）：

```text
real export inject = ["slots","locale","configForms","remote","remote.commands"]
as shipped (with remote.commands) -> applied=true ; ctx.remote.commands.execute resolved ; applyError=null
without remote.commands          -> applied=true ; THREW: cannot get property "remote.commands" without inject
```

**机制出处**（安装包原文，不是猜的）：

- `dsh-api-gateway/lib/client.browser.js:1626` `class ClientRemoteService extends Service` → `super(ctx, "remote")`；
- 同文件 `:1776-1782`：每个命名空间用 `this.ownerCtx.plugin({ name: remoteServiceKey(name), apply: (ctx) => { service = new RemoteNamespaceService(...) } })` 挂在**子 fiber**；
- 同文件 `:1961` `super(ctx, remoteServiceKey(name))`，`:2074-2076` `remoteServiceKey = (namespace) => \`remote.${namespace}\``；
- cordis `lib/index.js:129` 的 traceable proxy 对 `associate` 服务走 `useSite.reflect.props['remote.commands']` → 落到 `ctx['remote.commands']`，`:1257` 就是那句 `cannot get property "…" without inject`。

**判定：成立。** 修复者的探针我没看，我自己重做了一遍，结论一致。

### 2.2 D-01b 按 gateway 信封解答案 —— **成立**

**代码**：`client.js:1609` `readCommandAnswer(answer)`，`client.js:2065` 起使用；逻辑是 `answer.ok !== true` → 取 `answer.error`（对象形态取 `code: message`，字符串形态原文保留）→ `value === undefined/null` → `command-value-missing` → `value.result.kind === 'error'` → 带 `result.text` 落失败 → 否则 `ok:true, text`。

**对照官方调用方**（我自己从 `app.asar` 取的原文，`dsh-client-ui-commands/lib/client.js:1669-1676`）：

```js
const result = await this.ctx.remote.commands.execute(session.sessionId, line, attachments);
if (!result.ok) throw new Error(`command.execute failed: ${result.error.code}: ${result.error.message}`);
if (result.value === void 0) return { kind: "error", text: `unknown or malformed command: ${line}` };
…
if (attachments.length > 0 && result.value.result.kind === "error") return { kind: "error", text: result.value.result.text };
```

→ 信封形状 `{ok, value:{commandId, result:{kind, text}}}`、`ok:false` 时 `error.code/message`、`value === void 0` 三分支，本插件都按这个解。`client.js` 全文已无 `answer?.text`（只剩 `:1604` 注释里那句"读 `answer.text` 就是 D-01b"）。

**我的行为探针**（真 `client.js` 按页面同一条求值路径 `new Function` 加载，喂四种真实形状）：

```text
A success envelope -> written="改写稿" state=revertible actions=["revert"]
B kind:error + Host text -> state=failed reason=timeout detail="aborted after 480000ms"
C refusal {ok:false,error:{code,message}} -> state=failed reason=provider-error detail="unavailable: gateway offline"
D value undefined -> state=failed reason=provider-error detail="command-value-missing"
```

**测试 fake 已换成真实信封**（我逐处核了）：

| 位置 | 形状 |
|---|---|
| `test/client.test.js:339-347`（B3/B4） | `{ok:true, value:{commandId:'cmd-1', result:{kind:'success', text: encodeResult(...)}}}` |
| `:389-395`（B13 release） | 同上 `cmd-2` |
| `:411-417`（B15） | `{ok:true, value:{commandId:'cmd-3', result:{kind:'error', text: encodeResult({reason:'timeout', …})}}}` |
| `:434-475`（D-01b 专项） | 四种形状：`{ok:false,error:'…'}` / `{ok:false,error:{code,message}}` / `{ok:true,value:undefined}` / `kind:'error'` |
| `:836-847`（端到端） | `execute` 按真实 gateway 返回，不再返回裸 `{text}` |

另核：`test/client.test.js:159-167` 的 inject 断言已改成五项（不再是钉死缺陷的那版）。

**判定：成立。**

### 2.3 D-05 回退裸 patchId —— **成立（方向正确，且文档回写到位）**

**代码**：`lib/host.js:967-970`

```js
export function normalizeEntryId(value) {
  if (typeof value !== 'string' || value === '') return undefined;
  return value.startsWith(ENTRY_ID_PREFIX) ? value.slice(ENTRY_ID_PREFIX.length) : value;
}
```

→ 是**剥**前缀，不是加。`readEntryId`（`:957`）读 `ctx.fiber.entry.options.id`。我另核了 Loader 侧：`cordis-plugin-loader/lib/index.js:767` `fiber.entry = fiber.parent[Entry.key]`，`EntryTree` 的 `get id()` 才是 `include:<patchId>`，`options.id` 是裸的 —— 两个 id 的区分成立。

**我的探针**：

```text
createHost(...).entryId = lab-draft-studio
published rows = [{"kind":"global","name":"__DSH_LAB_DRAFT_STUDIO__","value":{"entryId":"lab-draft-studio","command":"lab-draft"}}]
include: input -> entryId = lab-draft-studio
```

客户端侧（真 `client.js`）：`configForms.get()` 收到的唯一参数 = `"lab-draft-studio"`（不是 `include:…`）。

**文档回写**：`01 §9:542`、`02 D18:64`、`02 §3-U7:86`、`06 U7:164` 均已改为"裸 patchId = 设置命名空间，`include:` 只是显示 id"；`bundle-lab/cordis.patch.yml` 头注释也改了。

**但有一处残留**：`02-plan.md:375`（§7.4 v3.2 回写表第 2 行）仍写"预期 entryId 随并存裁定改为 **`include:lab-draft-studio`**"。这是 v3.2 的历史记录行，没有标注被 v3.3 取代，与 D-05 直接矛盾。详见 §5-R2。

### 2.4 D-04 `readSettings` —— **成立（映射正确、降级可触发），但带首帧条件 R-1**

**代码**：`client.js:1713-1728`

```js
if (form === null) return { settingsAvailable: false, settings: null };
…
if (snapshot?.status !== 'ready') return { settingsAvailable: false, settings: null };
const value = snapshot?.value ?? null;
if (value === null || typeof value !== 'object') return { settingsAvailable: false, settings: null };
return { settingsAvailable: true, settings: value };
```

**安装包原文核对**（我自己取的）：

- `dsh-client-ui-settings/lib/client.js:1109`：controller 初始 `status: "loading"`；
- `:1217`：namespace 不在 describe 里 → `draft.status = "unavailable"`；
- `:1229`：命中且解码成功 → `draft.status = "ready"; draft.value = decoded`。

→ 只有 `ready` 才带 `value`，映射与真实 controller 一致。

**测试**：`test/client.test.js:787-809`「an unavailable form status is unavailable, not "available but empty" (D-04)」——断言 `settingsAvailable:false`、座位只剩 1 颗且是 general。**我的探针**（不经过它的测试）：

```text
E form status=unavailable -> settingsAvailable=false visibleSeats=1 banner=true get() id="lab-draft-studio"
F form status=ready       -> settingsAvailable=true visibleSeats=4 editableRows=19 get() id="lab-draft-studio"
G no published global     -> settingsAvailable=false get() calls=0
```

**判定：成立。** 但请读 §5-R1：这个映射的正确性依赖"第一次渲染发生在 settings describe 落地之后"，而渲染器把 inject 面**按 entry 缓存、无失效**。

### 2.5 D-02 —— **不再复现**（先给反向对照，证明修复承重）

**我的探针**（直接 import `lib/host.js` / `lib/settings.js` / `lib/wire.js`）：

```text
=== D-02 ===
resolveSettings(config, overlayFromSaveOnly({timeoutMs:60000})) -> temperature=0.3 timeoutMs=60000
negative control (overlay = cloneSettings(null) + patch)         -> temperature=null timeoutMs=60000
dispatch(save-settings {timeoutMs:60000})                        -> {"ok":true,…}
overlay after save                                               -> {"timeoutMs":60000}
settings after save                                              -> temperature=0.3 timeoutMs=60000
D-02 verdict : not reproduced
```

- 第一行就是裁定要求的调用：`temperature` 仍是 **0.3**。
- 第二行是**反向对照**：如果 overlay 仍是 `cloneSettings(null)` 填满的默认对象，`temperature` 会变成 `null`（数据丢失）——说明这个缺陷是真的，修复（`mergePatch` 稀疏累积，`lib/host.js:132/787`）是承重的，不是摆设。
- 第三行走的是**真实 `dispatch`**，不是手搓 state：overlay 只剩 `{"timeoutMs":60000}`。

**判定：不再复现。** 修复者声称"先复现后修"，我没看到它的探针，但修复后的行为与反向对照都成立。

### 2.6 D-03 —— **不再复现**

**我的探针**（真实 `dispatch`，`sessionQuery.readSurface` 四种输入）：

```text
readSurface -> {}            : messageCount = null
readSurface -> {events:[{},{}]}: messageCount = 2
readSurface throws           : messageCount = null
no sessionId                 : messageCount = null
D-03 verdict : not reproduced
```

代码：`lib/host.js:620` 非数组返回 `null`；`lib/host.js:796` 只有 `Array.isArray(events)` 才取长度。另核了 `lib/context.js:112-119`：`assembleContext` 对 `events === null` 与非数组都有显式分支，改成 `null` 没有把 refine 路径带崩。

**判定：不再复现。**

---

## 3. 端到端（我自己串的，不用它的测试文件）

真 `client.js`（页面同一条求值路径）→ 点击 → 把 `execute` 接到**真 `lib/host.js` 的 `handle()`** → 用真实 gateway 信封回给客户端 → 客户端 settle：

```text
E2E success: written = "改写稿" state = revertible actions = ["revert"]
E2E host answer kind = success | decoded = {"ok":true,"text":"改写稿","presetId":null,…,"prepared":{"provider":"p","model":"m","temperature":0.3,"reasoningEffort":"low"},…}
E2E seat detail = null

READY seats = 4 ids = ["general","coding","writing","translate"]
READY sent presetId = "general"

B1-b visiblePresets=[general,translate] -> seats = 2 ids = ["general","translate"]
B1-c enabled=false -> seats = 0 ids = []

DEGRADED seats rendered = 1 presetIds = ["general"]
DEGRADED sent presetId = null | host result presetId = null | hasStructureBlock = false
```

（第一段挂载点故意没有设置表单，所以走的是 B20 降级请求 `presetId:null`；READY 那段才是正常四颗、请求带 `presetId:"general"`。）

另测运行/取消：

```text
H pending click -> state=running elapsed=0 actions=["cancel"] ; after cancel -> state=idle elapsed=null
```

→ **点一下真的能改写、能回退、能取消**；`revertible` 不再"代码在、端到端不可达"。这一条是上一轮复验判"不可进 P4"的核心，现在闭合了。

---

## 4. B18/B19 降级是否正式 —— **成文了，但连带步骤没交代**

**成文核实**：

- `01 §9:545` 表末行「**B18 / B19（设置页 19 项编辑 + 预设编辑门）** | **已定降级：移出 P4 范围** | P4 之后单独立项」，理由两条（工作量；写路径 `persist` 未接、#20 依赖的 `lastResult` 写入点不存在）都写了，并写明"P4 签收单必须写明 B18/B19 不在本轮范围；B1–B17、B20、B21 判据不变"；
- `01 §3-B18:289`、`§3-B19:300` 各加了"本轮状态"引言；
- `02` 头部 `:12` 有 v3.3 回写说明。

**降级理由我复核为真**：`client.js` 全文 `h('input')`=0、`onChange`=0、`save-settings`=0、`countUnsaved` 只有 1 次出现（内联内核里的定义，无调用点）、`unsavedCount`/`data-edit-gate`/`restore-default` 均 0。

**但降级有个没人写出来的连带后果**：B1-b/B1-c（"只勾通用翻译"/"总开关=关"）、B6（"取消勾选翻译并保存"）、B7（"设置页把写作改名为文案，保存"）、B17（"在设置页可改"、负例"设成 5 秒被拒"）的**操作步骤都要求一个可编辑的设置页**。B18 一降级，这些步骤就没有执行入口了。§9 只写了"判据不变"，没写"操作路径换到哪"。P4 操作者会卡在"设置页没有保存按钮"上。详见 §6 条件 C3。

另外两处小错：

- `01 §9:545` 引用 `client.js:1799` 说 19 行渲染成 `span`；现在 1799 是 `return h('button', {`，span 在 `:1844`（行号漂移，实质不变）；
- `02:375` 的 `include:lab-draft-studio` 残留（见 §5-R2）。

---

## 5. 残余未修项判断（修复者列的 + 我新增的）

### 5.1 修复者列的未修项

| 项 | 是否阻断 P4 | 我的理由 |
|---|---|---|
| **D-15/D-16**（#20 `lastResult` 恒 `null`） | **不阻断** | #20 是 B18 的一个观察点，B18 已降级出范围；写路径不存在时硬定"回显归属"只会再造假接口（`10` 的判断成立）。**但它不是"随 B18 一起没了"**：B18 立项时必须先做"回显归属"裁定，否则下一轮会重演 D-02 那类 overlay 覆盖。 |
| **D-12**（`01 §4` 的 E2 命令清单与真实形态不符） | **阻断 P4 的证据收集**（不是阻断安装/点击） | 真实命令是 `/lab-draft <base64url>`（`lib/wire.js:28/99-102`），`decodeLine` 只认这个前缀 + base64（`:116-137`），**没有短形态**。而 `01 §4:53`、`§3-B5:144`、`B8:199`、`B9:212`、`B10:222`、`B17:283` 全写 `/draft-studio dump-request …`。操作者按文档敲必然 `unknown-command`，B5/B8/B9/B10/B17 的"命令 + 输出"证据一段都拿不到。**一行生成器就能清**（见 §6-C1），不是代码缺陷，但 P4 前必须补。 |
| **dispose 泄漏**（D-06 附带 MINOR） | **不阻断** | 复核为真：`dsh-session-query/lib/index.js:467/502` 的 lease 只有 `[Symbol.dispose]`，`lib/host.js:671` 判的 `observation?.dispose` 是空操作。后果是 cold/prepared 会话的 `entry.refs` 不回落、缓存不淘汰——是资源计数泄漏，不是功能缺陷；P4 一个会话点几次按钮的量级无感。**记已知问题即可**。 |
| **D-08 残余**（只带 `Sec-Fetch-Site`、不带 `Origin` 仍放行） | **不阻断** | 降级 A 的 HTTP 路由默认关闭（`index.js` 不挂 `mountRoute`），token 闸仍是每进程 UUID。**对外不要说"三闸独立"**；若 P4 启用降级 A，签收单要写这句。 |

### 5.2 我新增的两条（`13` 没写）

**R-1（首帧设置竞态，机制已证、时序未定）—— P4 第 0 步必须验**

- 机制：`ConfigFormController` 初始快照是 `status:"loading"`（`dsh-client-ui-settings/lib/client.js:1109`），`derive()` 要等 `mirror.view` 落地才改成 `ready`/`unavailable`（`:1217/:1229`）。
- 而渲染器把 inject 面**按 entry 缓存、没有失效**：`dsh-client-ui-renderer/lib/client.js:499-519`（`rootInjectCache` / `sessionInjectCache`），调用点 `:816/:887`。座位槽 `conversation.input.right` 是 `{kind:"list", scope:"session"}`（`dsh-client-ui-conversation/lib/client.js:22982`），所以每个会话的第一次渲染算一次面，之后不再重算。
- 后果：如果第一次渲染早于 describe 落地，`readSettings` 读到 `loading` → `settingsAvailable:false` → **四颗只剩一颗 + 设置页横幅，且不会自己恢复**（切会话/重载才可能恢复）。设置页那个面走 `cachedRootInject`（`:887`），同样是"打开那一刻算一次"——只要用户是在 describe 落地后打开设置页，它是对的；座位面才是风险点。D-04 的映射本身没错，错在"面是一次性的"。
- 这不是我编的：同一机制下，修复前的版本是"永远四颗 + settings:null"，修复后是"可能一颗"。**方向对，但把正确性押在了一个未验的时序上**。
- P4 处置：冷启动后先数按钮（见 §6-C5）。若命中，最稳的修法是让座位面可重算（`inject` 返回 `hooks` 源，或 `readSettings` 只在 `status === 'unavailable'` 时降级、`loading` 保持上一态），而不是改映射。

**R-2（文档残留错值）—— P4 前一行改掉**

- `02-plan.md:375`：`U7 → … 且预期 entryId 随并存裁定改为 **include:lab-draft-studio**`。与 D-05 和 `02:64/:86` 直接矛盾；虽然它在 §7.4 的 v3.2 历史表里，但没有"已被 v3.3 取代"的标注，操作者 grep `include:` 会先命中它。

---

## 6. 放行意见

### **带条件可进 P4。**

四条必修全部成立（D-01a / D-01b / D-05 / D-04），D-02/D-03 不再复现，B18/B19 降级成文，端到端点击→写回→回退在我自己的探针里跑通。这一版**不是上一轮那个"点一下永远转圈"的版本**了。

条件按"用户/操作者会怎么做"写，P4 脚本必须逐条落：

**C1（P4 前，证据命令）**：操作者不能按 `01 §4` 直接敲 `/draft-studio dump-request …`。P4 脚本必须附一个生成器或预生成的行，例如：

```powershell
node -e "import('./lib/wire.js').then(m=>console.log(m.encodeLine({action:'dump-request',presetId:'coding',prepare:true})))"
# → /lab-draft eyJhY3Rpb24iOiJkdW1wLXJlcXVlc3QiLCJwcmVzZXRJZCI6ImNvZGluZyIsInByZXBhcmUiOnRydWV9
```

并把 `01 §4:53` 与 `§3` 里所有 `/draft-studio dump-*` 改成真实形态（或注明"由 P4 脚本生成"）。不补这条，B5/B8/B9/B10/B17 的证据收集不了。

**C2（P4 前，B18 降级的连带）**：P4 脚本必须写清 B1-b/B1-c/B6/B7/B17 的"改设置"步骤走哪条路——二选一并写明：①`dsh-config-editor` 的配置编辑页（前提：该 profile 启用了它；本轮未安装、未验）；②改 `bundle-lab/cordis.patch.yml` 的 `visiblePresets`/`enabled`/`timeoutMs` 后重启（`readConfig` 每次都重读，路径确定）。同时明确：B7 的"13 个汉字保存被拒"和 B17 的"5 秒保存被拒"是**设置页交互负例**，本轮无设置页编辑器，只能由单测覆盖或记"不在本轮范围"，**不得记通过**。

**C3（P4 前，一行文档）**：`02-plan.md:375` 的 `include:lab-draft-studio` 改为 `lab-draft-studio`（或标注"已被 v3.3 取代"）。

**C4（P4 前，客户）**：B18/B19 是 REQ-02 第 6/7 条的客户原文（设置页、约 20 项可改、改完即时生效）。降级出 P4 是**客户可见的范围削减**，不是内部技术选择。签收单写"不在本轮范围"是必要的，但**还需要客户明确同意**；只写"已告知、待签收"不能算过。

**C5（P4 第 0 步，30 秒）**：冷启动 → 打开一个会话 → **在输入框里打第一个字之前先数按钮**。期望 4 颗。若出现 1 颗 + "读不到插件设置"横幅：
- 先切一次会话再切回，看是否恢复 4 颗；
- 恢复 → 记 R-1 为已知首帧竞态，继续走查，但 B1-a 必须在恢复后重记；
- 不恢复 → **停止走查**，先做 R-1 的修法（面可重算），再重启 P4；
- 无论哪种，**不得把"1 颗"记成 B20 通过**（B20 的触发条件是设置不可用，不是加载中）。

**C6（P4 第一次点击）**：点一颗，必须在秒级内看到运行中→写回；若又出现"永远 running"，先看 console 是否还有 `cannot get property "remote.commands"`（按本轮证据不应再有），再按新缺陷记。

**C7（P4 全程，口径）**：不要对外说"三闸独立"（D-08 残余）；降级 A 的 HTTP 路由默认不开，若为验 U4 打开，签收单写"只带 same-site 头可放行"。

**C8（P4 全程，计分）**：B18/B19 记"降级出范围、客户签收"，**不计通过也不计红**；B1–B17、B20、B21 的判据本身一字未改。

**C9（P4 安装后，U2）**：本轮未安装，第三方能否调用 `commands/execute`（U2）仍是负责人已接受的风险。安装后第一次点击就是 U2 的实测；失败按"新缺陷"记，不要归因成"环境问题"。

### 可以带进 P4 的真实资产

- 内联 + 生成器 + `--check` 的架构（手改会红、`lib` 改动会红）；
- `lib/run-store.js` 状态机、`lib/writeback.js` 三重守卫、`lib/host.js` 的 settings 解析/命令分发；
- D-06 的 `observeSession().projections` 读法、D-07 的 `detail` 透出（Host 面）、D-08 的两头缺失拒绝、D-09 的 `assert-preset.mjs`；
- 178 条测试 + 14 个变异装置（这是本项目最扎实的资产，下一轮继续用）。

---

## 7. 我未验的（写清边界，不含糊）

| 项 | 状态 |
|---|---|
| 真机页面上的首帧时序（R-1） | **未验**（无浏览器控制；Client Inspect 前几轮均 10s 超时）。机制已证，时序只能 P4 第 0 步量。 |
| 第三方能否调用 `commands/execute`（U2） | **未验**（需安装）。负责人已接受，P4 第一次点击即实测。 |
| 设置页在真实 `configForms` 上的 `describe()` 全量返回 | **未验**（未安装）。我用的是安装包 controller 源码 + fake 快照，形态与源码一致。 |
| 安装/`$DSH_HOME` | **未做**（约束）。 |

---

## 8. 附：本轮命令与证据文件

```text
# 独立复跑（bundle-lab/，复跑前后 28 文件 SHA-256 一致，无 .mutation-aside）
node --test "test/*.test.js"                 # 178/178
node scripts/check-syntax.mjs                # 20 files, 0 failure
node scripts/build-client.mjs --check        # ok
node scripts/mutate.mjs                      # 14/14 red → green

# 我自己的探针（全在 %TEMP%\final-verify，只读产品模块 / 只读 app.asar）
%TEMP%\final-verify\rt\probe-inject.mjs       # cordis 4.1.0：只声明 remote 抛错 / 补子路径不抛
%TEMP%\final-verify\rt\probe-real-plugin.mjs  # 真实 client.js 导出过 cordis：apply 成功、点击缝解析
%TEMP%\final-verify\probe-client.mjs          # inject / 信封四形状 / settings 三态 / 运行取消
%TEMP%\final-verify\probe-e2e.mjs             # 点击→真 host.handle→信封→写回→revertible；B1-b/c、B20
%TEMP%\final-verify\probe-d02-d03.mjs         # D-02（含反向对照）/ D-03 / D-05
%TEMP%\final-verify\asar\…                    # 只读抽取的官方源码（settings/gateway/commands/loader/cordis）

# 安装包原文（只读）
probe-tools\asar-grep.ps1 -Pattern 'remote\.commands\.execute' -Prefix '…/dsh-client-ui-commands' -Include '*client.js'
probe-tools\asar-grep.ps1 -Pattern 'super\(ctx, "remote"\)' -Prefix '…/dsh-api-gateway' -Include '*client*.js'
probe-tools\asar-grep.ps1 -Pattern 'status: "loading"' -Prefix '…/dsh-client-ui-settings' -Include '*client.js'
probe-tools\asar-grep.ps1 -Pattern 'cachedRootInject' -Prefix '…/dsh-client-ui-renderer' -Include '*client.js'
```

**未做**：未安装、未写 `$DSH_HOME`、未修改 `bundle-lab/` 任何文件（28 个 SHA-256 逐一相同）。
