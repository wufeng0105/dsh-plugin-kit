# 02 计划（P1）— dsh-draft-studio / 草稿工坊（返工版 v3）

> 输入：`01-requirements.md`（P0 返工版 v3，21 条验收 B1–B21，无待裁定项）+ `04-regate-P0P1.md`（本轮复审）+ `probes.md`（宿主探测）+ `00-client-answers.md`（客户答复，已回填）+ `process-lab/spec/process-v2.md`。
> 本版核心变化：把"UNVERIFIED 清零"从 P2 内拿出来，按规格 v2 建立 **P1.5 探针门**（§3）；依赖清单补全 list 座位的硬注册契约（D1）；证据口径与 `01` §4 统一。
> **v3 增量（只回应 `04` 的 3 项）**：S5 组件属性清单补 `data-elapsed-ms` / `data-hover-text` / `aria-disabled` 并把"基线片段 + 按条扩展"写进完成标志（N-2）；U1 探法改为"先确认参数 schema"，措辞改"判据不变、范围减 activity 展开态"（N-5/N-9），R9 与 D1 补 `left` 同在 `tools`（N-4）；一致性表补 4 行数值口径（N-6）。逐条回应见 §7.2。
> 铁律对齐（规格 v2 §共同铁律）：依赖清单里**没有**留到实施期才验的项——凡是本机探不到的，一律进 §3 探针门，写明探什么、怎么探、探不到怎么降级、降级后验收怎么变。

> **v3.1（05 复审定点修订，仅文档）**：只改 3 项必改 + 3 条顺手项——B3 `messageCount` 来源改为宿主方法表里真实存在的 `readSurface`（`01` §4.1、本文件 §1/D11/S4/§7.2.1/§7.2.3、`probes.md` P7）、`editorPhase` 选择器改为 `[data-composer-input]` 并统一键名（原基于 `contenteditable` 的查询取不到 submitting/sending）、B1-e activity 三态前置；顺带 N-3 措辞、`02:297` 行号、`02:178` 期望命中数。逐条见 §7.3。

> **v3.2（P2 开工回写，2026-11-08）**：把 `06-p1.5-probes.md` §9 的定点与 `06-lead-decision.md` 的裁定落进本文档 —— ①§3-U4 端口**不再写死 8314**（实测 6727 浏览器口 / 6728/6729/8326 Bearer 口），并补"插件路由无鉴权"的运行时实测；②U5/U6/U7 状态从"部分验/未验"改为已验（U7 的预期 entryId 随并存裁定改为 `include:lab-draft-studio`）；③D17 从 `UNVERIFIED` 改为"已定降级（源码级 114 个 alias 令牌）"；④§1 新增"与在装 `dsh-draft-studio@1.2.2` 的关系"决策行（方案 B 显式并存、全量实验前缀）；⑤§5 新增 R10（路由无鉴权）与 R11（并存的两套控件）。逐条见 §7.4。**本轮仍未安装任何插件、未碰 `$DSH_HOME`。**

> **v3.3（修复轮 v2 回写，2026-11-08）**：D-05 回退 —— 设置命名空间是**裸 patchId**（`lab-draft-studio`），`include:lab-draft-studio` 只是 `Config.listConfigs.id` 的显示形态；D18 / §3-U7 / §1 并存行同步改正（依据 `12-lead-decision-v4.md` D-05、`11-reverification.md` §2.3）。B18/B19 正式降级出 P4 范围，见 `01-requirements.md` §9 末行。**验收判据 B1–B21 不变；未安装、未碰 `$DSH_HOME`。**

---

## 1. 形态判断

**形态：持久安装的双半 bundle（Host 半 + Client 半），不是动态 Cordis 包。**

| 决策 | 选择 | 理由（探测依据见 probes.md 编号） |
|---|---|---|
| 分发形态 | Plugin Manager 可安装的 workspace bundle（`dsh.bundle.patch` + `dsh.client`） | 功能要跨重启存活（常驻能力）；动态包会话级、重启即失、每次 run 要人工批准（P15），不满足。 |
| **按钮落点（A1，已结案）** | 客户端插槽 **`conversation.input.right`（list，会话域）——主座位**。每颗按钮一条注册：`id = presetId`（四条互不相同），`order = 0..3` 固定稳定顺序。 | 该座位 `kind:"list"`、渲染在模型选择器之前、Stop/Send 左侧（`dsh-client-ui-conversation/lib/client.js:22982–22985`、`:22110`）；list 天然允许 1–4 条不同 `id` 并存（`dsh-web-frontend/dist/assets/index-BgUyXZcc.js` 偏移 492065–492133）。客户答复"列表座位优先"即指它。**不是容差妥协，不需要客户再裁定。** |
| 设置页落点 | 客户端插槽 `settings.section`（list，root 域）+ `settings.section.icon` | 宿主设置壳以 `settings.section` 台账渲染导航与页面，props 为 `{ close }`（P12/P13）。 |
| 设置持久化 | 插件 `Config`（schemastery schema，可改字段全部 `.volatile()`），客户端读写设置经命令通道 `dump-settings` / `save-settings`；Config 是否可用取决于 U5/U6，失败即走 D12 的文件降级 | `volatile` 在已安装 schemastery 源码中存在（P20）；`pnpm view @deepseek-ai/schemastery version` 返回 3.19.0（依赖可安装）。**U5/U6 在 P1.5 清零前不写任何依赖它的代码。** |
| 按钮触发改写的通道 | **复用既有 Remote 端点：`ctx.remote.commands.execute(sessionId, '/draft-studio <载荷>', [], signal)`**；宿主半注册同名命令作为处理器 | Remote 端点表构建期固定，第三方插件无法新增命名空间（P14）；命令端点文档内、经鉴权、带 AbortSignal、能返回文本（P5/P9）。`command/run`/`command/done` 是 log-only 记录，只用于证明请求次数/取消/错误类别，**不承载模型字段**（`01` §4）。 |
| 改写模型调用 | 宿主半先 `ctx.llm.prepareCall(config, signal, configure)` 取得物化后的调用配置（`configure` 里按模型 `reasoning.efforts` 判断强度是否支持，不支持则用 `defaultEffort` 并记 `effortFallback`），再用返回的 `prepared.stream(...)` 发流；自己计时 480s 超时 | `llm.prepareCall` 在本机契约中已验：返回 `PreparedLlmCall.config`（宿主校验/物化后的 provider/model/effort），"keeps that registration across header logging and dispatch"——B8/B9/B10 的证据源（Inspect 输出，见 `01` §4）。 |
| 会话上下文读取 | 宿主半 `ctx.sessionQuery.readSurface(sessionId)`（取 `SessionSurfaceSnapshot.events.length` 作 `messageCount`），按轮数/字数上限折叠 | 读服务已探明（P7；05 复审复核方法表后钉死取数口径，见 `01` §4.1）。 |
| 不新增的能力 | 不新增 Remote 命名空间、不写宿主 DOM、不接管发送、不改 `$DSH_HOME` profile | 全部是宿主实践红线（P14、skill references）。 |
| **与在装 `dsh-draft-studio@1.2.2` 的关系（v3.2 新增，按 `06-lead-decision.md` §1 裁定 = 方案 B 显式并存）** | 包名 `@local/lab-draft-studio`、`meta.title`、座位 id（`lab-draft-<presetId>`）、设置页 id（`lab-draft-studio`）**全部加实验前缀**；patch 行 `id: lab-draft-studio` → 设置命名空间 **`lab-draft-studio`**（`Config.listConfigs.id` 的显示形态才是 `include:lab-draft-studio`，两者不是同一个 id）。**不删除、不停用、不改动**在装的 `dsh-draft-studio@1.2.2` 及其数据（明确排除方案 A 的 `remove_bundle`：那是用户日常在用的真实产品，本实验无权动它）。验收判据不变：一切页面事实仍按 `data-draft-studio-*` 属性过滤（前代 0 命中，06 §2.3），B1-a 的 `count===4` 判据不变 | 06 §2.1/§2.2/§5-② 实测：前代在跑（`status:"schema"`），已占 `conversation.input.right`（id `dsh-draft-studio`, order 60）与 `settings.section`（同 id）；同座位还有 `@wufeng0105/dsh-teammate-model-picker`（id `teammate-model-picker`, order 10）。list 座位不同 id 并存（D1-①），本项目用不同 id 不会冲突，只会**并排**。改名前缀是把"用户看到两个草稿工坊"变成"实验件一眼可辨"的最低成本做法 |

**为什么不用另外两条被否掉的通道**（记录下来防复审翻案）：
- 动态 Cordis 包 + `host.call`：通道最干净，但会话级、重启即失、每次 run 要人批——与"常驻按钮"冲突（P15）。
- 插件自建 HTTP 路由（`webServer.register`）+ 页面 fetch：契约已读（P6），但鉴权行为未验（P22 只证明 401/404 基线），且拿不到页面凭证注入方式——只作为命令通道失效时的**降级**，不作为主通道。

**总开关语义**：设置里"总开关=关"→ 客户端不注册/不渲染按钮（`01` §3 B1-c，N=0）；"设置不可用"→ 按 B20 退一颗通用按钮。

---

## 2. 依赖清单

> 状态三态：`已验(契约)`＝宿主 Inspect 读到的精确契约；`已验(源码)`＝本机安装包源码里读到的实现事实（附文件:行或字符偏移）；`UNVERIFIED`＝本机探不到，**已进 §3 探针门**；`无法判定`＝只能装上后观察。
> 复跑方式：源码事实用 `probe-tools/asar-probe.ps1 -Get` + `Select-String`；契约事实用 `cordis_inspect_query`（命令见 `01` §4 表）。

| # | 我依赖宿主什么 | 为什么非它不可 | 探测结论 | 不成立时怎么降级 |
|---|---|---|---|---|
| D1 | 插槽 `conversation.input.right`（list，scope=session）及其**四条硬契约**：①每条注册**必须带 `options.id`**，同 `id`+同 priority 才冲突，不同 `id` 并排渲染且按 `order` 排序；②渲染条件 `input !== undefined && sessionId !== undefined`（无会话/新会话首帧不渲染）；③所在容器 `standardControls` 带 `hidden: activity`，activity 展开时 `right` 与 `model` 一起隐藏；④`renderSlot("conversation.input.right", {})` 传空 props，会话数据走标准 hooks | 按钮的唯一定身之所（A1 主座位）；B1 的可达性判定完全建立在这四条上 | `已验(源码)`：①`index-BgUyXZcc.js` 偏移 **492065–492300**（`requires options.id` @492133、同 id 冲突检查 @492275，本轮实测）+ `dsh-client-ui-renderer/lib/client.js:1203–1221`（list 的全部 rows 按 `order` 排序后全部渲染，single 才只取 `[0]`，见 1173–1177）；②③`dsh-client-ui-conversation/lib/client.js:22107–22111`（`hidden: activity`；`input === void 0 \|\| sessionId === void 0 ? null : renderSlot(...)`）；④座位声明 22982–22985。运行时占用者与 activity 展开频率 `UNVERIFIED` → U1 | 座位缺失（理论不成立，声明就在宿主包里）→ 换 `conversation.input.left`（同为 list；**注意：`left` 所在 `tools` 容器同样带 `hidden: activity`（`ui-conversation-client.js:22071`），换过去仍受 P2 前提约束，换座不解决 activity 隐藏**）；两者都缺 → 设置页内操作+命令，B1 记不通过。**对验收的影响**：B1/B2 的判定前提含 `01` §3.0 P1/P2（sessionId 非空、activity 未展开）；activity 长期展开属于记录项（客户知情记录 = `01` §8.5），不换座位、不判失败。注册缺 `id` 的失败模式**必须**在 S5 的注册步骤以 `id = presetId` 落死（R8）。 |
| D2 | 标准插槽 props：`useInput`（draft/draftRev/phase/occurrences/claim）与 `inputActions` | 读草稿、判"非空/含芯片"、写回、判"是否覆盖新输入"全靠它 | `已验(源码)`：`ctx.uiSession.provide` 公布 hooks `input`、props `inputActions`；InputState 字段 `draft/attachmentIds/draftRev/phase/claim?/occurrences/queue`（P11/P10）。 | 无替代——没有它整个客户端半不成立；若 props 不达插槽，则把按钮搬进 `conversation.composer.dock`（同域，props 同源）再验。 |
| D3 | 整段写回 + 单步撤销：`inputActions.insertText(text, span)`（span 含 `draftRev` 守卫）与 `inputActions.setDraft(text)` | B3 写回、B13 不覆盖新输入、B4 回退（Ctrl+Z 附加观察） | `已验(源码)`：`insertAsyncText(span,text)` 是"一次独立撤销操作"，`insertText` 对 `span.draftRev !== rev` 拒绝返回 false；`setDraft` 并入历史（不可作唯一撤销手段）（P10/P17）。 | 撤销不可用：回退按钮用原文快照做 `insertText`；仍失败 → `setDraft(原文)`（B4 的 Ctrl+Z 附加观察记"无法判定"）。 |
| D4 | 引用芯片语义文档：`{text, references:[{offset,length,ref,clipboardText,…}]}` 与占位符正则 `[\uE100-\uE11D\uFFFC]` | B21 的"`@` 不受影响"要靠按标记重建芯片 | `已验(源码)`：`resolveDraftInput`/`snapshotDraft`/占位符正则/`restoreDraft(text, references, quotes)` 均在 bundle 中（P10/P18）。 | 模型丢标记 → 按"原稿不丢、结果待重试"降级（B21 写死）；重建 API 与推断不符 → 退化为"/ 同规则"并在 P3 报偏离。 |
| D5 | 会话模型选择可读：投影 `modelSelection`（provider/model/reasoningEffort），并与**界面模型选择器的显示值**互为独立来源 | B8 跟随模式 | `已验(源码)`：宿主 UI 以 `session.projections.faceOf("modelSelection")` 读会话模型与强度（P19）。 | 冷会话读不到 → 回退用 `modelCatalog` 的 `default`，回显写明原因（B15 证据链）。 |
| D6 | 模型目录与强度清单：`ctx.remote.session.modelCatalog()` → groups/models/{reasoning:{efforts,defaultEffort}} | B9 固定模式的选择器、B10 的确定性构造（跨模型 efforts 差集） | `已验(契约)`：sessionController `@Remote('modelCatalog')`（P5）。 | 目录失败 → 固定模式只允许文本输入 model，不做强度校验；B10 由 `prepareCall` 的 configure 兜底（D8）。 |
| D7 | 一次性模型调用：`ctx.llm.prepareCall(config, signal, configure)` → `PreparedLlmCall{config, stream()}`；`ctx.llm.stream(...)` 兜底 | 改写的引擎 + B8/B9/B10 的**证据源**（`prepared.config` 是宿主物化后的 provider/model/effort） | `已验(契约)`：prepareCall "Resolve one call under its current adapter registration... keeps that registration across header logging and dispatch"；GenerateOptions/StreamChunk 全文（P4 + 本轮 Inspect 复核）。 | `llm` 不可注入 → 插件停用改写并明示（B20 极端形态）；不找旁门（自建 HTTP 调模型）——凭证只在宿主侧。 |
| D8 | 强度能力检测：`prepareCall` 的 `configure(controls, model)` 拿到 `LlmResolvedModelInfo.reasoning.{efforts,defaultEffort}`，据此在发流前改用默认强度 | B10 的"自动退回默认强度"，且**先于 I/O**，证据可断言（`effortFallback` + `prepared.config.reasoningEffort`） | `已验(契约)`：`resolveCallConfig`/`prepareCall` 描述 "Unsupported explicit efforts reject before provider I/O; no clamping"；configure 回调签名见本轮 Inspect（P4）。 | 实测行为不符 → 捕获流内 `finish(error)` 触发退回重试（判据不变，只是失败路径不同）。 |
| D9 | 客户端→宿主通道：`ctx.remote.commands.execute(agentId, line, attachments, signal)` | 按钮点下去唯一已鉴权的数据通道（命令、设置读写、dump-* 全走它） | `已验(契约+源码)`：`@Remote execute`，wire 参数 `agentId/line/attachments/signal`；客户端既有第一方调用 `ctx.fileUpload.uploadImage(sessionId,…)` 先例（P5/P9/P13）。**`UNVERIFIED`（显式标注）：第三方 bundle 在运行时调用该端点尚未实测——第一方先例不等于第三方可用；分钟级长调用与取消传播也属本条** → U2。 | 长调用被限 → 降级 A：HTTP 路由 `webServer.register`（D10，鉴权 UNVERIFIED，见 U4）；再不行 → 降级 B：宿主半起一次性后台任务 + 客户端短命令轮询。 |
| D10 | 宿主命令注册：`ctx.commands.register({name, description, input:{hint}, handler})` | D9 的对端 | `已验(契约)`：register/execute 全文；`CommandInvocation = {commandId, agent, rawInput, attachments, signal}`（本轮 Inspect 复核）；`command/run|done` 为 log-only。 | 不可注册（理论不成立）→ 走 HTTP 路由通道。 |
| D11 | 会话上下文读取：`ctx.sessionQuery.readSurface(sessionId)`（`SessionSurfaceSnapshot.events`，05 复审按宿主 Inspect 方法表钉死；旧文档引用的方法名已删除） | "带最近几轮"与"读了几轮几字" | `已验(契约)`：`readSurface(sessionId): Promise<SessionSurfaceSnapshot>`，`events: SurfaceEvent[]`（`SurfaceEventType` = 四类 message + `tool/result`，不含 `command/*`/`turn/*`/`step/*`；P7，05 复审复核）。 | 读失败 → 请求不带上下文，回显"没读的原因"（B15/B20 兼容）；B3 的 `messageCount` 为 `null` → 该条记「无法判定」。 |
| D12 | 设置持久化：插件 `Config`（schemastery）+ 可改字段 `.volatile()` 原地更新；客户端经命令通道读写 | B18/B19/B6（改名不丢、勾选不丢、即时生效） | `已验(源码+命令)`：`Schema.prototype.volatile` 存在（P20）；`pnpm view @deepseek-ai/schemastery version` → 3.19.0（本轮命令输出，依赖可安装）。`UNVERIFIED`：①workspace bundle 运行时能否 import 该包（U5）；②volatile 字段+默认值的实际读取语义（U6）。 | U5/U6 任一不成立 → **文件降级**：不声明 `Config`，设置存插件自有 JSON（round1 先例 `round1-enhance/bundle/host/paths.js:21–30` 的 `<home>/.dsh/<plugin>/` 形态），宿主半每次请求重读文件；B18 判据**不变**（仍是不重启即生效，证据改为 `dump-settings` 输出）；代价：用户不能在 cordis.patch.yml 里改设置，写入 04 已知问题。 |
| D13 | 设置页插槽：`settings.section`（list，root）props `{close}` + `settings.section.icon` | B18/B19 的载体 | `已验(源码)`：register 形如 `{name, id, order, label:()=>t(...), locale, children}`，渲染 `renderSlot("settings.section", { close: onClose }, { only: active })`（P12/P13）。 | 页面塞不进（理论不成立）→ 设置项挂插件 Manager 详情 + 手改；B19 记不通过。 |
| D14 | 取消传播：Remote 调用传 `AbortSignal`，宿主 `CommandInvocation.signal` 与 `prepareCall/stream` 的 signal 贯通 | B12 可取消 | `已验(契约)`：execute 端点带 `signal`（"cancellation signal owned by the UI request"）；llm 接 `signal`（P4/P5 + 本轮 Inspect）。 | 网关不传播取消（U2 的一部分）→ 宿主半用 invocation 内自建 480s 计时 + 客户端取消置本地状态、丢弃晚到结果（B12 判据仍可达，浪费一次请求）。 |
| D15 | 打包装载：`dsh.bundle.patch` 插行、`dsh.client {platform:'web', immediately:true, inject:[…]}`、locale/icon 导出 | 插件能在本机装上并让页面加载客户端半 | `已验(契约+先例)`：模板与文档（P2/P14）；round1 同构 bundle（`round1-enhance/bundle/package.json:27–33`）在本机流程跑过一轮打包。 | 安装需用户批准；装不上 → P2 无法开工，按阶段门挂起，不伪造证据。 |
| D16 | 客户端模块装载：`window.__ModuleLoader__.load({id, factory(require){…}})`，React 从模块表取 | 客户端半的入口形态 | `已验(源码)`：宿主自带包的 `lib/client.js` 全部是此形态；装饰模板同构（P10/P2）。 | 无需降级；这是宿主唯一客户端入口。 |
| D17 | 主题与文案：`--dsw-alias-*` 令牌 + `ctx.locale`/`locale: NS` | 界面与宿主一致（不写死颜色、不改根） | **已定降级（源码级清单已取得，v3.2 回写）**：Client Inspect 超时使 Theme Provider 的运行时清单取不到，改读已发布包 `dsh-client-ui-theme/lib/client.js`（140,079 字节）：正则 `--dsw-[a-z0-9-]+` 去重得 **414 个 `--dsw-*` 全部有定义**，其中 **`--dsw-alias-*` 114 个**（light/dark 两套值在 `:1470` 同一行） | 取不到令牌清单 → 用宿主已发布包 CSS 里的令牌名（源码级）并在 P3 复核；样式偏差不阻断验收（验收不含像素级比对）。**仍禁止写死字面色**（`practices.md:34`） |
| D18 | Config 条目寻址：`configForms.describe()` 按 `name` 找 entryId | 设置页要写对命名空间 | `已验(契约+命令)`：`Config.listConfigs` 返回 `id/patchId/name`；本轮全量目录（229 条）中 id 一律 `include:<patchId>`、name 精确等于包名（含 `@deepseek-ai/dsh-plugin-manager/tools` 这种子路径形态）。**并存裁定后本插件 patch 行 `id: lab-draft-studio`**（v3.2 回写）→ 预期**设置命名空间 = 裸 patchId `lab-draft-studio`**（v3.3 按 `12-lead-decision-v4.md` D-05 回退；`include:lab-draft-studio` 只是 `listConfigs.id` 的显示形态）；U7 只复核这一个值，且必须与在装的 `dsh-draft-studio` **不同**（不同 patchId 天然不同） | describe 找不到 → 设置页首帧用 `describe()` 全表按 name 匹配；仍不出现 → 走 D12 文件降级。 |

---

## 3. P1.5 探针门（规格 v2 新增，本节替代旧"UNVERIFIED 清单"）

- **入口**：P1（本文件）通过，且存在 `UNVERIFIED` 项（D1/D9/D12/D17 相关）。
- **产物**：探针记录写回 `probes.md`（每条：结论 + 出处：命令原文 + 输出，或 文件:行）。
- **规则**（规格 v2 §P1.5）：只做探测与最小验证，**不写功能代码**；需要安装时**只装探针**（selftest 命令 + 最小插槽组件），探针 bundle 不含任何业务逻辑。
- **出口判据**：下表 U1/U2/U3/U5/U6/U7 每条变成「已验」/「已定降级方案（写明降级后验收如何变化）」/「无法判定 + 由谁在何时接受该风险」。**清零后才允许进 P2（S2 起的业务代码）。**
- **U4 是条件项**：只有 U2/U3 失败需要降级 A 时才补探，但**必须在 P1.5 内完成**（降级 A 是否可行决定 P2 用哪条通道）。
- **U8 不再属于本节**：它是对 21 条验收的现场走查（验证行为，不是探测依赖），移入 §4 的 S8 与 P3 走查表。
- **v3.2 状态（P2 开工时）**：`06-p1.5-probes.md` §6.1 统计 = 已验 5 / 已定降级 1 / 无法判定（运行时）3，9 格全部就位；负责人已按 `06-lead-decision.md` 裁定 §6.2 的 3 个前置（关系 = 方案 B 并存、接受 U1-② 风险、U2/U3 运行时补测挂 S1 探针）。**因此本门对 P2 是"已开、带 2 个运行时尾巴"**：U1-②（activity 展开态现场记录）与 U2/U3（长 unary / 取消 / 8000 字符回显）在 S1 装探针后立即补跑，其余不再阻塞。

| # | 探什么 | 怎么探（命令原文，只读优先） | 现已得到的结论（出处） | 清零判据 | 探不到/失败时的降级，以及降级后验收如何变化 | 影响面 |
|---|---|---|---|---|---|---|
| U1 | ①`conversation.input.right` 的运行时占用者（是否已有其他插件条目）；②无 `sessionId` 首帧与 activity 展开时的实际渲染；③Theme 令牌清单（D17） | **先确认参数形态再探**（N-5）：`cordis_inspect_list` 读出 `Slots.listSubTree` / `Theme.listTokens` 的 input schema，按 schema 以 **JSON 对象**传参；然后 `cordis_inspect_query(client, Slots, listSubTree, {root:"conversation.composer.bar"})` 与 `cordis_inspect_query(client, Theme, listTokens, {})` 各一次。上一轮的事实是**两种失败都有**：`{root:…}` 形态被工具层拒绝两次（`"input" must be an object`，`03` §3.2）、改成对象形态后 10s 超时（`probes.md` P3 01:30、P195 02:04）。**参数形态一旦确认，同一形态不重试第三次**——仍超时/仍为空即直接装**最小探针 bundle**（只向 `right` 注册一个带 `id` 的空组件）并在页面 console 跑 `01` §4 基线片段 | **静态契约已闭环**：座位声明/渲染条件/hidden 均有源码行号（D1）；运行时两次实测未通过（一次参数被拒、一次超时，出处同上） | **按 ①②③ 分列清零**（N-5）：①`listSubTree` 返回该插槽的 occupants（空数组 = "无其他占用者"，也算已验），或探针组件渲染成功且 `count ≥ 1`；②无 `sessionId` 首帧跑 §4 片段得 `count === 0`，activity 展开态跑片段得 `count === 4 且 visible 全 false`——两条记录齐 = 已验（探针只证渲染、拿不到首帧的，该子项记"未验"）；③`listTokens` 返回令牌清单，或采用源码级降级（已发布包 CSS 令牌名）并记为"已定降级"。三项**各自**清零 | ①运行时仍有别的占用者：list 全量渲染（D1-①），只影响布局密度，**验收不变**，在 `04-selfcheck.md` 已知缺口里记"与既有条目并排"；②activity 展开隐藏 right：接受为宿主行为，**判据不变，但覆盖范围减 activity 展开态、记已知限制**（原写"验收不变"与同句"该态未验"互斥，本版按 N-9 改），B1 记录表标"activity 展开态未验"，客户知情记录见 `01` §8.5；③令牌清单取不到：用已发布包 CSS 的令牌名（源码级），P3 复核，**验收不变**。三项都既无结论也无降级（探针也不渲染）→ 按 R2 挂起 P2，不伪造 | B1 可达性记录；②的口径 = 判据不变、覆盖范围减该态 |
| U2 | 命令通道**分钟级长 unary** 与**取消传播**（D9/D14） | 安装探针命令 `/draft-studio-selftest`（宿主 handler `sleep 60s` 后返回；注册 `signal.addEventListener('abort')` 写时间戳）；客户端按钮调用之；再发一次并中途 abort | 契约层已验：`execute(agent, line, attachments, signal)`、`CommandInvocation.signal`（本轮 Inspect）；第三方运行时调用 **UNVERIFIED** | ①60s 调用成功返回且文本完整；②abort 后 2s 内 handler 侧 `signal.aborted === true`；两条命令 + 输出留痕 = 清零 | ①长调用被限 → 降级 B（后台任务+短命令轮询）：B3/B13 判据不变，只多一次轮询命令的 `command/run`；②取消不传播 → 宿主自建计时 + 客户端本地置态：B12 判据不变，浪费一次请求，记已知问题。**降级选择写死在本节，不允许 P2 现场再议** | R1 主链路；B3/B12/B14 的证据形态 |
| U3 | 命令行长度上限（草稿可能数千字） | 同一探针：客户端发 8000 字符 payload，宿主原样回显 | 契约层未发现行长度限制字段（`CommandDefinition` 只有 `input.hint`）；实际网关未验 | 原样回显 8000 字符 = 清零 | 被截断/拒绝 → 降级 A（HTTP 路由，先过 U4）；HTTP 也不行 → 载荷分块（\n 拼接）+ 宿主重组。**验收变化**：B21 的"含芯片长草稿"用例取上限改为"实测最大可传长度"，并在 04 记录 | R1；B3/B13/B21 的输入规模 |
| U4 |（条件）插件自建 HTTP 路由的鉴权行为，仅当 U2/U3 失败需要降级 A | **端口不许写死**（本版回写，见 06 §4/§9）：先用 `Get-NetTCPConnection -State Listen` 取当前实例的监听口，再对该口做对照探测。本机实测 pid 17760 同时监听 **6727（浏览器口）/ 6728 / 6729 / 8326（Bearer 口）**，**8314 无监听**（旧文本写死的 8314 在本轮实例上连接被拒，已删除）。探测：对照 `GET /`、`GET /__probe_no_route__`、`GET /api/nope`，再用**已在运行的前代插件**充当"探针件"（不违反"不安装"约束）：`POST /dsh-draft-studio/refine`，无任何凭证 | **已验（运行时，06 §4）**：`GET /` → 401、`GET /api/nope` → 401、`GET /__probe_no_route__` → 404、`POST /dsh-draft-studio/refine`（无凭证）→ **200 + 业务 JSON**。根因（源码级）：`dsh-host-webserver/lib/index.js:459-472` 的 `handle()` 对**命名路由**直接 `responder.handler(req,res)`，**不经过** `connection.admit()`；鉴权只在 `/api` 路由（`dsh-client-connection/lib/index.js:1049-1058`）与 index 分支上做。同一路由在浏览器口裸奔、在 Bearer 口 401 | 返回 200/约定体 = 可用（**已达成**）；401 → 页面内带凭证 fetch 再试；仍 401 → 放弃该通道，走 U2 的降级 B | 不适用（本条本身就是降级探针；其失败后果已并入 U2 的降级链）。**但"可用"带一个硬约束**：插件路由默认**无鉴权**，本机任意进程可调用并触发真实 LLM 调用（暴露面限于本机 + 浏览器口，`webServer` 拒绝绑定通配地址，`dsh-host-webserver/lib/index.js:301-307`）。因此**若走降级 A，route handler 必须自带守卫**（固定 token 或 `Sec-Fetch-Site`/`Origin` 检查），见 §5-R10 与 §7.4 | 仅降级 A |
| U5 | workspace bundle 运行时能否 `import '@deepseek-ai/schemastery'`（D12） | 先只读：`pnpm view @deepseek-ai/schemastery version`（已跑，3.19.0）；再读本机 profile 与在装包（06 §3-U5）：profile 已装 `@deepseek-ai/schemastery@3.19.0` 且显式声明依赖 `^3.18.1`；在装包 `dsh-draft-studio@1.2.2` 的 `index.js:121` 用 `export const Config = z === undefined ? undefined : z.object({…})`，其投影在运行中的宿主里**成功**（`listConfigs {entry:"include:dsh-draft-studio"}` 返回完整 schema + 每字段 `x-cordis.volatile`）；宿主 `dsh-app-boot/lib/index.js:3197-3201` `isNativeConfigSchema` 要求 `Reflect.get(value, Symbol.for("schemastery")) === true`，前代过了这关 | **已验（运行时，等价形态）**（06 §3-U5） | `listConfigs` 返回本插件条目且 `status` 不是 `schema` 报错形态 = 清零；安装后再用 `{name:"@local/dsh-draft-studio"}` 复核一次（成本≈0） | 不成立 → 走 D12 文件降级：设置存插件自有 JSON。**验收变化**：仅证据形态变（`dump-settings` 输出代替 Config 投影），B18/B19/B6 判据逐字不变；用户失去 cordis.patch.yml 编辑入口，记已知问题 | B18/B19/B6 的实现载体 |
| U6 | `volatile()` 字段 + 默认值的**实际读取语义**（改完是否立即被下一次 `config.field.get()` 读到；不设置的字段是否为 `undefined`） | 源码链（06 §3-U6）：`schemastery/src/index.ts:521-529` `Schema.resolve` 对 `meta.volatile` 返回 `createVolatile(value)`；`cosmokit/lib/index.js:116-123` `createVolatile(v)` → `Object.freeze({get:()=>current, [write]: v=>{current=v}})`；`cordis-plugin-loader/lib/index.js:513-558` `_commitVolatile()` —— volatile-only 变更走**原地引用更新、不重载插件**；默认值在 `schemastery/src/index.ts:769` 区域 `meta.volatile ? createVolatile(meta.default) : meta.default`。运行时旁证：前代 schema 默认值全部被正确投影（`timeoutMs` 480000、`contextMaxMessages` 8、`contextMaxChars` 4000、`presetButtons` 四值、`enabled` true） | **已验（源码 + 运行时投影旁证）**（06 §3-U6） | 回显出现新值 = 清零；为 `undefined` → 记"默认值兜底必要"，代码里 `?? 默认值`（设计内） | 语义不符 → 同 U5 的文件降级（文件每次请求重读，语义确定）。**验收变化**：B18 证据改走 `dump-settings`，判据不变 | B18 即时生效 |
| U7 | 本插件设置命名空间（D18） | 运行时：全量目录 229 条 `id === "include:" + patchId` 无一例外（06 §3-U7），但 `id` 是**显示 id**；设置命名空间是 `entry.options.id`（裸 patchId）。`include:dsh-draft-studio` 的 `patchId === "dsh-draft-studio"` 即 patch 行 `id`。**并存裁定后本插件 patch 行 `id` 定为 `lab-draft-studio`**（`06-lead-decision.md` §1），故设置命名空间为 **`lab-draft-studio`**（`Config.listConfigs.id` 的显示形态是 `include:lab-draft-studio`）；在装的 `include:dsh-draft-studio` 保持不变、不相撞 | **已验（运行时形态）**；本插件具体值待安装后复核（设计内） | `configForms.get('lab-draft-studio')` 返回 `status:"ready"` = 清零 | 命名空间与预期不符 → 设置页首帧 `describe()` 按 name 全表匹配（设计内，无验收变化）；匹配仍失败 → 走 D12 文件降级 | B18 设置读写寻址 |

**P1.5 执行顺序**：S1 一次性完成——探针 bundle 打包 → 用户批准安装 → U1（页面在线）→ U2/U3（同一探针命令）→ U5/U6/U7（同一安装）→（仅当失败）U4 → 结论写回 `probes.md` → 门评审。全程**不写业务代码**；探针命令只允许 `/draft-studio-selftest` 与 `/draft-studio dump-*` 系列的最小实现（dump-* 是验收证据命令，属探针件范围）。

---

## 4. 开发顺序与每步完成标志

> 每步的"完成标志"都必须是**可复跑的命令或可核对的事实**（`01` §4 口径），不接受"感觉好了"。

**S1 探针闭环（P1.5 门内的唯一步骤）**
- 内容：`@local/dsh-draft-studio-selftest` 探针 bundle（selftest 命令 + 最小插槽组件 + dump-* 命令骨架）。
- 完成标志：`node scripts/check-syntax.mjs` 通过；U1/U2/U3/U5/U6/U7（+U4 若触发）在 `probes.md` 各有一条「结论 + 出处（命令+输出 或 文件:行）」；`01` §9 表同步更新。
- 不通过的处理：按本节降级链改设计，**改完回写本文件 §1/§2** 再进 S2。S1 未清零 → P2 不开工。

**S2 bundle 骨架（P2 第一步，入口 = S1 清零）**
- 内容：`package.json`（name **`@local/lab-draft-studio`**（v3.2 并存裁定，见 §1）、exports 含 `./client`、`./locale/*.json`、`./icon`，`files` 白名单）、`cordis.patch.yml`（一行 insert，**`id: lab-draft-studio`**）、`index.js`（宿主半骨架 + 设置载体——**按 P1.5 U5/U6 的结论二选一**：Config schema，或 D12 的文件存储；U5/U6 已验 → **走 Config**）、`client.js`（空工厂）、`locale/zh.json`+`en.json`（meta.title/description + 全部界面文案；`meta.title` 用实验前缀）、`icon.svg`（原创）。
- 完成标志：`node scripts/check-syntax.mjs` 通过；`files` 白名单与磁盘文件三方差集为空（写进 04-selfcheck 对账表）。
- **并存约束（v3.2）**：不改动在装的 `dsh-draft-studio@1.2.2`；所有对外可见的 id 一律带 `lab-draft-` 前缀，禁止复用 `dsh-draft-studio` 这一 entryId / 座位 id / 设置页 id（复用 `dsh-draft-studio` 会落进前代的 cell 并替换它）。

**S3 纯逻辑层（全在 Node 测试内判红绿）**
- 模块：`lib/config-schema.js`（20 项 schema+默认值，#17 下限 30s 校验）、`lib/boundary.js`（空草稿/含 `/` 芯片/含 `@`/含附件的判定）、`lib/wire.js`（命令行载荷编解码 + 结果 JSON 编解码，含转义与长度防护）、`lib/prompt.js`（四套预设模板 + **结构块逐字常量** + 上下文折叠）、`lib/run-store.js`（按会话键的运行状态机：idle→running→done/failed/retry-pending；取消；发送自停）、`lib/context.js`（轮数/字数折叠与"没读的原因"）、`lib/llm-options.js`（`composeLlmOptions(config, sessionSelection)` 纯函数）。
- 完成标志：`node --test "test/*.test.js"` 全绿；`boundary`、`run-store`、`prompt`（结构块逐字断言 + 四套 sha256 两两不同）各至少一条**先红后绿**记录（改坏→红→还原→绿，输出贴进 04-selfcheck）。
- B1–B21 中可纯逻辑判定的部分标注到测试文件与用例名（P3 抽查）。

**S4 宿主半**
- 内容：注册 **`/lab-draft`** 命令族（v3.2 前缀；`dump-request/dump-settings/dump-draft/save-settings`）；读设置；读会话上下文（D11）；`prepareCall` 装配（跟随/固定、`configure` 强度检测、480s 超时、`LAB_DRAFT_STUDIO_TIMEOUT_MS` 自测注入仅限 `LAB_DRAFT_STUDIO_SELFTEST=1`）；结果 JSON（文本 + `presetId/systemSha256/prepared.config/effortFallback/timeoutSource/readRounds/readChars/reason` 元数据）经命令返回；**`dump-draft` 输出 `{text, references, messageCount}`（`messageCount` = `sessionQuery.readSurface(sessionId).events.length`：当前 surface 事件数，含四类 message 与 `tool/result`，不含 `command/*`/`turn/*`/`step/*`，供 B3，`01` §4.1；读失败 → `null` → B3 记「无法判定」）**；取消贯通（D14）。
- **降级 A 的守卫（v3.2，R10）**：若走 `webServer.register` 自建路由，handler **必须自带守卫**（固定 token 或 `Sec-Fetch-Site`/`Origin` 检查）——06 §4 已实测浏览器口对命名路由不鉴权，裸路由等于给本机任意进程开一个能触发 LLM 调用的口子。
- 完成标志：宿主半单测（注入假 llm/假 sessionQuery）全绿；`dump-request --prepare` 在本机对四套 preset 输出合法 JSON（命令 + 输出贴 04）。
- 覆盖验收：B5（四段 dump-request 输出）、B8/B9（`prepared.config` + 负向对照）、B10（`effortFallback` + `modelCatalog` 差集）、B17（超时路径单测）、B20（设置读失败路径）、B14（请求计数）。

**S5 客户端半：按钮**
- 内容：`conversation.input.right` 注册 **4 条**，每条 **`id = lab-draft-<presetId>`**（v3.2 前缀；四条互不相同）、`order = 0..3`；组件根节点必须带以下属性（`01` §4 基线片段与 §4.1 按条扩展表依赖它们，缺一个就是证据链断）：`data-draft-studio-seat="conversation.input.right"`、`data-preset-id`、`data-order`、`data-state`、`data-reason-code`、`aria-disabled`、**`data-elapsed-ms`**（毫秒整数，运行中递增）、**`data-hover-text`**（真正会显示的悬停文案原文）；回退/重试/取消控件带 `data-action`（B16/B11 靠它判有无）。四态渲染（秒表、置灰、悬停原因、重试/回退/取消）；`insertText` 写回（span.draftRev 守卫）；芯片边界（B21）降级路径；发送自停（监听 `phase`）；会话切换不取消（store 在插件 context）。**过滤属性 `data-draft-studio-seat` 保持原字面量不变**（`01` §4 片段与前代 0 命中的实测都建立在它上；实验前缀只加在 id/包名/标题上，不加在探针属性名上）。
- 完成标志：安装后按 **B1、B3、B4、B11、B12、B13、B14、B15、B16、B21** 现场走查，每条记录 = **§4 基线片段 JSON（B3/B11/B15/B16 再按 §4.1 追加键）** + `command/run|done` 条数 + `dump-draft` 快照（命令 + 输出）；截图仅辅助。**走查全程保持活动面板收起**（`01` §3.0 走查规程）；若中途展开，该条记「无法判定/未验」，收起后重跑。
- 明确不做：不写宿主 DOM、不加第二个 app、不 require 宿主 primitive 包。

**S6 客户端半：设置页**
- 内容：`settings.section` 注册（**`id: lab-draft-studio`**，v3.2 前缀；含 icon）；**19 项可改表单**（#1–#19）+ **#20 只读回显**（无输入控件）；预设编辑门（B19，未保存计数 = 字段数）；就地改名 ≤12 码位（B7）；恢复默认二次确认；勾选显示（B6）；模型来源与固定模型选择器（D6）；保存走命令通道，改完即读（B18）。
- 完成标志：安装后按 **B6、B7、B18、B19** 走查；"即时生效"用 `dump-request` 观察超时/温度新值（不再用 1 秒实测，见 `01` §3-B18）；B18 负例 = 第 20 项出现可编辑控件即红。
- **并存后果（v3.2，R11）**：设置导航里会同时出现**两个**草稿工坊页（前代 `dsh-draft-studio` 与本项目 `lab-draft-studio`）。本项目的页标题带实验前缀（"草稿工坊（实验）"），走查记录里必须注明"另一套不是本次交付物"。

**S7 降级路径**
- 内容：设置不可用→单按钮（B20）；固定模型缺失→退跟随（A8）；空结果→失败态 `empty-result`（A12）；`@` 丢标记→待重试 `reference-lost`（B21）；U2/U3 失败时的通道降级（按 §3 已选定的链）。
- 完成标志：每条降级各有单测（注入故障）+ 一条现场走查记录（命令 + 输出）。

**S8 证据打包进 P3（含 U8 走查）**
- 内容：U8 = 对 `01` §3 B1–B21 全部 21 条的现场走查（此前散落在旧 U 清单里的"最终裁决"性质）。走查执行 `01` §3.0 的规程：**全程保持活动面板收起**；中途展开的条目记「无法判定/未验」不记通过，收起后重跑并留两次片段 JSON。
- 完成标志：`04-selfcheck.md` 含：全部自验命令原文、**21 条验收的判定表（三态 + 证据命令）**、红绿证明、已知缺口（activity 展开态、Ctrl+Z 附加观察等）——activity 展开态按 `01` §8.5 的知情记录列示，签收人 = 客户（P4）。

**验收覆盖映射（每条 B 都有明确归属，不允许靠 S8 兜底）**

| 步骤 | 覆盖 |
|---|---|
| S3 单测 | B2（boundary）、B4 快照语义、B5 结构块/sha256（prompt）、B13 竞态（run-store）、B19 计数（config-schema） |
| S4 | B5/B8/B9/B10（dump-request）、B17（超时）、B20（设置失败）、B14 请求计数 |
| S5 | B1、B3、B4、B11、B12、B13、B14、B15、B16、B21 |
| S6 | B6、B7、B18、B19 |
| S7 | B20 终态、A8/A12/B21 降级 |
| S8/U8 | 21 条总表 + 未覆盖项复核 |

---

## 5. 风险清单

| # | 风险 | 触发条件 | 应对 | 等级 |
|---|---|---|---|---|
| R1 | **命令通道不是为"数据管道"设计的**：分钟级 unary 被网关限制 / 命令行长度上限 / `/` 菜单用户可见副作用 | U2/U3 失败 | P1.5 出二值结论后才写业务代码；降级链 A（HTTP 路由，U4 先验鉴权）→ B（后台任务+短命令轮询）都藏在 S4 接口后；A/B 都不行 → 回退形态"设置页内改写 + 复制粘贴回输入框"，B3/B13 记不通过并作为已知缺陷交付，**不伪造验收** | **最大风险** |
| R2 | 客户端结论全部来自源码级证据，Client Inspect 超时（已两次实测） | U1 两次路径都失败 | 探针 bundle 做最终裁决；探针也不渲染 → 挂起 P2，不伪造"通过" | 高 |
| R3 | schemastery 依赖解析失败 / volatile 语义与文档不符 | U5/U6 失败 | 文件型设置降级（D12），20 项与判据不变；B18 证据改 `dump-settings` | 中 |
| R4 | `@` 引用重建依赖模型保留标记 | 模型丢标记 | 按"原稿不丢、结果待重试"降级（B21 写死，不静默写回） | 中 |
| R5 | 改写写回与用户输入的竞态 | 用户在等待期打字 | span.draftRev 守卫 + run-store revision 比较，双保险；单测覆盖"等待期改字" | 中 |
| R6 | 会话切换/发送的边界（B14） | 切走再切回、发送 | run-store 按会话键存于插件 context；监听 input phase 自停；单测+走查 | 中 |
| R7 | 480s 超时下用户以为卡死 | 长等待 | 秒表+取消前置（B11）；超时原因文案明确；不缩短默认值（客户定的约 8 分钟） | 低 |
| R8 | **list 座位注册缺 `id` 抛错**（运行时 `requires options.id`） | S5 注册代码漏 id | `id = presetId` 写进 S5 步骤定义与单测（注册表构造函数断言 4 条 id 互异）；出现即开发期红，不会到验收 | 中 |
| R9 | **activity 展开隐藏 `right`**（`standardControls` 带 `hidden: activity`），按钮"消失" | 用户展开活动面板 | `01` §3.0 P2 把判定前提限定在未展开态；B1 记录表标注该态未验，客户知情记录见 `01` §8.5（触发/表现/恢复/签收人）；**不换座位**——`left` 所在的 `tools` 容器同样带 `hidden: activity`（`ui-conversation-client.js:22071`），换过去一样消失；`dock` 保可见但正是 B1-e 判红的落点。判据不变，只减该态的覆盖 | 中 |
| **R10** | **插件自建 HTTP 路由在浏览器口默认无鉴权**（v3.2 新增，06 §4 运行时实测） | 走降级 A（`webServer.register` + 页面同源 fetch）时 | 根因：`dsh-host-webserver/lib/index.js:459-472` 命名路由绕过 `connection.admit()`。应对：**route handler 必须自带守卫**（固定 token 或 `Sec-Fetch-Site`/`Origin` 检查），并在 `08-selfcheck.md` 记为已知风险；暴露面限于本机 + 浏览器口（`webServer` 拒绝绑定通配地址，`:301-307`），不是 LAN/公网。**这是前代产品现在就有的问题**（`/dsh-draft-studio/refine` 无凭证 200），属已知问题留档，不属于本流程实验的缺陷 | 中 |
| **R11** | **与在装 `dsh-draft-studio@1.2.2` 并存导致用户看到两套控件**（v3.2 新增） | 安装本项目后 | 交付形态改为显式并存（`06-lead-decision.md` §1 = 方案 B）：包名/`meta.title`/座位 id/设置页 id 全加 `lab-draft-` 前缀，README 首段写明"实验产物、与已装 Draft Studio 并存、功能不共享"；**不删除、不停用、不改动**前代及其数据。界面后果如实记录：工具行并排 = 前代 1 + 队友选择器 1 + 本项目 ≤4 = **最多 6 个控件**，设置导航里出现**两个**草稿工坊页（不同 id）。验收判据不受影响（`data-draft-studio-*` 过滤，前代 0 命中） | 中 |

---

## 6. P2 开工前置（gate checklist）与一致性自检

### 6.1 前置清单

- [x] A1/C1 已结案：座位 = `conversation.input.right`（list 主座位），`01` §7-A1、§8；本文件 §1。客户答复已回填，**无"待裁定"残留**（复核命令见 6.2 第 9 行）。
- [x] **04 复审的 3 项已清**：N-1（B1-e 可观察字段 + 模型缺失记无法判定）、N-2（§4 基线片段 + §4.1 按条扩展，S5 属性清单补齐）、C-1（activity 展开态的客户知情记录 `01` §8.5）。客户回执本身在 P4 随已知问题签收，**本轮不伪造**；逐条回应见 §7.2。
- [ ] **P1.5 清零**：U1/U2/U3/U5/U6/U7 全部「已验 / 已定降级 / 无法判定+接受人」，结论在 `probes.md`（每条带出处）。
- [ ] 安装批准在案：P1.5 只装探针 bundle；本轮 P0/P1 未装任何东西，符合任务边界。
- [ ] 页面在线（U1 需要）；探针命令可执行（U2/U3/U5/U6/U7 需要）。
- [ ] S1 探针件通过语法检查。
- [ ] `01` 的 **21 条**验收（B1–B21）被第二人读过（P3 审查员或客户）。
- [ ] 6.2 一致性自检表无红行。

### 6.2 内部一致性自检表（同一事实的唯一口径 + 出现位置）

| # | 事实 | 唯一口径 | 出现位置 | 一致？ |
|---|---|---|---|---|
| 1 | 按钮上限 | 4（勾选决定 0–4；总开关关 = 0） | `01` §3-B1、§5#1/5；`02` §1、S5 | ✓ |
| 2 | 预设数 | 4 套（presetId: general/coding/writing/translate） | `01` §3-B5、§5#6–9；`02` S3/S5 | ✓ |
| 3 | 配置项 | 20 项 = **19 可改 + #20 只读** | `01` §3-B18、§5、§7-A13；`02` S6 | ✓ |
| 4 | 超时 | 取值 **30–600 秒**、默认 **480 秒**；1 秒仅自测注入（`DSH_DRAFT_STUDIO_SELFTEST=1`） | `01` §3-B17、§5#17；`02` S4、§6.2 | ✓ |
| 5 | 温度 | 0–1，默认不设置；验收用 0 | `01` §3-B5、§5#18 | ✓ |
| 6 | 上下文 | 1–20 轮 / 200–8000 字符 | `01` §5#3/4；`02` S3 `lib/context.js` | ✓ |
| 7 | 显示名 | ≤12 **Unicode 码位** | `01` §3-B7、§5#10–13 | ✓ |
| 8 | 验收条目数 | **21 条（B1–B21）** | `01` §3；`02` S8、6.1 | ✓ |
| 9 | A1 状态已结案 | `01` §7 的 A1 行类型字段 = `自查可解（已结案）`；§8 标题 = 「客户答复回填（C1 已结案）」；本文件 §6.1 第一项 = `[x]` | `01` §7/§8；`02` §6.1 | ✓ 复核命令：`Select-String -Path 01-requirements.md -Pattern '^\| A1 '` → 输出含 `自查可解（已结案）`；`Select-String -Path 02-plan.md -Pattern 'A1/C1 已结案'` → 命中 **≥1 行**（v3.1 实测 2 行：§6.1 与本行；不再写死行号） |
| 10 | 模型/强度证据源 | `dump-request`（含 `prepared.config`）+ 宿主拒绝错误文本；`command/run\|done` 只证次数/取消/错误类别 | `01` §3-B8/B9、§4；`02` D7/S4 | ✓ |
| 11 | 探针门范围 | U1/U2/U3/U5/U6/U7 常态 + U4 条件；U8 归 S8 | `02` §3、§4、6.1；`01` §9 | ✓ |
| 12 | 座位契约 | 每条 `id = presetId`、`order 0..3`；无 sessionId 不渲染；activity 展开时 `standardControls` 整行隐藏（DOM 在：`count` 仍 4、`visible` 全 false） | `01` §3.0、§7-A1、§8/§8.5；`02` D1、S5、R8/R9 | ✓ |
| 13 | 输出长度上限 | **256–8192 tokens**，默认不设置（用宿主默认） | `01` §5#19 | ✓ |
| 14 | 上下文默认值 | 轮数默认 **6** / 字符默认 **2000** | `01` §5#3/4；`02` S3 `lib/context.js` | ✓ |
| 15 | 秒表采样的最小差 | 两次 §4 片段采样间隔 ≥1 秒、`elapsedMs`（`data-elapsed-ms`）差 **≥900ms** | `01` §3-B11、§4.1；`02` S5 | ✓ |
| 16 | 未保存计数的范围 | 被改动字段数，对象 = §5 **#6–#13 共 8 个字段**，跨四套合计、同字段去重 | `01` §3-B19；`02` S6 | ✓ |
| 17 | B1-e 的观察字段 | `modelFound` / `rowRects` / `visible` / `inDock` / `hiddenByActivity` / `leftOfModel` 全部取自 `01` §4 基线片段；`modelFound=false` → 整条「无法判定」；`count===4` ∧ `visible` 全 false ∧ `hiddenByActivity=true` → 整条「未验」，面板收起后仍 false → 「不通过」 | `01` §3-B1-e、§3.0、§4；`02` S5 | ✓ |

---

## 7. 返工记录：针对 03 / 04 报告的逐条回应

> 7.1 之前（本节正文）对照 `03-gate-P0P1.md` 的缺陷编号（B-1/B-2、M-1～M-8、m-1～m-9）与上一轮任务要求的 7 条返工项；**7.2 是对 `04-regate-P0P1.md` 的 v3 增量回应**。每段：改了什么 → 落点 → 依据。

**A1 改判（回应 B-2/M-8，任务第 1 条）**：A1 从「客户裁定」改为「自查可解·已结案」，落点写死为 `conversation.input.right`——它是宿主声明的 **list** 座位、渲染在模型选择器之前（源码 `dsh-client-ui-conversation/lib/client.js:22982–22985`、`:22110`），天然容纳 1–4 条不同 `id` 的按钮，因此是**主座位**，不是容差妥协；上一版"发送键与模型选择器之间只有单占位插槽"的窄命题只对 `activity` 成立，对 `right` 不成立，该表述已删。`01` §7-A1 重写（含四条出处）、§8 整节改为"客户答复回填（C1 已结案）"，引用 `00-client-answers.md` 两段原文并把"列表座位优先是第一优先"落进判据；§7 表头与 §0 速查都标注"本版无待裁定项"；`02` §1 按钮落点行同步改写，§6.1 第一项改为已勾选。复核命令与期望输出见 §6.2 第 9 行（A1 类型字段 = `自查可解（已结案）`）。

**B5 可机判化（回应 B-1，任务第 2 条）**：删除"人工按预设意图判读方向对"与"两两不完全相同"这两处不可复跑判据，改为三层：①请求侧——四套预设的 system 段**逐字包含**各自的结构块（`01` §3-B5 结构块原文表），`/draft-studio dump-request` 输出 `system` 与 `systemSha256`，断言 sha256 两两不同且标记行 `preset=<id>` 与请求一致；②输出侧——`node scripts/assert-preset.mjs` 对四份改写稿跑**各有独立判据（部分区分）**的正则谓词（general=要点、coding=编号步骤、writing=段落保留且无编号且无 ≥3 条要点行、translate=CJK≤5%），结构差异由谓词区分度保证（v3 按 §7.2.2-N-3 补 writing 第 4 条；v3.1 补 translate 第 4 条并写明 writing↔translate 的交集），不需要人看；③随机性控制——温度 0（§5#18）+ 固定模型/强度 + 每套最多 2 次重跑。负例改为三个可构造的红：模板映射写死（sha256 相同）、结构块串台、coding 输出无编号步骤。落点：`01` §3-B5 全节重写、§5#6–9 与 #18 注明结构块与温度用途、`02` S3（`lib/prompt.js` 结构块逐字常量）、S4（dump-request）、S8（assert-preset.mjs）。

**B1 与总开关冲突（回应 M-1，任务第 3 条之一）**：`01` §3-B1 拆成 B1-a（开关开+全勾→N=4）、B1-b（勾选数=N）、**B1-c（总开关关→N=0，单列验收）**、B1-d（空稿→0）、B1-e（位置）；`1 ≤ N ≤ 4` 的旧写法删除。"遮住编辑区"给出可操作定义：按钮与编辑区矩形相交面积 = 0 + 按钮在模型选择器左侧 + 垂直落在工具行内，由 §4 的 console 布局片段输出 JSON 判定。落点：`01` §3-B1、§3.0、§4 片段。

**超时口径统一（回应 M-2，任务第 3 条之一）**：设置项 #17 定为 **30–600 秒、默认 480 秒，<30 秒拒绝保存**；B17 的两条验收路径——正常路径用下限 30 秒 + 构造慢请求，自测注入通道 `DSH_DRAFT_STUDIO_TIMEOUT_MS=1000` 仅当 `DSH_DRAFT_STUDIO_SELFTEST=1` 生效且 `dump-settings` 标 `timeoutSource:"selftest"`。**1 秒测试与 30 秒需求下限的关系就此写清**：1 秒不是配置值，是只为"不等待 30 秒"而存在的测试钩子，用户可见配置域始终 30–600。B18 负例同步改掉"改超时为 1s"。落点：`01` §3-B17、§3-B18、§5#17；`02` S4、6.2 第 4 行。

**20 项可改 vs 只读展示（回应 M-3/m-9，任务第 3 条之一）**：二选一已定：**19 项可改 + 第 20 项"上次改写回显"只读**，并把该判定记为新增歧义 A13（自查可解，依据：原文第 12 条"回显"语义只能是读）。B18 的观察改为"#20 无输入控件、`data-readonly=true`"；S6 同步为"19 项可改表单 + #20 只读回显"；`01` §5 表 #20 标注只读。若客户坚持"20 项全可改"，路径是改 §5 表新增一项能力（只改表不改验收结构），已写在 §5 说明里。落点：`01` §3-B18、§5、§7-A13；`02` S6、6.2 第 3 行。

**B8/B9/B10 证据源更换（回应 M-4/m-5，任务第 3 条之一）**：`command/run|done` 不再承担"模型、强度"的证明——契约 `CommandInvocation` 只有 `{commandId, agent, rawInput, attachments, signal}`（本轮 `cordis_inspect_query(host, Service, listService, {service:"commands"})` 输出），日志只是同一次调用的 log-only 追加。替代证据链：①`/draft-studio dump-request <preset> --prepare` 输出装配结果与**宿主 `llm.prepareCall` 物化后的 `prepared.config`**（宿主侧校验/物化，Inspect 契约原文见 `01` §4）；②负向对照 `--negative=model|effort`——塞入不存在的 model/不支持的 effort，宿主以错误拒绝且错误文本含该值，证明字段真到达宿主；③跟随模式的界面独立来源 = 会话模型选择器显示值。B10 的"选一个不支持 S3 的模型"改为**确定性构造**：从 `modelCatalog` 取跨模型 efforts 差集（差集为空再退用未知强度串），输出 `effortFallback=true` 且 `prepared.config.reasoningEffort === defaultEffort`；实现改走 `prepareCall(config, signal, configure)`，强度检测先于 I/O。落点：`01` §3-B8/B9/B10、§4（证据清单 + "明确不接受的证据"）、`02` D7/D8/S4、6.2 第 10 行。

**P1.5 探针门（回应 M-5，任务第 4 条）**：按规格 v2 新增 `02` §3「P1.5 探针门」，把 U1/U2/U3/U5/U6/U7 从 P2 里拿出来；U4 保留为条件项（只有降级 A 需要时才探，且必须在门内完成）；U8 移出探针门、归 S8 验收走查（它是行为验证，不是依赖探测）。每条写清：探什么 / 怎么探（命令原文，只读优先）/ 现已得到的结论与出处（U1 的静态契约已闭环、U5 的 `pnpm view` 已证 3.19.0、U7 的 229 条目录形态已验）/ 清零判据 / 探不到时的降级与降级后验收如何变化 / 影响面。出口判据逐条对齐规格 v2 §P1.5（已验/已定降级/无法判定+接受人），**清零后才允许进 P2**；S1 重新定义为"P1.5 门内的唯一步骤"，S2 起才是 P2；`02` §6.1 的门 checklist 从"补探方法可执行"改为"P1.5 清零"。落点：`02` §3、§4-S1/S2、§6.1；`01` §9 三态表同步指向 P1.5。

**D1 补全（回应 M-6/m-8，任务第 5 条）**：D1 从一条扩为四条硬契约并全部带源码出处：①每条注册必须 `options.id`（`index-BgUyXZcc.js` 偏移 492065–492133，缺 id 抛 `requires options.id`；渲染端 `dsh-client-ui-renderer/lib/client.js:1203–1221` 按 `order` 全量渲染）；②渲染条件 `input !== undefined && sessionId !== undefined`（无 sessionId 不渲染，`client.js:22110`）；③`standardControls` 带 `hidden: activity`，activity 展开时 `right` 与 `model` 一起隐藏（`client.js:22107–22111`）；④`renderSlot` 传空 props。三项全部进依赖清单与风险表（新增 R8"注册缺 id 抛错"、R9"activity 展开隐藏"），并写明**对验收的影响**：`01` 新增 §3.0 观察前提（P1 sessionId、P2 activity 未展开、P3 id 必填），B1/B2 判定以默认态为准，activity 展开态记"未验"不判失败；S5 的注册步骤写死 `id = presetId`、`order 0..3` 并要求组件带 `data-*` 属性供片段读取。落点：`01` §3.0、§3-B1、§7-A1、§8；`02` D1、S5、R8/R9。

**S5 证据口径（回应 M-7，任务第 6 条）**：S5 完成标志从"每条记录三态与证据（截图+日志）"改为"每条记录 = 布局片段 JSON + `command/run|done` 条数 + `dump-draft` 快照"，截图降为辅助；`01` §4 整节重写为"只承认 文件:行 与 命令+输出"，并给出允许的命令清单（inspect/asar-probe/pnpm view/node --test/dump-*）与页面 console 片段，明确列出三类不接受的证据（含"command/run 证明模型强度"）。落点：`01` §4；`02` S5/S8、6.2 第 10 行。

**内部一致性（回应判据与任务第 7 条）**：新增 `02` §6.2 一致性自检表，12 行逐项钉死唯一口径与出现位置（按钮上限 4、预设 4 套、20=19+1、超时 30–600/480、温度 0–1、上下文 1–20 轮与 200–8000 字、名字 ≤12 码位、**验收 21 条（旧文误写"20 条"已改）**、无待裁定残留、模型证据源、探针门范围、座位契约）；`02` §6.1 第 6 项与 S8 同步为 21 条。`01` 侧同步修正：§9 三态表与 §0 速查、§5 表头说明。落点：`02` §6.2、§6.1、S8；`01` §0/§9。

**MINOR 一揽子（回应 m-1～m-4、m-6、m-7）**：m-1 B19 的 N 定义为"被改动的配置项个数（#6–#13，跨四套合计，同字段去重）"（`01` §3-B19）；m-2 B15 删"可读"，改为 `data-reason-code` 六值枚举 + 中文文案 + 无英文栈的可断言判据（`01` §3-B15）；m-3 B21 补判定动作（占位符残留但 `references` 变少 = 半损坏；引用仍可点 = 通过）（`01` §3-B21）；m-4 B16 明确操作对象与观察字段（`01` §3-B16）；m-6 D17 从"已验(契约)"降为 `UNVERIFIED` 并入 U1（`02` §2-D17、§3-U1）；m-7 D9 显式标注第三方可用性 `UNVERIFIED`（`02` §2-D9、§3-U2）。

**本轮新增的只读复核（供 P3 复用）**：①`case"list"` 要求 id：`asar-probe -Get dsh-web-frontend/dist/assets/index-BgUyXZcc.js` + 字符偏移定位（本轮实测偏移 492065/492133）；②渲染条件与 hidden：`client.js:22107–22111`（本轮重读）；③list 全量渲染按 order：`dsh-client-ui-renderer/lib/client.js:1203–1221`（本轮重读）；④`llm.prepareCall`/`CommandInvocation` 契约：本轮 `cordis_inspect_query` 全文输出；⑤Config 目录 229 条 id 形态：本轮 `Config.listConfigs` 两页；⑥`pnpm view @deepseek-ai/schemastery version` → 3.19.0（本轮命令输出）。以上命令均写在 `01` §4 与 `probes.md` 复跑块，全部只读、未安装、未碰 `$DSH_HOME`。

### 7.1 落点索引（审查员逐条定位用；行号为**返工版 v2** 最终行号）

> v3 在 v2 上做了增补，行号已整体下移；**v3 的落点见 §7.2.3**，本表保留为 v2 的历史索引（`04` 报告引用的就是这套行号）。

| 返工项 | 文件:行 |
|---|---|
| A1 改判（任务 1） | `01-requirements.md:400`（A1 行）、`:416`（§8）、`:31`（§1 位置段）；`02-plan.md:16`（§1 按钮落点行） |
| B5 可机判（任务 2） | `01-requirements.md:119–159`（§3-B5）、`:347–372`（§5 表 #6–9/#18）；`02-plan.md:96`（S3）、`:101`（S4） |
| B1 与总开关（任务 3a） | `01-requirements.md:62`（§3.0）、`:72–94`（§3-B1）、`:314`（§4 布局片段） |
| 超时口径 30/480/1s（任务 3b） | `01-requirements.md:248–255`（B17）、`:369`（§5#17）；`02-plan.md:101`（S4） |
| 19 项可改 + 1 只读（任务 3c） | `01-requirements.md:257–264`（B18）、`:347`（§5 表头）、`:412`（A13）；`02-plan.md:111`（S6） |
| B8/B9/B10 证据源（任务 3d） | `01-requirements.md:176–195`（B8/B9）、`:197–205`（B10）、`:292`（§4）；`02-plan.md:45–46`（D7/D8）、`:101`（S4） |
| P1.5 探针门（任务 4） | `02-plan.md:60–79`（§3）、`:87`（S1）、`:152`（§6.1）；`01-requirements.md:433`（§9） |
| D1 硬契约三条（任务 5） | `02-plan.md:39`（D1）、`:147–148`（R8/R9）；`01-requirements.md:62`（§3.0 P1–P3） |
| S5 证据口径（任务 6） | `02-plan.md:106–109`（S5）；`01-requirements.md:292`（§4 全节） |
| 内部一致性（任务 7） | `02-plan.md:164–179`（§6.2）、`:156`（§6.1 第一项）、`:176`（第 9 行复核命令） |

---

## 7.2 返工记录：针对 04 报告的逐条回应（v3 增量）

> 范围声明：只处理 `04-regate-P0P1.md` 的 3 项最小集合（N-1、N-2、C-1，含 N-9/N-8 这两个附带）+ 能顺手改的 N-3～N-7。**座位、架构、依赖矩阵、探针门、上一轮 19 条已清账项均未重做**。每段按"04 的判定 → 改了什么 → 落点"写。

### 7.2.1 最小集合 3 项

**① N-1｜B1-e 观测补字段并改判定（MAJOR）**

04 的判定：③"垂直落在工具行内"没有观察字段、没有"工具行"的定义；`leftOfModel` 在模型选择器缺失时返回 `true`，与片段注释"记无法判定"相反；dock 负例在现有仪器下不会红。

改了什么：

- `01` §4 基线片段新增四个字段：`modelFound`、`rowRects`、`visible`、`inDock`。**"工具行"的定义**写死为"每颗按钮与模型选择器的**最近公共祖先**的 rect"（正常态即宿主 `standardControls` 行）——宿主 DOM 不允许加探针属性，所以不靠 class 名定位，靠共同祖先自证；`inDock` 用宿主源码里硬编码的 `[data-composer-dock]`（`ui-conversation-client.js:22216–22218`，本轮重读确认）；`visible` = `offsetParent !== null && 面积 > 0`。
- `leftOfModel` 改为 `modelFound === false || 座位为空 → null`，原 `!model || …` 返回 `true` 的空真通道删除（N-1 指认的那行）。
- B1-e 判定重写（`01` §3-B1-e）：前置 `count === 4`；`modelFound === false` → 整条**「无法判定」**（不记通过）；判据 = `modelFound` ∧ `visible` 全真 ∧ `inDock` 全假 ∧ `leftOfModel` ∧ 每颗 rect 垂直落在 `rowRects[i]` 内 ∧ `editorOverlap === 0`。
- 负例从 1 条扩成 3 条：dock 负例改为**靠 `inDock` 必红**（04 已指出相交/左侧两条抓不住 dock）；模型选择器缺失 → 无法判定；activity 展开态 → `count===4` 但 `visible` 全 false，记「未验」不得记通过。
- **顺手修了一个 04 没点名的仪器 bug**：原片段把 `getBoundingClientRect()` 直接 `JSON.stringify`——`DOMRect` 的属性在原型上，序列化结果是 `{}`，所有 rect 字段实际不可用；现在 `R()` 先转普通对象。这是补字段时读原片段发现的，不改它 N-1 的 rect 判据就是空转。

落点：`01-requirements.md` §3-B1-e、§3.0（走查规程）、§4 基线片段；`02-plan.md` S5、§6.2 第 17 行。复核：`Select-String -Path 01-requirements.md -Pattern 'modelFound|rowRects|inDock'`（04 §7.4 的命令，模式已兼容复数 `rowRects`）。

**② N-2｜证据片段补字段（MAJOR，04 给了二选一）**

选了 **(b)「基线模板 + 按条扩展」**，并顺带把 (a) 里能在片段里直接补的字段补进基线：

- `01:64` 的声明从"全部观察都必须落成命令+输出"的笼统句改为：**§4 片段是基线模板**（覆盖 B1/B2/B12/B13/B21 与 B1-e），B3/B11/B15/B16 按 **§4.1 按条扩展表**追加键；表里没有的键不允许临场发明，缺就记"无法判定"。
- §4.1 表逐条写明来源（这是 04 要求的"有来源"）：B3 → `messageCount`（**命令**：`dump-draft` 输出，宿主半 `sessionQuery.readSurface(sessionId).events.length` 计数，计数对象见 `01` §4.1）+ `editorPhase`（**片段**：编辑区 `[data-composer-input]` 上的 `data-phase`，宿主源码 `ui-conversation-client.js:20974–20981` 渲染该 div、`:21031` 传入；v3.1 按 05 §3.2 改用稳定选择器）；B11 → `ariaDisabled` + `elapsedMs`（`data-elapsed-ms`）；B15 → `hoverText`（`data-hover-text`）；B16 → `actions`（`[data-action]` 子节点集合）。
- **`messageCount` 不走 DOM 片段的原因写进表**：对 `probe-tools/dump/` 全量检索 `data-message|data-turn|data-chat` 无命中，宿主消息列表没有稳定 DOM 属性，硬编一个选择器等于发明证据；命令输出本身就是 E2。
- `data-elapsed-ms` 加进 `02` S5 的组件属性清单（N-2 的"另一半"），连同新增的 `data-hover-text`、`aria-disabled`；B3/B11/B15/B16 条文同步改为引用具体键名（不再有"悬停内容的文本"这种无来源表述）。

落点：`01` §4、§4.1（新小节）、§3-B3/B11/B15/B16；`02` S5。复核：`Select-String -Path 01-requirements.md -Pattern 'messageCount|elapsedMs|aria-disabled|data-action|按条扩展'`（v3.1 后 §4.1 的追加键名、B3 正文与片段输出三处统一为 `editorPhase`，旧键名已删除；选择器判据见 §7.3）。

**③ C-1｜activity 前提的客户知情 + N-9 措辞 + N-8 走查规程**

04 专项裁定 §5.3：该前提"可接受"但只完成了一半，缺客户知情留痕、观测口径、措辞三样。

- **客户知情记录**：`01` 新增 **§8.5「activity 展开态的客户知情记录」**，表格写明：触发条件（`onActiveChange(true)`）、表现（`standardControls` 整行 hidden，按钮与宿主模型选择器一起不可见，`count===4` 而 `visible` 全 false）、恢复方式（收起面板；会话切换重置）、影响（只减 activity 展开态这一个态的覆盖，其余 20 条不受影响）、**由谁接受（客户，P4 交付时随已知问题签收）**、当前状态、客户不接受时的两条出路（均须回到 C1 位置裁定，属上抛）。§8 第 3 条同步指向 §8.5。
- **诚实边界**：本轮**没有客户回执**，`00-client-answers.md` 是客户答复文件、不在本轮产出范围，开发者代写"客户已接受"等于伪造；所以 §8.5 的状态栏写的是「记录已成文、客户回执未取得」，`02` §6.1 标 `[x]` 的只是"记录在案"，签收动作挂在 P4。`01` 头部的"无待裁定项"不受影响——这不是歧义裁定，是知情留痕。
- **N-9 措辞**：`02` U1 的 ② 从"接受为宿主行为……**验收不变**"改为"**判据不变，覆盖范围减 activity 展开态，记已知限制**"；影响面列同步。
- **N-8 走查规程**：`01` §3.0 新增"走查规程"段（全程保持活动面板收起；中途展开记「无法判定/未验」不记通过，收起后重跑并留两次片段 JSON；不得因 `count===4` 记通过），并同步进 `02` S5、S8 的完成标志。
- R9 的理由同步改为 04 §5.1 的源码事实（`left` 同在 `hidden: activity` 的 `tools` 容器 `:22071`；`dock` 保可见但正是 B1-e 判红点）。

落点：`01` §8.5、§3.0；`02` U1、S5、S8、R9、§6.1。

### 7.2.2 顺手修（N-3～N-7，全部 MINOR）

| 编号 | 04 的判定 | 改了什么 | 落点 |
|---|---|---|---|
| N-3 | "四套互斥"不成立；"主判据"与"且"矛盾；负例 1 的构造括注不必然让 sha256 相同 | writing 谓词补第 4 条"**`^-\s` 行数 < 3**"（排除 general 形态），术语表"互斥"改"**各有独立谓词、部分区分**"（v3.1 再补 translate 第 4 条并写明 writing↔translate 交集）；判定段删"主判据/辅助"表述，明写"两条是且关系，判据 2 可一票否决"；负例 1 构造改为"**四套模板整表指向同一常量**"并解释为什么只改 `preset.structure` 不够 | `01` §2 术语、§3-B5 判据 2/判定/负例 |
| N-4 | D1 降级座位 `left` 同在 `hidden: activity` 容器，计划没写；id 冲突出处 492275 落在所引区间外 | D1 降级栏补"`left` 所在 `tools` 容器同样 `hidden: activity`（`:22071`），换座不解除 P2 前提"；出处区间扩为 **492065–492300**（`requires options.id` @492133、同 id 冲突 @492275，本轮实测）并同步 A1 行与 §8 第 2 条；R9 理由同源码事实 | `02` D1、R9；`01` §7-A1、§8 |
| N-5 | U1 主探法沿用被拒形态；"仍超时则装探针"没覆盖"仍被拒绝"；清零判据未分列 | U1 探法改为"**先 `cordis_inspect_list` 读 input schema、按对象传参，同一形态不重试第三次，失败即走探针 bundle**"，并如实记录两种失败（`"input" must be an object` 两次 + 对象形态 10s 超时）；清零判据按 ①②③ 分列（occupants/首帧+展开态片段/令牌清单），任一项既无结论也无降级 → 门不过 | `02` §3-U1 |
| N-6 | 一致性表 12 行未覆盖 #19 256–8192、#3/#4 默认值、B11 900ms、B19 8 字段 | 表补第 13–17 行（输出长度、上下文默认值、秒表采样差、未保存计数范围、B1-e 观察字段）；第 12 行补"activity 展开时 count 仍 4、visible 全 false" | `02` §6.2 |
| N-7 | B17"三条都满足"实际列了四条 | 观察改编号列表（1–4），判定改"**四条**都满足 = 通过"并注明是 N-7 的计数修正 | `01` §3-B17 |

### 7.2.3 v3 落点索引与复核命令（行号为 v3 最终行号，审查员可直接复用）

> v3.1 的定点修订使本表部分行号下移；**v3.1 的新行号见 §7.3**。本表保留为 v3 的历史索引。

| 返工项 | v3 落点 |
|---|---|
| N-1 | `01-requirements.md:98–110`（B1-e 判定 + 3 条负例）、`:76`（§3.0 走查规程）、`:340–387`（§4 基线片段：`modelFound`/`rowRects`/`visible`/`inDock`/`leftOfModel`）、`:389`（DOMRect 序列化修正）；`02-plan.md:107–109`（S5）、`:186`（§6.2 #17） |
| N-2 | `01-requirements.md:64`（§3 头部"基线 + 按条扩展"声明）、`:340–404`（§4 片段 + §4.1 表）、`:124`（B3 证据）、`:228–231`（B11）、`:258–259`（B15）、`:265–267`（B16）；`02-plan.md:102`（S4 的 `dump-draft` 字段）、`:107–109`（S5 属性清单） |
| C-1 / N-9 / N-8 | `01-requirements.md:498–512`（§8.5 知情记录）、`:495`（§8 第 3 条指向）、`:76`（§3.0 走查规程）；`02-plan.md:72`（U1 措辞 + 探法）、`:109`（S5）、`:120–122`（S8）、`:149`（R9）、`:158`（§6.1 第二项） |
| N-3 | `01-requirements.md:50`（术语「结构判据」改"各有独立谓词、部分区分"；v3.1 再降级并写明交集）、`:139`（判据 1 去"主判据"）、`:156–162`（writing 第 4 条谓词）、`:168`（判定式）、`:170–171`（负例 1 构造） |
| N-4 | `02-plan.md:40`（D1：`left` 同受 activity 隐藏 + 492065–492300）、`:149`（R9 理由）；`01-requirements.md:467`（A1 出处）、`:494`（§8 第 2 条） |
| N-5 | `02-plan.md:72`（U1 探法：先读 schema / 两种失败 / ①②③ 分列清零） |
| N-6 | `02-plan.md:168–186`（§6.2，新增 #13–#17 并改 #12） |
| N-7 | `01-requirements.md:270–281`（B17 四条观察 + "四条都满足"） |

```powershell
Select-String -Path 01-requirements.md -Pattern 'modelFound|rowRects|inDock'          # N-1：B1-e 与片段
Select-String -Path 01-requirements.md -Pattern '无法判定'                             # N-1：模型缺失/dock 的处置
Select-String -Path 01-requirements.md -Pattern '按条扩展|messageCount|editorPhase|data-elapsed-ms|data-hover-text' # N-2（v3.1：键名统一 editorPhase）
Select-String -Path 01-requirements.md -Pattern 'activity 展开态的客户知情记录'        # C-1
Select-String -Path 02-plan.md -Pattern '判据不变，但覆盖范围减 activity 展开态'       # N-9（U1 措辞）
Select-String -Path 02-plan.md -Pattern '全程保持活动面板收起'                         # N-8（S5/S8 走查规程）
Select-String -Path 01-requirements.md -Pattern '行数 < 3'                            # N-3（writing 谓词）
Select-String -Path 02-plan.md -Pattern '492065–492300|tools` 容器同样'                # N-4
Select-String -Path 02-plan.md -Pattern '"input" must be an object'                    # N-5（探法修正）
Select-String -Path 01-requirements.md -Pattern '四条.*都满足 = 通过'                  # N-7（B17）
```

### 7.2.4 本轮未做 / 不能做（如实记录）

- **未写实现代码、未安装任何插件、未碰 `$DSH_HOME`**；本轮只改 `01-requirements.md` 与 `02-plan.md` 两个文件。
- **未改 `00-client-answers.md` / `03-gate-P0P1.md` / `04-regate-P0P1.md` / `probes.md`**：00 是客户答复文件，知情记录的"客户确认"一行只能等客户回执，不代写。
- **未重连 Client Inspect**：U1 的运行时探测仍按 §3 的门走，本轮静态文档返工不需要页面在线。
- 剩余开口（不是缺陷，是流程内待办）：①客户对 §8.5 的签收（P4）；②U1/U2/U3/U5/U6/U7 清零（P1.5）；③`04-selfcheck.md` 尚不存在，S8 产出时按 §4/§4.1 的字段口径落表。
- **v3.1 追加**：本轮（05 复审）除 `01`/`02` 外，还同步了 `probes.md` P7 的方法名（05 §5.2 第 1 项要求的同一根修复）；仍未改 `00-client-answers.md` / `03-gate-P0P1.md` / `04-regate-P0P1.md` / `05-regate2-P0P1.md`。

### 7.3 定点修订：针对 `05-regate2-P0P1.md` 的 3 项（v3.1，仅文档）

> 范围：`05` §5.2 的 3 项必改 + §5.3 的 3 条顺手项。**未改**座位、架构、依赖矩阵、探针门、B1–B21 其余条文；**未写功能代码、未安装、未碰 `$DSH_HOME`**。下表行号为 v3.1 最终行号。

| # | `05` 的判定 | 改了什么 | v3.1 落点 |
|---|---|---|---|
| 1 | **N-2/B3 `messageCount` 来源不存在**：`05` §3.3 实测宿主 `sessionQuery` 只有 15 个方法，文档原先引用的取数方法不在其中 | 取数改为 **`ctx.sessionQuery.readSurface(sessionId).events.length`**；在 `01` §4.1 写死计数对象（`SurfaceEvent[]`：四类 message + `tool/result`；不含 `command/*`、`turn/*`、`step/*`、`request/*` 与 shadowed/log-only）与失败口径（`readSurface` 抛错 → `messageCount: null` → B3 记「无法判定」） | `01:127`（B3 证据）、`01:401`（§4.1 B3 行）；`02:24`（§1）、`02:52`（D11）、`02:105`（S4）、`02:264`（§7.2.1）、`02:310`（复核命令）；`probes.md` P7 |
| 2 | **N-2/B3 `editorPhase` 空真**：基于 `contenteditable` 的选择器在 submitting/sending 取不到元素；§4.1 的追加键名与正文/片段两套写法不一致 | 选择器改 **`[data-composer-input]`**（同一 div，`ui-conversation-client.js:20974–20981` 渲染、`:21031` 传 `data-phase`）；写清 `:21829`/`:21833`/`:20976` 为何使旧选择器把相位读成 `null`；键名三处统一为 **`editorPhase`**（§4.1 追加键、B3 正文、§4 片段输出）；相位取值改为源码实测的 `plain/claimed/adjudicating/submitting/sending`（原写 `inert` 是误列） | `01:127`、`01:351`（片段的 editor 查询）、`01:386`（输出键）、`01:393`（字段口径）、`01:402`（§4.1 B3 行）；`02:264`、`02:301`、`02:310` |
| 3 | **N-1/C-2 activity 态被四条判据判「不通过」**，与 §3.0「不判失败」冲突 | B1-e 前置加三态分流：`count === 4` ∧ `visible` 全 `false` ∧ `hiddenByActivity === true` → 整条「无法判定/未验」，不进入四条判据；面板收起后仍 `visible === false`（`hiddenByActivity === false`）→ 「不通过」。片段新增 **`hiddenByActivity`** = `seats[0].parentElement?.closest('[hidden]') != null`（只看父级链，`standardControls` 的 `hidden: activity` 落点；座位自身 hidden 不算） | `01:77`（§3.0 走查规程）、`01:99`（观察字段）、`01:103`（定义）、`01:104`（前置）、`01:105`（三态分流）、`01:113`（负例 3）、`01:381`（片段字段）、`01:509`/`01:511`（§8.5） |

**顺手项（非阻断）**

| # | `05` 的判定 | 改了什么 | v3.1 落点 |
|---|---|---|---|
| N-3 | "两两区分"仍不严格：translate 输出满足 writing 谓词、general 的英文要点满足 translate 谓词 | 降级为「**各有独立谓词、部分区分**」并写明交集；translate 补第 4 条「`^-\s` 行数 < 3」排除 general；**writing↔translate 在「英文输入、段落保持」时结构同形，显式声明不靠文本谓词反推 presetId** | `01:51`（术语）、`01:159`（判据 2 说明）、`01:166`（translate 谓词） |
| 索引 | `02:297` 写 `01:46`，实际是术语表的「结构判据」行（v3 在 `01:50`，v3.1 因 §0 速查加一行而下移到 `01:51`） | 改 `01:51`，并注明 v3.1 再降级 | `02:301` |
| 计数 | `02:178` 期望「命中 1 行」，实测 2 行 | 改「**≥1 行**」，不再写死行号 | `02:180` |

**通过判据自验（本轮实跑）**

```powershell
# 字面量用拼接，避免本行被同一 grep 自命中：
Select-String -Path 01-requirements.md,02-plan.md -Pattern ('read' + 'Events')      # 实测 0 命中
Select-String -Path 01-requirements.md,02-plan.md -Pattern ('composer' + 'Phase')   # 实测 0 命中
```

- 判据 1（宿主方法表里不存在的方法名在 `01`/`02` 0 命中）：**已过**；两文件均为 0，`probes.md` 的旧方法名也已删除（P7 改为 `readSurface`/`listEvents` 的实测契约）。
- 判据 2（submitting 负例下 `editorPhase === "submitting"`）：从 `01` §4 抽出片段，用最小假 DOM 在 `data-phase="submitting"` 下实跑，`editorPhase` 返回 `"submitting"`（不是 `null`）。**已过**；同一假 DOM 的 activity 态返回 `hiddenByActivity === true`、座位 `display:none` 态返回 `false`，三态不混（判据 3）。

### 7.4 定点修订：P2 开工回写（v3.2，`06` §9 + `06-lead-decision.md`）

> 范围：只回写 `06-p1.5-probes.md` §9 列出的定点 + `06-lead-decision.md` 的裁定。**未改** B1–B21 的任何判据、未改座位、未改架构、未安装、未碰 `$DSH_HOME`。

| # | 来源 | 改了什么 | v3.2 落点 |
|---|---|---|---|
| 1 | `06` §9 / `06-lead-decision.md` §4（端口） | **端口不许写死**：U4 的探法从 `http://127.0.0.1:8314/...` 改为"先 `Get-NetTCPConnection -State Listen` 取当前实例的监听口，再对该口探测"；写实本机四口 **6727（浏览器口）/ 6728 / 6729 / 8326（Bearer 口）**，并注明 **8314 无监听**（旧文本在本轮实例上连接被拒，已删）。U4 的结论从"未验"升为**已验（运行时）**，证据见 `06` §4 | `02` §3-U4 |
| 2 | `06` §9（U5/U6/U7 状态） | U5 → **已验（运行时等价形态）**；U6 → **已验（源码 + 运行时投影旁证）**；U7 → **已验（运行时形态）**。~~预期 entryId 随并存裁定改为 `include:lab-draft-studio`~~ **【已被 `12-lead-decision-v4.md` §3 取代】**：设置命名空间是**裸 patchId** `lab-draft-studio`；`Config.listConfigs` 的 `id` 显示为 `include:<patchId>`，但 `entry.options.id` 与 `dsh-settings` 的 `ns` 都用裸名。本行保留为 v3.2 历史记录，不作为现行口径。 | `02` §3-U5/U6/U7；现行口径见 `02` D18 与 `01` §9 |
| 3 | `06` §9（D17） | D17 从 `UNVERIFIED` → **已定降级（源码级 114 个 `--dsw-alias-*` 令牌）**，写明"仍禁止写死字面色" | `02` §2-D17 |
| 4 | `06-lead-decision.md` §1（并存裁定 = 方案 B） | §1 新增一行决策：「与在装 `dsh-draft-studio@1.2.2` 的关系」，写明**包名/`meta.title`/座位 id/设置页 id 全部加实验前缀**（`@local/lab-draft-studio` / `lab-draft-<presetId>` / `lab-draft-studio`），**不删除、不停用、不改动**前代及其数据（明确排除方案 A 的 `remove_bundle`）；验收判据不变 | `02` §1、§4-S2/S4/S5/S6、§2-D18 |
| 5 | `06` §9（风险清单） | 新增 **R10**（插件自建 HTTP 路由在浏览器口默认无鉴权 → 若走降级 A，handler 必须自带守卫）、**R11**（并存导致界面出现两套控件，最多 6 个工具行控件 + 两个设置页） | `02` §5、§4-S4 |
| 6 | 本轮实跑 | 端口与鉴权层复核：`Get-NetTCPConnection -State Listen` → 6727/6728/6729/8326（同一 pid 17760）、8314 无监听；`GET /` → 401、`GET /api/nope` → 401、`GET /__probe_no_route__` → 404。**Client Inspect 再次超时**（`Slots.listSubTree {root:"conversation.input.right"}` → `timed out after 10000ms`），与 `06` §1.1 的"超时不是页面没开"一致（GUI 在线、鉴权层正常应答） | 本轮输出；`probes.md` P3 归因修正 |
| 7 | `02` §6.2 第 9 行复核命令 | `Select-String -Path 02-plan.md -Pattern 'A1/C1 已结案'` 的期望命中数仍为 ≥1 行，不受本轮编辑影响（已复跑） | `02` §6.2 |
