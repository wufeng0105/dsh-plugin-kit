/**
 * P3 replay: the OFFICIAL modelSelection projection, copied verbatim (structure
 * and comparison helpers) from the installed Harness so the fold is not my
 * paraphrase.
 *
 * Source (read-only, this machine's installation):
 *   dsh/node_modules/@deepseek-ai/dsh-agent/lib/index.js:102-174
 *
 * The rule under test:
 *   current() = state.pending ?? state.lastUsed ?? options        (:190-195)
 *   request/header -> lastUsed = selectionOfHeader(header)         (:157)
 *                  -> pending  = (pending === lastUsed ? null : pending)  (:158)
 *   model/selection -> pending = data                              (:152-155)
 *
 * Consequence being tested: after an override has produced at least one
 * request/header, deleting the override (the plugin's "restore") cannot return
 * the teammate to its descriptor route, because `lastUsed` now names the
 * override and `options` (the descriptor triple) is only the last fallback.
 */

function sameRoute(left, right) {
  return left.provider === right.provider && left.model === right.model;
}
function sameModelSelection(left, right) {
  return left === right || (left !== null && right !== null && sameRoute(left, right) && left.reasoningEffort === right.reasoningEffort);
}
function toSelection(provider, model, reasoningEffort) {
  return { provider, model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) };
}
function selectionOfHeader({ config, adapterDefaults }) {
  return toSelection(config.provider, config.model, adapterDefaults?.reasoningEffort === true ? undefined : config.reasoningEffort);
}

/** The projection's `apply`, verbatim in effect. */
function apply(state, event) {
  if (event.type === 'model/selection') {
    return sameModelSelection(state.pending, event.data) ? state : { ...state, pending: event.data };
  }
  if (event.type !== 'request/header') return state;
  const lastUsed = selectionOfHeader(event.data.header);
  const pending = sameModelSelection(state.pending, lastUsed) ? null : state.pending;
  return sameModelSelection(state.lastUsed, lastUsed) && pending === state.pending
    ? state
    : { lastUsed, pending };
}

/** AgentModel.current(), verbatim in effect (:190-195) with recordedSelection (:200-203). */
function current(state, options) {
  const recorded = state.pending ?? state.lastUsed;
  if (recorded !== null) return { ...recorded };
  return options.provider && options.model ? toSelection(options.provider, options.model, options.reasoningEffort) : undefined;
}

const DESCRIPTOR = { provider: 'deepseek', model: 'deepseek-chat' };          // dispatch route
const OVERRIDE = { provider: 'deepseek', model: 'deepseek-reasoner', reasoningEffort: 'high' };
const hdr = (sel) => ({ type: 'request/header', data: { header: { config: { provider: sel.provider, model: sel.model, ...(sel.reasoningEffort === undefined ? {} : { reasoningEffort: sel.reasoningEffort }) } } } });

const init = { lastUsed: null, pending: null };
const replay = (events) => events.reduce(apply, init);
const show = (s) => JSON.stringify({ pending: s.pending, lastUsed: s.lastUsed });

console.log('--- Scenario 1: teammate dispatched, one turn on the descriptor route ---');
let ev = [hdr(DESCRIPTOR)];
let st = replay(ev);
console.log('state after descriptor turn:', show(st), '| current() =', JSON.stringify(current(st, DESCRIPTOR)));

console.log('\n--- Scenario 2: plugin applies override at wake-up (select => model/selection), then a turn runs ---');
ev = [...ev, { type: 'model/selection', data: OVERRIDE }, hdr(OVERRIDE)];
st = replay(ev);
console.log('state:', show(st), '| current() =', JSON.stringify(current(st, DESCRIPTOR)));

console.log('\n--- Scenario 3: "restore" = delete the override; teammate wakes again (resume) ---');
// No new event is appended by a delete (the plugin deliberately writes nothing on restore).
// resume() rebuilds the same projection from the persisted log, with agentOptions = descriptor.
const resumed = replay(ev); // same persisted log
console.log('state after resume:', show(resumed));
console.log('agentOptions passed by coldResume (descriptor):', JSON.stringify(DESCRIPTOR));
console.log('current() on the first step after restore =', JSON.stringify(current(resumed, DESCRIPTOR)));
console.log('EXPECTED by A7 decision 1 =', JSON.stringify(DESCRIPTOR));
console.log('MATCH:', JSON.stringify(current(resumed, DESCRIPTOR)) === JSON.stringify(DESCRIPTOR));

console.log('\n--- Scenario 4: control — teammate never ran a turn under the override ---');
const ev2 = [hdr(DESCRIPTOR), { type: 'model/selection', data: OVERRIDE }];
const st2 = replay(ev2);
console.log('state:', show(st2), '| current() =', JSON.stringify(current(st2, DESCRIPTOR)));

console.log('\n--- Scenario 5: what WOULD restore the descriptor (a new selection event) ---');
const st3 = replay([...ev, { type: 'model/selection', data: DESCRIPTOR }]);
console.log('state:', show(st3), '| current() =', JSON.stringify(current(st3, DESCRIPTOR)),
  '| MATCH:', JSON.stringify(current(st3, DESCRIPTOR)) === JSON.stringify(DESCRIPTOR));
