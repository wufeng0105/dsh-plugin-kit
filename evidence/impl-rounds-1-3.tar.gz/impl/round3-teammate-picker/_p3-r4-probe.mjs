/**
 * P3 probe for the R4 claim: "the outermost agent/created listener always
 * returns undefined, so a failure can never reject the resume."
 *
 * The listener body (lib/host.js:217-220) is:
 *     ctx.on('agent/created', (payload) => { bridge.applyToAgent(payload?.agent); return undefined; })
 *
 * There is no try/catch at that level, so containment lives inside
 * `applyToAgent` (lib/host.js:132-144). This probe asks what happens when the
 * containment itself fails, i.e. when the *catch block* throws.
 */
import { createPlugin } from './bundle/lib/host.js';

function ctxWith(agentsList) {
  const listeners = new Map();
  return {
    listeners,
    fiber: { entry: { options: { id: 'teammate-picker' } } },
    agents: { list: agentsList },
    on(event, listener) {
      if (!listeners.has(event)) listeners.set(event, []);
      listeners.get(event).push(listener);
    },
  };
}
const fire = (ctx, event, payload) => (ctx.listeners.get(event) ?? []).map((l) => l(payload));

const CHILD = 'sess-child-1';
const OVERRIDE = { provider: 'deepseek', model: 'deepseek-reasoner' };

console.log('=== Case 1: a throwing logger, with a select() that also throws ===');
{
  const ctx = ctxWith(() => []);
  ctx.logger = { warn() { throw new Error('logger sink exploded'); }, debug() {} };
  const config = { overrides: { get: () => ({ [CHILD]: OVERRIDE }) } };
  createPlugin(ctx, config);
  const agent = { id: CHILD, model: { current: () => null, select: () => { throw new Error('adapter rejected'); } } };
  try {
    const out = fire(ctx, 'agent/created', { agent, source: 'resume' });
    console.log('  listener resolved, results =', JSON.stringify(out));
  } catch (error) {
    console.log('  listener THREW ->', String(error.message), '  <-- this rejects announce()/resume');
  }
}

console.log('\n=== Case 2: throwing logger, table read OK, no override (no select) ===');
{
  const ctx = ctxWith(() => []);
  ctx.logger = { warn() { throw new Error('logger sink exploded'); }, debug() {} };
  createPlugin(ctx, { overrides: { get: () => ({}) } });
  try {
    const out = fire(ctx, 'agent/created', { agent: { id: CHILD }, source: 'resume' });
    console.log('  listener resolved, results =', JSON.stringify(out));
  } catch (error) {
    console.log('  listener THREW ->', String(error.message));
  }
}

console.log('\n=== Case 3: throwing logger + table read throws (two failures) ===');
{
  const ctx = ctxWith(() => []);
  ctx.logger = { warn() { throw new Error('logger sink exploded'); }, debug() {} };
  createPlugin(ctx, { overrides: { get() { throw new Error('volatile ref gone'); } } });
  try {
    const out = fire(ctx, 'agent/created', { agent: { id: CHILD }, source: 'resume' });
    console.log('  listener resolved, results =', JSON.stringify(out));
  } catch (error) {
    console.log('  listener THREW ->', String(error.message));
  }
}

console.log('\n=== Case 4: a payload whose getter throws (no logger involvement) ===');
{
  const ctx = ctxWith(() => []);
  createPlugin(ctx, { overrides: { get: () => ({}) } });
  const payload = { get agent() { throw new Error('payload proxy'); } };
  try {
    const out = fire(ctx, 'agent/created', payload);
    console.log('  listener resolved, results =', JSON.stringify(out));
  } catch (error) {
    console.log('  listener THREW ->', String(error.message));
  }
}

console.log('\n=== Case 5: the volatile-update listener, same shapes ===');
{
  const ctx = ctxWith(() => { throw new Error('registry disposed'); });
  ctx.logger = { warn() { throw new Error('logger sink exploded'); }, debug() {} };
  createPlugin(ctx, { overrides: { get: () => ({}) } });
  const config2 = null;
  try {
    const out = fire(ctx, 'loader/volatile-update', [['overrides']]);
    console.log('  listener resolved, results =', JSON.stringify(out));
  } catch (error) {
    console.log('  listener THREW ->', String(error.message));
  }
}
