# break-restore.ps1 — one clean "break -> red -> restore -> green" demonstration.
#
# Deliberately mutates ONE line of the shipped source, runs the suite, restores
# the file byte-for-byte, and runs the suite again. Literal string replacement
# (not -replace) so the anchor cannot silently miss.
$ErrorActionPreference = 'Stop'
$bundle = Join-Path $PSScriptRoot 'bundle'
$target = Join-Path $bundle 'lib/core.js'
$backup = "$target.orig"

Copy-Item -LiteralPath $target -Destination $backup -Force
$original = [System.IO.File]::ReadAllText($target)

# The mutation a well-meaning reviewer might actually make: "restore should put
# the dispatch route back explicitly, not just delete the entry."
$anchor = "  return [{ op: 'unset', path: [CONFIG_FIELDS.overrides, childSessionId] }];"
$mutant = "  return [{ op: 'set', path: [CONFIG_FIELDS.overrides, childSessionId], value: { provider: 'deepseek', model: 'deepseek-chat' } }];"
if (-not $original.Contains($anchor)) {
  Copy-Item -LiteralPath $backup -Destination $target -Force
  throw "anchor not found in $target"
}

try {
  Write-Output '=== RED: mutant applied (restore writes instead of deleting) ==='
  [System.IO.File]::WriteAllText($target, $original.Replace($anchor, $mutant))
  Push-Location $bundle
  try {
    node --test 2>&1 | Select-String -Pattern '^✖|^ℹ (tests|pass|fail)'
    $redExit = $LASTEXITCODE
  } finally { Pop-Location }
  Write-Output "red exit code: $redExit"
} finally {
  Write-Output '=== RESTORE: original source put back ==='
  Copy-Item -LiteralPath $backup -Destination $target -Force
  Remove-Item -LiteralPath $backup -Force
  Push-Location $bundle
  try {
    node --test 2>&1 | Select-String -Pattern '^✖|^ℹ (tests|pass|fail)'
    $greenExit = $LASTEXITCODE
  } finally { Pop-Location }
  Write-Output "green exit code: $greenExit"
}
