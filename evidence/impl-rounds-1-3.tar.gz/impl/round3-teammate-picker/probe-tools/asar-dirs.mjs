// asar-dirs.mjs — list unique top-level entry names under a prefix inside app.asar (read-only)
// usage: node asar-dirs.mjs <asarPath> </dsh/node_modules/@deepseek-ai/>
import fs from 'node:fs';
const [, , asarPath, prefix] = process.argv;
const head = Buffer.alloc(16);
const fd = fs.openSync(asarPath, 'r');
fs.readSync(fd, head, 0, 16, 0);
const headerSize = head.readUInt32LE(4), jsonLen = head.readUInt32LE(12);
const buf = Buffer.alloc(jsonLen);
fs.readSync(fd, buf, 0, jsonLen, 16);
const header = JSON.parse(buf.toString('utf8'));
const pre = (prefix || '').replace(/^\//, '').split('/').filter(Boolean);
let node = header;
for (const p of pre) { node = node.files ? node.files[p] : undefined; if (!node) { console.error('NOT FOUND: ' + prefix); process.exit(2); } }
if (!node.files) { console.error('NOT A DIR: ' + prefix); process.exit(2); }
for (const k of Object.keys(node.files)) console.log(k + (node.files[k].files ? '/' : ''));
fs.closeSync(fd);
