// asar-list.mjs — list file paths inside app.asar under a prefix (read-only)
// usage: node asar-list.mjs <asarPath> [/dir/prefix] [limit]
import fs from 'node:fs';
const [, , asarPath, prefix, limitArg] = process.argv;
const head = Buffer.alloc(16);
const fd = fs.openSync(asarPath, 'r');
fs.readSync(fd, head, 0, 16, 0);
const headerSize = head.readUInt32LE(4), jsonLen = head.readUInt32LE(12);
const buf = Buffer.alloc(jsonLen);
fs.readSync(fd, buf, 0, jsonLen, 16);
const header = JSON.parse(buf.toString('utf8'));
const files = [];
(function walk(node, path) {
  if (node.files) { for (const k of Object.keys(node.files)) walk(node.files[k], path + '/' + k); return; }
  if (node.size !== undefined) files.push(path);
})(header, '');
const pre = (prefix || '').replace(/^\//, '').toLowerCase();
const limit = parseInt(limitArg, 10) || 200;
let n = 0;
for (const f of files) {
  if (pre && !f.replace(/^\//, '').toLowerCase().startsWith(pre)) continue;
  process.stdout.write(f + '\n');
  if (++n >= limit) { console.error(`[truncated at ${limit} of prefix-matched ${files.length}]`); break; }
}
fs.closeSync(fd);
