// asar-grep.mjs — regex-search files inside app.asar under a directory prefix (read-only)
// usage: node asar-grep.mjs <asarPath> </dir/prefix/or-empty> <regex> [limit] [fileSuffixFilter]
import fs from 'node:fs';
const [, , asarPath, prefix, pattern, limitArg, suffix] = process.argv;
if (!asarPath || pattern === undefined) { console.error('usage: node asar-grep.mjs <asarPath> </dir/prefix> <regex> [limit] [fileSuffix]'); process.exit(2); }
const head = Buffer.alloc(16);
const fd = fs.openSync(asarPath, 'r');
fs.readSync(fd, head, 0, 16, 0);
const headerSize = head.readUInt32LE(4), jsonLen = head.readUInt32LE(12);
const buf = Buffer.alloc(jsonLen);
fs.readSync(fd, buf, 0, jsonLen, 16);
const header = JSON.parse(buf.toString('utf8'));
const dataStart = 8 + headerSize;
const files = [];
(function walk(node, path) {
  if (node.files) { for (const k of Object.keys(node.files)) walk(node.files[k], path + '/' + k); return; }
  if (node.size !== undefined && Number.isFinite(Number(node.offset))) files.push({ path, offset: Number(node.offset), size: node.size });
})(header, '');
const pre = (prefix || '').replace(/^\//, '').toLowerCase();
const rx = new RegExp(pattern, 'i');
const limit = parseInt(limitArg, 10) || 40;
let hits = 0;
for (const f of files) {
  if (pre && !f.path.replace(/^\//, '').toLowerCase().startsWith(pre)) continue;
  if (suffix && !f.path.toLowerCase().endsWith(suffix.toLowerCase())) continue;
  const b = Buffer.alloc(f.size);
  fs.readSync(fd, b, 0, f.size, dataStart + f.offset);
  const lines = b.toString('utf8').split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    if (rx.test(lines[i])) { process.stdout.write(f.path + ':' + (i + 1) + ': ' + lines[i].trim().slice(0, 400) + '\n'); if (++hits >= limit) { fs.closeSync(fd); process.exit(0); } }
  }
}
fs.closeSync(fd);
console.error(`[hits: ${hits}]`);
