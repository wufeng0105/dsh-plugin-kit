// asar-find.mjs — list entry paths containing a substring (read-only)
// usage: node asar-find.mjs <asarPath> <substring> [limit]
import fs from 'node:fs';
const [, , asarPath, sub, limitArg] = process.argv;
const head = Buffer.alloc(16);
const fd = fs.openSync(asarPath, 'r');
fs.readSync(fd, head, 0, 16, 0);
const headerSize = head.readUInt32LE(4), jsonLen = head.readUInt32LE(12);
const buf = Buffer.alloc(jsonLen);
fs.readSync(fd, buf, 0, jsonLen, 16);
const header = JSON.parse(buf.toString('utf8'));
const needle = (sub || '').toLowerCase();
const limit = parseInt(limitArg, 10) || 40;
let hits = 0;
(function walk(node, path) {
  if (hits >= limit) return;
  if (node.files) { for (const k of Object.keys(node.files)) { walk(node.files[k], path + '/' + k); if (hits >= limit) return; } return; }
  if (node.size !== undefined && path.toLowerCase().includes(needle)) { console.log(path); hits++; }
})(header, '');
fs.closeSync(fd);
