// asar-slice.mjs — read a line range from a file inside app.asar (read-only)
// usage: node asar-slice.mjs <asarPath> </inner/path/to/file.js> <startLine> <endLine>
import fs from 'node:fs';
const [, , asarPath, inner, s, e] = process.argv;
if (!asarPath || !inner) { console.error('usage: node asar-slice.mjs <asarPath> </inner/path> [startLine] [endLine]'); process.exit(2); }
const head = Buffer.alloc(16);
const fd = fs.openSync(asarPath, 'r');
fs.readSync(fd, head, 0, 16, 0);
const headerSize = head.readUInt32LE(4), jsonLen = head.readUInt32LE(12);
const buf = Buffer.alloc(jsonLen);
fs.readSync(fd, buf, 0, jsonLen, 16);
const header = JSON.parse(buf.toString('utf8'));
const dataStart = 8 + headerSize;
const parts = inner.replace(/^\//, '').split('/').filter(Boolean);
let node = header;
for (const p of parts) { node = node.files ? node.files[p] : undefined; if (!node) { console.error('NOT FOUND: ' + inner); process.exit(2); } }
if (node.size === undefined) { console.error('NOT A FILE: ' + inner); process.exit(2); }
const b = Buffer.alloc(node.size);
fs.readSync(fd, b, 0, node.size, dataStart + Number(node.offset));
const lines = b.toString('utf8').split(/\r?\n/);
const start = Math.max(1, parseInt(s, 10) || 1), end = Math.min(lines.length, parseInt(e, 10) || lines.length);
for (let i = start; i <= end; i++) process.stdout.write(String(i).padStart(6) + ': ' + lines[i - 1] + '\n');
fs.closeSync(fd);
