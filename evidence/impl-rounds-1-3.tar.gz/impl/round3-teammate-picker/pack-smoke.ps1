# pack-smoke.ps1 — M-3 proof: `npm pack` the bundle, install the TARBALL into a
# throwaway directory, and load it from there.
#
# The verifier's M-3 finding was that `files[]` omitted `lib/schema.js` while
# `index.js` imports it, so a packed install died with ERR_MODULE_NOT_FOUND.
# "The array looks right" is not evidence; this script packs and loads.
#
# Nothing is installed into the profile: the target is a directory under
# $env:TEMP, and the bundle's own directory is only read.
$ErrorActionPreference = 'Stop'

$bundle = Join-Path $PSScriptRoot 'bundle'
$work = Join-Path $env:TEMP ('teammate-picker-pack-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
$consumer = Join-Path $work 'consumer'
New-Item -ItemType Directory -Path $consumer -Force | Out-Null

Push-Location $bundle
try {
  npm pack --json 2>&1 | Out-File -FilePath (Join-Path $work 'pack.json') -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw "npm pack failed" }
  $tarball = Get-ChildItem -Filter '*.tgz' -File | Select-Object -First 1
  if (-not $tarball) { throw 'npm pack produced no tarball' }
  $tgz = Join-Path $work $tarball.Name
  Move-Item -LiteralPath $tarball.FullName -Destination $tgz -Force
} finally { Pop-Location }

Write-Output "=== npm pack file list ==="
$packed = Get-Content -LiteralPath (Join-Path $work 'pack.json') -Raw | ConvertFrom-Json
$files = @($packed[0].files | ForEach-Object { $_.path })
$files | Sort-Object | ForEach-Object { Write-Output "  $_" }
Write-Output "packed file count: $($files.Count)"

Write-Output ''
Write-Output '=== three-way diff: files[] vs tarball vs index.js imports ==='
$manifest = Get-Content -LiteralPath (Join-Path $bundle 'package.json') -Raw | ConvertFrom-Json
$declared = @($manifest.files)
$missingDeclared = $declared | Where-Object { $f = $_; -not ($files | Where-Object { $_ -like $f }) }
Write-Output "declared but not packed: $(if ($missingDeclared) { $missingDeclared -join ', ' } else { '(none)' })"

$entry = Join-Path $bundle 'index.js'
$imports = Select-String -Path $entry -Pattern "from '(\.[^']+)'" -AllMatches |
  ForEach-Object { $_.Matches } | ForEach-Object { $_.Groups[1].Value }
foreach ($spec in $imports) {
  $rel = $spec -replace '^\./', ''
  $hit = $files -contains $rel
  Write-Output ("import {0,-20} packed={1}" -f $rel, $hit)
}

Write-Output ''
Write-Output '=== install the tarball and import it ==='
Push-Location $consumer
try {
  npm init -y 2>&1 | Out-Null
  npm install --no-save --no-audit --no-fund $tgz 2>&1 | Select-Object -Last 3
  if ($LASTEXITCODE -ne 0) { throw 'npm install of the tarball failed' }
  # The plugin's dependency comes from the Host profile. Copying it (with its own
  # two dependencies) is what "installed in a profile" looks like; nothing is
  # written to the profile itself.
  $profileModules = Join-Path $env:USERPROFILE '.dsh\profiles\desktop\node_modules'
  foreach ($dep in @('@deepseek-ai\schemastery', '@deepseek-ai\cosmokit', '@standard-schema\spec')) {
    $source = Join-Path $profileModules $dep
    if (-not (Test-Path -LiteralPath $source)) { throw "missing dependency fixture: $source" }
    $target = Join-Path $consumer ('node_modules\' + $dep)
    New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
    Copy-Item -Path $source -Destination $target -Recurse -Force
  }
} finally { Pop-Location }

$installedEntry = Join-Path $consumer 'node_modules\@local\dsh-teammate-picker\index.js'
Write-Output "installed entry exists: $(Test-Path -LiteralPath $installedEntry)"

$probe = Join-Path $work 'probe.mjs'
@'
const entry = process.argv[2];
const url = new URL('file:///' + entry.replace(/\\/g, '/')).href;
try {
  const m = await import(url);
  const names = Object.keys(m).sort();
  console.log('exports:', names.join(','));
  console.log('apply:', typeof m.apply);
  console.log('Config:', m.Config === undefined ? 'UNDEFINED (degraded)' : typeof m.Config);
  if (m.Config !== undefined && typeof m.Config.toJSON === 'function') {
    const doc = m.Config.toJSON();
    const refs = doc.refs ?? {};
    const look = (v) => (typeof v === 'number' || typeof v === 'string' ? refs[String(v)] : v);
    const rootNode = refs[String(doc.uid)] ?? look(doc.ref);
    for (const key of Object.keys(rootNode?.dict ?? {})) {
      const node = look(rootNode.dict[key]);
      console.log(`Config field ${key}: type=${node?.type} volatile=${node?.meta?.volatile === true}`);
    }
  }
  process.exit(m.Config === undefined ? 3 : 0);
} catch (e) {
  console.log('IMPORT FAIL', e.code ?? '', '|', String(e.message).split('\n')[0]);
  process.exit(4);
}
'@ | Set-Content -LiteralPath $probe -Encoding utf8
node $probe $installedEntry
$probeExit = $LASTEXITCODE
Write-Output "probe exit=$probeExit  (0 = Config schema present; 3 = degraded; 4 = import failed)"

Write-Output ''
Write-Output "work dir kept for inspection: $work"
exit $probeExit
