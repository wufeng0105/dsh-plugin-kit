# 08-verification.md — P3 独立验证（round3-teammate-picker）

> 验证者立场：**证伪，不是背书**。实现者自述（`06-implementation.md` / `07-selfcheck.md`）只作线索，凡结论均以我自己的复跑/读码重新成立或推翻。
> 验证时间：2026-11-08 07:29–08:10（Asia/Shanghai）。
> 约束遵守：**未改 `bundle/` 任何文件**、未安装任何 bundle、未写 `$DSH_HOME` / profile。所有破坏性实验（变异、伪造安装）都在 `$env:TEMP` 副本上做。
> 证据等级：**[运行时]** = 本机命令实跑输出；**[源码]** = 安装包内 `文件:行`；**[契约]** = inspect 返回。客户端 inspect 本轮**再次超时**（见 §7），故 Client 侧结论全部止于源码级。

## 0. 结论摘要（先给判定）

| 项 | 结论 |
|---|---|
| 独立复跑 | **81 tests / 81 pass / 0 fail**；9/9 `node --check` 退出码 0（与实现者数字一致，但下文的"一致"不代表"正确"，见缺陷） |
| A1–A16 三态 | **VERIFIED 3**（A11、A12、A15）／**UNVERIFIABLE 6**（A1、A4、A5、A6、A8、A9）／**FAIL·GAP 5**（A2、A3、A7、A10、A13）／**部分已证 2**（A14、A16-判定3） |
| 缺陷 | **BLOCKER 2 / MAJOR 4 / MINOR 4** |
| 放行意见 | **不可进 P4 交付**（BLOCKER 未清）；清完后须带条件复核 |
| 是否同意实现者「三处最易误解」自述 | **第 1 处同意并已实证；第 2 处部分不同意（结论对、归因错，真实后果比他写的严重）；第 3 处不同意（判据本身有洞）** — 详见 §6 |

## 一、独立复跑（不引用实现者输出）

### 1.1 测试

环境：`node v24.22.2`（`C:\Program Files\nodejs\node.exe`），工作目录 `bundle/`。

```
cd bundle; node --test
ℹ tests 81
ℹ suites 0
ℹ pass 81
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 229.9788
```

分文件复跑（四文件各自单独跑，排除"聚合器掩盖"）：

| 文件 | tests | pass | fail |
|---|---|---|---|
| `test/core.test.mjs` | 38 | 38 | 0 |
| `test/host.test.mjs` | 24 | 24 | 0 |
| `test/client.test.mjs` | 11 | 11 | 0 |
| `test/schema.test.mjs` | 8 | 8 | 0 |

### 1.2 语法检查

```
index.js exit=0 ; client.js exit=0 ; lib/core.js exit=0 ; lib/host.js exit=0 ; lib/schema.js exit=0
test/core.test.mjs exit=0 ; test/host.test.mjs exit=0 ; test/client.test.mjs exit=0 ; test/schema.test.mjs exit=0
```

### 1.3 `npm test`（`package.json` 里声明的入口）**是坏的**

```
cd bundle; npm test
✖ test (123.9673ms)
ℹ tests 1
ℹ pass 0
ℹ fail 1
exit=1
```

原因（我复跑确认）：

```
cd bundle; node --test test/
Error: Cannot find module '...\bundle\test'
  code: 'MODULE_NOT_FOUND'
```

`package.json:23` 写的是 `"test": "node --test test/"`，在 Node 24 上被当作**文件路径**解析而失败。实现者自己在 `06-implementation.md:117` 记录了这一点（"`node --test test/` 带目录参数会失败"），**但没有改掉 manifest** —— 记录与修复是两件事。见 MINOR-1。

### 1.4 我自己的三项破坏性复跑（全部在 `%TEMP%` 副本上，`bundle/` 零改动）

用 `Get-FileHash` 记录了 `bundle/` 全部 14 文件 SHA256 前 16 位（见 §8），证明验证结束时源树未被触碰。

| 实验 | 做法 | 结果 |
|---|---|---|
| M1 恢复语义变异 | 把 `overrideDeleteOps` 的 `unset` 改成一条 `set` | **81 → pass 80 / fail 1**（红） → 该测试确实钉住了"恢复=删" |
| M2 去掉最外层 try/catch | 只删 `applyToAgent` 的外层 `try{...}catch{}` | **81 pass / 0 fail（仍然全绿）** → 与实现者 §4 mutation#1 一致，证明"绿"不能证明 R4 |
| M3 去掉**所有内层** select 兜底 | 让 `selectSafely` 直接抛，只留外层 catch | **pass 78 / fail 3** → 外层 catch 确实在起作用，R4 不是纸糊的 |

M3 是本次新增的关键反证：它同时证明「内层兜底存在」和「外层 catch 独立有效」。但见 §6 第 3 处——这不等于 R4 无洞。

## 二、A1–A16 逐条判定

判定口径：
- **VERIFIED（离线可证）**：我用代码/命令亲手证到了该条判据所依赖的事实，且该事实**足以二值判定**这一条。
- **UNVERIFIABLE（离线不可证）**：判据本身对，但需要装进真实 DSH/页面才能观测。
- **FAIL / GAP**：实现与验收不符，或实现者声称已验而我证伪。

| # | 验收要点 | 三态 | 证据 / 缺什么 |
|---|---|---|---|
| **A1** | 只在队友会话渲染 | **UNVERIFIABLE**（结构已证） | 谓词 `shouldRenderPicker`（`lib/core.js:426-435`）与 `client.js` 的 `rendersIn`（`client.js:51-58`）逐状态一致，由 `test/client.test.mjs:257-275` 用"从源码抽函数体"钉住（我复跑通过）。**缺**：真实 DOM 里主线 `null` / 队友非 `null`。 |
| **A2** | 显示当前模型与推理等级 | **FAIL / GAP** | 控件**只渲染一个标签**（`client.js:106-118`），全文无 `model`/`effort` 文本拼接（`Select-String 'effort' client.js` = **0 命中**）。`foldSessionRouteFacts` 折出路由的能力有测试，但**从未被 Client 调用**（`session/events` 在 `client.js` 中 0 命中）。判据 1「textContent 含 provider 与 model」在当前实现下**必然为假**。 |
| **A3** | 两级菜单（集合相等判据） | **FAIL** | 菜单不存在。`client.js` 中 `modelCatalog` = **0 命中**，`data-dsh-teammate-picker-restore` = **0 命中**，无分组、无 `P_ok`/`E`/`P_fail` 计算。判定 2/3/4 全部不可满足。 |
| **A4** | 切换写入只动该子会话 | **UNVERIFIABLE**（写操作构造已证） | `overrideSetOps` 产出 `[{op:'set', path:['overrides', childSessionId]}]`（`lib/core.js:306-311`），路径逐段落在 volatile 节点下（我按 `dsh-settings/lib/index.js:153-158` 的 `isVolatilePath` 手工核对通过）。**缺**：没有任何代码真正调用它（`grep '.mutate(' *.js,lib/*.js` → **0 命中**）；且见 BLOCKER-2，`Config` 为 `undefined` 时这条写路径在运行时根本无 schema 可校验。 |
| **A5** | 换掉不可用路由后可继续 | **UNVERIFIABLE** | 冷回填链路在源码层成立（见 A8）。**缺**：真实队友 + 不可用路由 + `request/header.config` 前后比对。A5 的客户限定语（只证"错误类型变化"）在交付物中**未出现**（见 MINOR-3）。 |
| **A6** | 活跃回合中切换，下一 step 生效 | **UNVERIFIABLE（且存在未证假设）** | 热路径只走 `loader/volatile-update` 一路（`lib/host.js:222-225`），无 `turn/start` 兜底。`loader/volatile-update` 的官方语义我已核：`cordis-plugin-loader/lib/index.js:513-557`，volatile-only 变更不重挂、`emit` 到 owning fiber。**但这只证明"事件会到"，不证明"到了以后还在 step 准备前"**。见 MAJOR-1。 |
| **A7** | 恢复派发路由 | **FAIL（BLOCKER-1）** | 「恢复=删条目」的代码确实存在且被测试钉住（M1 红）。**但删条目在官方的 projection 语义下回不到 descriptor 路由**：`AgentModel.current()` = `pending ?? lastUsed ?? options`（`dsh-agent/lib/index.js:190-195, 200-203`），而 `lastUsed` 一旦被 `request/header` 记成覆盖路由（`:157-162`），删掉覆盖**不会**让它回退到 `options`。我用官方 projection 的逐字副本做了事件重放（§3.2），四步复现：覆盖生效后跑过一回合 → 删除覆盖 → resume → `current()` 仍返回**覆盖路由**，期望值（descriptor）不匹配。 |
| **A8** | 重启后覆盖仍在 | **UNVERIFIABLE** | 两个子项：(a) 存储持久——**BLOCKER-2 使其不成立**（`Config` 在安装后仍是 `undefined`，见 §3.3）；(b) 首跳 = 覆盖路由——冷回填时序我按源码核过，**成立**（`dsh-agent/lib/index.js:703-719` 的 `announce` 被 `await`，`dsh-agent-loop/lib/index.js:1565-1593` 包在 `runMaintenance` 内，`:586-609`/`:618-622` 期间唤醒被挂起，`:666-672` 首 step 读 `model.current()`）。故 (b) 可证、(a) 不可交付。 |
| **A9** | 无覆盖时零介入 | **UNVERIFIABLE（部分已证）** | `decideRoute` 无覆盖时**返回入参对象本身**（`lib/core.js:191`），测试用 `assert.equal` 而非 `deepEqual` 钉住引用相等（`test/core.test.mjs:192-198`，我复跑通过）——这是零介入最硬的一条离线证据。全包 `session.append` / `appendPluginRecord` **0 命中**（我独立 grep 确认）。**缺**：两态日志 `type` 序列 diff。 |
| **A10** | 显示开关 | **FAIL（GAP）** | `showSelector` 在 Client 半**完全没有被读取**（`client.js` 中 `showSelector` = **0 命中**；11 处命中全在 `core.js`/`host.js`/测试里）。判定 1「关闭后所有会话 DOM 为 null」在当前实现下**恒假**——开关改不动渲染。判定 5/6（插件自带开关、经 `configForms` 写入）也未实现（`mutate` 在 `client.js` = 0 命中）。 |
| **A11** | one-shot / 外部后端不渲染 | **VERIFIED（离线可证，DOM 除外）** | 谓词对 `mode:'one-shot'`（`lib/core.js:429`）、`'external'`（`:430`）返回 `render:false`；`'continuable'` 字面量在官方侧确实存在（`dsh-subagent/lib/types/catalog.js:22` `z.literal('continuable')`）。DOM 面仍属 UNVERIFIABLE，但**判据所依赖的机制事实已由我独立证到**。 |
| **A12** | 其余会话一律不渲染 | **VERIFIED（离线可证）** | `subagent === null/undefined` → `render:false`（`lib/core.js:427`），与官方 `SessionSnapshot.subagent` 的 `T \| null` 形状一致（`dsh-api-session-controller/lib/client.js:2919`）。空白/普通/fork/Hero 四态的 snapshot 均为 `subagent === null`，故四态同判。 |
| **A13** | 切换到不可用模型：失败干净 | **FAIL（GAP）** | 该条要求"失败后仍能再次切换并继续"，前提是**存在切换 UI**。A3/A10 已 FAIL，本条的交互对象不存在。 |
| **A14** | 不改任何官方包 | **VERIFIED（范围有限）** | 本轮我未安装、未写 profile/官方目录；官方安装包 `app.asar` = **213,202,918 B**，与我读码时的切片一致，未变更。**但**交付包自身的三方向差集**不为空**，见 MAJOR-3：`files[]` 漏了 `lib/schema.js`，而 `index.js:12` **硬 import** 它。打包安装会直接 `ERR_MODULE_NOT_FOUND`（我构造 tarball 内容实测，§3.4）。 |
| **A15** | 不引入新的会话事件类型 | **VERIFIED** | 全包 `session.append` / `appendPluginRecord` **0 命中**（我独立 grep）；代码只构造 `settings.mutate` 操作，不写会话。插件侧唯一会写的路由事件是官方的 `model/selection`。 |
| **A16** | 观感对齐（3 机判） | **判定 3 VERIFIED；判定 1/2 UNVERIFIABLE** | 判定 3：`Select-String -Path client.js -Pattern '#[0-9a-fA-F]{3,8}\b\|rgba?\(\|hsla?\('` → **matches=0**（我复跑）。判定 1：容器锚点 `data-conversation-region="composer"` 在官方 client 中确实存在（`dsh-client-ui-conversation/lib/client.js:20596`），但控件位置未 live 复核。判定 2：`client.js` 中 `--dsw-`/`style:`/`className` **0 命中** → 控件完全无内联样式，对比度与"两主题颜色不等"需真实 `getComputedStyle`。 |

### 2.1 三态分布

| 三态 | 条数 | 条目 |
|---|---|---|
| **VERIFIED（离线可证）** | **3** | A11、A12、A15 —— 三条所依赖的机制事实全部由我独立证到（谓词对 `one-shot`/`external`/`null` 的二值结果 + `'continuable'` 字面量在官方 union 中存在；全包零 `session.append`）。其 DOM 面仍属运行时，但**判据赖以成立的那一半已闭合**。 |
| **UNVERIFIABLE（离线不可证）** | **6** | A1、A4、A5、A6、A8、A9 |
| **FAIL / GAP** | **5** | A2、A3、A7、A10、A13 |
| **部分已证（整条仍需运行时）** | **2** | A14（本轮我未动官方包；但包自身 `files[]` 有 M-3 缺陷）、A16（仅判定 3 已证） |
| 合计 | **16** | A1–A16（3 + 6 + 5 + 2）。A14/A16 不计入上面三态，避免重复计数。 |

## 三、四处专项核查

### 3.1 R4 try/catch：**保护在最外层吗？——不是；但当前不会因此炸**

实现者说"不能靠 grep try，要看最外层 listener 是否无条件 return undefined"。**我按他的方法自己读了最外层**：

```js
// lib/host.js:217-220
ctx.on('agent/created', (payload) => {
  bridge.applyToAgent(payload?.agent);
  return undefined;
});
```

**最外层没有 try/catch。** 但 `return undefined` 是无条件执行的——**只要 `applyToAgent` 正常返回**。保护实际来自 `applyToAgent` 自己的 try（`lib/host.js:132-144`）。

我做了两个方向的实验：

1. **M2（删外层 catch，只删 `applyToAgent` 那一层）→ 81 pass / 0 fail**。这复现了实现者的 mutation#1，并证明"测试全绿"不能证明最外层安全。
2. **M3（保留外层 catch，拆掉所有内层 select 兜底，让 `select` 直接抛）→ pass 78 / fail 3**。证明外层 catch 独立有效。
3. **新增故障注入（`_p3-r4-probe.mjs`）**：让 `logger.warn` 本身抛错，且 `select` 也抛错：

```
=== Case 1: a throwing logger, with a select() that also throws ===
  listener THREW -> logger sink exploded   <-- this rejects announce()/resume
```

**结论**：`applyToAgent` 的 `catch` 块里**直接调用 `logger.warn(...)`（`lib/host.js:141`）**。一旦 logger 抛错（日志 sink 故障、序列化循环引用、logger 被替换成会抛的实现），`catch` 本身抛出，**`return undefined` 永远到不了**，`announce()` 拒绝 → 冷队友唤醒失败。这正是 R4 要防的最坏情形，而它发生在"保护"内部。

**判定**：R4 **未被真正满足**。保护不在最外层，且最外层的 `return undefined` 不是 `finally` 保障。修法很便宜：把 listener 包成 `try { ... } catch {} return undefined;`，或在 `applyToAgent` 用 `try/finally`。见 MAJOR-2。

### 3.2 「恢复派发路由 = 删除该条 override」：**语义写对了，但运行时回不到 descriptor（BLOCKER）**

代码确认存在：

```js
// lib/core.js:323-326
export function overrideDeleteOps(childSessionId) {
  ...
  return [{ op: 'unset', path: [CONFIG_FIELDS.overrides, childSessionId] }];
}
```

M1 变异测试证明它被钉住（改成 `set` 立刻红）。**但没有"写回 descriptor"的退化路径**——我 grep 了 `bundle/` 全部运行时文件，只有 `overrideDeleteOps` 一处产出 `unset`，没有任何地方构造"等于 descriptor 的 override"。这一点实现者是对的。

**问题不在"删 vs 写"，在"删了以后官方会不会听"**。我把官方 `modelSelection` projection 逐字抄成可执行副本（`_p3-restore-replay.mjs`，来源 `dsh-agent/lib/index.js:102-174`）做事件重放：

```
--- Scenario 2: 覆盖生效后跑一回合 ---
state: {"pending":null,"lastUsed":{"provider":"deepseek","model":"deepseek-reasoner","reasoningEffort":"high"}}
current() = deepseek-reasoner（覆盖路由）

--- Scenario 3: "恢复" = 删除覆盖；队友再次唤醒（resume，agentOptions = descriptor） ---
state after resume: {"pending":null,"lastUsed":{...reasoner...}}
current() on the first step after restore = deepseek-reasoner
EXPECTED by A7 decision 1 = deepseek-chat
MATCH: false            <-- A7 判定 1 不成立
```

原因链条（每一步都有源码行）：
1. `request/header` 到达时 `lastUsed = selectionOfHeader(header)`（`dsh-agent/lib/index.js:157`）；
2. `pending` 若与 `lastUsed` 相同则被清空（`:158`）；
3. `current()` = `pending ?? lastUsed ?? options`（`:190-195`）；
4. 删 override **不产生任何事件**（插件刻意不写，见 `lib/host.js` 注释与 A7 判定 4 要求）；
5. resume 时 `coldResume` 把 descriptor 三元组塞进 `agentOptions`（`dsh-subagent/lib/index.js:2186-2190`），但 `options` 是**最后**的 fallback。

所以：**只要队友在覆盖路由下跑过哪怕一回合，删覆盖后下次唤醒仍走覆盖路由**。A7 判定 1 不可达。

**对照证据（同类实现怎么做的）**：本机 profile 里已装有一份同名功能的成熟实现 `@wufeng0105/dsh-teammate-model-picker@0.3.2`。它的"恢复"不是删表就完事，而是通过 `agent/pre-step` + `agent/request` 两个 waterfall **在运行时改写请求路由**，并用 `modelSwitchNotice` 把切换事实写进对话（`host/core/install-plan.mjs` 的 `dispose` 分支 + `index.js` 的 `onRequest`/`onPreStep`）。也就是说，产业内的做法是**必须在请求路径上介入**，仅靠"删持久表 + 等下次唤醒"不足以回退。

**判定**：BLOCKER-1。A7 判定 1 需要改验收（客户豁免）或改实现（在唤醒/step 处主动写一次 `model/selection` = descriptor，或挂 `agent/request` 覆写）。

### 3.3 `Config === undefined` 软加载：**不只是"本地没依赖"，装进 profile 后仍然是 undefined（BLOCKER）**

实现者说这是"本地 `bundle/` 没有 schemastery 依赖"导致的（`06-implementation.md:163`、`07-selfcheck.md` §6 第 2 处）。**我证伪了这个归因**。

根因在 `lib/schema.js:82-84`：

```js
const loaded = await importer('@deepseek-ai/schemastery');
const namespace = loaded?.default ?? loaded;
return namespace !== null && typeof namespace === 'object' ? namespace : null;
```

schemastery 的 `default` 导出是**函数**，不是 object：

```
node -e "import('file:///.../@deepseek-ai/schemastery/lib/index.mjs').then(m=>{...typeof m.default...})"
typeof default = function
is object? false
has .object? function
```

于是 `typeof namespace === 'object'` 恒为 `false` → `loadSchemastery()` **恒定返回 `null`** → `export const Config = undefined`（`index.js:17`）。

我用三种安装形态实测（全部在 `%TEMP` 模拟，依赖真实到位）：

| 安装形态 | schemastery 可达？ | `import index.js` 结果 |
|---|---|---|
| 软链/junction 到 workspace（`plugin_manager` 对目录安装即 `link:`/`file:`） | 是（`require.resolve` 成功） | **`Config = undefined (DEGRADED)`** |
| 拷贝安装（tarball 内容）到 `profile/node_modules`，依赖齐全 | 是（从包内 `lib/` 能 `RESOLVED from pkg/lib: ['default']`） | **`Config = undefined (DEGRADED)`** |
| 拷贝安装 + 依赖缺失 | 否 | `Config = undefined` |

并且我证明了**只要绕过这个 guard，真实 schemastery 完全可用**：

```
=== 把真实 namespace 直接喂给 createConfigSchema ===
createConfigSchema(real ns) works; root fields = [ 'showSelector', 'overrides' ]
  showSelector: type=boolean volatile=true
  overrides: type=dict volatile=true
overrides inner type = object | sKey = string
```

**后果（这才是重点）**：
- 官方 `dsh-settings/lib/index.js:503-506`：`schema(entry)` 取自 `entry.fiber?.runtime?.Config`；`Config` 为 `undefined` → `schema === undefined` → **`throw new Error('No configurable plugin entry')`**。`configForms.get(entryId)` 拿不到表单，`settings.mutate` 不可写。
- 于是 A8 判定 1（重启后覆盖仍在）、A10（开关持久值）、A4/A7 的写路径**全部没有可用存储**。
- Client 会落「设置不可用」禁用态（`client.js:107,117`）——这是**诚实降级**，但意味着**功能整体不可用**，不是"本地不方便"。

**判定**：BLOCKER-2。修法：把 guard 改成放行 function（`typeof namespace === 'object' || typeof namespace === 'function'`），或按官方惯例直接 `import z from '@deepseek-ai/schemastery'`（本机 profile 顶层确实有该依赖，`@wufeng0105` 那份实现更是把 schemastery **vendor 进包内** `vendor/schemastery.mjs` 以避免此类问题）。

### 3.4 `turn/start` 兜底未做：**让 A6 建立在一条未验证的单点上，且 A7 的回退链已断**

- 现实：热应用只有 `loader/volatile-update` 一路（`lib/host.js:222-225`），没有 `turn/start`/`agent/pre-step` 兜底。
- 我核了官方事件语义：`_commitVolatile()`（`cordis-plugin-loader/lib/index.js:526-557`）只在 `ref.get()` 与 `source.get()` 不等时 `updateVolatile` 并 emit；`paths` 为空则**不 emit**。所以"事件会到"是有条件的：**必须真的发生了 volatile 值变化**。这条没问题。
- **但"到了以后是否还在 step 准备之前"没有任何证据**。`agent/pre-step` 在 `dsh-agent-loop/lib/index.js:666-672` 先读 `model.current()`，而 `:1000-1001` 明确：step 准备后再改路由会被官方**拒绝**（抛错）。U-3 只证了「`agent/created` 早于首 step」这一条路径；**live 队友的 volatile-update 时序没有被任何探针覆盖**（05 报告 R1 自己把它列为缺口）。
- 更关键：一旦 `volatile-update` 在某个 step 中途到达，`select()` 会写 `model/selection`，但该 step 的 selection 已经固定 → 官方抛 `agent "x": agent/request proposed ... after step preparation fixed`。这**不是**"下一 step 生效"，而是**当前 step 报错**，直接违反 A6 的"不中断"判据。

**判定**：MAJOR-1。A6 在运行时是否可达**未被证明**，且缺少 plan 中约定的兜底（`turn/start` 比对）。实现者把它写成"留作 P3 的备选，不是遗漏"（`06-implementation.md:166`），但 P3 就是**现在**——本轮我不能 live 验（超时+不装），所以它从"备选"变成"交付时仍未验的关键假设"。

## 四、代码抽查（任务指定的五处）

### 4.1 override 表读写与校验 —— 通过
- `normalizeTable` 丢弃坏条目而非抛错（`lib/core.js:107-120`），且刻意不用 `isPlainObject`（注释解释：原型被污染的表仍有可用自有项）——这个判断正确，我认同。
- `UNSAFE_KEYS = {__proto__, prototype, constructor}` 永久拒绝（`:33,44`），且 `setOverride`/`normalizeTable` 都用 `Object.defineProperty` 写入（`:117,149`），**避免原型污染**。测试 `setOverride cannot shadow the prototype of the table` 覆盖。
- `deleteOverride` 对不存在的 key 是 no-op 且返回等值新表（`:161-166`），不 mutate 入参。

### 4.2 路由决策的"零介入"（引用相等） —— 通过，且有硬证据
```js
// lib/core.js:186-192
for (const [source, candidate] of [['dispatch', dispatchRoute], ['current', currentRoute], ['fallback', fallbackRoute]]) {
  if (candidate !== null && candidate !== undefined) return { route: candidate, source, intervened: false };
}
```
返回的是 `candidate` 本身，不是拷贝。测试用 `assert.equal(decision.route, DISPATCH)`（引用相等）钉住（`test/core.test.mjs:192-198`）。M2 之外我还试过"返回副本"这一变异（实现者 mutation#2），会红。**这条实现者说得对。**

### 4.3 volatile 字段读写 —— 读 OK，写 OK，但**没人调用**
- `unwrapVolatile`（`lib/core.js:262-267`）用 `typeof value.get === 'function' && typeof value.toJSON !== 'function'` 判定，与官方 `createVolatile` 产物形状一致（`cosmokit/lib/index.js:102-110`：冻结对象，只有 `get` + 一个 symbol 写入器）。判断合理。
- `readShowSelector` 不可读时回落（`:276-283`），测试覆盖抛错路径。
- 写：`overrideSetOps`/`overrideDeleteOps`/`showSelectorOps` 三条都产出正确的 volatile 路径，`isVolatilePath` 逐段校验通过（我按 `dsh-settings/lib/index.js:153-158` 手工核过：`overrides` 节点 `meta.volatile === true` → 首段即放行）。
- **缺口**：这三个函数**在交付代码里零调用**（`grep overrideSetOps|overrideDeleteOps|showSelectorOps` 只命中 `core.js` 定义与测试）。Client 半没有任何 `mutate` 调用。所以"写路径已就位"只是**构造器存在**，不是"能写"。

### 4.4 `webserver/index-inject` 下发 entryId —— 机制对，取值有疑
- 形态正确，与官方先例同构：`dsh-client-shortcuts/lib/index.js:13-21`（`table.push({kind:'global', name, value: config})`），渲染侧 `dsh-host-webserver/lib/index.js:29-34`（`globalThis[name] = JSON.stringify(value)`），读侧 `Reflect.get(globalThis, ...)`（`dsh-api-remote-access/lib/client.js:807`）。`lib/host.js:207-214` 的写法可以工作。
- 取值用 `ctx.fiber.entry?.options.id`（`lib/host.js:68`），与官方 `dsh-experimental-speech-to-text/lib/index.js:20` 同款——**这一点实现者对**。
- **但**：`Config.listConfigs` 返回的 settings namespace 是 **`include:teammate-model-picker`**（我实测，见 §3.3 引用的 inspect 输出），而 `entry.options.id` 是 `teammate-model-picker`；`entry.id` getter 会拼上前缀（`cordis-plugin-loader/lib/index.js:457-461`，`sep = ":"`）。`dsh-settings` 用的正是 `entry.options.id`（`:432,443,502`），与 `options.id` 一致，所以**这里其实是自洽的**——`settings.describe` 的 `ns` 和 `configForms` 的 `namespace` 都是 `options.id`（`teammate-model-picker`），下发的值正确。**这一处我查完判"无缺陷"**，但需要 live 确认 `configForms.get('teammate-model-picker')` 能命中（当前因 BLOCKER-2 必然返回 null，见 3.3）。

### 4.5 Client 半 `Reflect.get` 读回 —— 通过（含一处真实降级）
```js
// client.js:65-70
function readEntryIdFromGlobal() {
  const published = Reflect.get(globalThis, ENTRY_GLOBAL);
  ...
}
```
- 不做"包名兜底"，缺 id 时 `settingsAvailable: false` + `disabled` 按钮（`client.js:107-117`），符合 §3-Q12 的"可见降级，不静默失败"。
- 重试逻辑正确：成功才 memoize，失败不 latch（`client.js:144-152`），测试 `the form is retried on the next injection call rather than latched unavailable` 覆盖。
- **降级判定用 `ready !== null`（`client.js:163`），而 `configForms.get()` 在官方实现里永远返回一个 controller 对象（`dsh-client-ui-settings/lib/client.js:1294-1301`，从不返回 null）**。所以 `settingsAvailable` 实际上只反映"entryId 存不存在 + 服务在不在"，**不反映 namespace 是否真的被 Host 服务**（那要看 `mutate` 的返回或 `describe`）。BLOCKER-2 场景下它会误报"可用"。见 MINOR-2。

## 五、缺陷清单

### BLOCKER

**B-1｜A7「恢复派发路由」在运行时不可达：删 override 不会让 `current()` 回退到 descriptor**
- 证据：`dsh-agent/lib/index.js:157-162,190-195,200-203`（projection 语义）+ 我的重放实验 `_p3-restore-replay.mjs` 输出 `MATCH: false`。
- 影响：A7 判定 1 必然失败；A8 若在覆盖生效后被"恢复"，同样受影响。这是 REQ 功能 2 的一半（"另有恢复派发路由清掉该队友的覆盖"）。
- 实现侧修法：恢复时**主动写一次** `model/selection = descriptor`（而非只删表），或挂 `agent/request` 覆写路由（参考本机已装同类实现的做法）。验收侧修法：走 `02-plan.md` P1-B2 的客户豁免流程（A7 判定 1 改为"下一次唤醒后 `request/header.config` = 覆盖路由不得再出现"之类可判定形式）。

**B-2｜`Config` 恒为 `undefined`：软加载 guard 类型判断错误，导致整个持久化/写入面不可用**
- 证据：`lib/schema.js:84` 的 `typeof namespace === 'object'`；schemastery `default` 为 **function**（我实测 `typeof default = function`）；三种安装形态实测均 `Config = undefined (DEGRADED)`（含依赖齐全的拷贝安装）；`dsh-settings/lib/index.js:503-506` 在 `Config === undefined` 时 `throw new Error('No configurable plugin entry')`。
- 影响：A8 判定 1、A10 判定 3/5/6、A4/A7 的写路径全部落空。功能整体不可用（Client 会诚实显示"设置不可用"，但那是失败态不是通过）。
- 修法：guard 放行 function；或仿官方 `import z from '@deepseek-ai/schemastery'`；或 vendor 依赖进包（同类实现即如此）。

### MAJOR

**M-1｜A6 的热应用时序未证，且官方对 step 中途改路由是"抛错"而非"下一 step 生效"**
- 证据：`dsh-agent-loop/lib/index.js:1000-1001`（step 准备后改路由 → throw）；热路径只有 `loader/volatile-update`（`lib/host.js:222-225`），无 `turn/start`/`pre-step` 兜底；05 报告 §5-R1 自己把该时序列为未验缺口。
- 影响：A6 可能表现为"当前回合报错"而不是"下一 step 生效"。至少应补兜底并加反向用例。

**M-2｜R4 保护不在最外层，且 catch 块内的 `logger.warn` 可抛出，导致 `announce()` 拒绝**
- 证据：`lib/host.js:217-220`（listener 无 try/catch）、`:140-142`（catch 里直接 `logger.warn`）；我的注入实验 `_p3-r4-probe.mjs` Case 1 输出 `listener THREW -> logger sink exploded`。
- 影响：与 R4 要防的"冷队友唤醒失败"完全同型。修法便宜（`try/finally` 或 listener 级 try）。

**M-3｜交付包 `files[]` 漏 `lib/schema.js`，但 `index.js` 硬 import 它 → 打包安装即崩**
- 证据：`package.json:13-21` 的 `files` 无 `lib/schema.js`；`index.js:12` `import { createConfigSchema, loadSchemastery } from './lib/schema.js';`；我按 `npm pack --dry-run` 的文件清单构造 tarball 内容实测：`IMPORT FAIL ERR_MODULE_NOT_FOUND | Cannot find module '...\lib\schema.js'`。
- 注：目录安装（`link:`）不受影响，但 A14 要求"`files` 与包内文件三方向差集为空"，且 P4 复检会抓。`npm pack --dry-run --json` 实际产出 9 个文件，缺 `lib/schema.js`。

**M-4｜A2/A3/A10/A13 的 Client 面根本未实现，但实现者把它们描述成"切片留白、结构已就位"**
- 证据：`client.js` 全文只有一颗按钮（`:101-119`）；`modelCatalog` / `session/events` / `mutate` / `showSelector` / `data-dsh-teammate-picker-restore` 在 `client.js` 中均为 **0 命中**。
- 影响：这不是"留白"，是 5 条验收（A2、A3、A10、A13，加 A7 的 UI 部分）在交付物里**没有任何可执行路径**。`07-selfcheck.md` 把它们标成"未做（S6 范围）"是诚实的，但 `06-implementation.md:98` 说"当前只渲染一颗带稳定属性的座位按钮，A1/A10 的 DOM 存在性判据在结构上已就位"——**A10 并未就位**（开关不可读），这句表述误导。

### MINOR

**m-1｜`package.json` 的 `test` 脚本是坏的**：`"node --test test/"` 在 Node 24 解析为文件路径 → `MODULE_NOT_FOUND`。实测 `npm test` = 1 test / 1 fail。实现者已知（`06-implementation.md:117`）但未修。

**m-2｜`settingsAvailable` 判据偏弱**：用 `configForms.get()` 非 null 判可用（`client.js:163`），而官方 `get()` 从不返回 null（`dsh-client-ui-settings/lib/client.js:1294-1301`），所以它只反映"entryId 在 + 服务在"，namespace 未被 Host 服务时仍报"可用"。

**m-3｜A5 的客户限定语在交付物中缺失**：`00-client-answers.md:8-10` 要求"验收记录/交付说明必须写明 A5 只证错误类型变化、不得推出额度耗尽可用"。`06-implementation.md`/`07-selfcheck.md` 提到 A5 时（`07:175`）**未带该限定**。这是客户明确要求随判定引用的内容。

**m-4｜`dsh.client.inject` 写了两个包名但 Client 半并不 import 它们**：`package.json:30-33` 声明 `@deepseek-ai/dsh-client-ui-conversation`、`@deepseek-ai/dsh-client-ui-settings`。前者用于 slot 排序合理；后者并不需要（Client 只用 `ctx.configForms` 服务，且已由 `inject: ['configForms']` 承担）。多一条激活依赖 = 多一条失败面。实现者自己也在 `06:177` 提到"若正式清单要求更严格，可与 P3 一并收窄"。

## 六、对实现者「三处最易误解」自述的表态

1. **「恢复派发路由不是把 descriptor 写回去，而是删掉该条 override」——同意，且已独立实证。**
   代码 `lib/core.js:323-326` 只产 `unset`；我的 M1 变异把 `unset` 改成 `set` 立刻红（80/1）。我也确认没有"写回 descriptor"的退化路径（全包只有一处产 `unset`）。
   **但**——这条自述只讲了"怎么写"，没讲"写了以后官方认不认"，而后者正是 B-1：**删对了也回不去**。所以"同意"是对这句话本身，不是对功能。

2. **「`Config` 为 `undefined` 不是 bug，本地没依赖，装进 profile 就变成真 schema」——部分不同意：结论错、归因也错。**
   - 归因错：不是"本地没依赖"，是 `lib/schema.js:84` 的类型 guard 把 schemastery 的 **function** default 判掉了。依赖齐全的拷贝安装实测仍是 `undefined`。
   - 后果比他写的重：`Config === undefined` → `dsh-settings` 直接 throw（`:503-506`）→ 写面全废。这不是"P3 第一件事查一下 schema"，而是"功能现在不可用"。
   - 他建议"如果你在本地跑 `Config.listConfigs` 查到 `absent`，先确认是不是还没安装，不要改 `index.js` 去修它"——**这条建议会让人错过真 bug**。按他说的做，你会以为装了就没事；实际装了还是 `absent`。

3. **「R4 的判据要看最外层 listener 是否无条件 return undefined，不能 grep try」——方法同意，判据不同意。**
   方法对（我用它复现了 M2：删内层 catch 仍全绿）。但"最外层无条件 return undefined"**不是充分条件**：`return undefined` 不在 `finally` 里，catch 块内的 `logger.warn` 一抛，return 就到不了（`_p3-r4-probe.mjs` Case 1 实证）。正确判据应是：**最外层 listener 的返回不被任何可抛路径绕过**（`try{...}catch{}return undefined` 或 `finally`），而不只是"能不能看到 return undefined"。

## 七、证据等级与验证限制（如实记录）

- **客户端 inspect 超时**：`Slots.listSubTree(root:"conversation.input.right")` 本轮**再次 10s 超时**（`Client inspect query Slots.listSubTree timed out after 10000ms`）。与 05 报告 T-3/T-4 同型。因此 A16 判定 1、A1/A11/A12 的 DOM 面、A10 的开关本体**一律为源码级，未取得运行时证据**。
- **未安装**：按约束本轮未安装 bundle、未跑 `plugin_manager` 任何 action、未写 profile。所有"安装后行为"用 `%TEMP` 下的等价目录结构模拟（软链 / 拷贝 / 依赖缺失三形态），这是**近似**，不能替代真实 `install_bundle` 的 pnpm 行为（尤其 `link:` vs 拷贝的真实选择）。B-2 的结论在这三种形态下**一致**，故我判其稳健。
- **本机 profile 里有同类实现**（`@wufeng0105/dsh-teammate-model-picker@0.3.2`），我只读、未修改、未执行其代码，仅作文档/设计对照证据（§3.2）。
- **`bundle/` 零改动**：验证前后对 14 个文件做了 SHA256 记录，见 §8。

## 八、`bundle/` 完整性记录（证明未改）

```
37C847B65CB04F7F  client.js          795D56C45831D09B  cordis.patch.yml
80DD463CA92D68B6  icon.svg           578B8364E81FA66B  index.js
E0F868BCA08EA02F  lib\core.js        80A898C88F6385FD  lib\host.js
D751C529F1B683B7  lib\schema.js      668A072B34B1A977  locale\en.json
D907B46BAEA60F24  locale\zh.json     BD79D9BCC8246D00  package.json
523E597A0052ADA3  test\client.test.mjs   DB7543116E275AB8  test\core.test.mjs
2747647CA0F574A7  test\host.test.mjs     202507CB73F40ECC  test\schema.test.mjs
```

我在工作区根新增的仅为本报告与若干只读探针脚本（`_p3-*.mjs`），**未改 `bundle/` 任何字节**。

## 九、放行意见：**不可进 P4 交付**

理由：两条 BLOCKER 都直接命中客户明定功能——
- B-1 让「恢复派发路由」（REQ 功能 2 的后半）在运行时不可达；
- B-2 让「覆盖按队友保存、重启仍生效」（REQ 功能 3）与「一个显示开关」（REQ 功能 4）失去存储与写入面。

**清障后转"带条件放行"的具体条件**（每条都落到用户可见行为）：

1. **B-2 先修**（一行 guard）。修完的验收动作：装进 profile 后 `Config.listConfigs {"entry":"<本插件 entry id>"}` 返回 `status: "schema"`，且 `showSelector`/`overrides` 两节点带 `x-cordis.volatile: true`。**在此之前，一切"写入能持久"的说法都不成立。**
2. **B-1 二选一**：实现侧在恢复时主动写 `model/selection = descriptor`（或挂 `agent/request` 覆写）；或走客户豁免把 A7 判定 1 改成可判定形式。**在此之前，用户点「恢复派发路由」后，下一次继续仍会用旧覆盖模型。**
3. **M-1**：补 `turn/start`（或等价）兜底，并加一条"活跃回合中切换不导致当前回合报错"的用例。**在此之前，用户可能看到当前回合直接报 `after step preparation fixed` 而不是"下一条生效"。**
4. **M-2**：把 R4 保护改成 `try{...}catch{}` + 无条件 `return undefined`（或 `finally`）。**在此之前，日志 sink 异常会让冷队友唤不起来。**
5. **M-3**：`files[]` 补 `lib/schema.js`，重跑 `npm pack --dry-run` 使三方向差集为空。**在此之前，从 tarball 安装会直接起不来。**
6. **M-4**：把 A2/A3/A10/A13 的 Client 面实现到"菜单能开、能选、能写"，或明确降级为"本期不做"并取得客户同意。**在此之前，用户在队友会话里看到的只是一颗写着"队友模型"的按钮，点不开任何菜单。**

**在 1、2、5 未清之前，我不建议进 P4。**

---

### 附：本报告所有数字的复跑入口

```powershell
cd bundle; node --test                                   # 81/81
cd bundle; node --check index.js client.js lib/core.js lib/host.js lib/schema.js
node _p3-restore-replay.mjs                              # A7/B-1：MATCH: false
node _p3-import-probe.mjs "<安装路径>\index.js"           # B-2：Config = undefined (DEGRADED)
node _p3-r4-probe.mjs                                    # R4：listener THREW -> logger sink exploded
node _p3-schema-dump.mjs                                 # 真实 schemastery 下 volatile=true（证明能力存在，guard 挡住了）
```
