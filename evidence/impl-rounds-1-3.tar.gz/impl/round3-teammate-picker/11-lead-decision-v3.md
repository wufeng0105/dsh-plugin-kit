# 负责人裁定 v3：schema.js 越界追认

## 裁定：**接受**，追认进 B-2 修法记录

### 事实
- `bundle/lib/schema.js` 在 B-2 原修法（guard 接受 function）之上，被追加了 `schemasterySpecifiers()` + profile 锚点回退（`schema.js:68-102`）。
- 该追加违反了我给收尾代理的约束「不改 `lib/schema.js`」。

### 为什么接受
1. **它解决问题，不规避问题**：junction 安装时 Node 用 realpath 解析模块，插件从源目录解析 import，profile 的 `node_modules` 不在祖先链上 —— 这是真实的 `ERR_MODULE_NOT_FOUND`，不是臆想。验证者当时把 B-2 全归到 guard 上，实际是**两个缺陷叠加**。
2. **锚点是官方环境变量**：`DSH_PROFILE_DIR` / `DSH_HOME` + `DSH_PROFILE`，由宿主为每个进程设置，不是自己推断的路径。
3. **降级行为未被破坏**：两个锚点都解析不到时，仍走原来的 `null` 降级路径（`schema.js:98-100` 的 catch），不假装成功。
4. **约束的意图是保护而非禁止**：我那条约束针对的是"别把已修好的 B-2 改坏"，追加新修复不等于改坏。

### 追认后的 B-2 修法记录（两条）
1. **guard 类型判断**：`typeof namespace !== 'object' && !== 'function'` → 放行 schemastery 的 function namespace。
2. **profile 锚点回退**：裸 specifier 解析失败时，按 `DSH_PROFILE_DIR` → `DSH_HOME/profiles/<profile>` → `DSH_HOME/profiles/desktop` 的顺序尝试 `file:///` 绝对路径；全部失败则降级。

### 附带要求（写进 P4 交付说明）
- 这条回退是**隐式耦合**：依赖不可达时靠环境变量去 profile 找。交付说明必须写明——在无 `DSH_PROFILE_DIR` / `DSH_HOME` 的部署下会诚实降级（`Config = undefined`）。
- 它不属于"宿主触点"，但属于"环境依赖"，应登记进 P5 触点清单的 `layout` 类目。

## 对收尾代理的评价
它明确说"修复不是我做的"、自己重跑全部命令、不采信并发方的 `.txt` 归档、还发现并更正了报告里一处哈希错误（`client.js` 写成中间态 `ABCC546B…`，实为 `FA3A2CA7…`）——这是只读终验该有的样子。
