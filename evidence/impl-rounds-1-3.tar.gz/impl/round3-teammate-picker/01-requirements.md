# 01-requirements.md — dsh-teammate-model-picker 需求文档（P0）

> 需求来源：`process-lab\requirements\REQ-03-dsh-teammate-model-picker.md`（下称 REQ）
> 流程规格：`process-lab\spec\process-v2.md`（下称 SPEC）
> 版本：**r3**（2026-11-08）。r2 → r3 = 按 `05-p1.5-probes.md` §3 的 M5/M6/M8 回填 P1.5 结论（见 §8）；r2 的返工对象 = `03-gate-P0P1.md`（逐条落点见 §7）。
> 本文件只做 P0（需求），不做实现设计（设计在 `02-plan.md`）。
> 所有关于宿主能力的描述均带出处（出处索引见 `probes.md` P-xx；P1.5 的新出处见 `05-p1.5-probes.md` §4）。
> 客户裁定原文见 `00-client-answers.md`（Q2 = `:5`，Q8 = `:6`，A5 限定 = `:8-10`）与 `00-client-answers-2.md`（A10 呈现位 = `:5`，U-4 收窄 = `:6`，U-2 路径 B = `:7`，R1–R4 运行时缺口 = `:7`）。

## 1. 需求理解

给**可继续的子代理会话**（REQ 称「队友」，见 §4-Q1 的口径裁定）在 Web GUI 输入行工具区加一个模型选择器：显示当前模型与推理等级，两级菜单（模型 / 推理等级），外加一个「恢复派发路由」动作清掉该队友的模型覆盖。核心价值：队友额度耗尽后不用重建队友，换一个有额度的模型让它继续跑；主线会话与全局默认模型不受影响。

**价值边界的诚实表述**：插件提供的是「换一个路由继续跑」的能力，**不是**「修复额度耗尽」。额度耗尽的判定、配额、重试都属于宿主/服务端，插件既不识别也不补偿（见 A5 的客户限定与 §3 第 5 条）。

对 REQ「背景」段陈述的痛点，探测到的宿主机制与之一致：会话模型选择是**会话级持久事实**（`model/selection` 记录、`request/header` 收尾），队友子会话在派发时按解析出的路由写入描述符并在每次请求沿用最近一次请求的路由（P-14、P-15）；官方模型选择 UI 对子代理会话显式拒绝（P-11），官方 RPC `session.selectModel` 对 `origin === 'subagent'` 的会话直接返回 `session/agent-busy`（P-13）。

功能四条（REQ §功能）逐条落位：

| REQ | 落位 |
|---|---|
| 1 选择器在队友会话输入行工具区，显示当前模型+推理等级，只在队友会话渲染 | 验收 A1、A2、A11、A12 |
| 2 两级菜单（模型/推理等级）+「恢复派发路由」 | 验收 A3、A7 |
| 3 覆盖按队友各自保存、重启仍生效、无覆盖零介入 | 验收 A5、A8、A9 |
| 4 一个显示开关 | 验收 A10；落点 = 插件 Config 布尔字段 `showSelector`（**客户裁定 Q2**，profile patch 层，§4）；**呈现位 = 插件自带 UI（挂官方座位），不是 Settings 自动表单**（U-6a 已定降级，**客户已批准**，`00-client-answers-2.md:5`） |

硬约束四条（REQ §硬约束）的验收映射：

| 硬约束 | 验收 |
|---|---|
| 1 不改任何官方包 | A14 |
| 2 不引入新的会话事件类型 | A15 |
| 3 无覆盖时零介入 | A9 |
| 4 不动全局默认模型 | A4、A5 |

## 2. 逐条行为版验收（A1–A16）

约定：

- 「机判」= 下列命令/输出可二值判定，判定栏必须给出**表达式 + 期望值**；「人工补充」= 允许观察但不构成通过依据（不得单独用来判通过）。
- 「子会话日志」指队友子会话的持久事件流。审查员可用任一官方只读通道复核：`@deepseek-ai/dsh-session-query` 的 `readSession(sessionId)`（P-18）或会话持久化文件（JSONL/zstd，P-19）。P2 交付时把每条用到的具体命令固化进自验说明（SPEC P2 出口判据）。
- 「DOM 判定」= 在 GUI（当前实例：http://127.0.0.1:6727；r2 记的 8314 为旧端口，P1.5 第二轮起为 6727）浏览器控制台或 Playwright 会话中执行 `document.querySelector(...)`；选择器挂载点一律带稳定属性 `data-dsh-teammate-picker`（A16 一致），恢复项带 `data-dsh-teammate-picker-restore`。判定片段见 §6。
- **父级在线 / 普通 composer 前提（P1.5 收窄，U-4）**：**凡在队友会话里执行的验收场景（A1–A8、A10、A13、A15、A16；A9/A11/A12 见其自身限定）一律要求该队友视图由普通 composer 挂载**，即不在 `mode === 'unknown'`、不在本地 one-shot、且 `parentAvailable !== false`（或 running）。这三类状态下官方 `ui-subagent` 用只读 composer **顶替整条 composer chain**，`conversation.input.right` 根本不渲染。这是对 REQ「只在队友会话渲染」的范围收窄，已写进 §3 第 13 条（不在验收里判、也不算缺陷；对应 `00-client-answers-2.md:6` 客户已接受）。
- **写入生效口径（P1.5 路径 B，客户 Q8）**：覆盖值先写入**插件侧 Config volatile 表**，**下一次唤醒**（`agent/created`）时回填生效；已在运行中的队友由 `loader/volatile-update` 热应用（运行时未验，P2/P3 覆盖）。验收的「切换后」时点因此分两态：live 队友 = 切换后下一 step；冷队友 = 下一次唤醒的首个 step（A8 判定 3）。

### A1 只在队友会话渲染

- **操作**：安装插件后，同一浏览器内先打开主线会话，再打开一个可继续队友会话（右栏子代理树或面包屑进入，父级在线）。
- **观察**：主线会话 composer 工具区 DOM；队友会话同区域 DOM。
- **判定**（机判）：主线会话下 `document.querySelector('[data-dsh-teammate-picker]')` 为 `null`；队友会话下非 `null`。

### A2 显示当前模型与推理等级

- **操作**：在队友会话读取控件文本；与该子会话日志中最近一次生效路由（`request/header` 的 `config`，无则 `subagent/descriptor` 三元组）比对。
- **观察**：控件显示 provider/model 与推理等级名。
- **判定**（机判）：
  1. 控件文本包含该路由的 provider 与 model 标识（`textContent.includes(provider) && textContent.includes(model)`）。
  2. 有 reasoning 元数据的模型：显示值 ∈ `resolveModelInfo().reasoning.efforts` 的等级 id 集合（P-17）。
  3. 无 reasoning 元数据：显示固定占位键 `teammatePicker.effort.auto`（zh = 「自动」，en = `Auto`；Q5）。判定 = 文本等于该键在当前 locale 的值，不接受同义改写。

### A3 两级菜单：模型 / 推理等级

- **操作**：点击控件 → 打开第一级（模型列表，按 provider 分组）→ 选择一个模型 → 打开第二级（推理等级列表）。
- **观察**：两级菜单的内容集合；列表来源为全量目录（不随白名单联动，REQ 边界）。
- **判定**（机判，**集合相等，不用 `≥`**）：
  1. 基准集合：`P_ok = { p | p ∈ listProviders() 且 listModels(p) 成功且非空 }`；`E = ⋃_{p∈P_ok} listModels(p)`（键 = `provider + '/' + model`）；`P_fail = { p | listModels(p) 抛错 }`。
  2. 第一级「有模型分组」集合 == `P_ok`（双向差集为空）；条目键集合 == `E`（双向差集为空）。
  3. `P_fail` 中的 provider 以单列「加载失败」条目呈现，既不计入 `P_ok` 也不得被静默吞掉；`P_fail` 非空不使本条失败，但必须连同 provider 名与错误写入自验说明（对齐 D6 的单组失败降级）。
  4. 第二级：选中 `(p,m)` 后等级集合 == `resolveModelInfo(p,m).reasoning.efforts` 的等级 id 集合（双向差集为空）；无 `reasoning` 元数据 → **不出现**第二级，控件按 A2 第 3 项显示占位（REQ 宽容项允许）。
  - 为什么不用 `≥`：零模型 provider 会让正确 UI 的组数小于 `listProviders()`（`≥` 判假），空组又会让 `≥` 判真；两种错都实测可发生（03 报告 P0-M3）。

### A4 切换写入：只动该子会话

- **操作**：在某队友会话选择新模型+等级（**必须选与当前路由不同的一条**，见判定第 4 项）；随后读取三处：该子会话日志、主线会话日志、profile 配置中全局默认模型段。
- **观察**：子会话日志新增 `model/selection`（官方既有事件类型）；主线日志无新增请求/选择事件；全局默认不变。
- **判定**（机判）：
  1. 三处各自前后快照 diff = 仅子会话新增 1 条 `model/selection`（其 `provider/model/reasoningEffort` = 所选值）。
  2. 主线 diff 为空。
  3. 全局默认段字节不变（P-9/P-20）。
  4. **同路由例外**：官方 `AgentModel.select()` 对「与当前相同」的路由直接 return、不写事件（`dsh-agent/lib/index.js:196-199`）。因此本验收固定选一条**不同**的路由；若操作失误选了同路由，判「测试无效、重跑」，不得判插件失败。

### A5 换掉不可用路由后队友可继续（模拟「额度耗尽」）

- **适用限定（客户裁定，必须随判定一起引用，`00-client-answers.md:8-10`）**：本验收用「不可用路由」模拟「额度耗尽」。客户接受这个模拟，但要求写明**两者失败面不同**：
  - 额度耗尽 = **服务端拒绝**：路由本身有效，请求已发出、被服务端回绝；
  - 不可用路由 = **本地解析不到**：路由无效，请求根本没发出。
  - 所以 **A5 只能证明「换模型后错误类型变了」，不能证明「额度问题解决了」**。任何交付说明、验收记录、宣传语都不得由 A5 推出「额度耗尽可用」。
- **操作**：构造一个使用不可用路由的队友（Q3）；发「继续」，确认失败如旧；在控件里换到一个可用模型+等级；再发「继续」。
- **观察**：换前失败回合的 `request/header.config`；换后下一条 `request/header.config`；随后是否出现 `assistant/message`；换前错误的错误码/文案。
- **判定**（机判）：
  1. 换前：失败回合的 `request/header.config` = 派发路由（`subagent/descriptor` 三元组）。
  2. 换后：`request/header.config` 的 `provider/model/reasoningEffort` = 新选择，且该回合至少产出 1 条 `assistant/message`，`turn/end` 的 reason ≠ error。
  3. 同窗口内主线会话无新增 `request/header`；全局默认段字节不变。
  4. **只记错误类型变化**：换前失败的错误码/文案记入自验说明，换后同一错误不再出现 → 记「错误类型已变化」。判定栏**不得**出现「额度问题已解决」「额度耗尽场景已验证可用」这类结论（见上方限定）。
- **反向约束**：本条通过不能作为「额度监控/自动降级」需求的入场券（§3 第 5 条）。

### A6 活跃回合中切换：下一 step 生效

- **操作**：让队友处于进行中回合（长任务），此时切换模型。
- **观察**：进行中请求不被中断（原 `request/header` 与其 `assistant/message` 完成）；随后 step 的 `request/header.config` 为新路由。
- **判定**（机判）：切换时刻到下一 step 之间不出现 aborted/中断事件；下一 step 的 `request/header.config` = 新选择（对齐官方语义 P-16；step 准备后改路由会被官方拒绝，见 `dsh-agent-loop/lib/index.js:1000-1001`）。

### A7 恢复派发路由

- **操作**：在已覆盖的队友会话菜单中点「恢复派发路由」；再发「继续」（冷队友则等下一次唤醒）。
- **观察**：覆盖标记消失；下一条 `request/header.config` 回到派发路由（descriptor 三元组，P-15）。
- **判定**（机判）：
  1. 恢复后 `request/header.config` 的 provider/model/effort = `subagent/descriptor` 记录值。**时点**：live 队友 = 恢复后下一 step；冷队友 = 恢复后**下一次唤醒**的首个 step（与 A8 判定 3 同口径）。
  2. 该回合失败如旧（失败本身是宽容项，不是缺陷）。
  3. 无覆盖状态下该菜单项为不可用：`document.querySelector('[data-dsh-teammate-picker-restore]')` 存在且 `el.disabled === true`（或 `aria-disabled === 'true'`，二者取一并在 P2 自验说明固定）。
  4. **实现口径（P1.5 路径 B，不改变判据）**：「恢复派发路由」= **删除该队友的覆盖条目**，不是写一条等于 descriptor 的覆盖。因此恢复后插件侧覆盖表里该 `childSessionId` 不存在（可用 `settings.describe` 读回确认，记入自验说明）；下次唤醒按 descriptor 路由。

### A8 重启后覆盖仍在

- **操作**：完成 A4/A5 后重启 DSH（Host 进程重启），打开同一队友会话，发「继续」。
- **观察**：控件显示与重启前一致；新 `request/header.config` = 覆盖路由。
- **判定**（机判）：
  1. 重启后控件显示值与 A4 记录一致（A2 判据）。
  2. 重启后**首个** `request/header.config` = 覆盖路由。
  3. **冷场景口径（P1.5 已定，不再是条件句）**：实现采用「下一次唤醒生效」（客户 Q8 + `02-plan.md` §1 **路径 B，已定为唯一实现**），本条第 2 项以「重启后首次唤醒的首个 step」为准。U-3 已验（源码级）：`agent/created` 串行监听在 maintenance 相位内被 await，驱动唤醒被挂起，首 step 的 `model.current()` 在回填之后读取 → 本项**可达**。若运行时反证（P3），**不得用「再发一次继续」替代**（那是第二次唤醒，违反 Q8），须走 `02-plan.md` P1-B2 的客户豁免流程。
  4. **硬要求（客户已批准，`00-client-answers-2.md:7`）**：`agent/created` 监听体必须 `try/catch`。官方契约原文「a listener failure rejects」（`agents` 服务契约）——监听器抛错会让 `announce()` 拒绝、**冷队友唤醒直接失败**（比不生效更糟）。P2 自验说明必须记录该监听体的 try/catch 代码位置。

### A9 无覆盖时零介入

- **操作**（固定脚本，两态对比）：
  1. 准备两个相邻创建、`descriptor` 三元组相同、preset 相同的队友会话：T-A（装插件）、T-B（不装插件，作为基线）。
  2. 对每个队友按同一脚本执行三个动作：`继续`（发一条固定短指令）→ `中断`（回合进行中 abort）→ `恢复`（重新打开会话并继续）。
  3. 采集两边子会话日志的事件序列：`events.map(e => [e.type, 关键字段])`，剔除 `ts`/`id`/耗时等非语义字段。
- **判定**（机判）：
  1. **日志主判据**：装插件前后该会话日志 `type` 序列逐项相等；T-A 日志中不出现任何非官方 `type`，不出现插件注入字段（双向差集为空）。
  2. **空转判据**：仅打开 T-A 队友会话、不做任何切换动作时，打开前后日志 diff 为空（零写入）。
  3. **零介入的实现口径（P1.5 路径 B）**：无覆盖时插件**不调用** `agent.model.select()`；覆盖表（插件侧 Config volatile `overrides`）为空即可，`agent/created` 监听读到空表直接返回。该监听本身不写会话日志，因此不影响本条主判据。
  4. **行为等价判据（机判，替代原来的「行为无差异」表述）**：上述固定脚本下，两边的 `type` 序列 diff 为空 **且** `turn/end.reason` 序列相等 → 行为等价成立；任一处不等 → 不通过并记录差异。**比对窗口**限定为 `turn/start → 首个 assistant/message`，脚本用「无工具调用」的固定短指令（避免模型自主决定工具调用导致序列天然不同）；窗口外只比对 `type` 集合、不比对顺序。**可比性前置**：若两次基线（T-B 连跑两次）自身序列就不同，判「环境不具备可比性」，本条降为「插件零注入事件 + 插件事件类型集合为空」并记录原因，不得硬判通过。
  5. **人工补充（不作通过依据）**：主观手感/响应快慢的观感差异。
  - 退化方案：若无法构造两个同 descriptor 队友，改为「同一队友：装插件 → 跑脚本 → 卸载插件 → 再跑脚本」，以两次 `type` 序列相等为判据；卸载步骤不得触发任何会话写入。

### A10 显示开关

- **操作**：在**插件自带 UI**（挂官方座位，非 Settings 自动表单）关闭显示开关；检查主线与队友会话；再开启；重启后复查。
- **观察**：DOM 存在性；开关持久值。
- **判定**（机判）：
  1. 关闭后所有会话（含队友）`document.querySelector('[data-dsh-teammate-picker]')` 为 `null`。
  2. 开启后 A1 复测通过。
  3. 重启后 `Config.listConfigs` 读到的本插件 entry 中 `showSelector` 值 == 重启前值（Config key = `showSelector`，boolean，**Config volatile 字段**，profile patch 层，客户 Q2）；且 DOM 存在性与该值一致。
  4. 反向：不得出现「关掉后重启又自己出现」（客户明确排除「临时隐藏但重启复位」，§3 第 14 条）。
  5. **呈现位口径（M5，P1.5 U-6a 已定降级，客户已批准）**：`showSelector` **不会**出现在 Settings 的自动表单里（`dsh-settings/README.md:33`：表单只暴露 volatile 字段的 form 结构，但「no shipped client」使用 `autoGenerate`；`dsh-client-ui-settings-plugins/README.md:12`：官方插件各有一个 companion package 注册自己的页面）。因此本条的**呈现位判据 = 插件自带入口（挂官方座位）**，**不再按「Settings 页可见」判**；存储与持久语义仍按客户 Q2 的裁定（Config、profile patch 层、重启仍在）。文案必须说明这是「我这个人不想看」，不是「这个会话不要」（`00-client-answers-2.md:5` ① ②）。
  6. **读取方式（M5）**：持久值读取走 `Config.listConfigs {"entry": <本插件 Loader entry id>}`（按 entry 精查，P1.5 已实测可用，见 `05-p1.5-probes.md` §4.6 与 §4.8(3)），或 Client 侧经 `ctx.configForms.get(entryId)` 快照 / `settings.describe` 读回。**注意 entry id ≠ 包名**：形如 `<profile 内 patch 行 id>`，由 Host 经 `webserver/index-inject` 下发（M9 / `02-plan.md` D19）。Clients 侧写入同样必须先拿到该 entryId，缺失时控件必须是「设置不可用」禁用态（不得静默失败）。

### A11 one-shot / 外部后端子代理不渲染

- **操作**：打开一个**本地 one-shot 子会话**（必测，环境可构造）；再检查外部后端子任务（ACP/SDK/Codex/Claude Code，环境依赖项）。
- **观察**：控件 DOM。
- **判定**（机判）：
  1. **主判据（必测）**：本地 one-shot 子会话下 `document.querySelector('[data-dsh-teammate-picker]')` 为 `null`（非可继续子代理不属于「队友」，Q1）。**机制口径（P1.5 U-4）**：one-shot 与 `unknown`、父级离线同属「官方只读 composer 顶替整条 composer chain」，slot 根本不渲染 → `null` 是必然结果，不是插件主动隐藏。
  2. **条件项（环境依赖）**：外部后端存在性先由 `agentProviders` 目录/插件配置列出（命令 + 输出记入自验说明）。存在 → 逐个打开其子会话，判据同上，期望 `null`；不存在 → 记 `N/A（环境无外部后端）`，附列出命令与输出。**N/A 不构成失败，但不得省略记录**；也不得用 N/A 掩盖主判据。**机制口径**：`mode === 'external'` 的子代理没有本地子会话，同样不满足「可继续」，谓词层面即返回不渲染。

### A12 其余会话一律不渲染

- **操作**：依次打开：空白新会话、普通已开始会话、fork 出的会话、Hero（未绑定会话）状态。
- **观察**：控件 DOM。
- **判定**（机判）：四种状态下 `document.querySelector('[data-dsh-teammate-picker]')` 均为 `null`。

### A13 切换到不可用模型：失败干净

- **操作**：选择一个目录中存在但实际不可用的路由（如凭证缺失 provider 下模型）；确认切换；发「继续」。
- **观察**：子会话该回合以错误收口（`turn/end` reason=error 或等价），控件状态回到可操作；子会话日志无损坏（可继续读取、可再切换）。
- **判定**（机判）：失败回合后仍能再次切换并「继续」成功；子会话日志能被 `readSession` 正常读出（无 invalid-record）。

### A14 不改任何官方包

- **操作**：记录安装产物 `files` 清单与 DSH 安装目录（`resources\app.asar`、`resources\app.asar.unpacked`）安装前后的哈希/mtime；审查安装目录内是否新增/改动任何 `@deepseek-ai/*` 文件。
- **判定**（机判）：官方目录哈希前后一致；交付包 `files` 与包内文件三方向差集为空（该项在 P4 复检，SPEC P4）。

### A15 不引入新的会话事件类型

- **操作**：在装与未装两种状态下各产生一次切换，diff 两条日志新增事件的 `type` 集合。
- **判定**（机判）：新增事件 `type` 全部属于官方既有事件类型集合（`model/selection` 为官方既有类型，见 P-15）；无自定义 `type` 字符串出现。

### A16 观感对齐（三条机判 + 一条人工补充）

- **操作**：在队友会话取控件与菜单的 DOM 位置、主题取值；浅色/深色主题各一次。
- **判定 1（位置，机判）**：
  ```js
  const picker = document.querySelector('[data-dsh-teammate-picker]');
  const slot = SLOT_CONTAINER && document.querySelector(SLOT_CONTAINER);   // U-4 记录后固化，见 §6
  const input = document.querySelector('textarea, [contenteditable="true"]');
  const p = picker.getBoundingClientRect(), i = input.getBoundingClientRect();
  ({ inSlot: !!slot && slot.contains(picker),
     // 水平落在输入框宽度内；垂直落在输入行邻域（上下各 3 倍输入框高度内，兼容工具行在输入框上/下的两种宿主布局）
     inInputRow: p.left >= i.left - 1 && p.right <= i.right + 1 &&
                 p.top >= i.top - 3 * i.height && p.bottom <= i.bottom + 3 * i.height })
  ```
  通过条件：`inSlot === true` **且** `inInputRow === true`（控件在 composer 工具行内、与输入框同区）。若 `SLOT_CONTAINER` 未取到（U-4 记录缺失），退化为仅 `inInputRow` 判据，并把「slot 容器选择器缺失」记入已知问题。
- **判定 2（主题跟随 + 对比度，机判）**：浅/深两主题下分别计算控件文本与其第一个不透明背景祖先的对比度，**两主题都必须 ≥ 4.5:1**（WCAG 2.x 相对亮度公式，脚本见 §6）；**且**两主题的 `color` 计算值不相等（证明跟随宿主 token，而不是写死一种颜色）。任一主题 < 4.5 或两值相等 → 不通过。
- **判定 3（无硬编码颜色，机判）**：交付包 `client.js` 内 picker 相关样式不含颜色字面量：`Select-String -Pattern '#[0-9a-fA-F]{3,8}\b|rgba?\(|hsla?\(' client.js` 无命中；有命中必须逐条在自验说明给出豁免理由（例如插件图标资源），否则不通过。
- **人工补充（不作通过依据）**：走查截图、「看起来是否像官方控件」的观感判断（SPEC 铁律 7）。截图只作补充证据。

## 3. 「不做」清单（具体）

1. 不暴露给 agent 的换模型工具/动作（REQ 边界明写：只有 UI 路径）。
2. 不做模型目录白名单、与官方白名单/预设联动（REQ 边界明写：展示全量）。
3. 不做与官方像素级一致的还原、不追求与官方选择器键盘序列同源（REQ 宽容项）。
4. 不做与官方 `/model` 命令 popup 的集成或复用（官方入口对子代理会话显式不可用，P-11/P-13，本期不修复官方入口）。
5. 不做额度/余额监控、预警或自动降级路由（插件不判定「额度耗尽」，只提供切换能力；A5 的限定语就是这条的验收侧对应）。
6. 不做多模型并发路由、负载均衡、失败自动 fallback 链。
7. 不做 agent 侧可编程 API（host Service 之外的编程入口不承诺稳定）。
8. 不支持外部执行后端（ACP / Codex / Claude Code / DSH SDK 等无本地子会话的子代理，P-12）与 one-shot 子代理（无继续语义）。
9. 不改变 fork/子代理的模型继承与恢复策略（`subagent/descriptor`、preset 恢复规则不动，P-15）。
10. 不实现孙代理/后代树的全局路由管理（每个会话独立选择，独立生效）。
11. 不动全局默认模型、不动 `agentDefaultModel` 的 profile 写入路径（硬约束 4；官方 `session.selectModel` 附带全局默认写入，P-13，本插件不使用该 RPC）。
12. 不修改任何官方包文件、不新增会话事件类型（硬约束 1/2）。
13. **不提供「官方只读 composer 顶替」状态下的选择器**：`mode === 'unknown'`、本地 one-shot、或 `parentAvailable === false` 且非 running 的子会话视图，由官方 `ui-subagent` 用只读 composer **顶替整条 composer chain**（`dsh-client-ui-subagent/lib/client.js:1220-1228,1273-1278`），`conversation.input.right` 根本不渲染，此时「继续」本身也不可用，场景自洽。**注意 `mode === 'unknown'` 与 one-shot / 父级离线是同一类（都不渲染），不是「渲染占位」**（P1.5 U-4，M4/M6；旧规则「unknown 也渲染占位」已删除）。这是对 REQ「只在队友会话渲染」的**范围收窄**，在此留痕（03 报告 P0-M4），**客户已接受**（`00-client-answers-2.md:6`）；A1/A5/A8/A9 一律在普通 composer 挂载（父级在线）场景执行。
14. **不做每会话开关，也不做「临时隐藏但重启复位」**（客户 Q2 裁定：这是「我这个人不想看」，不是「这个会话不要」；落点只有 profile 级的插件 Config）。
15. **不做自建 Client→Host RPC，不注册 HTTP 路由**（P1.5 U-1/U-7）。读写全部走官方 Client 服务 / namespace：读 = `remote.session`（`session/events`、`session/projections`、`session/modelCatalog`）+ `useProjection`；写 = `ctx.configForms` → `settings.mutate` → 本插件 Config volatile 字段。**也不对冷队友做 `agents.resume()`**（U-2 已定降级：官方冷继续要求父级 live，且会补写 `turn/end`）。

## 4. 歧义清单（每条标「客户裁定 / 自查可解」）

| # | 歧义 | 标记 | 处理 |
|---|---|---|---|
| Q1 | 「队友」= Agent Teams 成员，还是一切可继续子代理？ | 自查可解 | 按 REQ 括号定义「可继续的子代理」执行；Team 成员是其中的子集，自然覆盖（P-12）。验收 A11/A12 用此口径 |
| Q2 | 显示开关的位置与持久范围 | **客户裁定（已回填）** | 原文：放**插件 Config**（profile patch 层），随用户配置持久、重启仍在；**不做**每会话开关，**不做**「临时隐藏但重启复位」。理由：「这是『我这个人不想看这个选择器』，不是『这个会话不要』」。落点 = Config **volatile** 布尔字段 `showSelector`；**呈现位 = 插件自带 UI（挂官方座位）**，U-6a 已定降级且**客户已批准**（`00-client-answers-2.md:5`）。判定见 A10，范围收窄见 §3 第 14 条（`00-client-answers.md:5`） |
| Q3 | 「额度耗尽」是否需要插件识别并特别提示 | 自查可解 | 不识别额度；失败反馈用通用错误。A5 用「不可用路由」模拟耗尽，但**两者失败面不同**：额度耗尽 = 服务端拒绝（路由有效），不可用路由 = 本地解析不到（路由无效）。故 A5 只证明错误类型变化，不证明额度问题解决（客户限定见 A5 与 `00-client-answers.md:8-10`） |
| Q4 | 从未切换过时「恢复派发路由」的可见性 | 自查可解 | 置灰显示（可见但不可用），避免「功能消失」的误解；判据见 A7 第 3 项 |
| Q5 | 推理等级是否允许任意输入 | 自查可解 | 只提供适配器声明集合；无声明的模型隐藏该级并显示 `teammatePicker.effort.auto` 占位（对齐官方「无任意 effort 输入」语义，P-11） |
| Q6 | 孙代理（子代理的子会话）是否提供选择器 | 自查可解 | 提供（同为可继续子代理）；各会话覆盖互相独立 |
| Q7 | 切换后是否自动重试失败回合 | 自查可解 | 不自动重试；由用户发「继续」（对齐 REQ 验收 2 的文字「发『继续』」） |
| Q8 | 冷队友（未驻留、无 live Agent）上切换的生效时机 | **客户裁定（已回填）** | 原文：**下一次唤醒生效即可**。不改写已经存盘的日志、不要求唤醒前改变历史记录；「恢复派发路由」同样——下一次唤醒必须回到派发路由。即「写入即定，唤醒即用」。实现落点 = `02-plan.md` §1 **路径 B（已定为唯一实现）**：插件侧 Config volatile `overrides` 表 + `agent/created` 回填（U-3 已验，源码级）+ `loader/volatile-update` 热应用。**路径 A（resume→select→dispose）已作废**（U-2 已定降级：官方冷继续要求父级 live，且 `resume` 会补写 `turn/end`）——它不是客户要求，也不再是候选（`00-client-answers.md:6`、`00-client-answers-2.md:7`） |
| Q9 | 观感主题（浅/深色） | 自查可解 | 跟随宿主主题 token；A16 判定 2/3 |
| Q10 | 控件文案语言 | 自查可解 | 跟随宿主 locale（zh/en 双基线，P-22）；**U-5 已验（源码/契约级）**：`inject:['locale']` + `register(NS,{zh,en,…})` 与官方 `ui-subagent` 同构，无需双语硬编码降级 |
| Q11 | 「覆盖」的存储表要不要按 `childSessionId` 做 key？覆盖表满了/条目坏了怎么办 | 自查可解 | key = 子会话 id（`childSessionId`），一条 override 三个字段（provider/model/reasoningEffort?）；条目缺失 = 无覆盖；条目非法（provider/model 非字符串）按「无覆盖」处理并记日志，不得抛错给唤醒路径（R4 硬要求的延伸） |
| Q12 | 「设置不可用」态（`entryId` 下发失败）长什么样 | 自查可解 | 控件仍渲染（A1 的 DOM 判据不因此失败），但菜单不可展开、开关不可写、文案说明「设置不可用」；这是 R5/R9 的可见降级，**不得**静默失败也不得抛错 |

**裁定状态汇总：Q2、Q8 已获客户裁定并全文回填（见上表、§1 第 4 行、A10、§3 第 14 条、`02-plan.md` §1/§3/§5）；P1.5 之后的四条补充裁定已并入：A10 呈现位 = 插件自带 UI（`00-client-answers-2.md:5`）、U-4 只读态收窄被接受（`:6`）、U-2 路径 B 被接受（`:7`）、R4 try/catch 升为硬要求（`:7`）。待客户裁定 0 条。其余 8 条自查可解，不上抛；新增 Q11/Q12 为 P1.5 回填带出的实现级自查项。**

## 5. 内部一致性自检（P0 + P1.5 回填后）

- 验收条数：16（A1–A16），与 §1 表格映射、`02-plan.md` §5 一致。
- 歧义：**12 条**（Q1–Q10 + P1.5 回填带出的 Q11/Q12）；其中客户裁定 2 条（Q2、Q8）+ 补充裁定 4 项（A10 呈现位、U-4 收窄、U-2 路径 B、R4 try/catch），已回填，**待裁定 0 条**。
- 「硬约束四条」与验收映射在 §1、§2 双处出现，编号一致。
- 「队友」口径全篇 = `origin === 'subagent'` 且描述符 `mode === 'continuable'` 的子会话（P-15），A11/A12 与 Q1/Q6/§3 第 8、13 条使用同一口径。
- `model/selection` 全篇定性为「官方既有会话事件类型」（P-15），A15 与 `02-plan.md` 依赖 D3 一致。
- A5 的限定语与 `00-client-answers.md:8-10` 逐点对应（服务端拒绝 / 本地解析不到 / 只证错误类型变化）；Q3 与之同向，全篇已无与客户限定相反的表述（原「判定面相同」已删除）。
- 机判/人工口径：A2/A3/A7/A9/A10/A11/A16 均给出表达式与期望值；A16 的人工项已降级为「人工补充，不作通过依据」。
- **通道口径（P1.5）**：全篇无「自建 RPC / HTTP 路由 / resume 冷队友」作为实现手段的表述；§3 第 15 条明确禁止。A2/A3/A7 的**取数方式**改为官方 namespace（判据本身未变）。
- **存储口径（P1.5）**：覆盖表落在插件 Config volatile 字段（Q2 的持久语义 + Q8 的下次唤醒）；A7 判定 4 与 A9 判定 3 记录「恢复 = 删条目」「无覆盖 = 不调 select」，且**不进会话日志**，因此不影响 A9 的日志判据。
- **呈现位口径（P1.5）**：A10 判定 5 明确「插件自带 UI」判据，不再假设 Settings 自动表单；存储语义未变（客户 Q2 原意保留）。
- **`unknown` 口径收口（04-O1）**：§2 约定、§3 第 13 条、A11 主判据三处一致——`mode='unknown'` 与 one-shot、父级离线同属「官方只读 composer 顶替 → slot 不渲染」，旧「unknown 也渲染占位」表述已全篇删除。
- **R4 硬要求可见性**：`agent/created` listener 必须 try/catch 已写入 A8 判定 4 与 §8-M6，与 `02-plan.md` §4-R8 同源。

## 6. 判定工具箱（机判片段，P2 自验说明直接引用）

- 选择器常量：

  ```js
  const PICKER = '[data-dsh-teammate-picker]';
  const RESTORE = '[data-dsh-teammate-picker-restore]';
  // U-4 已定降级（源码级）：普通 composer 挂载时 slot 渲染；只读态顶替时整个 composer chain 不渲染。
  // 容器选择器来自官方输入区锚点（dsh-client-ui-conversation/lib/client.js:20592-20598）：data-composer-seat / data-conversation-region="composer"
  const SLOT_CONTAINER = '[data-conversation-region="composer"]'; // P1.5 建议值；P2 live 用 Slots.listSubTree 复核，取不到时 A16 判定 1 退化为仅 inInputRow
  ```

- 事件序列抽取（A9，两态对比用；P1.5 后 Client 侧同一数据可经官方 `session/events` 取，判据不变）：

  ```js
  // snapshot = sessionQuery.readSession(sessionId)   或   remote.session.events({address, ...}) 折叠出的 events
  const seq = snapshot.events.map(e => e.type);
  const reasons = snapshot.events.filter(e => e.type === 'turn/end').map(e => e.reason);
  // 派发路由（A2/A7 的基准）：子会话日志中第一条 subagent/descriptor 的 agentProvider/agentModel/agentReasoningEffort
  const descriptor = snapshot.events.find(e => e.type === 'subagent/descriptor')?.data;
  const dispatchRoute = descriptor && { provider: descriptor.agentProvider, model: descriptor.agentModel,
    ...(descriptor.agentReasoningEffort === undefined ? {} : { reasoningEffort: descriptor.agentReasoningEffort }) };
  ```

- 对比度（A16 判定 2，WCAG 2.x）：

  ```js
  const lin = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
  const lum = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
  const rgba = s => { const m = s.match(/[\d.]+/g).map(Number); return [m[0], m[1], m[2], m[3] ?? 1]; };
  const bgOf = el => { for (let n = el; n; n = n.parentElement) { const c = rgba(getComputedStyle(n).backgroundColor); if (c[3] === 1) return c; } return [255, 255, 255, 1]; };
  const contrast = el => { const a = lum(rgba(getComputedStyle(el).color)), b = lum(bgOf(el)); return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05); };
  // 通过条件：浅/深两主题下 contrast(textEl) >= 4.5 且两主题 getComputedStyle(textEl).color 不相等
  ```

- 模型目录基准集合（A3）：`P_ok` / `E` / `P_fail` 的定义见 A3 判定第 1 项。**P1.5 后的取数方式**（判据不变）：Client 侧调官方 `session/modelCatalog()`（`dsh-api-session-controller/lib/index.js:473-522`），返回 `{default, routableProviders, groups[].models[]（含 reasoning.efforts/defaultEffort）, failures[]}`；`P_fail` 直接用返回的 `failures[]`，`E` 用 `groups[].models[]` 的并集。P2 固化为一段只读脚本。

- 覆盖表读回（A7 判定 4 / A10 判定 6）：Client 侧 `ctx.configForms.get(entryId).getSnapshot()` → `{value, base, user, revision, writable}`；Host 侧 `Config.listConfigs {"entry": "<Loader entry id>"}`。`entryId` 来自 `Reflect.get(globalThis,'__DSH_TEAMMATE_PICKER__')?.entryId`（M9）。

## 7. 返工记录：针对 `03-gate-P0P1.md` 的逐条回应

> 格式：编号（03 报告缺陷 ID）→ 修了什么 → 落点（`01-requirements.md:行`）。行号以本次交付的文件为准。

| ID | 回应 | 落点（文件:行） |
|---|---|---|
| **P0-B1** | A5 重写并改名「换掉不可用路由后队友可继续」：原文引用客户限定——额度耗尽 = 服务端拒绝、不可用路由 = 本地解析不到，**失败面不同**；A5 只证明错误类型变化，不证明额度问题解决；新增判定 4（只记错误类型变化）与反向约束。Q3 的「判定面相同」删除，改为「失败面不同」表述。 | `01-requirements.md:81-94`（A5；限定块 `:83-86`、判定 4 `:93`、反向约束 `:94`）、`:14`（价值边界）、`:215`（Q3）、`:233`（§5 一致性断言） |
| **P0-B2** | Q2/Q8 改标「客户裁定（已回填）」，写入客户原文；删除「默认假设」「待客户裁定汇总」「若客户要……」条件句；A10 补 Config key 与「重启复位被排除」项；§1 功能表 4、§3 第 14 条同步。 | `01-requirements.md:214`（Q2）、`:220`（Q8）、`:224`（裁定状态汇总）、`:25`（§1 功能表第 4 行）、`:133-141`（A10；判定 3 `:140`、判定 4 `:141`）、`:207`（§3 第 14 条）；02 侧 `02-plan.md:18,54,55,100-106` |
| **P0-M1（A16）** | 「深浅两色均可读」删除；改为三条机判：判定 1 = DOM 位置（slot 容器 contains + 输入行包围盒）；判定 2 = 对比度 ≥ 4.5:1（两主题）且两主题颜色值不等；判定 3 = 无硬编码颜色字面量。可读性/截图降为「人工补充，不作通过依据」。 | `01-requirements.md:173-190`（判定 1 `:176`、判定 2 `:188`、判定 3 `:189`、人工补充 `:190`）、`:254-261`（§6 对比度脚本 `:261`）、`:243`（`SLOT_CONTAINER`） |
| **P0-M2（A9）** | 「行为无差异」改为机判：固定脚本（继续→中断→恢复）下两态 `type` 序列 diff 为空 且 `turn/end.reason` 序列相等；新增空转判据（打开即零写入）与退化方案（同会话装/卸对比）；主观手感标人工补充。 | `01-requirements.md:120-131`（判定 1–4 `:127-130`、退化方案 `:131`）、`:248`（§6 事件序列脚本） |
| **P0-M3（A3）** | 「≥」判据删除；改为集合相等：组 = `P_ok`（有模型的 provider），条目 = `listModels` 并集 `E`，双向差集为空；失败组 `P_fail` 单列「加载失败」条目，不计入集合也不得静默；并写明不用 `≥` 的原因。 | `01-requirements.md:60-69`（判定 1–4 `:65-68`）、`:265`（§6 目录基准集合） |
| **P0-M4（不做清单）** | 「父级离线只读态不提供选择器」写进不做清单第 13 条，标明是范围收窄；§2 约定新增「父级在线前提」，明确 A1/A2/A5/A6/A8/A9/A10 在父级在线下执行。 | `01-requirements.md:206`（§3 第 13 条）、`:43`（§2 约定「父级在线前提」） |
| **P0-M5（A11）** | 拆为「主判据 = 本地 one-shot（必测）」+「条件项 = 外部后端（环境依赖）」；写明存在性须列出命令与输出、不存在记 `N/A（环境无外部后端）` 并留痕，N/A 不构成失败也不得掩盖主判据。 | `01-requirements.md:143-149`（判定 1 `:148`、判定 2 `:149`） |
| MINOR P0-m1 | A7 第 3 项给出恢复项禁用的可查询属性（`disabled` / `aria-disabled` 二选一，P2 固定）。 | `01-requirements.md:109`（A7 判定 3）、`:240`（`RESTORE` 常量） |
| MINOR P0-m2 | A10 判定 3 写明 `showSelector`（boolean，profile patch 层）的读取方式（`Config.listConfigs`）。 | `01-requirements.md:140`（A10 判定 3） |
| MINOR P0-m3 | A2 判定 3 固定占位 locale key `teammatePicker.effort.auto`（zh=「自动」，en=`Auto`）。 | `01-requirements.md:58`（A2 判定 3）；`:215`（Q5 同步） |
| MINOR P0-m4 | A4 操作写明「必须选不同路由」+ 判定 4 同路由例外（`select()` early return，`dsh-agent/lib/index.js:196-199`）。 | `01-requirements.md:73`（A4 操作句）、`:79`（A4 判定 4） |

> 03 报告 §1.2 提到 P-13 出处链不完整 / P-15 漏 `:1418`（MINOR P1-m1/m2，属 `probes.md`）。本轮按任务范围只改 01/02，未追溯改写探测记录；待补内容记在 `02-plan.md` §7 末两行。

> **§7 的行号说明**：上表记录的是 r2 → r3（03 门禁返工）那次的行号。P1.5 回填（§8）已改动 §1/§2/§3/§5/§6，**旧行号相对当前文件已漂移**；§7 保留不动用于留痕，不重算行号。要「当前落点」请看 §8。

## 8. 回填记录：P1.5 结论对本文件的改动（对应 `05-p1.5-probes.md` §3 的 M5/M6/M8）

> 依据：`05-p1.5-probes.md` §3（形态结论 + 对 01/02 的建议改动清单）与 `00-client-answers-2.md`（客户补充裁定）。
> 纪律：**只改形态/落点/呈现位，不改任何验收判据的真假性**。凡改到判据的地方，都是补「取数方式 / 时点 / 呈现位」这类口径，机判表达式本身不放松。
> 版本：`01-requirements.md` r3（2026-11-08）。

| # | 05 的条目 | 本文件改了什么 | 落点 |
|---|---|---|---|
| **M5** | A10 判定 3 的读取方式 + 呈现位（U-6a 已定降级、客户已批准） | A10 重写：操作改为「插件自带 UI」；**新增判定 5（呈现位口径）与判定 6（读取方式 + entryId 注意事项）**；判定 3 把 `showSelector` 标注为 **volatile** 字段；§1 功能表第 4 行、Q2 行同步。判据真假性未变（仍是「DOM 存在性 == 持久值」）。 | §2-A10（判定 3/5/6）、§1 功能表、§4-Q2 |
| **M6** | §3 第 13 条 + `unknown` 同理；补 R4 硬要求 | §3 第 13 条改写：标题改为「官方只读 composer 顶替状态」；写明 `mode==='unknown'`、one-shot、父级离线 **三者同类**（都不渲染），**删除旧「unknown 也渲染占位」**，并注明客户已接受收窄；**新增 §3 第 15 条**（不自建 RPC / 不注册 HTTP 路由 / 不 resume 冷队友）。A8 判定 3 改为直陈（U-3 已验，口径可达），**新增判定 4 = `agent/created` listener 必须 try/catch（R4 硬要求，客户已批准）**。§2 约定块改为「父级在线 / 普通 composer 前提（场景式列举）」+ 新增「写入生效口径（路径 B）」两条。 | §3 第 13 条、§3 第 15 条（新）、A8 判定 3/4、§2 约定块 |
| **M8** | 04-O2…O8 措辞级观察，顺手修 | **O3**：A4 未改判据，但 A7 判定 1 与 A8 判定 3 补「冷队友 = 下一次唤醒首跳」的时点口径（O3 的原建议点在 A4/S4；A4 的 live 场景口径未变，冷场景口径已由 A8 判定 3 承担）。**O4**：§2 约定的「父级在线前提」由枚举六条改为场景式（A1–A8、A10、A13、A15、A16）。**O5**：A9 判定措辞统一（「装插件前后」= T-A 自身前后；「两边」= T-A/T-B），并新增判定 3（零介入实现口径）。**O7**：§7 顶部加「行号说明」，不再引旧行号断言的「`:240`」。**O6**（`02-plan.md:3` 的时序措辞）与 **O8**（§5 数字口径）在 `02-plan.md` 侧处理；本文件 §5 已同步改为「12 条歧义」并说明来源。 | §2-A7/A8/A9、§2 约定块、§5、§6、§7 顶部说明 |
| 附带（非 M 项，回填必须连带改的） | 通道/存储口径渗透到验收取数 | ① §2 约定块新增「写入生效口径（路径 B）」；② §5 增 3 条一致性断言（通道/存储/呈现位）；③ §6 工具箱：`SLOT_CONTAINER` 从 `null` 改为官方锚点建议值、事件序列脚本补 `subagent/descriptor` 折叠、A3 基准集合适配 `session/modelCatalog`、新增覆盖表读回片段；④ 新增 Q11（覆盖表 key/坏条目）与 Q12（设置不可用态）；⑤ §3 新增第 15 条。 | §2 约定块、§5、§6、§4-Q11/Q12、§3 第 15 条 |

**未做（明确留白）**

- `probes.md` 的 P1-m1/m2 出处补充（M7）不在本轮范围；见 `02-plan.md` §8-M7。
- 本文件不含任何实现代码与运行时结论；P2 最小切片见 `06-implementation.md` / `07-selfcheck.md`。

