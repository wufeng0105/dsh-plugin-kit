# 07-selfcheck.md — P2 最小切片自检

> 版本：2026-11-08。自检对象 = `bundle/`（81 条测试）+ 01/02 回填。
> 纪律：**本文件区分「已离线证」与「需运行时验」，不把离线结果写成运行时结论。** 本轮未安装、未碰 `$DSH_HOME`、未写真实 profile，因此**没有一条验收是运行时已验**。
> 三态定义：**已离线证** = 逻辑/结构在本机命令下可复现二值结果；**需运行时验** = 判据已就位、但必须装到真实 Host/页面才能观测；**未做** = 本轮切片明确不做。

## 1. 测试原文输出

命令与完整输出（`cd bundle && node --test`，Node v24.22.2，零第三方依赖）：

```
✔ client.js registers one factory under the package name (3.1977ms)
✔ the factory injects the three services it uses and exposes apply() (1.9002ms)
✔ apply registers into conversation.input.right with its OWN cell id (2.6078ms)
✔ apply registers the locale namespace with both zh and en baselines (0.4699ms)
✔ the injected face reports settings available when both the id and the form resolve (0.6735ms)
✔ a missing entry id degrades to settings-unavailable instead of throwing (0.5961ms)
✔ a missing configForms service degrades instead of throwing (0.4504ms)
✔ a throwing configForms.get degrades instead of throwing (1.8723ms)
✔ the form is retried on the next injection call rather than latched unavailable (0.5665ms)
✔ the client render predicate agrees with lib/core.js on every documented state (0.778ms)
✔ the client reads the entry id from the published global, never from a package name (0.361ms)
✔ normalizeRoute accepts a complete triple and detaches it (2.9923ms)
✔ normalizeRoute drops an absent or empty effort (0.3197ms)
✔ normalizeRoute rejects everything that is not a usable route (0.2651ms)
✔ sameRoute compares provider, model and effort, treating absent effort as a value (0.2088ms)
✔ deepEqualJson compares JSON values structurally and never mutates (0.3086ms)
✔ isPlainObject and isUsableKey gate the dictionary writes (0.3466ms)
✔ normalizeTable keeps valid entries and drops corrupt ones instead of throwing (0.3812ms)
✔ normalizeTable tolerates any non-object input (0.2115ms)
✔ setOverride adds an entry without mutating the input table (0.4073ms)
✔ setOverride replaces an existing entry for the same teammate only (0.3656ms)
✔ setOverride rejects an unusable key or route (0.7692ms)
✔ setOverride cannot shadow the prototype of the table (0.2639ms)
✔ deleteOverride removes exactly one entry and is a no-op for absent keys (0.2432ms)
✔ readOverride returns null for missing, unsafe or corrupt entries (0.1484ms)
✔ decideRoute prefers the override and reports intervention (0.2175ms)
✔ decideRoute without an override returns the input route by identity (zero intervention) (0.1201ms)
✔ decideRoute falls back through dispatch -> current -> fallback -> none (0.1189ms)
✔ decideRoute ignores a corrupt override instead of trusting it (0.0947ms)
✔ planAgentCreatedApply selects only when an override exists and differs (0.2209ms)
✔ planAgentCreatedApply is safe with an empty table, a bad id or a corrupt table (0.1001ms)
✔ planVolatileApply reports no change for an identical table (idempotent event) (0.2823ms)
✔ planVolatileApply only touches teammates whose effective override changed (0.2041ms)
✔ planVolatileApply leaves restored teammates to their next wake-up (0.1389ms)
✔ planVolatileApply tolerates live agents without an id (0.1774ms)
✔ unwrapVolatile reads a schemastery reference and ignores plain values (0.3624ms)
✔ readShowSelector reads the switch and falls back on a corrupt or unreadable value (0.2293ms)
✔ readOverrides unwraps the volatile reference and normalizes the table (0.2337ms)
✔ overrideSetOps and overrideDeleteOps build volatile-path mutations (0.4318ms)
✔ showSelectorOps writes the boolean at its own top-level volatile path (0.2148ms)
✔ dispatchRouteOfDescriptor reads the descriptor triple, effort optional (0.1772ms)
✔ foldSessionRouteFacts extracts descriptor, newest header and newest selection (0.252ms)
✔ foldSessionRouteFacts reports a mainline session as not a teammate (0.1178ms)
✔ foldSessionRouteFacts keeps the first descriptor and the newest of the rest (0.1619ms)
✔ foldSessionRouteFacts survives malformed events (0.1581ms)
✔ effectiveRouteOf prefers the pending selection, then the header, then the descriptor (0.2883ms)
✔ shouldRenderPicker renders for a continuable teammate with a live parent (0.1854ms)
✔ shouldRenderPicker refuses every official read-only state (P1.5 U-4) (0.1482ms)
✔ readEntryId reads the published global and rejects anything else (0.1724ms)
✔ entryIdOf reads the Loader entry id and tolerates a non-Loader mount (1.4233ms)
✔ indexInjections publishes exactly one global row under the documented key (0.9529ms)
✔ the index-inject listener appends its row to the emitted table (0.5323ms)
✔ the index-inject listener does not throw on a malformed table (0.3026ms)
✔ a non-Loader mount warns once and publishes a null entry id (0.3644ms)
✔ createPlugin registers exactly the three documented listeners (0.2561ms)
✔ agent/created applies the override to the newly created teammate (0.5063ms)
✔ agent/created leaves every other session untouched (zero intervention) (1.0669ms)
✔ agent/created skips a select() when the teammate already carries the override (0.3025ms)
✔ agent/created contains a throwing model.select and still resolves (0.4142ms)
✔ agent/created contains a throwing config read and still resolves (0.2507ms)
✔ agent/created contains a throwing agent.model.current() (0.2465ms)
✔ agent/created survives a malformed payload (0.3162ms)
✔ agent/created ignores an agent that has no model facade (0.1354ms)
✔ volatile-update applies a changed override to the live teammate (0.4815ms)
✔ volatile-update does not act when the table is unchanged (showSelector-only edit) (0.1709ms)
✔ volatile-update does not re-apply the same table twice (0.1339ms)
✔ volatile-update applies to each live teammate independently (0.1974ms)
✔ volatile-update does not write a selection when an override is restored (0.1506ms)
✔ volatile-update sees an override added while no teammate is live and stores the baseline (0.2254ms)
✔ volatile-update contains a throwing agent list and still resolves (0.2273ms)
✔ volatile-update contains a throwing model.select on the hot path (0.1768ms)
✔ createWakeUpBridge needs a reader and seeds its baseline without acting (0.4872ms)
✔ the applied table only ever holds normalized overrides (0.1206ms)
✔ createConfigSchema declares both fields volatile (2.933ms)
✔ createConfigSchema declares the override route as provider/model/reasoningEffort (0.2234ms)
✔ createConfigSchema refuses an incomplete schemastery namespace (0.5607ms)
✔ CONFIG_SPEC mirrors the schema declaration (0.2929ms)
✔ loadSchemastery returns the namespace object from a default export (0.2523ms)
✔ loadSchemastery returns the module itself when there is no default export (0.1795ms)
✔ loadSchemastery degrades to null instead of throwing (0.2452ms)
✔ loadSchemastery resolves the real package when this deployment provides it (1.2856ms)
ℹ tests 81
ℹ suites 0
ℹ pass 81
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 354.4831
```

按文件：`core.test.mjs` 38 条、`host.test.mjs` 24 条、`client.test.mjs` 11 条、`schema.test.mjs` 8 条，合计 **81**。
原文另存 `_test-output.txt`（复跑：`cd bundle; node --test | Out-File ..\_test-output.txt`）。

### 1.1 改坏→红→改回→绿（原文）

```
=== RED: mutant applied (restore writes instead of deleting) ===

✖ overrideSetOps and overrideDeleteOps build volatile-path mutations (1.5966ms)
ℹ tests 81
ℹ pass 80
ℹ fail 1
✖ failing tests:
✖ overrideSetOps and overrideDeleteOps build volatile-path mutations (1.5966ms)
red exit code: 1
=== RESTORE: original source put back ===
ℹ tests 81
ℹ pass 81
ℹ fail 0
green exit code: 0
```

复跑：`pwsh -NoProfile -NonInteractive -File .\break-restore.ps1`（原文另存 `_break-restore-output.txt`）。
变异内容：把「恢复派发路由 = 删除该条 override」改成「写回派发路由三元组」。这是最容易犯的错——语义上「恢复」确实回到了派发路由，但写一条覆盖会让后续 descriptor 变化时不再跟随，而且违反 A7 判定 4 的「插件侧覆盖表里该 childSessionId 不存在」。测试抓住了它。

## 2. 语法与结构检查

| 检查 | 命令 | 结果 |
|---|---|---|
| 全部 JS 文件语法 | `node --check index.js client.js lib/*.js test/*.mjs`（逐个） | **9/9 退出码 0** |
| Host 入口可加载 | `node -e "import('./index.js')"` | `exports: Config,apply`；`Config: undefined`（本地无 schemastery，见 06 §3.3） |
| 无第三方依赖 | 检查所有 import/require | 运行时仅 `./lib/*.js`；client.js 只 `require('react')`（宿主模块表提供）；`@deepseek-ai/schemastery` 走 `loadSchemastery()` 软加载 |
| 不追加会话事件 | grep `session.append` / `appendPluginRecord` | **0 命中** |
| 不碰全局默认 / 官方 RPC / HTTP | grep `agentDefaultModel` / `selectModel` / `webServer.register` / `resume(` | **0 命中** |
| A16 判定 3（无硬编码颜色） | `Select-String -Path bundle/client.js -Pattern '#[0-9a-fA-F]{3,8}\b|rgba?\(|hsla?\('` | **无命中** |
| manifest | `package.json` 解析 | `name=@local/dsh-teammate-picker`；`exports = ., ./client, ./locale/*.json, ./icon`；`dsh.client.platform=web` |

## 3. 额外离线证据：Config schema 用真实 schemastery 跑过

`bundle/` 目录本身不带依赖，所以用本机 profile 里的真实 `@deepseek-ai/schemastery@3.19.0` 直接验证声明（只读，未安装、未写 profile）：

```js
const z = (await import('file:///C:/Users/Administrator/.dsh/profiles/desktop/node_modules/@deepseek-ai/schemastery/lib/index.mjs')).default;
const route = z.object({ provider: z.string().required(), model: z.string().required(), reasoningEffort: z.string() });
const schema = z.object({ showSelector: z.boolean().default(true).volatile(), overrides: z.dict(route).default({}).volatile() });
schema.toJSON();
```

输出关键片段：

```json
"8":  { "type": "boolean", "meta": { "default": true, "volatile": true } },
"12": { "type": "dict", "meta": { "default": {}, "volatile": true },
        "inner": 5, "sKey": 10 },
"5":  { "type": "object", "meta": { "default": {} },
        "dict": { "provider": 1, "model": 3, "reasoningEffort": 4 } },
"13": { "type": "object", "meta": { "default": {} },
        "dict": { "showSelector": 8, "overrides": 12 } }
```

→ `showSelector` 与 `overrides` 两个节点都带 `"volatile": true`；`overrides` 是 `sKey`(string) + `inner`(object) 的 dict，正是 `settings.mutate` 的 `['overrides', childSessionId]` 需要的形态（`isVolatilePath` 逐段放行）。

## 4. 验收 A1–A16 逐条标注（三态）

> 口径提醒：**没有任何一条是运行时已验。** 「已离线证」只说明该条依赖的逻辑/结构在本机可复现，不等于验收通过。

| # | 验收 | 三态 | 离线证了什么 / 还差什么 |
|---|---|---|---|
| **A1** | 只在队友会话渲染 | **需运行时验**（结构已离线证） | 谓词 `shouldRenderPicker` 对 10 种快照状态有二值结果，且 `client.js` 的 `rendersIn` 与之逐状态一致（漂移检测）。**差：** 真实 DOM 里 `document.querySelector('[data-dsh-teammate-picker]')` 在主线为 `null`、在队友非 `null`。 |
| **A2** | 显示当前模型与推理等级 | **未做**（取数已离线证） | `foldSessionRouteFacts` / `effectiveRouteOf` 能从事件数组折出「当前生效路由」（优先级 selection → header → descriptor）；`dispatchRouteOfDescriptor` 折出派发三元组。**差：** 控件还没渲染模型名与 effort 文本（S6），无法判 `textContent.includes(...)`。 |
| **A3** | 两级菜单（集合相等判据） | **未做** | 菜单、分组、`P_ok`/`E`/`P_fail` 全部未实现（S6）。`session/modelCatalog()` 未接线。 |
| **A4** | 切换写入只动该子会话 | **需运行时验**（写操作构造已离线证） | `overrideSetOps` 产出的 path 恰为 `['overrides', childSessionId]`（volatile 路径，逐段合法），不会碰全局默认段。**差：** 子会话日志是否新增恰好 1 条 `model/selection`；主线/全局默认 diff 为空。 |
| **A5** | 换掉不可用路由后队友可继续 | **需运行时验** | 写路径与回填路径已就位（`planAgentCreatedApply` + `select`）。**差：** 真实队友 + 模拟不可用路由；`request/header.config` 前后比对；A5 的客户限定（只证错误类型变化）仍必须随判定引用。 |
| **A6** | 活跃回合中切换，下一 step 生效 | **需运行时验** | 热应用只走 `loader/volatile-update`（见 06 §5 偏差）；`planVolatileApply` 会挑出「有效覆盖变了」的 live 队友。**差：** live 队友在下一 step 是否用新路由（R10 机判）。 |
| **A7** | 恢复派发路由 | **部分已离线证** | 「恢复 = 删除该条 override」由 `overrideDeleteOps` 产出 `{op:'unset', path:['overrides', id]}` 并由测试钉死；`planVolatileApply` 对恢复**不写 selection**（等下次唤醒）。**差：** 菜单项与 `data-dsh-teammate-picker-restore` 的 `disabled` 判据（S6）；恢复后 `request/header.config` 回落需运行时。 |
| **A8** | 重启后覆盖仍在 | **需运行时验** | 覆盖表落 Config volatile（schema 已用真实 schemastery 验过 `volatile:true`）；`agent/created` 回填有 3 条「抛错仍 resolve」的测试（R4）。**差：** 真重启后 `Config.listConfigs` 读回值一致 + 首个 `request/header.config` = 覆盖路由。 |
| **A9** | 无覆盖时零介入 | **已离线证**（日志侧需运行时） | `decideRoute` 无 override 时**返回传入路由对象本身**（引用相等，测试用 `assert.equal` 而非 `deepEqual`）；`planAgentCreatedApply` 无覆盖返回 `noop`；全包 grep `session.append` = 0 命中；`planVolatileApply` 对未变化表返回空 actions 两次。**差：** 两态日志 `type` 序列 diff（需运行时）。 |
| **A10** | 显示开关 | **需运行时验**（纯函数已离线证） | `readShowSelector` 兼容 volatile 引用与裸值、不可读时回落；`showSelectorOps` 路径为 `['showSelector']`（顶层 volatile）。**差：** 插件自带 UI 的开关本体（S6 未做）；重启后 `Config.listConfigs` 读回值与 DOM 一致。**呈现位按客户批准的「插件自带 UI」判，不按 Settings 页判**（`00-client-answers-2.md:5`）。 |
| **A11** | one-shot / 外部后端不渲染 | **已离线证**（DOM 需运行时） | 谓词对 `mode:'one-shot'`、`mode:'external'` 返回 `render:false`。**差：** 真 one-shot 子会话 DOM 为 `null`；外部后端 N/A 留痕。 |
| **A12** | 其余会话一律不渲染 | **已离线证**（DOM 需运行时） | 谓词对 `subagent === null`（空白/普通/fork/Hero）返回 `render:false`。**差：** 四种状态的实际 DOM。 |
| **A13** | 切换到不可用模型：失败干净 | **未做** | 无写路径 UI，也没有「选错再切回」的交互（S6）。计划已定「不做预检」（`02-plan.md` D7 已定降级）。 |
| **A14** | 不改任何官方包 | **本轮已离线证（范围有限）** | 本轮未安装、未写任何 profile/官方目录（§5 合规）；`bundle/` 内 14 个文件全部为新建。**差：** 安装后官方目录哈希前后比对（P4 复检）。 |
| **A15** | 不引入新的会话事件类型 | **已离线证** | 全包 grep `session.append` / `appendPluginRecord` = **0 命中**；代码只构造 `settings.mutate` 操作，不写会话。**差：** 装/未装两态实际日志的 `type` 集合 diff。 |
| **A16** | 观感对齐（3 机判） | **部分已离线证** | **判定 3（无硬编码颜色）：已离线证**——`client.js` 对 `#hex`/`rgb()`/`hsl()` 的扫描无命中；控件无内联颜色，全部继承宿主。**判定 1（位置）需运行时**：`SLOT_CONTAINER` 建议值 `[data-conversation-region="composer"]` 尚未 live 复核。**判定 2（对比度）需运行时**：要真实 `getComputedStyle`。 |

### 4.1 三态分布

| 三态 | 条数 | 条目 |
|---|---|---|
| **已离线证**（含「部分已离线证」中的已证判据） | **4** 整条 + **3** 条部分 | 整条：A9、A11、A12、A15；部分：A7（恢复=删）、A14（本轮未动官方包）、A16（判定 3） |
| **需运行时验** | **6** | A1、A4、A5、A6、A8、A10 |
| **未做** | **3** | A2、A3、A13 |
| **合计** | **16** | A1–A16 |

> 计数口径：A7/A14/A16 记在「已离线证」组（各自只证了其中一条判据，已在表内写清）。**注意：16 条里没有一条是运行时已验**——本轮任务明确「运行时验证留 P3」。

## 5. 合规记录

- 未安装任何 bundle；未执行 `plugin_manager` 任何 action。
- 未写 `$DSH_HOME`（`C:\Users\Administrator\.dsh`）、未写 `profiles\desktop` 的 `package.json`/`cordis.patch.yml`/`node_modules`。唯一一次读取 profile 是**只读**打开 `node_modules\@deepseek-ai\schemastery` 的 `package.json` 与 `lib/index.mjs`，用于验证 Config schema（§3），未写入、未安装。
- 未改 `01-requirements.md`/`02-plan.md` 之外的既有文档；`probes.md`、`05-p1.5-probes.md`、`00-client-answers*.md` 均只读。
- 工作区新增：`01`/`02` 回填、`bundle/`（14 文件：7 个运行时 + 4 个测试 + 3 个目录内资源）、`break-restore.ps1`、`_test-output.txt`、`_break-restore-output.txt`、`06-implementation.md`、`07-selfcheck.md`。
- 本文件所有命令均可复跑；所有数字（81 / 38 / 24 / 11 / 8）来自实际运行，非估算。

## 6. 下一个人最可能误解的三处（交接用）

1. **「恢复派发路由」不是把 descriptor 三元组写回去，而是删掉该条 override。** 两种做法在「当前这一次」结果相同，但删条目才能让后续 descriptor 变化时继续跟随，也是 A7 判定 4 的判据。已用 mutation 演示（§1.1）——如果你看到有人把 `overrideDeleteOps` 改成 `set`，那就是退化。
2. **`Config` 在 `bundle/` 目录里是 `undefined`，这不是 bug。** 本地没有 schemastery 依赖，`loadSchemastery()` 软加载失败即降级。装进 profile 后应变成真实 schema。如果你在本地跑 `Config.listConfigs` 查到 `absent`，先确认是不是还没安装，不要因此改 `index.js` 去「修」它。
3. **`agent/created` 的 R4 保护里有多层 catch，「去掉一层仍然绿」是正常的。** mutation #1 就出现过这个现象。判 R4 是否成立要看**最外层 listener 是否无条件 `return undefined`**（`createPlugin` 里那个 lambda），而不是 grep 有没有 `try`；否则你会在正确的代码里找到「可疑」然后改坏它。


