# 03-gate-P0P1.md — P0 / P1 门禁审查（round3-teammate-picker）

> 审查员：独立审查（只读产物与规格，不采信实现者自述当结论）
> 审查时间：2026-11-08
> 审查对象：`01-requirements.md`（P0）、`02-plan.md`（P1）、`probes.md`；输入含 `process-lab/spec/process-v2.md`、`process-lab/requirements/REQ-03-dsh-teammate-model-picker.md`、`00-client-answers.md`
> 审查边界：未改任何开发者产物；未安装任何插件/bundle；未读写 `$DSH_HOME`；官方源码只用只读方式核对。
> 三态口径：**已验 / 未验 / 无法判定**。下文不把“无法判定”写成“通过”。

## 0. 结论摘要

| 阶段 | 判定 | 一句话 |
|---|---|---|
| **P0 需求** | **不通过（打回）** | A5 与客户追加澄清**相反**；Q2/Q8 客户已裁定但文档仍写“待裁定/默认假设”；A16 的“机判替代”仍含人工判读；A9/A3 的机判不成立或不完整。 |
| **P1 计划** | **不通过（打回）** | D12 的“已验”缺 live 证据；“插件无需自建存储”与 D8/D10/U-2 的“插件 Config/域存储”自相矛盾；U-3 失败后的“再发一次继续”违反客户 Q8 的“下一次唤醒生效”；S2/S3 在 P1.5 清零前写功能代码。 |

**两条大断言**：

1. **「官方对队友会话双路拒绝」——成立**。客户端选择器（`conversation.input.model` / `/model`）对 addressed subagent 会话不可用并抛错；官方 RPC `session.selectModel` 对 `origin === 'subagent'`（及被父 Agent 拥有的子会话）返回 `session/agent-busy`。出处真实，结论引用正确。
2. **「重启后覆盖仍在 / 无覆盖零介入，由宿主机制免费满足，插件无需自建存储」——前半成立，后半过度乐观**。宿主确有 `model/selection` 持久投影，冷恢复不覆盖已记录选择；但该机制只在“插件能把选择写进子会话日志（live Agent 或 resume 后 select）”时成立。冷队友走客户裁定的“下一次唤醒生效”时，覆盖的待生效值必须有地方存——计划自己的 D8/U-2 就写了“插件 Config/域存储”。因此 **“插件无需自建存储”不是已验事实，是有条件的假设**，不能作为形态定论。

**D12 裁定**：**降级为 `UNVERIFIED → U-4`**（不新增 U-8；U-4 已覆盖“队友视图确实渲染该 slot”）。P0 的验收可判定性不受影响（A1/A11/A12 用 `querySelector` 可判），但 P1 不能再把 D12 写成“已验”。

**放行意见**：P0、P1 均打回；修完 P0 后重过 P0 门，修完 P1 后重过 P1 门，再进 P1.5。P1.5 清零前不得写功能代码（包括 S2/S3）。两条大断言中，双路拒绝可直接作为设计前提；“无需自建存储”必须等 U-2/U-3 结论，不能先定形态。

---

## 1. P0 判定

### 1.1 出口判据逐条对照（SPEC v2 §P0）

| 判据 | 结果 | 依据 |
|---|---|---|
| 每条验收能判真假 | **不满足** | A5 的“额度耗尽”用不可用路由模拟，且文档写“判定面相同”，与客户答复“失败面不同”相反；A16 的“机判替代”含“深浅两色均可读”；A9 的“继续/中断/恢复等行为无差异”没有机判命令。 |
| 含“人工判读”的必须显式标注并给出可机判替代 | **不满足** | A16 标了“人工→机判替代”，但替代判据仍含主观项；A9 未标“人工”，却把行为等价写成“（机判）”。 |
| 歧义清单每条标「客户裁定 / 自查可解」，自查可解不上抛 | **形式满足，状态不满足** | Q1、Q3–Q7、Q9、Q10 标“自查可解”，未上抛；Q2、Q8 标“客户裁定”正确。但客户已在 `00-client-answers.md` 裁定，`01` 仍写“待客户裁定/默认假设”。 |
| “不做”清单具体 | **基本满足，有遗漏** | §3 共 12 条，具体；但未列入“父级离线的只读态队友不提供选择器”（`02-plan.md:84` 的 R4 是范围收窄，不是“不做”项）。 |

### 1.2 验收抽查（逐条看“机判”是否真能执行）

| 验收 | 判定 | 理由 / 出处 |
|---|---|---|
| **A1 只在队友会话渲染** | **可判** | `document.querySelector('[data-dsh-teammate-picker]')` 为 null / 非 null，二值可判；主线与队友会话各开一次即可。前提是“队友会话”能被稳定打开，P0 已给出 Q1 口径。 |
| **A2 显示当前模型与推理等级** | **基本可判** | 控件文本含 provider/model + 等级名（P-17）；无 reasoning 时显示占位。占位文本“自动/无等级”未固定为唯一字符串，属 MINOR。 |
| **A3 两级菜单** | **不可靠** | “第一级分组数与模型条目数 **≥** 宿主 `listProviders()`/`listModels()` 返回值”：若某 provider 无模型、或目录组加载失败（D6 自己允许“失败行”），正确 UI 的组数会小于 `listProviders()` 数，`≥` 反而判假；若 UI 多出空组，`≥` 又判真。应改为“组 = 有模型的 provider 集合；条目 = 各 provider `listModels` 的并集；失败组单独列出”。`01-requirements.md:52` |
| **A4 切换只动该子会话** | **可判** | 三处 diff：子会话新增 1 条 `model/selection`、主线 diff 为空、全局默认段字节不变。注意：官方 `AgentModel.select` 对“同路由”会直接 return（`dsh-agent/lib/index.js:197`），测试必须选一个**不同**的模型/等级，否则“新增 1 条”会假失败。`01-requirements.md:55-57` |
| **A5 额度耗尽换模型后可继续** | **不可接受（BLOCKER）** | 客户明确要求保留限定：“额度耗尽是服务端拒绝、路由本身有效；不可用路由是本地就解析不到；A5 只能证明错误类型变了，不能证明额度问题解决了。” `01` 的 A5 没有这句，反而在 Q3 写“判定面相同”。这是**需求内容错误**，不是措辞问题。`01-requirements.md:59-62,137`；`00-client-answers.md:10` |
| **A6 活跃回合中下一 step 生效** | **可判** | 切换时刻到下一 step 无 aborted 事件；下一 step `request/header.config` = 新选择。需要构造长任务，执行成本高但可判。 |
| **A8 重启后覆盖仍在** | **可判，但依赖 P1 的存储分支** | 重启后控件值 + 首个 `request/header.config` = 覆盖路由。宿主投影机制成立（见 §3.2），但“冷队友的待生效覆盖存在哪里”决定该条在冷场景是否可达。`01-requirements.md:74-77` |
| **A9 无覆盖零介入** | **半可判** | 日志 diff 为空是机判；但“继续/中断/恢复等行为无差异”没有给命令/事件序列等价判据，却被标成“（机判）”。`01-requirements.md:79-82` |
| **A10 显示开关** | **基本可判** | 关：所有会话 `querySelector` 为 null；开：A1 复测；重启后保持。缺“开关持久值”的具体 Config key/value，属 MINOR。`01-requirements.md:87` |
| **A16 观感对齐** | **不满足“机判替代”** | DOM 父容器与 `conversation.input.right` 位置一致可机判；但“文本走宿主主题 token（深浅两色均可读）”里的“可读”是人工判断，截图又被排除为通过依据，等于没有可执行的二值判据。`01-requirements.md:112-114` |

**抽查结论**：A1、A2、A4、A6、A8、A10、A12、A13、A14、A15 基本可判；A5 是内容级错误；A3、A9、A16 的“机判”不成立或不完整。P0 不能以“16 条都写了机判”作为通过理由。

### 1.3 歧义清单

- **Q2（显示开关）**：`01-requirements.md:136` 仍写“**默认假设**：插件 Config 布尔字段……若客户要菜单内开关，改动很小”。客户已裁定：放插件 Config（profile patch 层），随用户配置持久、重启仍在；**不做每会话开关，也不做“临时隐藏但重启复位”**（`00-client-answers.md:5`）。应改为“客户裁定”，删掉“默认假设/若客户要”。
- **Q8（冷队友生效时机）**：`01-requirements.md:142` 仍写“**默认假设**：下次唤醒生效……若客户要求立即写入……”。客户已裁定：**下一次唤醒生效即可**；「恢复派发路由」也一样，“写入即定，唤醒即用”（`00-client-answers.md:6`）。应改为“客户裁定”，并把“立即写入”从待决分支降为可选优化。
- **Q3（额度耗尽是否识别）**：`01-requirements.md:137` 的“判定面相同”与客户“失败面不同”直接冲突；这是 A5 错误的同源问题，必须一起改。
- **Q1、Q4–Q7、Q9、Q10**：均标“自查可解”，未上抛；Q1 的“可继续子代理”口径与 A11/A12 一致，符合“自查可解的不许上抛”。

### 1.4 “不做”清单

§3 的 12 条总体具体（不改官方包、不新增事件、不做白名单、不做 agent 工具、不做额度监控、不做 fallback 链等），但：

- **缺“父级离线的只读态队友不提供选择器”**。R4 说父级离线时 `ui-subagent` 换成只读 composer，`conversation.input.right` 可能不渲染；这是对 REQ“只在队友会话渲染”的一个范围收窄，应写进“不做”清单或取得客户确认，不能只放在 P1 风险表里。`02-plan.md:84`；`REQ-03:11`
- **A11 的外部后端是“如有”**：`01-requirements.md:90` 写“外部后端子任务（ACP/SDK/Codex/Claude Code，如有）”。若环境中没有这些后端，该条只能跳过；应写明跳过规则（至少用本地 one-shot 子会话覆盖）或标记为环境依赖项。这不算内容错误，但影响“每条验收能判真假”。

### 1.5 P0 判定

**不通过（打回）。** 不是“带条件放行”：A5 与客户追加澄清相反，属于需求内容错误；Q2/Q8 是铁律 6 明确禁止的“客户答复后仍留待裁定”。修完下列项后可重过 P0 门：

1. 改 A5：加入客户原话限定（失败面不同；只证明错误类型变化，不证明额度问题解决）；删掉 Q3 的“判定面相同”。
2. 回填 Q2/Q8：状态改为“客户裁定”，写入客户原裁定；删除“默认假设”“待客户裁定汇总”“若客户要……”的条件句；同步 `02-plan.md` 的“待客户裁定 2 条”和“Q8 默认假设”。
3. 改 A16：把“可读”降为人工补充（明确不作通过依据），机判只保留 DOM 位置/主题 token 的可计算判据；或给出对比度阈值等可执行判据。
4. 改 A9：给“继续/中断/恢复行为无差异”一个可执行比较（固定脚本下的事件类型/顺序 diff，或明确只判日志 diff、行为部分标人工补充）。
5. 改 A3：把“≥”改为精确集合/计数规则，并说明失败组如何计入。
6. 把“父级离线只读态不提供选择器”写进“不做”清单或取得客户确认；A11 写明外部后端不可用时的跳过/替代。

---

## 2. P1 判定

### 2.1 依赖清单 D1–D17 逐条检查

格式要求：引用点 / 为什么非它不可 / 探测结论或 `UNVERIFIED` / 不成立时的降级。逐条结果：

| D | 四要素 | 结论 |
|---|---|---|
| D1 `ctx.agents` | 有 | 已验（Service 目录 + 类型契约）；降级“整体不可用”合理。 |
| D2 `agent.model.select/current` | 有 | 已验（README + 源码）；降级“无”合理。 |
| D3 `model/selection` 投影 | 有 | 已验；但“重启仍在/零介入都建立在它上面”需要加条件（见 §3.2）。 |
| D4 `subagent/descriptor` | 有 | 已验；缺 descriptor 的降级合理。 |
| D5 `sessionQuery` | 有 | 已验；冷队友只读降级合理。 |
| D6 `ctx.llm` 目录 | 有 | 已验；单 provider 失败降级合理。 |
| D7 `resolveCallConfig` | 有 | 已验；跳过预检的降级合理。 |
| D8 `agent/created` | 有 | `UNVERIFIED → U-3`；但降级“提示再发一次继续”违反 Q8（见 §2.5）。 |
| D9 Host Config | 有 | `UNVERIFIED → U-6`；降级到菜单内开关 + `configEditor` 合理，但客户 Q2 已选 Config，降级应注明需客户同意。 |
| D10 `agents.resume` 冷路径 | 有 | `UNVERIFIED → U-2`；但“或冷时禁选（客户裁定 Q8）”是**误引客户裁定**：Q8 说下一次唤醒生效，不是禁选（见 §2.5）。 |
| D11 `ctx.webServer.register` | 有（但结论混写） | “已验（Service 存在）；路由鉴权细节 `UNVERIFIED → U-7`”。依赖的核心是“路由可用”，不是“Service 存在”；结论列应把“可用”标为 `UNVERIFIED`。 |
| D12 `conversation.input.right` | 有 | 标“已验（官方 slot 目录）”，但 live 证据缺失；见 §4，应降为 `UNVERIFIED → U-4`。 |
| D13 Slot 标准 props | 有 | `UNVERIFIED → U-4`；诚实。 |
| D14 `subagentAddress` + `subagent` 快照 | 有 | 已验；但冷会话 `mode='unknown'` 时 Client 是否还能渲染，是设计缺口（见 §2.5）。 |
| D15 Client 装载契约 | 有 | 已验（官方模板）；降级“无”合理。 |
| D16 `ctx.locale` | 有 | `UNVERIFIED → U-5`；双语硬编码降级合理。 |
| D17 Client→Host 通道 | 有 | `UNVERIFIED → U-1`；HTTP 兜底 + 形态不成立，合理。 |

**结论**：17 条都有四要素，**形式合格**；D11 的“已验”是部分结论，D12 的“已验”是过度结论，D8/D10 的分支与 §1 的“无存储”矛盾。P1 的形式完整，但证据等级和一致性不合格。

### 2.2 7 条 UNVERIFIED 与 §3.5

`02-plan.md:63-73` 的 U-1…U-7 均写了“探什么 / 怎么探 / 清零判据 / 不成立时降级”，且都在 P1.5 计划表内，**形式上满足**“每条进入 P1.5”。但：

- **缺“对验收的影响”列**。现在只有“不成立时降级”，没有写“哪条验收会变成不可达/口径改变”。例如：
  - U-1 不成立 → A1–A16 全部不可交付（形态不成立）；
  - U-2 不成立 → A5/A8 冷队友路径改走“下一次唤醒”，并且需要插件侧存储；
  - U-3 不成立 → A8 首个唤醒路由不可达；
  - U-4 不成立 → A1/A11/A12 不可判；
  - U-5 不成立 → 不影响 REQ 验收（locale 是要求 4 之外的实现项）；
  - U-6 不成立 → A10 落点改变；
  - U-7 不成立 → 形态不成立。
  这是 P1 出口判据“UNVERIFIED 每条写明补探方式，并进入 P1.5”之外的**审查任务明确要求**；应补一列。`02-plan.md:63-73`
- **U-2 的降级写的是“下次唤醒生效（Q8 默认假设）”，并落到“插件 Config/域存储”**：客户已裁定下次唤醒生效，这不是“降级”；更重要的是，这句话直接推翻了 §1 的“不需要独立存储后端”。`02-plan.md:12,68`
- **U-3 的降级写“提示用户再发一次继续”**：客户 Q8 要求“下一次唤醒必须回到派发路由/使用覆盖路由”，再发一次是**第二次唤醒**才生效；这是改变验收，不是降级，且没有客户豁免。`02-plan.md:69,83`；`00-client-answers.md:6`

### 2.3 最大风险与应对

- **最大风险 R1（Client→Host 通道）有明确应对**：S1 先探 U-1，失败转 U-7 HTTP，双路失败则判形态不成立并上报。`02-plan.md:81,88` 这条合格。
- **R2（冷队友写入）有探针**，但降级分支“冷时禁选”与客户 Q8 不符（见 §2.5）。
- **R3（回填时序）有探针**，但降级“再发一次继续”与 Q8 不符（见 §2.5）。
- **R4（父级离线只读 composer）** 被写成“已知问题”，但没有进入 P0 的“不做”清单；这是范围收窄未留痕（见 §1.4）。
- **R5/R6** 合理。

### 2.4 内部一致性自检（随机抽 3 处交叉核对）

1. **数值**：验收 16 条（A1–A16）在 `01-requirements.md:150` 与 `02-plan.md:92` 一致；依赖 17 条（D1–D17）一致；UNVERIFIED 7 条（U-1…U-7）一致；歧义 10 条一致。**但“待客户裁定 2 条（Q2、Q8）”与 `00-client-answers.md:5-6` 已裁定冲突**；`01-requirements.md:21,136,142,146` 和 `02-plan.md:92,95` 未回填。按铁律 6，这属于**状态不一致**，不是数值笔误。
2. **状态**：D12 写“已验（官方 slot 目录）”（`02-plan.md:54`），但 `probes.md:73-77` 明说“live 实测未做（T-2 超时），故 D13 = U-4”，且 U-4 的清零判据包含“队友视图确实渲染该 slot”（`02-plan.md:70`）。同一个 live 缺口，D12 写“已验”、D13 写 `UNVERIFIED`，**状态冲突**。
3. **口径**：`02-plan.md:12` 说“不需要独立存储后端（覆盖本身持久在子会话日志的 `model/selection`）”；`02-plan.md:45-48,61,68` 又说冷路径失败时“把覆盖写进插件 Config/域存储”，D8/D10 是“两个分支，P1.5 保留其一”。**同一份计划里“无自建存储”与“有插件存储分支”并存**，且客户 Q8 的“下一次唤醒生效”使后者成为现实候选。这是本案最大的口径冲突。
   另一个口径冲突：`02-plan.md:47` 把“冷时禁选”标注为“客户裁定 Q8”，但客户 Q8 的裁定是“下一次唤醒生效”，不是“禁选”；这是**误引客户裁定**。

### 2.5 P1 判定

**不通过（打回）。** P1 的探针设计（U-1…U-7、S1 优先、R1 兜底）是强项，但以下问题不能放行：

1. **D12 证据等级**：降为 `UNVERIFIED → U-4`（见 §4）。
2. **“无插件自建存储”与 D8/D10/U-2 矛盾**：把 §1 的“不需要独立存储后端”改为条件句；明确“live/resume 写入 → 宿主日志持久”和“冷队友下次唤醒 → 插件侧 pending 覆盖存储 + `agent/created` 回填”是两条形态不同的路径，P1.5 用 U-2 结论二选一；不要在 U-2 前把“无存储”写成定论。`02-plan.md:12,45-48,61,68`
3. **U-3/R3 降级违反 Q8**：若 `agent/created` 回填晚于首 step，不能以“再发一次继续”作为降级；要么证明 U-3（首跳前完成 select），要么给出不改验收的其他机制，要么向客户申请明确豁免。`02-plan.md:69,83`；`00-client-answers.md:6`
4. **S2/S3 在 P1.5 清零前写功能代码**：SPEC P1.5 明确“只做探测与最小验证，不写功能代码”。计划写“S2/S3 可先行（纯读）”，但 S2 是 Host 骨架、S3 是读路径 RPC，都是功能代码。应把 S2/S3 移到 S1 之后，或明确它们是探针脚手架、不进入交付物。`02-plan.md:19,28`；`process-v2.md:39`
5. **§3.5 补“对验收的影响”列**：逐 U 写清哪条 A 会变、怎么变。`02-plan.md:63-73`
6. **D11 结论列**：把“路由可用”标为 `UNVERIFIED → U-7`；“Service 存在”单独作为已验事实，不要合成一个“已验”。`02-plan.md:48`
7. **D14 冷会话 `mode='unknown'` 的渲染规则**：S5 的 `useSession(s=>s.subagent)` + mode 判定要在“unknown”时仍能渲染一个占位并调用 Host `describeTeammateRoute`，否则冷队友根本看不到选择器，A1 在冷场景失败。`02-plan.md:23,56,70`；`probes.md:83`
8. **“冷时禁选（客户裁定 Q8）”删除或改写**：客户没有裁定禁选；如要保留禁选，必须单独取得客户同意。`02-plan.md:47`

---

## 3. 两条大断言核查（独立核对，不采信产物说法）

> 官方源码读取方式：用只读 `read` 直接打开 `C:\Users\Administrator\AppData\Local\Programs\DeepSeek Harness\resources\app.asar\dsh\node_modules\@deepseek-ai\...` 的 `文件:行`；下称 `<ASAR>`。未安装、未改包。

### 3.1 断言一：「官方对队友会话双路拒绝」——成立

**结论：成立，出处真实，引用基本正确。**

**客户端选择器（UI 路）**：

- `conversation.input.model` 的 `inject` 中，`available = sessions.subagentAddress(sessionId) === void 0`；对 addressed subagent 会话为 `false`。`<ASAR>\dsh-client-ui-model-selection\lib\client.js:2074`
- `/model` 命令的 `available` 同样要求 `subagentAddress === void 0`。`:2034`
- 命令的 `options` 与 `onSelect` 对 addressed subagent 会话直接抛 `Error("model selection is unavailable for addressed subagent sessions")`。`:2044,2048`
- `assertAvailable()` 也抛同一错误。`:944`
- README 明说 “addressed subagent sessions expose neither entry” / “subagent continuation deliberately exposes no independent model-selection contract”。`<ASAR>\dsh-client-ui-model-selection\README.md:76,109`

**官方 RPC（`session.selectModel` 路）**：

- `selectModel` 先 `resolveAgent(sessionId)`。`<ASAR>\dsh-api-session-controller\lib\index.js:704-705`
- `resolveAgent` → `resolve`；`liveAgent` 对 `hasApiSessionSubagentOwner` 为真的会话返回错误。`:967-970,278-282`
- `hasApiSessionSubagentOwner` 在 `session.header.origin === "subagent"` 时直接返回 `true`。`:130-136`
- 错误构造为 `new RemoteError("session/agent-busy", ... "is owned by subagent routing" ...)`。`:142-144`
- 冷会话路径 `resumeObserved` 也会抛 `ApiSessionSubagentOwnership`，`resolve` 把它转成同一个 `session/agent-busy`。`:305-307,209`
- 因此 `selectModel` 不会走到 `agent.model.select`，更不会触发 `agentDefaultModel.saveSelection`；后者在 `:715-716` 仅对普通会话生效。官方 RPC 确实同时具备“拒绝子代理会话”和“附带全局默认写入”两个否定性事实。

**引用质量**：`probes.md:108-109`（P-11）与 `:118-119`（P-13）的结论正确。唯一的小问题是 P-13 没有把 `selectModel → resolveAgent → resolve` 的调用链完整列出（只列了 ownership 判定与错误文案），属于**出处链不完整**，不是结论错误。`probes.md:117-120`

**结论使用是否正确**：正确。`01-requirements.md:12` 用它论证“现有能力对队友拒绝”；`02-plan.md:10,13` 用它论证“不能复用官方 RPC，必须自建 Host 写路径与 Client 控件”。这个设计前提可以成立。

**一个措辞提醒**：UI 层的“拒绝”是 `available=false` + 抛错 + 命令不可用，不等于“官方选择器完全不渲染”（它可能仍渲染一个不可用/禁用态）。这不影响“插件必须自建控件”的结论，但 P3 验收不要把“官方控件不出现”当成前提。

### 3.2 断言二：「重启后覆盖仍在 / 无覆盖零介入，由宿主机制免费满足，插件无需自建存储」——宿主机制成立，后半过度乐观

#### 3.2.1 宿主机制确实存在（已验）

- **持久投影**：`modelSelection` 投影把 `model/selection` 记为 `pending`，把 `request/header` 记为 `lastUsed`；`pending` 与 `lastUsed` 相同则清空。`<ASAR>\dsh-agent\lib\index.js:140-174`
- **读取优先级**：`AgentModel.current()` = `recordedSelection()`（`pending ?? lastUsed`），只有完全没有记录时才回退到构造时的 `options`。`:190-203`
- **写入**：`AgentModel.select()` 追加官方 `model/selection` 事件；同路由直接 return。`:196-199`
- **重启/冷恢复**：`AgentLoop` 构造时只把 `options` 存进 `AgentModel`，不调用 `select`（`<ASAR>\dsh-agent-loop\lib\index.js:536-546`）；step 准备取 `this.model.current()`（`:671`）；step 准备后改路由会被拒绝（`:1000-1001`）。
- **子代理冷恢复**：`coldResume` 把 descriptor 的 `agentProvider/agentModel/agentReasoningEffort` 作为 `agentOptions` 传给 `agents.resume`（`<ASAR>\dsh-subagent\lib\index.js:2155-2203,2186-2190`）；`agents.resume` 进入 `initializeAgent`，该函数只构造 Agent，不调用 `select`（`<ASAR>\dsh-agent-loop\lib\index.js:1455-1598,1710-1775`）。子代理的 `setup` 只在 `create` 分支追加 `subagent/descriptor`，`resume` 分支不追加、不 select（`<ASAR>\dsh-subagent\lib\index.js:1802-1814`）。
- **只有配置型 Agent 的 resume 才会 `applyConfiguredRoute` → `select`**：`<ASAR>\dsh-agent-loop\lib\index.js:1371,1380-1391,1418`；子代理冷恢复不走这条。**因此，已写入子会话日志的 `model/selection` 不会被冷恢复覆盖。**

**结论**：对“选择已写进子会话日志”的场景，`重启后覆盖仍在` 与 `无覆盖时回退到 descriptor 路由` 都是宿主机制免费满足的。`probes.md:127-130`（P-15）的核心结论正确，且它引用的关键行与源码一致（P-15 漏了 `:1418`，不影响结论）。

#### 3.2.2 “插件无需自建存储”不是无条件事实（过度乐观）

这是本案最大的简化主张，必须拆成三条：

| 子主张 | 判定 | 说明 |
|---|---|---|
| 重启后覆盖仍在 | **已验（条件：选择已进子会话日志）** | 投影重放 + `current()` 优先 recorded selection；冷恢复不覆盖。 |
| 无覆盖零介入 | **已验（条件：只读路径）** | 无记录时 `current()` 回退到 `options`，首个请求仍走 descriptor；插件不写日志。 |
| 插件无需自建存储 | **未验/条件不成立** | 只有“插件能在 live Agent 或 resume 后的 Agent 上调用 `agent.model.select()`”时才成立。冷队友在“下一次唤醒生效”语义下，覆盖的待生效值必须先存在某处；计划自己的 D8/U-2 就写了“插件 Config/域存储”。 |

**为什么后半过度乐观**：

1. **冷队友不能直接写日志**：`session.append` 需要一个打开的 Session/Agent；冷队友没有 live Agent。计划 U-2 正是去探“resume → select → dispose”是否安全；如果 U-2 失败，覆盖只能先存插件侧（Config/域存储），等 `agent/created`（source='resume'）回填。`02-plan.md:47,68` 这条路径一旦启用，**“无自建存储”就不成立**。客户 Q8 已接受“下一次唤醒生效”，意味着这条路径是**合法且很可能被采用**的，不是边缘情况。
2. **回填时序未验**：`agent/created` 监听内的 `select` 是否早于首 step，是 U-3。若晚于首 step，首个请求仍走旧路由；计划 R3 的降级“提示再发一次继续”是**第二次唤醒**，不满足 Q8 的“下一次唤醒”。`02-plan.md:69,83`
3. **投影缓存不是阻断项，但要看显示源**：Client 侧若用 `useProjection('modelSelection')` 显示，重启/冷会话可能先看到旧快照；计划的 S3 用 `sessionQuery.readSession` 折叠，S6 说“数据来自 S3 RPC”，这是正确方向。但计划没有明确写“显示源必须是 Host RPC，不得用 Client 投影”，应补一句。`02-plan.md:21-24`
4. **写入方式**：只要插件用官方 `agent.model.select()`，投影就能识别；若插件自己 append 原始 `model/selection`，投影也能识别（同事件类型）；若插件写插件 Config 而不回填，宿主投影看不到，A8 的首个请求就不会变。因此“写入方式不同导致失效”的风险主要在**冷路径的插件侧存储 + 回填**，不在 live 路径。

**建议**：把 `02-plan.md:12` 改为条件句，例如：“live/resume 可写时，覆盖持久在子会话日志，无需插件存储；冷队友走 Q8 下次唤醒时，需要插件侧 pending 覆盖存储 + `agent/created` 回填（U-2/U-3 决定是否启用）。” 这样既不否定宿主机制，也不把未验分支写成定论。

---

## 4. D12 裁定

**问题**：`02-plan.md:54` 把 `conversation.input.right` 标为“已验（官方 slot 目录）”；开发者自报“只有静态源码证据、live 证据缺失，可能该降为 UNVERIFIED”。

**独立核对**：

- Slot 契约确实存在：`conversation.input.right` 在 `conversation.composer.bar` 的 `children` 中声明为 `kind:"list", scope:"session"`。`<ASAR>\dsh-client-ui-conversation\lib\client.js:22958-22998`
- 渲染点：在 `InputBar` 的 `standardControls` 中 `renderSlot("conversation.input.right", {})`，条件是 `input`/`sessionId` 存在。`:22107-22110`
- 队友视图：`ui-subagent` 的 `ConversationSlotPanel` 对显式传入的子会话渲染共享的 Conversation 内容（`conversation.session` view chat）。`<ASAR>\dsh-client-ui-subagent\lib\client.js:786-803`
- 只读 composer 的替换条件：`selectReadOnlySubagent` 对 `mode === 'unknown'`、`one-shot`、或 `parentAvailable === false` 且非 running 的会话返回只读；对 `continuable` 且 `parentAvailable !== false` 返回 `null`（不替换，走正常 composer）。`:1220-1228,1273-1278`
- **live 证据**：`probes.md:34-37` 记录 T-2 两次 `Slots.listSubTree` 超时；`probes.md:73-77` 明说“live 实测未做，故 D13 = U-4”。D12 与 D13 共用同一个 slot 目录证据。

**裁定**：

1. **P0 验收可判定性：够。** A1/A11/A12 的判据是 `document.querySelector`，不依赖 live slot 树；静态源码已经足以说明“normal composer 会渲染该 slot，且 continuable + parent-online 不会被只读 composer 替换”。P0 不需要因此打回。
2. **P1 证据等级：不够“已验”。** D12 的“已验”最多只能覆盖“slot 契约存在且是 session-scoped”；“队友会话视图确实渲染”仍是静态推断，且 live 探针超时。开发者自己也说可能该降 UNVERIFIED。应改为：**“slot 契约 = 已验；队友视图渲染 = `UNVERIFIED → U-4`”**。
3. **不需要新增 U-8。** U-4 的“怎么探”已经写了“最小探针 bundle 注册该 slot 并 `console.log(props)`”，清零判据是“探针组件在主线会话不渲染、在队友会话渲染且 props 含 subagent.address”。这正好覆盖 D12 的 live 缺口。把 D12 并入 U-4 的探针范围即可；§5 的“UNVERIFIED 7 条”不变（U-4 仍是一条）。
4. **如果团队坚持保留“已验”**：必须把上面的 `22958-22998`、`22110`、`786-803`、`1220-1228` 四处引用补进 D12 的出处，并把结论限定为“slot 契约已验；渲染待 U-4”，不能笼统写“已验”。

---

## 5. 缺陷清单

### 5.1 BLOCKER（必须修，修前不得进入下一阶段）

| ID | 位置 | 缺陷 | 证据 | 修复要求 |
|---|---|---|---|---|
| **P0-B1** | `01-requirements.md:59-62,137` | A5 与客户追加澄清**相反**：文档写“判定面相同”，客户写“失败面不同”；A5 未保留“只能证明错误类型变了，不能证明额度问题解决”的限定。 | `00-client-answers.md:10` | 在 A5 的描述/判定中原文保留客户限定；删除 Q3 的“判定面相同”，改为“失败面不同：服务端拒绝 vs 本地解析不到”。 |
| **P0-B2** | `01-requirements.md:21,136,142,146`；`02-plan.md:92,95` | 客户已裁定 Q2/Q8，文档仍写“待客户裁定/默认假设”；违反 SPEC 铁律 6。 | `00-client-answers.md:5-6`；`process-v2.md:12` | Q2/Q8 改“客户裁定”，写入原裁定；删“默认假设/待裁定汇总/若客户要……”；同步 02 的“待客户裁定 2 条”和“Q8 默认假设”。 |
| **P1-B1** | `02-plan.md:12` vs `:45-48,61,68` | §1 写“不需要独立存储后端”；U-2 降级却写“插件 Config/域存储”。严格说，“插件 Config”不是独立后端，但 per-teammate pending 覆盖仍需要插件侧持久 map（放 Config 也是插件侧状态）；“域存储”则连“无独立后端”也不成立。客户 Q8 的下次唤醒语义使这条路径成为现实候选，因此“插件无需自建存储”不是无条件事实。 | 本报告 §3.2；`00-client-answers.md:6` | 把 §1 改为条件句；明确 live 写入与冷队友 pending 存储两条路径；U-2 结论后再定形态，不得先写“无需存储”。 |
| **P1-B2** | `02-plan.md:69,83` | U-3 失败后的降级“提示用户再发一次继续”是第二次唤醒，不满足客户 Q8 的“下一次唤醒生效”；未取得客户豁免。 | `00-client-answers.md:6`；`process-v2.md:40` | 要么证明 U-3（首跳前完成 select），要么给出不改验收的其他机制，要么书面向客户申请“第二次唤醒”豁免；不能把它写成普通降级。 |

### 5.2 MAJOR（应修；不修则 P0/P1 判据不完整）

| ID | 位置 | 缺陷 | 证据 | 修复要求 |
|---|---|---|---|---|
| **P0-M1** | `01-requirements.md:112-114` | A16 的“人工→机判替代”仍含“深浅两色均可读”主观项；截图被排除为通过依据，等于没有可执行判据。 | 本报告 §1.2 | 机判只保留 DOM 位置/主题 token/对比度阈值；可读性标“人工补充，不作通过依据”。 |
| **P0-M2** | `01-requirements.md:79-82` | A9 的“继续/中断/恢复等行为无差异”没有机判命令，却被标“（机判）”。 | 本报告 §1.2 | 给固定脚本下的事件序列 diff，或把行为部分标人工补充；日志 diff 仍作主判据。 |
| **P0-M3** | `01-requirements.md:52` | A3 的“分组数/条目数 ≥ listProviders/listModels 返回值”对零模型 provider 或失败组会误判。 | 本报告 §1.2；`02-plan.md:43`（D6 允许失败行） | 改为精确集合规则：组 = 有模型的 provider；条目 = 各 provider `listModels` 的并集；失败组单列。 |
| **P0-M4** | `02-plan.md:84`；`01-requirements.md:117-129` | 父级离线只读态不提供选择器，是 REQ“只在队友会话渲染”的范围收窄，但未进“不做”清单/未取得客户确认。 | `REQ-03:11`；`probes.md:113`（P-12） | 写进“不做”清单，或取得客户确认；同时说明 A1/A5 在父级在线场景执行。 |
| **P0-M5** | `01-requirements.md:90` | A11 的外部后端是“如有”，没有跳过/替代规则；环境中没有 ACP/Codex 等时该条不可执行。 | 本报告 §1.2 | 写明“至少用本地 one-shot 子会话覆盖；外部后端不可用则记录为未验/环境依赖”，或删掉外部后端举例。 |
| **P1-M1** | `02-plan.md:54` | D12 “已验”缺 live 证据；与 P-5/U-4 的状态冲突。 | `probes.md:34-37,73-77`；`02-plan.md:70` | 降为“slot 契约已验；队友视图渲染 `UNVERIFIED → U-4`”；补四处源码引用（见 §4）。 |
| **P1-M2** | `02-plan.md:63-73` | §3.5 缺“对验收的影响”列；只有“不成立时降级”。 | 审查任务 §二；`process-v2.md:31` | 逐 U 写明影响的 A 编号和口径变化（至少 U-1/U-2/U-3/U-4/U-6/U-7）。 |
| **P1-M3** | `02-plan.md:19,28` | S2/S3 在 P1.5 清零前写功能代码，违反“P1.5 只做探测与最小验证，不写功能代码”。 | `process-v2.md:39` | 把 S2/S3 移到 S1 之后，或明确它们是探针脚手架、不进入交付物；S1 清零前不写任何功能代码。 |
| **P1-M4** | `02-plan.md:48` | D11 的结论把“Service 存在”与“路由可用”合成“已验”；核心可用性仍是 U-7。 | 本报告 §2.1 | 结论列改为“Service 存在 = 已验；路由可用 = `UNVERIFIED → U-7`”。 |
| **P1-M5** | `02-plan.md:23,56,70` | 冷会话 `mode='unknown'` 时 Client 可能不渲染选择器；D14 说依赖 Host RPC，但如果 Client 先按 mode 隐藏，就没有机会调用 RPC。 | `probes.md:83`；`<ASAR>\dsh-client-ui-subagent\lib\client.js:1220-1228` | S5 明确：`subagent` 存在即渲染占位，由 Host `describeTeammateRoute` 返回 mode 后决定显示/禁用；不得先按 `mode==='continuable'` 过滤。 |
| **P1-M6** | `02-plan.md:47` | “冷时禁选（客户裁定 Q8）”把“冷时禁选”与客户裁定并列，容易被读成客户同意禁选；客户 Q8 只裁定“下一次唤醒生效”，没有禁选内容。若括号只修饰前半句，应把“冷时禁选”单独标为未获同意。 | `00-client-answers.md:6` | 删除“冷时禁选”或改为“需客户另行同意”；降级只保留“下一次唤醒 + 插件侧 pending 存储 + 回填”。 |

### 5.3 MINOR（建议修；不影响门禁结论，但影响可复跑/可读性）

| ID | 位置 | 缺陷 | 修复建议 |
|---|---|---|---|
| **P0-m1** | `01-requirements.md:72` | A7“无覆盖时菜单项置灰”没有具体 DOM 属性/状态判据。 | 指定 `disabled`/`aria-disabled` 或等价可查询属性。 |
| **P0-m2** | `01-requirements.md:87` | A10“开关状态保持”没有具体 Config key/value。 | 写明 `showSelector` 的配置路径与读取方式。 |
| **P0-m3** | `01-requirements.md:47` | A2 占位文本“自动/无等级”未固定唯一字符串。 | 指定一个 locale key 或精确文本。 |
| **P0-m4** | `01-requirements.md:55-57` | A4 要求“新增 1 条 `model/selection`”，但同路由 `select()` 会 early return。 | 明确测试选不同模型/等级；或把“同路由不写”写成允许的例外。 |
| **P1-m1** | `probes.md:117-120` | P-13 未列 `selectModel → resolveAgent → resolve` 调用链；结论正确但出处链不完整。 | 补 `:704-728`、`:967-970`、`:192-217`。 |
| **P1-m2** | `probes.md:127-130` | P-15 漏引 `:1418`（另一处 `applyConfiguredRoute`）；结论仍正确。 | 补 `:1418`，避免“只有 1371”的误读。 |
| **P1-m3** | `02-plan.md:45-48,61,68-69` | 若 U-2 走 resume+select，同时 U-3 的 `agent/created` 监听也回填，可能写两条 `model/selection`，违反 U-2“恰好 1 条”。 | 明确二选一：U-2 成功则不注册回填；U-3 路径则不走 resume+select。 |
| **P1-m4** | `02-plan.md:21-24` | S6 说“数据来自 S3 RPC”，但未明说不得用 Client `useProjection` 作为显示源；重启/冷会话可能有旧投影。 | 在 S6 写明显示源 = Host `describeTeammateRoute`，Client 投影只作辅助。 |

---

## 6. 放行意见

1. **P0：打回。** 先修 P0-B1、P0-B2（两项 BLOCKER），再修 P0-M1…M5。修完后按同一道 P0 门重审；P0 未过，P1.5/P2 不得开工。
2. **P1：打回。** 先修 P1-B1、P1-B2（两项 BLOCKER），再修 P1-M1…M6。P1 重审通过后才进 P1.5；P1.5 清零前不写功能代码（含 S2/S3）。
3. **两条大断言的使用**：
   - “官方双路拒绝”可以直接作为设计前提（出处已复核）；插件必须自建 Host 写路径与 Client 控件，不能复用 `session.selectModel`。
   - “重启后覆盖仍在 / 无覆盖零介入”可以作为**宿主机制事实**使用；但“插件无需自建存储”只能作为**待 U-2/U-3 验证的假设**，不能先定形态。若 U-2 失败、走 Q8 的下次唤醒路径，插件需要 per-teammate 的 pending 覆盖存储 + `agent/created` 回填；这要在 P1.5 记录里写清，并回填 `02-plan.md` §1/§3。
4. **D12**：降为 `UNVERIFIED → U-4`，不新增 U-8；P0 验收可判定性不受影响，P1 的“已验”表述必须改。
5. **未决/无法判定项**：
   - 本报告未对 live UI 的实际 DOM 渲染做观测（`Slots.listSubTree` 超时，T-2）；该缺口由 U-4 在 P1.5 清零。
   - 本报告未安装任何插件，未验证第三方 bundle 的 `ctx.remote` / `ctx.webServer` 通道；该缺口由 U-1/U-7 在 P1.5 清零。
   - 本报告未验证 `agent/created` 监听相对首 step 的时序；该缺口由 U-3 在 P1.5 清零。
   以上三项均标“未验”，不得写成“通过”。

---

### 附：本次审查用到的关键出处索引

- 流程规格：`process-lab/spec/process-v2.md:11-13`（铁律 5/6/7）、`:20-23`（P0 出口）、`:29-33`（P1 出口）、`:35-40`（P1.5）。
- 客户需求：`process-lab/requirements/REQ-03-dsh-teammate-model-picker.md:12-14`（功能）、`:18-21`（硬约束）、`:30-36`（验收）。
- 客户答复：`00-client-answers.md:5`（Q2）、`:6`（Q8）、`:10`（A5 限定）。
- 开发者产物：`01-requirements.md:21,47,52,55-62,72,79-82,87,90,112-114,136-146,150-154`；`02-plan.md:12,19,28,45-48,54-56,61,63-73,81-88,92-95`；`probes.md:34-37,73-77,107-130,177-181,190-200`。
- 官方源码：`<ASAR>\dsh-api-session-controller\lib\index.js:130-144,192-217,278-282,305-307,704-728,967-970`；`<ASAR>\dsh-client-ui-model-selection\lib\client.js:944,2034,2044,2048,2074`；`<ASAR>\dsh-client-ui-model-selection\README.md:76,109`；`<ASAR>\dsh-agent\lib\index.js:140-174,190-203`；`<ASAR>\dsh-agent-loop\lib\index.js:536-546,671,1000-1001,1371,1380-1391,1418,1455-1598,1710-1775`；`<ASAR>\dsh-subagent\lib\index.js:1802-1814,1815-1830,2155-2203`；`<ASAR>\dsh-client-ui-conversation\lib\client.js:22107-22110,22958-22998`；`<ASAR>\dsh-client-ui-subagent\lib\client.js:786-803,1220-1228,1273-1278`。
