/**
 * mutation-proof.mjs — "break -> red -> restore -> green" for B-1 and M-2.
 *
 * Runs against a COPY of `bundle/` under the temp directory, never the real
 * source tree: the point is to prove the suite is load-bearing, not to leave
 * mutants behind. Written in Node rather than PowerShell so the string surgery
 * is byte-exact against the LF-only sources.
 *
 * B-1 mutant: the restore stops writing the dispatch route back — the exact
 *             behaviour `08-verification.md` §3.2 proved unreachable. The A7
 *             replay must go red.
 * M-2 mutant: the pre-fix shape §3.1 reproduced — no listener-level try/catch,
 *             and an unguarded logger call inside the containment. The
 *             "logger itself throws" tests must go red.
 */
import { execFile } from 'node:child_process';
import { cp, mkdtemp, readFile, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { promisify } from 'node:util';

const run = promisify(execFile);
const here = process.cwd();
const source = resolve(here, 'bundle');

/** Run `node --test` in a directory; resolve with {code, failing, counts}. */
async function suite(cwd) {
  let stdout = '';
  let code = 0;
  try {
    const result = await run(process.execPath, ['--test'], { cwd, maxBuffer: 32 * 1024 * 1024 });
    stdout = result.stdout + result.stderr;
  } catch (error) {
    stdout = (error.stdout ?? '') + (error.stderr ?? '');
    code = error.code ?? 1;
  }
  const failing = stdout.split('\n').filter((line) => line.startsWith('✖ ')).map((line) => line.trim());
  const counts = {};
  for (const line of stdout.split('\n')) {
    const match = line.match(/^ℹ (tests|pass|fail) (\d+)/);
    if (match) counts[match[1]] = Number(match[2]);
  }
  return { code, failing, counts };
}

function report(label, result) {
  console.log(`--- ${label} (exit=${result.code}) ---`);
  console.log(`    tests=${result.counts.tests} pass=${result.counts.pass} fail=${result.counts.fail}`);
  for (const name of result.failing) console.log(`    ${name}`);
  if (result.failing.length === 0) console.log('    (no failing test reported)');
}

/** Replace `from` with `to`, asserting the anchor existed exactly once. */
function splice(text, from, to, label) {
  const at = text.indexOf(from);
  if (at === -1) throw new Error(`anchor not found: ${label}`);
  if (text.indexOf(from, at + 1) !== -1) throw new Error(`anchor is not unique: ${label}`);
  return text.slice(0, at) + to + text.slice(at + from.length);
}

const work = await mkdtemp(join(tmpdir(), 'teammate-picker-mutation-'));
await cp(source, work, { recursive: true });
console.log(`copy: ${work}`);
console.log(`baseline: ${JSON.stringify((await suite(work)).counts)}\n`);

const corePath = join(work, 'lib/core.js');
const hostPath = join(work, 'lib/host.js');
const coreOriginal = await readFile(corePath, 'utf8');
const hostOriginal = await readFile(hostPath, 'utf8');

// ===========================================================================
console.log('############ B-1: restore must write the dispatch route back ############');
// The mutant: "restore = delete the row" — the claim the verifier broke. With
// planRestore always declining, no listener ever appends `model/selection`, so
// the official projection keeps answering with the override route.
const b1 = await suite(work); // sanity: the copy is green before the mutation
if (b1.code !== 0) throw new Error('the copied tree is not green before mutation; aborting');

const b1Mutant = splice(
  coreOriginal,
  "  return { action: 'select', route: dispatch, reason: 'restore-dispatch-route' };",
  "  return { action: 'noop', reason: 'restore-is-a-delete-only' };",
  'planRestore write-back',
);
await writeFile(corePath, b1Mutant);
const b1Red = await suite(work);
report('B-1 MUTANT (restore decays to a delete)', b1Red);

await writeFile(corePath, coreOriginal);
const b1Green = await suite(work);
report('B-1 RESTORED (write-back in place)', b1Green);

// ===========================================================================
console.log('\n############ M-2: listener return must survive a throwing logger ############');
// The pre-fix shape, verbatim from 08-verification.md §3.1: containment lives
// inside applyToAgent, the listener itself has none, and the catch logs through
// the raw logger. A throwing sink then escapes the catch and rejects announce().
const m2AnchorStart = "  ctx.on('agent/created', (payload) => {\n    try {\n      bridge.applyToAgent(payload?.agent);\n    } catch (error) {\n      warnSafely(logger, 'teammate-picker: agent/created listener failed', error);\n    } finally {\n      return undefined;\n    }\n  });";
if (!hostOriginal.includes(m2AnchorStart)) throw new Error('M-2 listener anchor not found');

const guardAnchor = "  try {\n    logger?.warn?.(message, detail);\n  } catch {\n    // A failed log must never become a failed wake-up.\n  }";
if (!hostOriginal.includes(guardAnchor)) throw new Error('M-2 warnSafely anchor not found');

let m2Mutant = splice(
  hostOriginal,
  m2AnchorStart,
  "  ctx.on('agent/created', (payload) => {\n    bridge.applyToAgent(payload?.agent);\n    return undefined;\n  });",
  'agent/created listener containment',
);
m2Mutant = splice(m2Mutant, guardAnchor, '  logger?.warn?.(message, detail);', 'warnSafely guard');
await writeFile(hostPath, m2Mutant);
const m2Red = await suite(work);
report('M-2 MUTANT (no listener try/catch, unguarded logger)', m2Red);

await writeFile(hostPath, hostOriginal);
const m2Green = await suite(work);
report('M-2 RESTORED (try/catch/finally + guarded logger)', m2Green);

// ===========================================================================
console.log('\n=== verdict ===');
const rows = [
  ['B-1 mutant  (must be RED)  ', b1Red.code],
  ['B-1 restored (must be GREEN)', b1Green.code],
  ['M-2 mutant  (must be RED)  ', m2Red.code],
  ['M-2 restored (must be GREEN)', m2Green.code],
];
for (const [label, code] of rows) console.log(`  ${label} exit=${code}`);

const ok = b1Red.code !== 0 && b1Green.code === 0 && m2Red.code !== 0 && m2Green.code === 0;
console.log(ok ? 'RESULT: PASS' : 'RESULT: FAIL');
console.log(`copy kept for inspection: ${work}`);
process.exit(ok ? 0 : 1);
