# 06-implementation.md — P2 最小切片实现说明

> 版本：2026-11-08。对应 `02-plan.md` r3 的 S2/S3/S4/S5（离线可验部分）。
> 范围声明（任务给定）：**只做离线可验切片**。不安装、不碰 `$DSH_HOME`、不写真实 Config 到 profile、不跑运行时验证（P3 做）。
> 测试入口：`cd bundle && node --test`（零第三方依赖；Node 24.22.2）。
> 结果：**81 tests / 81 pass / 0 fail**（原文见 `07-selfcheck.md` §1）。

## 1. 交付物清单

```
bundle/
├─ package.json         # bundle 清单：dsh.bundle.patch + dsh.client（platform web, immediately）
├─ cordis.patch.yml     # 一行 Host entry：id = teammate-picker，config = {showSelector, overrides}
├─ index.js             # Host 入口：export Config + apply(ctx, config)
├─ client.js            # Client 半：__ModuleLoader__ 工厂 + conversation.input.right 注册
├─ icon.svg             # 原创图标（无外部素材、无版权依赖）
├─ locale/en.json       # meta.title / meta.description（英文）
├─ locale/zh.json       # meta.title / meta.description（中文）
├─ lib/
│  ├─ core.js           # 纯逻辑内核（不 import 任何宿主包，全部可单测）
│  ├─ host.js           # Host 骨架：3 个 listener + 失败容器 + entryId 下发
│  └─ schema.js         # Config 声明（schemastery）+ 懒加载 seam
└─ test/                # node:test，4 个文件 81 条
   ├─ core.test.mjs     # 38 条
   ├─ host.test.mjs     # 24 条
   ├─ client.test.mjs   # 11 条
   └─ schema.test.mjs   # 8 条
```

工作区另外两个文件（不在 `bundle/` 内，不随包分发）：`break-restore.ps1`（改坏→红→改回→绿 演示脚本）、`_test-output.txt` / `_break-restore-output.txt`（原文输出）。

## 2. 实现了什么

### 2.1 纯逻辑内核 `lib/core.js`（S3 的折叠 + S4 的决策 + 写操作构造）

不 import 任何宿主包、不读 `globalThis`、不 await。这是本切片的重点：**把能离线证明的部分全部挤到这一层**，剩下的未验面只有接线。

| 能力 | 函数 | 关键约束 |
|---|---|---|
| 路由校验/归一 | `normalizeRoute`、`sameRoute` | provider/model 必填且非空；effort 可选；非对象/空串/数字一律 `null`（不抛） |
| 覆盖表读写 | `normalizeTable`、`readOverride`、`setOverride`、`deleteOverride` | **不改入参**（返回新表）；坏条目丢弃而非抛错；`__proto__`/`prototype`/`constructor` 三个 key 永久拒绝 |
| 路由决策 | `decideRoute` | 有 override → override；**无 override 时原样返回传入的路由对象本身**（引用相等，`intervened:false`）——「零介入」是可断言的，不是口头承诺 |
| 冷回填决策 | `planAgentCreatedApply` | 无覆盖 → `noop`；已同路由 → `noop`（不去撞官方同值 no-op）；否则 `select` |
| 热应用决策 | `planVolatileApply` | `deepEqualJson` 比对上一次已应用表；**只对「有效覆盖变了」的 live 队友动作**；恢复（删条目）不写 selection |
| Config 纯函数 | `readShowSelector`、`readOverrides`、`unwrapVolatile` | 兼容 volatile 引用（`.get()`）与裸值；`showSelector` 不可读时回落默认值 |
| `settings.mutate` 操作构造 | `overrideSetOps`、`overrideDeleteOps`、`showSelectorOps` | 路径固定为 `['overrides', childSessionId]` 与 `['showSelector']`，两者都在 volatile 节点下 |
| 会话折叠 | `foldSessionRouteFacts`、`dispatchRouteOfDescriptor`、`effectiveRouteOf` | 首条 `subagent/descriptor` 权威；`request/header` 取最新；`model/selection` 取最新；优先级 = selection → header → descriptor |
| 渲染判定 | `shouldRenderPicker` | `subagent === null` 不渲染；`unknown`/`one-shot`/`external`/`parentAvailable === false` 不渲染；只有 `continuable` + 父级在线渲染 |
| entryId 读回 | `readEntryId` | 只认 `{entryId: string}`；`entryId: null` 视为未下发（不是「用包名兜底」） |

### 2.2 Host 半（S2 + S4）

`index.js` 导出 `apply(ctx, config)` 与 `Config`（`Config` 在 schemastery 缺失时为 `undefined`，见 §3.3）。

`lib/host.js` 注册 **3 个 listener**：

| 事件 | 行为 | 失败处理 |
|---|---|---|
| `webserver/index-inject` | `table.push({kind:'global', name:'__DSH_TEAMMATE_PICKER__', value:{entryId}})`（M9） | 整段 try/catch；`table` 不是数组直接返回 |
| `agent/created`（serial） | 从 Config 读表 → 命中且不同于 `agent.model.current()` 才 `select()` | **整段 try/catch，只记日志，永远 `return undefined`**（R4 硬要求） |
| `loader/volatile-update` | 重读表 → `deepEqual` 与已应用表比对 → 变了才对 live 队友 `select()` | 整段 try/catch；`agents.list()` 抛错时只 warn 并跳过 |

`entryId = ctx.fiber.entry?.options.id`；缺失时 warn 一次并下发 `{entryId:null}`，由 Client 落「设置不可用」态（R9）。

### 2.3 Client 半（S5 + M9 读回）

`client.js` 是 classic script：`window.__ModuleLoader__.load({id, factory})`，`factory(require)` 里 `require('react')` 从宿主模块表取 React（不重装）。

- `inject: ['slots','locale','configForms']`
- `ctx.effect(() => ctx.locale.register('teammatePicker', {en, zh}))`（zh/en 双基线）
- `ctx.slots.inject('conversation.input.right', () => ctx.slots.register({name:'conversation.input.right', id:'teammate-picker', order:100, locale:'teammatePicker', inject}, TeammatePicker))`
  - **`id: 'teammate-picker'` 是自己的格键**。`Slots` 目录原文：list 座位「reusing a shipped id puts you in THAT cell and replaces it」——复用官方 id 会顶掉官方格。
- 组件：`useSession(s => s.subagent)` → `rendersIn()` 判定 → 不是队友返回 `null`；是队友渲染一颗带 `data-dsh-teammate-picker` 的按钮，并带 `data-dsh-teammate-picker-state`（`idle`/`unavailable`）与 `data-dsh-teammate-picker-entry`。
- entryId 读回：`Reflect.get(globalThis, '__DSH_TEAMMATE_PICKER__')`；拿不到 → `settingsAvailable: false`、按钮禁用 + 文案（可见降级，不静默失败）。
- 一次成功解析后 memoize；失败不 latch，下次 `inject()` 重试（避免 boot 顺序把「暂时没有」固化成「永久不可用」）。

### 2.4 Config（S2）

`lib/schema.js` 的 `CONFIG_SPEC` 是唯一事实源，`createConfigSchema(z)` 按它构造：

```js
z.object({
  showSelector: z.boolean().default(true).volatile(),
  overrides: z.dict(z.object({
    provider: z.string().required(),
    model: z.string().required(),
    reasoningEffort: z.string(),
  })).default({}).volatile(),
})
```

两字段都 `.volatile()` 是硬需求：`dsh-settings` 只接受 volatile 路径（逐段校验），而 volatile-only 变更不重挂插件、改发 `loader/volatile-update`。已用本机 `@deepseek-ai/schemastery@3.19.0` 实跑 `schema.toJSON()` 确认 `"meta":{"volatile":true}` 落在 `showSelector` 与 `overrides` 两个节点上（见 `07-selfcheck.md` §3）。

## 3. 留空壳及原因

| 位置 | 留空的部分 | 为什么 |
|---|---|---|
| `client.js` `TeammatePicker` | **两级菜单（模型 / 推理等级）、「恢复派发路由」项、目录加载与搜索** | 这些必须对着真实 DOM/主题/键盘行为调，属于 S6；离线只能断言「注册了什么」，断言不了「长什么样、点了有没有用」。切片的纪律是：**没验过的不写进去冒充完成**。当前只渲染一颗带稳定属性的座位按钮，A1/A10 的 DOM 存在性判据在结构上已就位。 |
| `client.js` 读路径 | **没接 `remote.session.events` / `modelCatalog` 的真实调用** | 折叠逻辑已写成纯函数并测好（`foldSessionRouteFacts`），接线需要真页面（`remote` namespace 只在浏览器里活着）。P3 接线时只需把事件数组喂进这几个函数。 |
| `lib/host.js` | **没有 `ctx.llm` / `ctx.sessionQuery` 注入** | 形态改为「读 = Client 侧官方 namespace」后，Host 半不再需要它们（`02-plan.md` D5/D6 已改写）。少一个 inject 就少一条运行时失败面。 |
| `index.js` | **`export const inject = [...]` 没写** | Host 半只用 `ctx.on` + `ctx.fiber` + `ctx.logger`；`ctx.agents` 用 `ctx.get`-风格的软访问（`typeof ctx?.agents?.list === 'function'`），缺服务时降级而不是不激活。真正需要 hard inject 的是 S6 之后若引入 `configEditor`。 |
| `cordis.patch.yml` | **只 insert 一行** | 路径 B 只需要本插件自己一行；不引入 `include:`、不改其他行（安装属于下一步，本轮明确不做）。 |
| `package.json` `files` | **只列运行时文件**（不含 `test/`） | 测试不随包分发；`files` 已含 `lib/*.js` 与 locale/icon，P4 复检时三方向差集应为空。 |
| 全局 | **没写 `$DSH_HOME`、没装包、没写 profile** | 任务硬约束。所有验证在 `bundle/` 目录内完成。 |

## 4. 怎么跑测试

```powershell
cd bundle
node --test                 # 全部 81 条
node --test test/core.test.mjs     # 只跑纯逻辑 38 条
node --test test/host.test.mjs     # Host 接线 24 条
node --test test/client.test.mjs   # Client 非视觉部分 11 条
node --test test/schema.test.mjs   # Config 声明 8 条
```

注意：`node --test test/`（带目录参数）在本机 Node 24 上会被当成文件名解析而失败；用 `node --test`（自动发现 `*.test.mjs`）或直接给文件路径。

语法检查：

```powershell
cd bundle
node --check index.js; node --check client.js
node --check lib/core.js; node --check lib/host.js; node --check lib/schema.js
```

### 改坏→红→改回→绿（一条命令复跑）

```powershell
pwsh -NoProfile -NonInteractive -File .\break-restore.ps1
```

它会：备份 `lib/core.js` → 把 `overrideDeleteOps` 从 `unset` 改成一条 `set`（即「恢复 = 写回派发路由」这个真实会犯的错）→ 跑测试 → 恢复原文件 → 再跑测试。实测输出：

```
=== RED: mutant applied (restore writes instead of deleting) ===
✖ overrideSetOps and overrideDeleteOps build volatile-path mutations (1.5966ms)
ℹ tests 81
ℹ pass 80
ℹ fail 1
red exit code: 1
=== RESTORE: original source put back ===
ℹ tests 81
ℹ pass 81
ℹ fail 0
green exit code: 0
```

开发过程中一共做了 4 次 mutation，其中**一次没有红**——记录下来，因为它暴露了真实结构：

| # | 变异 | 结果 | 说明 |
|---|---|---|---|
| 1 | 去掉 `applyToAgent` 外层的 `try/catch` | **仍然绿** | 里面有 3 层嵌套容器（`readTableSafe` 的 catch、`readCurrent` 的 catch、`selectSafely` 的 catch）把它兜住了。**这是好性质**（纵深防御），但也说明「把 try/catch 挪掉一层」不会立刻表现为红——所以 R4 的验收必须看**最外层是否 return undefined**，不能只看「有没有 try」。 |
| 2 | `decideRoute` 返回路由副本而非原对象 | 红（2 条） | 零介入的引用相等语义被抓住 |
| 3 | `overrideDeleteOps` 改成写回 dispatch | 红（1 条） | 恢复语义被抓住（即脚本跑的那次） |
| 4 | `deepEqualJson` 用 `JSON.stringify` 比对 | 红（1 条） | `{a:1}` 与 `{a:1,b:undefined}` 的差异被抓住 |

## 5. 与计划（`02-plan.md` r3）的偏差

| 计划 | 实际 | 性质 | 理由 |
|---|---|---|---|
| S2「inject: agents」 | 改为**软访问**（`typeof ctx?.agents?.list === 'function'`） | **偏差（有意）** | `agent/created` 的回填不依赖 `agents` 服务；`ctx.agents.list()` 只服务热应用。硬 inject 会让缺 `agents` 的 profile 直接不激活——但那种 profile 里本插件也没有意义。软访问 + 降级更好，且可单测。**若 P3 发现热应用必须在缺服务时硬失败，改回 inject 即可（一行）。** |
| S2「Config 直接 `import z`」 | 改为 `loadSchemastery()` 懒加载 + `Config = undefined` 降级 | **偏差（有意）** | 本地 `bundle/` 目录下没有 schemastery（依赖由 profile 提供），直接 import 会让 `index.js` 连语法检查都过不了 `import` 解析。懒加载让「包缺失 → 无 Config 面」而不是「插件整体加载失败」。**代价：`Config` 为 `undefined` 时 Settings/mutate 不可用**——已由 Client 的「设置不可用」态覆盖（R9）。 |
| S2 完成标志「`Config.listConfigs` 能查到本插件 entry」 | **未执行** | **未做（运行时）** | 需要安装 + 真 Host 实例，本轮明确不做。列为 `07-selfcheck.md` 的「需运行时验」。 |
| S3「Client 调官方 `session/events`/`modelCatalog`」 | 只做了**折叠纯函数 + 单测**，没接真实 namespace 调用 | **部分（有意切片）** | 接线需活页面。折叠输入/输出契约已由 5 条测试钉死，P3 只需换数据源。 |
| S4「`loader/volatile-update` 优先，`turn/start` 兜底」 | **只实现 volatile-update 一路** | **偏差（有意，缩小）** | 05 报告 R1 已把风险下调为「低」（6 个官方插件同法监听）。`turn/start` 兜底需要 `agent/pre-step` 类挂点，而 `practices.md:16` 明确 pre-step 监听者「不拥有决策必须 `return next()`」，加进去会扩大失败面。**留作 P3 的备选，不是遗漏。** |
| S5「挂 `data-dsh-teammate-picker`」 | 已挂，另加 `-state`/`-entry` 两个辅助属性 | **增补** | 便于 A10 的「DOM 存在性 == 持久值」判定与人工排查。 |
| 计划未提 | 新增 `lib/schema.js`（Config 声明独立成文件） | **增补** | 让 Config 声明本身可单测（recording fake），不必为了测一个 schema 去装 schemastery。 |
| 计划未提 | 新增 `test/client.test.mjs` 的**谓词漂移检测** | **增补** | `rendersIn` 在 `client.js` 里必须重复一份（classic script 不能 import ESM）。用「从源码抽出函数体 + 与 `lib/core.js` 逐状态比对」防止两份实现漂移。 |
| 计划 S6「显示源 = Client 侧官方 namespace」 | 未做 | **未做（S6 范围）** | 本轮切片止于 S5。 |

**没有偏差的地方**：`agent/created` 的 try/catch（R4）、`webserver/index-inject` 的 entryId 下发（M9）、`overrides`/`showSelector` 全 volatile、恢复 = 删条目、无覆盖零介入、所有文件 `node --check` 通过——都按计划实现且有测试。

## 6. 已知风险与 P3 必做项（交接）

1. **`Config` 在包内为 `undefined`**（本地无 schemastery）。安装到 profile 后依赖由 pnpm 提供，应变成声明的 schema。P3 第一件事：`Config.listConfigs {"entry":"teammate-picker"}` 查 schema，确认 `showSelector`/`overrides` 均带 `x-cordis.volatile`。
2. **`dsh.client.inject` 写的是包名**（`@deepseek-ai/dsh-client-ui-conversation`、`@deepseek-ai/dsh-client-ui-settings`）。这只影响激活顺序，不构成依赖；若正式清单要求更严格，可与 P3 一并收窄。
3. **热应用只走 `volatile-update`**。P3 必须实测：改 `overrides` 后 live 队友是否在下一次 step 用新路由（A6）；若无反应，按 R10 的兜底加 `turn/start` 比对（不要直接改成 pre-step 改写）。
4. **Client 半没有真实读路径**。P3 接线时注意：`session/events` 要先取尾页拿 `cursor` 再取 `throughSeq:min(cursor,64)` 的首段（`throughSeq` 超过 `cursor` 会 bad-request）——这条已在 `02-plan.md` §1 落点表里，折叠函数不需要改。
5. **`agent/created` 的 R4 不能靠「有没有 try」判断**。见 §4 的 mutation #1：多层嵌套 catch 会掩盖外层缺失。P3 的代码评审要看**最外层 listener 是否无条件 `return undefined`**，最好加一条「注入故障仍能唤醒」的 live 用例。
6. **未安装、未写 profile**：本目录任何测试都不触碰 `$DSH_HOME`；`_test-output.txt` / `_break-restore-output.txt` 是测试原始输出，不是运行时证据。
