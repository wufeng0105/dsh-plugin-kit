# install-shapes.ps1 — B-2 proof across the three installation shapes the
# verifier used (08-verification.md §3.3):
#
#   1. link     - a junction/symlink to bundle/ (what plugin_manager does for a
#                 directory spec: link:/file:)
#   2. copy     - the packed tarball's files copied into node_modules, with the
#                 real @deepseek-ai/schemastery reachable as a dependency
#   3. missing  - the same copy, dependency removed
#
# For each shape the probe imports index.js and reports `Config`. The old guard
# (`typeof namespace === 'object'`) failed shapes 1 and 2 — the dependency was
# reachable and still degraded, which is exactly the verifier's finding.
#
# Nothing writes to the profile: schemastery is read from it and only copied
# into a directory under $env:TEMP.
$ErrorActionPreference = 'Stop'

$bundle = Join-Path $PSScriptRoot 'bundle'
$profileModules = Join-Path $env:USERPROFILE '.dsh\profiles\desktop\node_modules'
$schemaPkg = Join-Path $profileModules '@deepseek-ai\schemastery'
if (-not (Test-Path -LiteralPath $schemaPkg)) { throw "schemastery not found at $schemaPkg" }
# schemastery's own dependencies must come along, or the copy resolves the entry
# and then fails inside it (ERR_MODULE_NOT_FOUND on @deepseek-ai/cosmokit).
$schemaDeps = @('@deepseek-ai\cosmokit', '@standard-schema\spec')

$root = Join-Path $env:TEMP ('teammate-picker-shapes-' + [guid]::NewGuid().ToString('N').Substring(0, 8))
New-Item -ItemType Directory -Path $root -Force | Out-Null

$probe = Join-Path $root 'probe.mjs'
@'
const entry = process.argv[2];
const url = new URL('file:///' + entry.replace(/\\/g, '/')).href;
try {
  const m = await import(url);
  console.log('  exports:', Object.keys(m).sort().join(','));
  console.log('  apply:', typeof m.apply);
  console.log('  Config:', m.Config === undefined ? 'undefined (DEGRADED)' : typeof m.Config);
  if (m.Config !== undefined && typeof m.Config.toJSON === 'function') {
    const doc = m.Config.toJSON();
    const refs = doc.refs ?? {};
    const look = (v) => (typeof v === 'number' || typeof v === 'string' ? refs[String(v)] : v);
    const rootNode = refs[String(doc.uid)] ?? look(doc.ref);
    for (const key of Object.keys(rootNode?.dict ?? {})) {
      const node = look(rootNode.dict[key]);
      console.log(`  field ${key}: type=${node?.type} volatile=${node?.meta?.volatile === true}`);
    }
  }
  process.exit(m.Config === undefined ? 3 : 0);
} catch (e) {
  console.log('  IMPORT FAIL', e.code ?? '', '|', String(e.message).split('\n')[0]);
  process.exit(4);
}
'@ | Set-Content -LiteralPath $probe -Encoding utf8

function Invoke-Shape {
  param([string]$Name, [string]$Entry, [string]$Expectation, [switch]$ClearProfileEnv)
  Write-Host ''
  Write-Host "=== shape: $Name ==="
  Write-Host "  entry: $Entry"
  if ($ClearProfileEnv) {
    Write-Host '  DSH_PROFILE_DIR/DSH_HOME/DSH_PROFILE: cleared (this shape must see no dependency)'
    $saved = @{
      DSH_PROFILE_DIR = $env:DSH_PROFILE_DIR
      DSH_HOME        = $env:DSH_HOME
      DSH_PROFILE     = $env:DSH_PROFILE
    }
    try {
      Remove-Item Env:DSH_PROFILE_DIR -ErrorAction SilentlyContinue
      Remove-Item Env:DSH_HOME -ErrorAction SilentlyContinue
      Remove-Item Env:DSH_PROFILE -ErrorAction SilentlyContinue
      node $probe $Entry | ForEach-Object { Write-Host $_ }
      $code = $LASTEXITCODE
    } finally {
      foreach ($key in $saved.Keys) { if ($saved[$key]) { Set-Item -Path "Env:$key" -Value $saved[$key] } }
    }
  } else {
    node $probe $Entry | ForEach-Object { Write-Host $_ }
    $code = $LASTEXITCODE
  }
  Write-Host "  probe exit=$code  (expected: $Expectation)"
  return [int]$code
}

$results = [ordered]@{}

# --- shape 1: link (junction) ------------------------------------------------
$linked = Join-Path $root 'shape1-link'
New-Item -ItemType Directory -Path (Join-Path $linked 'node_modules\@local') -Force | Out-Null
New-Item -ItemType Directory -Path (Join-Path $linked 'node_modules\@deepseek-ai') -Force | Out-Null
# the dependency must be reachable from the linked package's real location,
# which it is: bundle/ sits under the workspace, so also link it next to bundle
$linkPath = Join-Path $linked 'node_modules\@local\dsh-teammate-picker'
cmd /c mklink /J "$linkPath" "$bundle" | Out-Null
if (-not (Test-Path -LiteralPath $linkPath)) { throw 'junction creation failed' }
cmd /c mklink /J (Join-Path $linked 'node_modules\@deepseek-ai\schemastery') "$schemaPkg" | Out-Null
foreach ($dep in $schemaDeps) {
  $target = Join-Path $linked ('node_modules\' + $dep)
  New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
  cmd /c mklink /J "$target" (Join-Path $profileModules $dep) | Out-Null
}
$results['1-link (junction, dependency reachable)'] = Invoke-Shape -Name '1-link (junction, dependency reachable)' `
  -Entry (Join-Path $linked 'node_modules\@local\dsh-teammate-picker\index.js') -Expectation '0 = Config is a schema'

# --- shape 2: copy with dependency ------------------------------------------
$copied = Join-Path $root 'shape2-copy-deps'
$dest2 = Join-Path $copied 'node_modules\@local\dsh-teammate-picker'
New-Item -ItemType Directory -Path $dest2 -Force | Out-Null
Copy-Item -Path (Join-Path $bundle '*') -Destination $dest2 -Recurse -Force
New-Item -ItemType Directory -Path (Join-Path $copied 'node_modules\@deepseek-ai') -Force | Out-Null
Copy-Item -Path $schemaPkg -Destination (Join-Path $copied 'node_modules\@deepseek-ai\schemastery') -Recurse -Force
foreach ($dep in $schemaDeps) {
  $target = Join-Path $copied ('node_modules\' + $dep)
  New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
  Copy-Item -Path (Join-Path $profileModules $dep) -Destination $target -Recurse -Force
}
$results['2-copy with dependency'] = Invoke-Shape -Name '2-copy with dependency' `
  -Entry (Join-Path $dest2 'index.js') -Expectation '0 = Config is a schema'

# --- shape 3: copy without dependency ---------------------------------------
$bare = Join-Path $root 'shape3-copy-missing'
$dest3 = Join-Path $bare 'node_modules\@local\dsh-teammate-picker'
New-Item -ItemType Directory -Path $dest3 -Force | Out-Null
Copy-Item -Path (Join-Path $bundle 'index.js'), (Join-Path $bundle 'client.js'), (Join-Path $bundle 'package.json') -Destination $dest3 -Force
Copy-Item -Path (Join-Path $bundle 'lib') -Destination $dest3 -Recurse -Force
$results['3-copy, dependency missing'] = Invoke-Shape -Name '3-copy, dependency missing' `
  -Entry (Join-Path $dest3 'index.js') -Expectation '3 = degrades to undefined, does not throw' -ClearProfileEnv

Write-Output ''
Write-Output '=== summary ==='
foreach ($name in $results.Keys) { Write-Output ("  {0,-40} exit={1}" -f $name, $results[$name]) }
Write-Output "artifacts: $root"

# shape 1 and 2 must be 0 (Config present); shape 3 must be 3 (honest degrade).
if ($results['1-link (junction, dependency reachable)'] -ne 0) { exit 1 }
if ($results['2-copy with dependency'] -ne 0) { exit 1 }
if ($results['3-copy, dependency missing'] -ne 3) { exit 1 }
exit 0
