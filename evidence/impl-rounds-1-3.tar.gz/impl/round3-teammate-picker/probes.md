# probes.md — 探测记录（round3-teammate-picker，P0/P1 阶段）

> 探测时间窗：P0/P1 阶段 2026-11-08 02:22 – 02:36；**P1.5 阶段 03:07 – 03:50**（Asia/Shanghai, +08:00）。单条时间在条目内标注（同分钟内的合并标注）。
> 证据口径遵循 SPEC 铁律 5/7：宿主能力断言只认「安装包 文件:行」或「命令 + 返回」；截图/口头不作为通过依据。
> 安装包源码路径统一缩写：`<ASAR>` = `C:\Users\Administrator\AppData\Local\Programs\DeepSeek Harness\resources\app.asar\dsh\node_modules\@deepseek-ai`（app.asar 内路径，只有 DSH Host 自身的文件读取能打开；shell/ripgrep 打不开，见 P-3）。

## 0. 探测方法与可复跑命令

**asar 内容读取**（只读，不写不删）：用 Node 解析 asar 头并按偏移读取文件。三个临时脚本写在 `%TEMP%\`（`asar-list.mjs` / `asar-grep.mjs` / `asar-search.mjs` / `asar-slice.mjs`），共用同一解析核：

```js
// 头部解析核（16 字节头；dataStart = 8 + headerSize）
const head = Buffer.alloc(16); fs.readSync(fd, head, 0, 16, 0);
const headerSize = head.readUInt32LE(4), jsonLen = head.readUInt32LE(12);
const buf = Buffer.alloc(jsonLen); fs.readSync(fd, buf, 0, jsonLen, 16);
const header = JSON.parse(buf.toString('utf8'));
const dataStart = 8 + headerSize;
// 读取某 entry：fs.readSync(fd, b, 0, entry.size, dataStart + Number(entry.offset))
```

Node 路径：`C:\Users\Administrator\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe`。
复跑示例（等价于 `asar-slice.mjs <asar内路径> <起行> <止行>`）：

```
node asar-slice.mjs "/dsh/node_modules/@deepseek-ai/dsh-agent/lib/index.js" 130 204
```

**Live 探测**：`cordis_inspect_query`（只读，approval-free）。本会话可用的 provider 见 P-8。

## 1. 客户端 inspect 超时记录（如实记，不许写成通过）

| # | 调用 | 结果 | 时间 |
|---|---|---|---|
| T-1 | `cordis_inspect_query(platform=client, provider=Service, method=listService)` | **超时失败**（`Client inspect query Service.listService timed out after 10000ms. Open or reconnect the Harness page, then retry.`） | 02:23 |
| T-2 | `cordis_inspect_query(platform=client, provider=Slots, method=listSubTree)`（两次重试） | **两次均超时失败**（同上文案） | 02:26 / 02:30 |
| T-3 | `cordis_inspect_query(platform=client, provider=Slots, method=listSubTree, input={root:"conversation.input.right"})`（P1.5 重试） | **超时失败**：`Slots.listSubTree: Client inspect query Slots.listSubTree timed out after 10000ms. Open or reconnect the Harness page, then retry.` | 03:18 |
| T-4 | `Slots.listSubTree({root:"conversation.input.right"})` + `client Service.listService`（P1.5 第二轮重试） | **两者均超时**（同上文案，10s） | 06:56 |

替代证据路径（SPEC 要求）：客户端侧结论全部改用只读源码（P-4/P-5/P-6/P-7），并如实标注「live 槽位树未探到」。**受此影响，依赖 D13 标为 UNVERIFIED（U-4）**，P1.5 补探。

## 2. 探测条目

### P-1 宿主 Service 目录与关键契约
- 探什么：宿主可注入 Service 面。
- 命令：`cordis_inspect_query(host, Service, listService)`（全目录，输出 spill 66KB）；及单服务契约 `input={service:"agents"|"llm"|"storageDomain"|"agentDefaultModel"|"subagentModelSelection"}`。
- 结论：
  - `agents`：`get(id)` / `resume(ResumeAgentOptions)` / `create(...)`；`ResumeAgentOptions = { resumeSessionId, parentAgent?, agentOptions?, signal?, setup? }`（inspect 返回的类型契约原文）。
  - `llm`：`listProviders()`(@Remote) / `listModels(provider)` / `resolveModelInfo(provider, model, signal?)` / `resolveCallConfig(config)`。
  - `sessionQuery`：`readSession(sessionId): SessionLogSnapshot` / `observeSession(...)` / `listEvents(...)`。
  - `subagentModelSelection`：无方法（"Host settings owner that records Session authorization before the first model request"）。
  - `agentDefaultModel`：`currentSelection()` / `saveSelection(next)`（**本插件禁用后者**，见 P-13）。
- 出处：inspect 返回原文（命令+返回）；关键类型 `SessionHeader = { ..., parentSession?: SessionId, origin?: 'subagent', delegationDepth?, agentPreset? }`、`Session.requestHeader(): EpochHeader`、`SessionEventMap['request/header']` 同样出自该返回。
- 时间：02:24–02:28。

### P-2 官方 Slot 目录（静态源）
- 探什么：`conversation.input.right` 等 composer 工具区 slot 的官方声明。
- 命令：`node asar-search.mjs '/lib/client.js' 'conversation\.input\.right' 25`。
- 返回（摘要）：`<ASAR>\dsh-cordis-client-runner\lib\client.js:4036` 起为该 slot 的目录条目：`kind:"list"`, `scope:"session"`, summary “Compact controls before the composer submit action…”，registerOptions `{id(必填), order?, label?}`，occupants `[]`，`replaceRisk:"none"`，standardProps 列 `useSession: SessionSnapshotSelector`、`sessionId: SessionId`、`useProjection: UseProjection` 等；示例代码即第三方注册写法。源路径注释 `packages/client/ui-conversation/src/client/contract/slots.ts:316`。
- 结论：这是「输入行工具区」的官方落点，第三方占用无替换风险。
- 时间：02:31。

### P-3 安装包读取边界
- 探什么：app.asar 能否被 shell/grep 直接读。
- 命令：`Get-ChildItem '...\resources\app.asar.unpacked\dsh'`（成功，仅原生模块）；`Get-ChildItem '...\resources\app.asar\dsh'`（**失败**：app.asar 是单文件，不是目录）。
- 结论：与 cordis-plugin-development skill 一致——asar 内文件只有 DSH Host 自身的文件读取（本会话 read 工具）能打开；shell、ripgrep、node 均不能按目录访问。因此源码断言用「read 工具直读已知路径」与「§0 的 Node 偏移读取」两条路取证。
- 时间：02:22–02:23。

### P-4 ui-conversation 的 slot 声明与渲染顺序
- 探什么：composer 工具区各 slot 的 kind/scope 与渲染位置。
- 命令：`node asar-grep.mjs 'dsh-client-ui-conversation' 'conversation\.[a-zA-Z0-9_.]+'`；`node asar-slice.mjs ".../dsh-client-ui-conversation/lib/client.js" 22808 23010`；`... 22095 22115`。
- 返回（摘要）：`lib/client.js:22958-22998`（`conversation.composer.bar` 持有子 slot 声明）：`conversation.input.left/plan/right` 均 `kind:"list", scope:"session"`；`conversation.input.model` `kind:"single"`；`conversation.composer.dock` `kind:"list"`。渲染顺序 `lib/client.js:22110`：`children: [ renderSlot("conversation.input.right", {}), renderSlot("conversation.input.model", { locked }) ]`。
- 结论：`.right` 是官方模型位左侧的工具区，与 REQ「输入行工具区」吻合；A16 的同容器判据以此为准。
- 时间：02:25。

### P-5 Slot 标准 props 目录
- 探什么：第三方 slot 组件能拿到什么 props。
- 出处：同 P-2（`dsh-cordis-client-runner/lib/client.js:4036-4092`，standardProps 全表）。
- 结论：`useSession`/`sessionId`/`useProjection` 等 19 个标准 props 官方目录已列；**live 实测未做（T-2 超时）**，故 D13 = U-4。
- 时间：02:31。

### P-6 客户端会话快照的 `subagent` 字段
- 探什么：客户端如何表达「这是子代理会话 / 可继续」。
- 命令：`node asar-search.mjs 'dsh-client' 'parentAvailable' 30`；`node asar-slice.mjs ".../dsh-api-session-controller/lib/client.js" 2913 2937`。
- 返回（摘要）：`client.js:2919-2925` 快照字段 `subagent: this.address === void 0 ? null : { address: {parentSessionId, childSessionId, mode}, parentAvailable? }`；`ui-conversation/lib/client.js:21824` `const continuable = subagent?.address.mode === "continuable"`；`ui-subagent/lib/client.js:795` 同谓词。
- 结论：客户端判定「队友会话」的官方事实源 = `useSession(s => s.subagent?.address.mode === 'continuable')`；冷会话 mode 可能为 `'unknown'`（P-12），需 Host 复核。
- 时间：02:27。

### P-7 客户端 `sessions.subagentAddress` 门面
- 命令：`node asar-slice.mjs ".../dsh-api-session-controller/lib/client.js" 3902 3910`。
- 返回（摘要）：`client.js:3908` `subagentAddress(id)`，JSDoc “Feature plugins use this to avoid Agent-bound RPCs in persisted child views.”
- 结论：第三方 Client 半可用官方门面做零 RPC 判定。
- 时间：02:33。

### P-8 Inspect provider 清单
- 命令：`cordis_inspect_list`。
- 结论：host 侧 Service/Event/Config/Tool；client 侧 Service/Event/Builtin/Slots/Theme。client 侧查询当前均超时（T-1/T-2）。
- 时间：02:22。

### P-9 全局默认模型的所有权
- 出处：`<ASAR>\dsh-agent-default-model\README.md:12,50-57,71,115-116`；inspect Config schema（`include:agent-default-model`）含 `provider/model/reasoningEffort` 且 `x-cordis.volatile`。
- 结论：全局默认是 profile 配置级事实，独立于会话选择；「不动全局默认」的验收基准就是这段配置不变化（A4）。
- 时间：02:25。

### P-10 会话头判定（宿主侧）
- 出处：`<ASAR>\dsh-session\lib\index.js:1051,1053`（header 校验 `parentSession`/`origin`）；inspect `SessionHeader` 契约（P-1）。
- 结论：宿主侧判定 `session.header.origin === 'subagent'`。
- 时间：02:29。

### P-11 官方模型选择 UI 对子代理会话拒绝
- 出处：`<ASAR>\dsh-client-ui-model-selection\README.md:76`（"addressed subagent sessions expose neither entry"）、`:109`（"subagent continuation deliberately exposes no independent model-selection contract"、"No create-time or addressed-subagent selection"）、`:111`（无任意 effort 输入）；源码 `<ASAR>\dsh-client-ui-model-selection\lib\client.js:944`（"model selection is unavailable for addressed subagent sessions"）、`:2034,2044,2048,2074`（`sessions.subagentAddress(sessionId) === void 0` 才 available）。
- 结论：REQ 背景「现有切换模型能力对队友明确拒绝」成立（UI 层）。UI 层拒绝的机制同时证明 REQ 边界「观感对齐即可」只能靠自建控件达成。
- 时间：02:26。

### P-12 子代理后端与延续语义
- 出处：`<ASAR>\dsh-subagent\README.md:61,69`（local 子会话可冷恢复；外部后端一次性）、`:137`（descriptor 记录 child provider/model/effort 供冷恢复）；`<ASAR>\dsh-client-ui-subagent\README.md:40,70-72`（continuable/one-shot/父级离线只读 composer）。
- 结论：A11（one-shot/外部不渲染）与 R4（父级离线只读态）成立依据；「队友」= 可继续子代理（Q1 口径）。
- 时间：02:26。

### P-13 官方 `session.selectModel` 的两个否定性事实
- 出处：`<ASAR>\dsh-api-session-controller\lib\index.js:704-728`（`selectModel` 实现）：`:715 agent.model.select(selected)`，**`:716 ctx.agentDefaultModel.saveSelection(selected)`（附带全局默认写入）**；`:130-136 + :196`（`hasApiSessionSubagentOwner`：`session.header.origin === "subagent"` 即返回 true）+ `:142-144`（错误文案 "session is owned by subagent routing"）；`:473-522`（官方 `buildModelCatalog`：`ctx.llm.listProviders()` + `listModels` + `resolveModelInfo`，不依赖 Session）。
- 结论：插件**不得**复用官方 RPC（硬约束 4 会被违反 + 子代理会话被硬拒）；全量目录可在宿主用同一组公开 `llm` 方法自建（D6）。
- 时间：02:29。

### P-14 会话级模型选择的写入/读取 API
- 出处：`<ASAR>\dsh-agent\README.md:45-52`（`agent.model`：`current()` 顺序 = pending → lastUsed → live `agent.options`；`select()` 记录完整选择；"Selecting a Session model does not change deployment defaults"；"Ordinary resume keeps the recorded choice"）；源码 `<ASAR>\dsh-agent\lib\index.js:131-203`（selectionSchema、投影 apply、`AgentModel.select` = `session.append("model/selection", ...)`）；`<ASAR>\dsh-subagent\lib\index.js:2250`（`agent.options` 用法）。
- 结论：D2/D3 成立；覆盖写入 = `agent.model.select()`，读取 = `current()`/投影，`agent.options` = 派发路由（live 侧）。
- 时间：02:28。

### P-15 持久化与唤醒路由语义（REQ 背景的机制解释）
- 出处：`<ASAR>\dsh-agent\lib\index.js:140-174`（`modelSelection` 投影：`model/selection`→pending；`request/header`→lastUsed，pending 同值即清）；`<ASAR>\dsh-agent-loop\lib\index.js:539-545`（构造时只存 options，**不调用 select**）、`:671`（step 准备取 `this.model.current()`）、`:1000-1001`（step 准备后改路由会被拒绝，"use agent.model.select() before step preparation"）；`<ASAR>\dsh-subagent\lib\index.js:2186-2190`（冷恢复把 descriptor 三元组作为 `agentOptions` 传入）、`:1815-1820`（`agents.resume({..., agentOptions})`）；`<ASAR>\dsh-agent-loop\lib\index.js:1371,1380-1391`（只有配置型 agent 的 resume 才调 `applyConfiguredRoute`→`select`）。
- 结论：(a) 队友每次唤醒沿用旧路由的原因是 lastUsed/选项回退，而不是「每次冷恢复重写选择」；(b) 冷恢复**不会**覆盖已记录选择；(c) 因此 `model/selection` 天然满足「重启仍在」（A8）且无覆盖时零介入（A9）成立。P0/P1 设计据此不引入插件自建存储（若 P1.5 推翻，回填 02-plan §5）。
- 时间：02:31–02:33。

### P-16 事件目录与 `agent/created` 契约
- 命令：`cordis_inspect_query(host, Event, listEvents)`；单事件 `input={event:"agent/created"}`。
- 结论：`agent/created` mode=serial，payload `{agent, source: SessionStartSource, signal?}`，`SessionStartSource = 'startup' | 'resume' | 'clear' | 'compact'`；"AgentLoop holds queued input until all listeners finish"。目录中亦有 `agent/pre-step`（waterfall，`modelSelection` 只读且「listeners must preserve all three」，dsh-agent README:78）——**不可用于改路由**。
- 时间：02:28。

### P-17 模型目录与推理等级
- 出处：inspect `llm` 契约（P-1）：`listModels(provider): LlmModelInfo[]`（含 name/badge）、`resolveModelInfo(...): LlmResolvedModelInfo`（含 `reasoning: { efforts: LlmReasoningEffortInfo[] , defaultEffort? }`）、`listProviders(): LlmProviderInfo[]`；`dsh-api-session-controller/lib/index.js:473-522`（官方目录构建同法）。
- 结论：A3 的机判基准（目录/等级条目数）成立。
- 时间：02:27。

### P-18 冷会话只读通道
- 出处：inspect `sessionQuery` 契约（P-1）：`readSession(sessionId): SessionLogSnapshot`、`observeSession(...)`；`dsh-subagent\lib\index.js:2162-2175`（官方冷恢复正是用 `sessionQuery.observeSession` 折叠 descriptor，不唤醒 Agent）。
- 结论：S3 读路径实现可完全复用官方语义（P-15 同法）。
- 时间：02:27。

### P-19 会话持久化形态
- 出处：`<ASAR>\dsh-session-persistence-jsonl\README.md:12,28-32,43,57-70`（root 必填、每会话一目录、v3 当前格式 `session.v3.jsonl(.zstd)`）。
- 结论：A4/A15 的「日志 diff」可经 `sessionQuery.readSession` 或持久化文件复核；具体审查员命令在 P2 固化（SPEC P2）。
- 时间：02:34。

### P-20 插件配置持久化机制
- 出处：skill 参考 `references/host-plugin.md:66-77`（configEditor 写回完整 config；`.volatile()` 原地更新）；`agent-default-model` 的 Config schema 即 profile patch 事实（P-9）。
- 结论：D9 的开关若走 Config，重启后随 profile 持久。
- 时间：02:24。

### P-21 插件 manifest / meta / 安装
- 出处：skill `references/host-plugin.md:5-53`（bundle patch、`meta.title/description`、icon、`files`）与 `references/ui-plugin.md:1-11`（`dsh.client` platform/immediately/inject）。
- 结论：S2/S5 的包结构契约成立；安装本身留待客户授权（本次未安装任何东西）。
- 时间：02:23。

### P-22 Client locale 服务
- 出处：`<ASAR>\dsh-client-locale\README.md:40`（`ctx.locale.register(ns, {zh, en, ...})` + `ctx.locale.bind(ns)`；zh/en 双基线必填）、`:86`（slot 系统 LocaleFace）。
- 结论：D16 的 API 形态已验；**第三方 bundle 可注入性未实测**（client inspect 超时），故 U-5。
- 时间：02:35。

### P-23 `ctx.webServer`（HTTP 兜底通道）
- 出处：inspect host Service 目录：`webServer`：`getOrigin()` / `register(route: WebRoute | WebResourceRoute)` / `registerFallback(...)`。
- 结论：服务存在已验；第三方路由的同源 fetch 与鉴权细节未探（U-7）。
- 时间：02:24。

### P-24 Client 模块装载契约
- 出处：skill `templates/decoration/client.js`（`window.__ModuleLoader__.load({ id, factory(require){... inject:['slots'], apply(ctx){...} } })`）与 `templates/decoration/package.json`（`dsh.client = { platform:'web', immediately:true, inject:['@deepseek-ai/dsh-client-ui-conversation'] }`）。
- 结论：D15 成立；第三方 bundle 的 client 进场形态明确。
- 时间：02:23。

### P-25 动态插件 Client→Host 先例（U-1 的旁证，非结论）
- 命令：`node asar-search.mjs 'dsh-cordis-client-runner/lib/client.js' 'ctx\.remote|remoteClient|typert' 30`。
- 返回（摘要）：`client.js:7841-7942` 多处 `ctx.remote.dynamicCordisRunner.xxx`（动态插件运行时的 RPC 通道）。
- 结论：`ctx.remote.<service>` 形态存在，但那是动态插件运行器专用；**bundle 型第三方 client 是否同样注入 `ctx.remote` 未证实** → U-1。
- 时间：02:35。

## 2b. P1.5 阶段探测条目（P-26…P-38）

> 证据口径：本轮未安装探针 bundle，全部结论为「源码 / 契约」级；运行时缺口见 `05-p1.5-probes.md` §5。
> `<ASAR>` 含义同前。asar 读取脚本本轮落在 `probe-tools/`（asar-slice/grep/list/dirs/find.mjs，只读）。
> 第一轮 P-26…P-33（03:14–03:38）；第二轮 P-34…P-38（06:56–07:05，补探 namespace 契约、entry id 缺陷、index-inject 下发、volatile-update 先例，并更正 P-30 段的工具限制误记）。

### P-26 自有 Client→Host namespace 不成立（U-1 否证）
- 出处：`<ASAR>\dsh-api-gateway\README.md:58`（`$mount()` "registers a **generated** Host-for-Client contribution"）；`:90-91`（"SRC markers have no Client type projection and are **not normal Client contribution inputs**"）；`<ASAR>\dsh-typert-protocol\README.md:118`（"Strict codecs carry generated schema factories; `src-json` codecs identify the weaker source-launch path"）。
- 旁证：官方 Client 程序集只 mount 生成物（`dsh-api-remotes/lib/client.js:28282-28321`，27 个 `TYPERT_REMOTE*`）；官方 UI 包的生成物入口（`dsh-client-ui-plugin-manager/package.json:27-35` `"./typert"`/`"./remote"`）；第三方模板/文档无生成链（skill `references/host-plugin.md:5-18`、`references/ui-plugin.md:1-13`）。
- 结论：bundle 无构建链 → **自有 namespace 不可用**；改走官方已挂载 namespace（P-27…P-30）。
- 时间：03:14–03:20。

### P-27 官方读通道：`session/events` 冷安全 + subagent address（U-1）
- 出处：`<ASAR>\dsh-api-remotes\lib\client.js:22451-22663`（`session/events` "cold-safe" 页读；`address` 支持 `{kind:'subagent',parentSessionId,childSessionId,mode:one-shot|continuable|unknown}`；返回 `records[].event{type,seq,time,data}`）；`dsh-api-session-controller/lib/index.js:1789-1798`（`events()`→`usingObservation`）；`:1924-1957`（`sessionQuery.observeSession` 冷读，不唤醒）；`:1154-1171`（`validateAddress`：origin/父校验、`mode:'unknown'` 免 mode 校验、descriptor 缺失/损坏独立错误码）；`:1195-1225`（`paginate` 默认 `maxMessages:50`）。
- 结论：`descriptor` 位于子日志**开头**（写入点 `dsh-subagent/lib/index.js:1806`、fold `:703-704`）。取法：先 `session/events`（不带 `throughSeq`）拿尾页与 `cursor`，再带 `throughSeq: min(cursor, 64)` 取首段事件（`throughSeq > cursor` 会 bad-request）；无需唤醒 Agent。
- 时间：03:20。

### P-28 官方读通道：投影与目录（U-1）
- 出处：`<ASAR>\dsh-api-remotes\lib\client.js:23629-23673`（`session/projections` 冷读全部 client-visible 投影）+ `dsh-api-session-controller/lib/index.js:1833-1868`（冷走 `usingObservation({projection:true})`）；`dsh-api-remotes/lib/client.js:22970-22987`（`session/modelCatalog`）+ `dsh-api-session-controller/lib/index.js:473-522`（`buildModelCatalog` 含 `reasoning.efforts/defaultEffort` 与 `failures[]`）。
- 结论：热/冷读「当前生效路由」与「全量目录 + 推理等级」均有官方端点；客户端面可用 `useProjection('modelSelection')`（`dsh-api-session-controller/lib/client.js:1554-1556` `faceOf`）。
- 时间：03:22。

### P-29 官方写通道：volatile Config + `settings.mutate`（U-6b / D18）
- 出处：`<ASAR>\dsh-settings\lib\index.js:501-537`（`write()` 只允许 volatile 路径；嵌套 `validatePaths` 逐段校验 `:513-523`；经 `configEditor.edit` 持久 `:508`；revision 冲突拒绝 `:511`）；`dsh-settings\README.md:12`（"Changes persist through the active profile's Cordis patch"）；`dsh-client-ui-settings\lib\client.js:1252-1301`（`ConfigForms.get(entryId)`）+ `:1165-1180`（`mutate`→`remote.settings.mutate`）；`cordis-plugin-loader\README.md:63` + `lib\index.js:553`（volatile-only 变更不重挂，emit `loader/volatile-update` 带路径）。
- 结论：**per-teammate 覆盖表**（嵌套 dict）与 `showSelector` 布尔都可作为本插件 Config 的 **volatile** 字段，由客户端 `ctx.configForms.get(entryId).mutate()` 写回，host 端 `config.overrides.get()` 读用。D18 能力面成立。
- 时间：03:30。

### P-30 U-6a：Settings 表单不会自动呈现普通 Config 字段
- 出处：`<ASAR>\dsh-settings\README.md:33`（"Forms expose **only volatile fields**"）+ `:39`（`autoGenerate` "no shipped client does so yet"）；`dsh-client-ui-settings-plugins\README.md:12`（每个官方插件的配置页 = 自带 companion package）+ `dsh-client-ui-settings\README.md:40`（同）；机检 `node probe-tools/asar-grep.mjs "<asar>" /dsh/node_modules/@deepseek-ai/ 'autoGenerate' 40 /lib/client.js` → 仅命中 schema 文本，无 Client UI 实现。
- 结论：`showSelector` 即使声明为 volatile，也不会出现在 Settings 自动表单；呈现位 = 插件自带开关（仍写 Config，Q2 存储语义满足）。见 `05-p1.5-probes.md` §5-R2。
- 时间：03:32。

### P-31 U-3 时序：`agent/created` 串行监听先于首 step
- 出处：`<ASAR>\dsh-agent\lib\index.js:703-718`（`announce()` 内 `await this.ctx.serial(entry.carrier,'agent/created',…)`）；`dsh-agent-loop\lib\index.js:1565-1593`（`initializeAgent` 把 announce 包在 `runMaintenance` 内）+ `:586-609`（maintenance 结束才回 idle/才 wake）+ `:618-622`（非 idle 时 wake 只置位不驱动）+ `:666-672`（首 step `preStep` 读 `model.current()`）；`dsh-agent\lib\index.js:190-203`（`current()`=pending??lastUsed??options；`select()` 同值 no-op、仅 `session.append('model/selection',…)`）+ `:152`（selection 事件即时进投影 pending）。
- 结论：**冷回填先于首 step 成立**（源码级）；A8 判定 2 可达。注意 `announce()` 契约 "a listener failure rejects"（`:698` + `agents` 服务契约）→ 监听器必须 try/catch（`05` §5-R4）。
- 时间：03:24。

### P-32 U-2 否证材料：官方冷继续要求 live parent；resume 有写副作用
- 出处：`<ASAR>\dsh-subagent\lib\index.js:2155-2210`（`coldResume` 全链）+ `:2171-2172`（`assertAdmitting(parent)`/`authorizeLineage(parent,…)`）；`dsh-agent-loop\lib\index.js:1710-1775`（`resume()` 全链）+ `:1739-1740`（`interruptedTurnClosers(persisted)` 非空则 `handle.append(closers)` —— 可能补写 `turn/end`）；`:1565-1593`（resume 期间 `sessions.announce`+`agents.announce`，注册 live agent）。
- 结论：root 身份对 subagent-origin 冷会话 resume 非官方用法，且自带「补写 turn/end」副作用，违反 U-2 自设判据 → **弃用路径 A，转路径 B（Q8）**。
- 时间：03:26。

### P-33 U-4/U-5 源码补强：composer 顶替规则与 locale 注入
- U-4：`<ASAR>\dsh-client-ui-subagent\lib\client.js:787-803`（子会话复用 Conversation）；`dsh-client-ui-conversation\lib\client.js:20583-20591`（`renderSlotChain("conversation.composer",…,{fallback:composerBar})` —— fallback 才含 `conversation.input.right`）+ `:22808-22815`（`conversation.composer`=chain / `conversation.composer.bar`=single）+ `:20592-20598`（`data-conversation-region="composer"` 容器锚点）；`dsh-client-ui-subagent\lib\client.js:1220-1228`（`selectReadOnlySubagent`：`unknown`/`one-shot`/父级离线 → 占位）+ `:1273-1278`（该只读 composer 以 `priority:-10`+`select` 注册到 `conversation.composer`，命中即顶替整条 chain）。
  - 结论：队友视图**普通 composer 挂载时** `conversation.input.right` 会渲染；`unknown`/one-shot/父级离线**不渲染**（官方只读 composer 顶替）→ D14「unknown 也渲染占位」不可实现，A16-1 的 `SLOT_CONTAINER` 建议 = `[data-conversation-region="composer"]`。
- U-5：`dsh-client-ui-subagent\lib\client.js:1213-1219`（`inject` 含 `locale`）+ `:1234-1243`（`ctx.locale.register(NS,{zh,en,…})`）；`dsh-client-locale\README.md:40`（P-22 API）；skill `references/ui-plugin.md:13`（"Route visible UI text through the Client locale service"）。
  - 结论：第三方 bundle 可注入并生效（源码/契约级）；无需 zh/en 硬编码降级。
- 时间：03:34–03:38。

### P-34 `Config.listConfigs` 按 entry 精查可用（更正上一轮误记）
- 命令与返回（本轮实测）：
  - `cordis_inspect_query(host, Config, listConfigs, input={"entry":"include:agent-default-model"})` → 返回该 entry 的完整 JSON Schema：`provider`/`model`/`reasoningEffort` 均带 `"x-cordis":{"volatile":true}`，`packageDir` 指向 app.asar 内包目录，`limitations: []`；
  - `input={"name":"@deepseek-ai/dsh-agent-default-model"}` → 返回 1 条（`include:agent-default-model`, status `schema`）；
  - `input={"name":"agent-default-model"}` → `{entries:[],total:0}`（**包名须写全名**）。
- 结论：上一轮「input 含 `-`/数字即被拒」**不成立**，属 Host 实例瞬时状态（该轮 GUI 端口 8314，本轮 6727，Host 已重启）。U-6b 结论不变。另：这条返回是「真实插件把 Config 声明为 volatile」的活证据，与 `dsh-settings/README.md:33` 互证。
- 时间：06:56。

### P-35 Client 侧拿不到 Loader entry id（写通道的实现级缺陷）
- 出处：`settings.describe()` 的 `ns` = `entry.options.id`（`<ASAR>\dsh-settings\lib\index.js:432,443,502`）；Client 可见的 boot graph 行 id = **包名**（`dsh-client-modules\lib\index.js:957-961` `graphRow(packageName,…)`/`table.set(packageName,…)`；Client 侧校验 `dsh-client-modules\lib\client.js:122-125` 只认 `row.id/url/rev`）；`node probe-tools/asar-grep.mjs "<asar>" /dsh/node_modules/@deepseek-ai/ 'fiber\.entry' 30 /lib/client.js` → **hits: 0**。
- 结论：`configForms.get(entryId)` 的 entryId **无法由 Client 自行推导**（包名 ≠ entry id，实测 entry id 形如 `include:agent-default-model`）。必须由 Host 半下发。
- 时间：07:02。

### P-36 官方下发通道：`webserver/index-inject` + `{kind:'global'}`
- 契约：`cordis_inspect_query(host, Event, listEvents, input={"event":"webserver/index-inject"})` → `mode: emit`，`(table: IndexInjection[], peer: PeerScope)`，`IndexInjection` 含 `{kind:'global', name, value}`，"Emitted on every index render … listeners push their current rows"。
- 普通插件最小用法（可照抄）：`<ASAR>\dsh-client-shortcuts\lib\index.js:13-21`（`apply(ctx,config)` 内 `ctx.on("webserver/index-inject",(table)=>{table.push({kind:'global',name:'__DSH_SHORTCUTS_CONFIG__',value:config})})`）；同款 `<ASAR>\dsh-client-ui-settings-models\lib\index.js:16-24`。
- 读侧：`<ASAR>\dsh-api-remote-access\lib\client.js:807` `Reflect.get(globalThis, KEY)`。
- Host 取自身 entry id：`<ASAR>\dsh-experimental-speech-to-text\lib\index.js:15-20`（`this.entryId = ctx.fiber.entry?.options.id`，注释 "Profile-local entry id used by Settings"）；`fiber.entry` 为 Loader 通用机制（`<ASAR>\cordis-plugin-loader\lib\index.js:742-772`）。
- 结论：P-35 的缺陷有官方解法——Host 半下发 `{entryId}`，Client 读 `globalThis`。**已写入 `05` §3 表与 M9**。
- 时间：07:05。

### P-37 `loader/volatile-update` 的官方 listener 先例（R1 降险）
- 出处（6 处，均为普通 Host 插件在本 ctx 监听）：`<ASAR>\dsh-experimental-speech-to-text\lib\index.js:21-23`；`<ASAR>\dsh-llm-deepseek\lib\index.js:2737-2748`（监听内**重读** `dependencies.options()` + `try/catch` + `deepEqualJson` 比对后再 `registration.replace`）；另见 `dsh-client-product-analytics\lib\index.js:331`、`dsh-llm-deepseek-api-key\lib\index.js:148`、`dsh-llm-pi-ai\lib\index.js:3000`、`dsh-plugin-market\lib\index.js:1115`。
- 结论：第三方插件监听该事件是官方常规用法，非特例；应照抄 `llm-deepseek` 的安全形态（重读 + try/catch + 比对后动作）。`05` §5-R1 风险由「中」下调为「低」。
- 时间：07:04。

### P-38 官方 Client 半以 `inject` 声明已挂载 namespace（补强 U-1 正证）
- 出处：`<ASAR>\dsh-client-ui-settings\lib\client.js:1481`（`const inject = ["remote","remote.settings"]`）；`dsh-client-ui-model-selection\lib\client.js:1998-2004`（`"remote.session"`）；`dsh-api-job-controller\lib\client.js:347`；共 30+ 处（`node probe-tools/asar-grep.mjs "<asar>" /dsh/node_modules/@deepseek-ai/ '"remote\.[a-zA-Z]+"' 30 /lib/client.js`）。
- 结论：第三方 Client 半 `inject:["remote","remote.settings","remote.session"]` 即可用官方 namespace；生成物只属于「把 Host 方法发布成 namespace」的一方，**不是消费者门槛**。
- 时间：07:00。

## 3. 约束合规记录

- 未安装任何插件/bundle（本阶段只读探测）。
- 未写入 `$DSH_HOME`；`02:22` 曾只读列出 `$DSH_PROFILE_DIR` 顶层目录名（未打开任何插件目录、未读写任何文件），随后未再触碰。
- 未读 `DshBundle\dsh-*` 等其他插件目录；客户需求/流程规格外的本地输入只有 DSH 安装包（官方源码/README）。
- 临时 asar 脚本写在 `%TEMP%`，工作区交付物只有本文件 + `01-requirements.md` + `02-plan.md`。
- **P1.5 轮**：未安装/未卸载任何 bundle；未改 `$DSH_HOME`；未读写任何其他插件目录；只读手段 = host `cordis_inspect_query`（Service/Event/Config）+ `app.asar` 只读读取（`probe-tools/` 4 个脚本）+ 包 README。客户端 `Slots.listSubTree` 再次超时（T-3），客户端结论全部降为源码级并如实标注。P1.5 交付物 = `05-p1.5-probes.md` + 本文件回填 + `probe-tools/`。

## 4. P1.5 探针门记录（已回填；详证见 `05-p1.5-probes.md`）

| U | 结论 | 出处 | 时间 |
|---|---|---|---|
| U-1 | **已验（源码/契约级）**：自有 `ctx.remote.<本服务>` 不成立（Client 只接受生成物 contribution）；官方 namespace/服务足够（读=`session/events`/`session/projections`/`session/modelCatalog`，写=`configForms`→`settings.mutate`，下发=`webserver/index-inject`，通知=`loader/volatile-update`）。第二轮补强：官方 Client 半以 `inject:["remote","remote.settings"]` 消费 namespace（P-38） | P-26…P-29、P-36…P-38；`<ASAR>\dsh-api-gateway\README.md:58,90-91`；`dsh-api-remotes\lib\client.js:28282-28321,22451-22663,23629-23673,22970-22987`；`dsh-api-session-controller\lib\index.js:1154-1171,1789-1798,1833-1868,1924-1957,473-522`；`dsh-client-ui-settings\lib\client.js:1252-1301,1165-1180,1481` | 03:14–07:05 |
| U-2 | **已定降级**（弃用路径 A，转路径 B/Q8）：官方冷继续要求 live parent，且 `resume` 会为未闭合回合补写 `turn/end`，违反 U-2 自身判据 | P-32；`<ASAR>\dsh-subagent\lib\index.js:2155-2210,2171-2172`；`dsh-agent-loop\lib\index.js:1710-1775,1739-1740`；`00-client-answers.md:6` | 03:26 |
| U-3 | **已验（源码级）**：`agent/created` 串行监听在 maintenance 相位内被 await，驱动唤醒被挂起，首 step 的 `model.current()` 在监听完成后读取；`select()` 同值 no-op | P-31；`<ASAR>\dsh-agent\lib\index.js:703-718,190-203,152`；`dsh-agent-loop\lib\index.js:1565-1593,586-609,618-622,666-672` | 03:24 |
| U-4 | **已定降级（契约已验 + 范围收窄）**：队友子会话复用同一 Conversation，普通 composer 挂载时 slot 渲染；`unknown`/one-shot/父级离线时官方只读 composer 顶替整条 chain，slot 不渲染（与 01 §3-13 一致） | P-33；`<ASAR>\dsh-client-ui-subagent\lib\client.js:787-803,1220-1228,1273-1278`；`dsh-client-ui-conversation\lib\client.js:20583-20598,22808-22815`；P-4 的 slot 目录 | 03:34–03:38 |
| U-5 | **已验（源码/契约级）**：`locale` 是官方 Client 服务，第三方 bundle 以 `inject:['locale']` + `ctx.locale.register/bind` 使用 | P-33；`<ASAR>\dsh-client-ui-subagent\lib\client.js:1213-1219,1234-1243`；`dsh-client-locale\README.md:40` | 03:34–03:38 |
| U-6 | **6a 已定降级**（Settings 不自动呈现普通 Config 字段，开关需插件自带 UI）；**6b 已验（源码级）**（volatile 嵌套表经 `settings.mutate` 写回、持久、重启保持）。第二轮：`Config.listConfigs {"entry":"include:agent-default-model"}` 返回真 schema，三字段带 `x-cordis.volatile`（P-34），并更正上一轮的误记工具限制 | P-29/P-30/P-34；`<ASAR>\dsh-settings\lib\index.js:501-537`；`dsh-settings\README.md:12,33,39`；`dsh-client-ui-settings-plugins\README.md:12`；`cordis-plugin-loader\README.md:63`、`lib\index.js:553` | 03:30–07:00 |
| U-7 | **已定降级（不需要）**：官方通道已覆盖读写，不再启用 HTTP 路由；同源 fetch/鉴权未实测（不装探针） | P-26/P-28；`webServer` 契约（inspect）；`<ASAR>\dsh-api-remote-access\README.md:86` | 03:30 |

（探测方式与清零判据见 `02-plan.md` §3.5；详细证据链、运行时缺口与「能否进 P2」结论见 `05-p1.5-probes.md`。）
