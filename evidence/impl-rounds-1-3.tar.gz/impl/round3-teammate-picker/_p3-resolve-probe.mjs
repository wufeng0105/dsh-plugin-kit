// P3: why does loadSchemastery() fail inside a simulated profile install?
const from = process.argv[2]; // directory to resolve from
import('node:module').then(async ({ createRequire }) => {
  const req = createRequire(from + '/probe.cjs');
  try {
    const resolved = req.resolve('@deepseek-ai/schemastery');
    console.log('require.resolve ->', resolved);
  } catch (e) {
    console.log('require.resolve FAILED:', e.code, '|', String(e.message).split('\n')[0]);
  }
  try {
    const m = await import('@deepseek-ai/schemastery');
    console.log('dynamic import -> ok, keys:', Object.keys(m).slice(0, 5));
  } catch (e) {
    console.log('dynamic import FAILED:', e.code, '|', String(e.message).split('\n')[0]);
  }
});
