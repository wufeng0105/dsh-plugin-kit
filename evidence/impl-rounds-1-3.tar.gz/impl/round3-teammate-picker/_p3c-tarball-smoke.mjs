/**
 * M-3 smoke test: unpack the real `npm pack` tarball and load its entry point
 * the way a profile would, with NO dependency set present.
 *
 * The failure this pins (08-verification.md §3.4 / M-3): `index.js` hard-imports
 * `./lib/schema.js`, so a tarball whose `files[]` omits it dies with
 * ERR_MODULE_NOT_FOUND at import time — before any plugin code runs.
 *
 * Usage: node _p3c-tarball-smoke.mjs <tarball.tgz> <unpackDir>
 */
import { execFileSync } from 'node:child_process';
import { existsSync, readdirSync, statSync } from 'node:fs';
import { mkdir, rm } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const [tarball, unpackDir] = process.argv.slice(2);
if (!tarball || !unpackDir) {
  console.error('usage: node _p3c-tarball-smoke.mjs <tarball.tgz> <unpackDir>');
  process.exit(2);
}

const out = resolve(unpackDir);
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });

// `tar` ships with Windows 10+ and with Git; use it rather than adding a dep.
execFileSync('tar', ['-xzf', resolve(tarball), '-C', out], { stdio: 'inherit' });

const root = join(out, 'package');
if (!existsSync(root)) {
  console.error('FAIL: tarball has no package/ directory');
  process.exit(3);
}

/** Recursively list files under a directory, relative to it. */
function walk(dir, prefix = '') {
  const rows = [];
  for (const name of readdirSync(dir).sort()) {
    const full = join(dir, name);
    const rel = prefix === '' ? name : `${prefix}/${name}`;
    if (statSync(full).isDirectory()) rows.push(...walk(full, rel));
    else rows.push(rel);
  }
  return rows;
}

const shipped = walk(root);
console.log(`tarball files (${shipped.length}):`);
for (const file of shipped) console.log(`  ${file}`);

const REQUIRED = ['index.js', 'client.js', 'lib/core.js', 'lib/host.js', 'lib/schema.js', 'cordis.patch.yml'];
const missing = REQUIRED.filter((file) => !shipped.includes(file));
console.log('required present:', missing.length === 0 ? 'yes' : `NO -> missing ${missing.join(', ')}`);

// Load it exactly as a profile would: no node_modules, so any bare specifier the
// entry point needs at import time would surface here as a failure.
const entry = join(root, 'index.js');
let verdict;
try {
  const mod = await import(pathToFileURL(entry).href);
  const configState = mod.Config === undefined ? 'undefined (DEGRADED)' : `schema (${typeof mod.Config})`;
  const hasApply = typeof mod.apply === 'function';
  verdict = {
    ok: missing.length === 0 && hasApply,
    exports: Object.keys(mod),
    config: configState,
    apply: hasApply,
  };
  console.log(`IMPORT OK   exports=${JSON.stringify(verdict.exports)}`);
  console.log(`Config    = ${configState}`);
  console.log(`apply()   = ${hasApply ? 'function' : 'MISSING'}`);
} catch (error) {
  console.log(`IMPORT FAIL ${error.code ?? ''} | ${String(error.message).split('\n')[0]}`);
  verdict = { ok: false, error: error.code ?? 'unknown' };
}

console.log(`SMOKE: ${verdict.ok && missing.length === 0 ? 'PASS' : 'FAIL'}`);
process.exit(verdict.ok && missing.length === 0 ? 0 : 1);
