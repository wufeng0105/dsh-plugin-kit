# 负责人裁定 v2（针对 08-verification.md 的两个 BLOCKER）

> 前提说明：上一轮我按实现者建议裁定 A7 为「写入即定、唤醒即用」。验证者用官方 projection 重放证明该裁定不可达。**裁定作废，由验证证据为准。**

## B-1｜A7「恢复派发路由」不可达

**推翻原裁定。** 事实链（验证者证据）：
- `dsh-agent/lib/index.js:157-162` 把 lastUsed 记成覆盖路由
- `current() = pending ?? lastUsed ?? options`（`:190-203`）
- 只要队友在覆盖路由下跑过一回合，删表后 resume 仍返回覆盖路由

**二选一，由客户拍板**：

| 方案 | 做法 | 代价 |
|---|---|---|
| **B-1a（推荐）** | 降级需求：把 A7 改成「恢复 = 写回派发时的路由并生效」，即主动写 `model/selection` 事件把路由改回 descriptor 值，而不是删表 | 会写一条官方事件；A7 判据从"表中不存在"改成"实际路由回到 descriptor" |
| B-1b | 走豁免：接受"恢复功能不可达"，从验收里删掉 A7，界面标注不可用 | 功能缺失 |

**客户裁定 = B-1a。** 理由：需求里「恢复派发路由」是用户可见功能，不能删；写一条官方 `model/selection` 是宿主允许的合规动作（不新增事件类型、不改官方包）。

## B-2｜`Config` 恒 undefined

**要求按验证者的具体修法**：`lib/schema.js` 把 `typeof namespace === 'object'` 的类型判断修正为同时接受 function（schemastery 的 default 是 function）。修完后必须用验证者那三种安装形态（软链/拷贝/依赖缺失）各验一次，且 `Config !== undefined`。

## 其余 4 条 MAJOR 全修
- M-1：A6 热应用补兜底（`loader/volatile-update` 之外，按 `practices.md:16` 用不拥有决策必须 `return next()` 的挂点，或接受"当前回合报错"并写进已知限制+界面提示）
- M-2：R4 保护移到最外层，`return undefined` 放进 `finally`，catch 里的 logger 调用本身要 try/catch
- M-3：`files[]` 补 `lib/schema.js`，并实际 `npm pack` 后从 tarball 安装验证起得来
- M-4：Client 面 `modelCatalog`/`session/events`/`mutate`/`showSelector`/`restore` 要么实现，要么在文档里如实标"未实现"（不许写"结构上已就位"）

## 关于「最易误解」自述的三点表态（验证者立场，采纳）

1. 恢复=删条目：同意（已实证无写回退化路径）——但按 B-1a 后这条要改。
2. "Config 为 undefined 不是 bug"：**实现者的结论和归因都错**，采纳验证者的更正。
3. R4 判据：采纳验证者的"`return undefined` 不在 finally 就不算"，不接受"方法对但判据松"。
