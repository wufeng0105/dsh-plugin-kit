// P3: dump the real schema document produced by the shipped schema.js builder.
import { createConfigSchema } from './bundle/lib/schema.js';

const real = await import('file:///C:/Users/Administrator/.dsh/profiles/desktop/node_modules/@deepseek-ai/schemastery/lib/index.mjs');
const z = real.default ?? real;
const schema = createConfigSchema(z);
const json = schema.toJSON();
console.log(JSON.stringify(json, null, 2));
console.log('--- normalized: refs map ---');
const refs = json.refs ?? json.$refs ?? {};
console.log('refs keys:', Object.keys(refs));
for (const [id, node] of Object.entries(refs)) {
  console.log(id, '=>', JSON.stringify(node));
}
const rootId = json.ref ?? json.$ref;
console.log('root ref:', rootId);
const rootNode = refs[rootId];
console.log('root dict:', JSON.stringify(rootNode?.dict));
const look = (v) => (typeof v === 'string' ? refs[v] : v);
if (rootNode?.dict) {
  for (const [key, value] of Object.entries(rootNode.dict)) {
    const node = look(value);
    console.log(`field ${key}: type=${node?.type} volatile=${node?.meta?.volatile === true} node=${JSON.stringify(node)}`);
  }
}
