// P3b read-only probe: list an asar directory entry (files only, depth limited).
// Usage: node _p3b-asar-ls.mjs <asarPath> <innerDir> [depth]
import { open } from 'node:fs/promises';

const [asarPath, innerDir = '', depthArg = '1'] = process.argv.slice(2);
const depth = Number(depthArg);

const handle = await open(asarPath, 'r');
try {
  const sizeBuf = Buffer.alloc(8);
  await handle.read(sizeBuf, 0, 8, 0);
  const headerSize = sizeBuf.readUInt32LE(4);
  const headerPickle = Buffer.alloc(headerSize);
  await handle.read(headerPickle, 0, headerSize, 8);
  const jsonLength = headerPickle.readUInt32LE(4);
  const json = JSON.parse(headerPickle.subarray(8, 8 + jsonLength).toString('utf8'));

  let node = json;
  for (const part of innerDir.replace(/\\/g, '/').split('/').filter(Boolean)) {
    node = node?.files?.[part];
    if (!node) {
      console.error('not found at', part);
      process.exit(3);
    }
  }
  const walk = (n, path, level) => {
    if (!n.files) return;
    for (const [name, child] of Object.entries(n.files)) {
      const full = `${path}/${name}`;
      console.log(child.files ? `${full}/` : `${full}  ${child.size}`);
      if (child.files && level > 1) walk(child, full, level - 1);
    }
  };
  walk(node, innerDir.replace(/\\/g, '/').replace(/\/+$/, ''), depth);
} finally {
  await handle.close();
}
