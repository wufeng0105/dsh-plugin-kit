// P3 independent re-run of the Config schema claim (read-only).
// Loads the schemastery shipped in the ASAR-adjacent profile node_modules and
// the *actual* bundle/lib/schema.js builder, not a re-typed copy.
import { createConfigSchema, loadSchemastery, CONFIG_SPEC } from './bundle/lib/schema.js';

const loaded = await loadSchemastery();
console.log('loadSchemastery() from bundle/ ->', loaded === null ? 'null (package not resolvable here)' : 'namespace object');

// Feed the exact same builder the real namespace obtained from the profile.
const real = await import('file:///C:/Users/Administrator/.dsh/profiles/desktop/node_modules/@deepseek-ai/schemastery/lib/index.mjs');
const z = real.default ?? real;
const schema = createConfigSchema(z);
const json = schema.toJSON();
console.log('toJSON type:', json?.type);

const nodes = [];
const walk = (node, path) => {
  if (node === null || typeof node !== 'object') return;
  if (node.meta && node.meta.volatile === true) nodes.push(path.join('.') || '<root>');
  for (const [key, value] of Object.entries(node)) walk(value, [...path, key]);
};
walk(json, []);
console.log('volatile node paths found (by walk):', JSON.stringify(nodes));

// Resolve the two declared fields by following the root dict, so this proves
// the *fields'* nodes are volatile rather than counting unrelated metadata.
const root = json;
console.log('root dict keys:', Object.keys(root.dict ?? {}));
const resolve = (dict, key) => (dict && Object.hasOwn(dict, key) ? dict[key] : undefined);
const deref = (nodeOrId) => (typeof nodeOrId === 'string' ? root[nodeOrId] : nodeOrId);
const showNode = deref(resolve(root.dict, 'showSelector'));
const overNode = deref(resolve(root.dict, 'overrides'));
console.log('showSelector node:', JSON.stringify(showNode));
console.log('overrides node (truncated):', JSON.stringify(overNode).slice(0, 300));
console.log('showSelector volatile:', showNode?.meta?.volatile === true);
console.log('overrides volatile:', overNode?.meta?.volatile === true);
console.log('overrides sKey/inner:', overNode?.type, 'sKey=', overNode?.sKey, 'inner=', overNode?.inner);
console.log('CONFIG_SPEC names:', CONFIG_SPEC.map((f) => f.name).join(','));

// Negative control: a schema built the way a reviewer might assume works but
// that does NOT mark the nested dict volatile, to show the detector can fail.
const bad = z.object({ overrides: z.dict(z.object({ provider: z.string(), model: z.string() })).default({}) });
const badJson = bad.toJSON();
const badOverrides = deref2(badJson, 'overrides');
function deref2(j, key) {
  const id = j.dict?.[key];
  return typeof id === 'string' ? j[id] : id;
}
console.log('negative control, overrides volatile:', badOverrides?.meta?.volatile === true);
