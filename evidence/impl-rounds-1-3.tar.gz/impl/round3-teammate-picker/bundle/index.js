/**
 * Host entry point for the teammate model picker.
 *
 * The module exports the two forms the Loader accepts together: `apply(ctx,
 * config)` plus the static `Config` schema. The Config is loaded lazily so a
 * missing schemastery package degrades to "no Config surface" instead of
 * failing the whole plugin — the Client then reports settings as unavailable
 * rather than pretending to save.
 */

import { createPlugin } from './lib/host.js';
import { createConfigSchema, loadSchemastery } from './lib/schema.js';

const schemastery = await loadSchemastery();

/** The plugin Config schema, or `undefined` when schemastery is unavailable. */
export const Config = schemastery === null ? undefined : createConfigSchema(schemastery);

/**
 * Mount the Host half.
 *
 * @param {object} ctx the Cordis context owning this plugin row
 * @param {object} config the parsed config; volatile fields are references with `.get()`
 */
export function apply(ctx, config) {
  createPlugin(ctx, config);
}
