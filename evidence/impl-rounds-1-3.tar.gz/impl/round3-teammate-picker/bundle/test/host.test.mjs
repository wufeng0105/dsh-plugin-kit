/**
 * Tests for the Host half's wiring: listeners, failure containment, and the
 * entry-id publication.
 *
 * A fake Cordis context stands in for the real one. That is the point of the
 * split: `lib/host.js` touches only `ctx.on`, `ctx.logger`, `ctx.fiber` and
 * `ctx.agents`, so the two behaviours that matter most — "a throwing listener
 * must not fail the resume" and "an unchanged table must not act" — are
 * provable offline.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { createPlugin, createWakeUpBridge, entryIdOf, indexInjections } from '../lib/host.js';
import { ENTRY_GLOBAL } from '../lib/core.js';

const CHILD = 'sess-child-1';
const CHOSEN = { provider: 'deepseek', model: 'deepseek-reasoner', reasoningEffort: 'high' };
const DISPATCH = { provider: 'deepseek', model: 'deepseek-chat' };

/** A context that records listeners and exposes the live agents the bridge sees. */
function fakeContext({ entryId = 'teammate-picker', liveAgents = [], loaderMounted = true } = {}) {
  const listeners = new Map();
  const ctx = {
    listeners,
    warnings: [],
    liveAgents,
    fiber: loaderMounted ? { entry: { options: { id: entryId } } } : {},
    logger: {
      warn: (...args) => ctx.warnings.push(args.map(String).join(' ')),
      debug: () => {},
    },
    agents: { list: () => ctx.liveAgents },
    on(event, listener) {
      if (!listeners.has(event)) listeners.set(event, []);
      listeners.get(event).push(listener);
    },
  };
  return ctx;
}

/**
 * A Config whose volatile fields answer `.get()` from mutable state, so a test
 * can change the value and then fire `loader/volatile-update` the way the
 * Loader does.
 */
function fakeConfig({ overrides = {}, showSelector = true } = {}) {
  const state = { overrides, showSelector };
  return {
    state,
    showSelector: { get: () => state.showSelector },
    overrides: { get: () => state.overrides },
  };
}

/** A live agent whose `model.select` records calls. */
function fakeAgent(id, { current = null, throwsOnSelect = false, options = null, header = { origin: 'subagent' } } = {}) {
  const selected = [];
  const agent = {
    id,
    selected,
    session: { header },
    model: {
      // The real AgentModel keeps the AgentOptions it was built with; for a
      // teammate those are the descriptor triple (`dsh-subagent:2186-2190`).
      options: options ?? undefined,
      current: () => current,
      select: (route) => {
        if (throwsOnSelect) throw new Error('adapter rejected the route');
        selected.push(route);
        // `AgentModel.select()` appends `model/selection`, and the projection
        // then answers `current()` with that pending value.
        agent.model.currentValue = route;
      },
      currentValue: current,
    },
  };
  agent.model.current = () => agent.model.currentValue;
  return agent;
}

/** A mainline agent: same facade, but the official header has no subagent origin. */
function fakeMainlineAgent(id, options) {
  return fakeAgent(id, { options, header: { id } });
}

/** Fire one recorded event and return what the listener produced. */
function emit(ctx, event, payload, ...rest) {
  return (ctx.listeners.get(event) ?? []).map((listener) => listener(payload, ...rest));
}

const INDEX_INJECT = 'webserver/index-inject';
const AGENT_CREATED = 'agent/created';
const PRE_STEP = 'agent/pre-step';
const VOLATILE_UPDATE = 'loader/volatile-update';

// ---------------------------------------------------------------------------
// entry-id publication (M9)
// ---------------------------------------------------------------------------

test('entryIdOf reads the Loader entry id and tolerates a non-Loader mount', () => {
  assert.equal(entryIdOf(fakeContext()), 'teammate-picker');
  assert.equal(entryIdOf(fakeContext({ loaderMounted: false })), undefined);
  assert.equal(entryIdOf({}), undefined);
  assert.equal(entryIdOf({ fiber: { entry: { options: { id: '' } } } }), undefined);
});

test('indexInjections publishes exactly one global row under the documented key', () => {
  assert.deepEqual(indexInjections('teammate-picker'), [
    { kind: 'global', name: ENTRY_GLOBAL, value: { entryId: 'teammate-picker' } },
  ]);
  assert.deepEqual(indexInjections(undefined), [{ kind: 'global', name: ENTRY_GLOBAL, value: { entryId: null } }]);
  assert.equal(ENTRY_GLOBAL, '__DSH_TEAMMATE_PICKER__');
});

test('the index-inject listener appends its row to the emitted table', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig());
  const table = [];
  emit(ctx, INDEX_INJECT, table);
  assert.equal(table.length, 1);
  assert.equal(table[0].name, ENTRY_GLOBAL);
  assert.equal(table[0].value.entryId, 'teammate-picker');
});

test('the index-inject listener does not throw on a malformed table', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig());
  for (const bad of [null, undefined, 'table', 42]) {
    assert.doesNotThrow(() => emit(ctx, INDEX_INJECT, bad), `table ${String(bad)}`);
  }
});

test('a non-Loader mount warns once and publishes a null entry id', () => {
  const ctx = fakeContext({ loaderMounted: false });
  createPlugin(ctx, fakeConfig());
  assert.equal(ctx.warnings.length, 1);
  assert.match(ctx.warnings[0], /without a Loader entry id/);
  const table = [];
  emit(ctx, INDEX_INJECT, table);
  assert.deepEqual(table[0].value, { entryId: null });
});

// ---------------------------------------------------------------------------
// agent/created: the cold wake-up path
// ---------------------------------------------------------------------------

test('createPlugin registers exactly the four documented listeners', () => {
  const ctx = fakeContext();
  const plugin = createPlugin(ctx, fakeConfig());
  assert.deepEqual(plugin.listeners, [INDEX_INJECT, AGENT_CREATED, PRE_STEP, VOLATILE_UPDATE]);
  assert.deepEqual([...ctx.listeners.keys()].sort(), [AGENT_CREATED, INDEX_INJECT, PRE_STEP, VOLATILE_UPDATE].sort());
  for (const [event, list] of ctx.listeners) assert.equal(list.length, 1, `${event} must have one listener`);
});

test('agent/created applies the override to the newly created teammate', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = fakeAgent(CHILD);
  const results = emit(ctx, AGENT_CREATED, { agent, source: 'resume' });
  assert.deepEqual(agent.selected, [CHOSEN]);
  assert.deepEqual(results, [undefined], 'the serial listener must resolve with undefined');
});

test('agent/created leaves every other session untouched (zero intervention)', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { 'someone-else': CHOSEN } }));
  const mainline = fakeAgent('sess-mainline');
  const results = emit(ctx, AGENT_CREATED, { agent: mainline, source: 'startup' });
  assert.deepEqual(mainline.selected, []);
  assert.deepEqual(results, [undefined]);
});

test('agent/created skips a select() when the teammate already carries the override', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = fakeAgent(CHILD, { current: CHOSEN });
  emit(ctx, AGENT_CREATED, { agent, source: 'resume' });
  assert.deepEqual(agent.selected, [], 'an equal selection would be a no-op anyway; do not even ask');
});

// R4 (hard requirement, client answer 2 line 7): the listener must never reject.
test('agent/created contains a throwing model.select and still resolves', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = fakeAgent(CHILD, { throwsOnSelect: true });
  let results;
  assert.doesNotThrow(() => {
    results = emit(ctx, AGENT_CREATED, { agent, source: 'resume' });
  });
  assert.deepEqual(results, [undefined], 'a rejection here would fail announce() and the resume itself');
  assert.equal(ctx.warnings.length, 1);
  assert.match(ctx.warnings[0], /agent\.model\.select\(\) failed/);
});

test('agent/created contains a throwing config read and still resolves', () => {
  const ctx = fakeContext();
  createPlugin(ctx, { overrides: { get() { throw new Error('volatile reference is gone'); } } });
  ctx.warnings.length = 0; // drop the construction-time seed warning
  assert.doesNotThrow(() => emit(ctx, AGENT_CREATED, { agent: fakeAgent(CHILD), source: 'resume' }));
  assert.equal(ctx.warnings.length, 1);
  assert.match(ctx.warnings[0], /reading the override table failed/);
});

test('agent/created contains a throwing agent.model.current()', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = {
    id: CHILD,
    model: {
      current: () => { throw new Error('projection not ready'); },
      select: () => { throw new Error('must not be reached with an unreadable current'); },
    },
  };
  assert.doesNotThrow(() => emit(ctx, AGENT_CREATED, { agent, source: 'resume' }));
  // Two contained failures: the unreadable current(), then the select() the
  // fallback plan attempted — both logged, neither escapes.
  assert.equal(ctx.warnings.length, 2);
  assert.match(ctx.warnings[0], /agent\.model\.current\(\) failed/);
  assert.match(ctx.warnings[1], /agent\.model\.select\(\) failed/);
});

test('agent/created survives a malformed payload', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  for (const payload of [undefined, null, {}, { agent: null }, { agent: {} }, { agent: { id: '' } }]) {
    assert.doesNotThrow(() => emit(ctx, AGENT_CREATED, payload), `payload ${JSON.stringify(payload)}`);
  }
});

// ---------------------------------------------------------------------------
// R4, second half (M-2): a throwing LOG must not escape either
// ---------------------------------------------------------------------------

/** A context whose logger throws, the way a broken log sink does. */
function ctxWithThrowingLogger({ liveAgents = [] } = {}) {
  const ctx = fakeContext({ liveAgents });
  const explosions = [];
  ctx.logger = {
    warn: () => { explosions.push(1); throw new Error('logger sink exploded'); },
    debug: () => {},
  };
  ctx.explosions = explosions;
  return ctx;
}

test('the agent/created listener resolves even when the logger itself throws (M-2)', () => {
  const ctx = ctxWithThrowingLogger();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = fakeAgent(CHILD, { throwsOnSelect: true });
  let results;
  assert.doesNotThrow(() => { results = emit(ctx, AGENT_CREATED, { agent, source: 'resume' }); },
    'a throwing log sink inside the catch used to reject announce() and fail the wake-up');
  assert.deepEqual(results, [undefined]);
  assert.ok(ctx.explosions.length > 0, 'the fixture must really have thrown from the logger');
});

test('the loader/volatile-update listener resolves even when the logger throws (M-2)', () => {
  const ctx = ctxWithThrowingLogger();
  const config = fakeConfig({ overrides: {} });
  createPlugin(ctx, config);
  ctx.agents.list = () => { throw new Error('registry disposed'); };
  config.state.overrides = { [CHILD]: CHOSEN };
  let results;
  assert.doesNotThrow(() => { results = emit(ctx, VOLATILE_UPDATE, [['overrides']]); });
  assert.deepEqual(results, [undefined]);
});

test('the bridge itself never throws through a broken log sink (M-2, direct callers)', () => {
  // The listener-level `finally` already keeps `announce()` alive; this covers
  // the callers that have no such safety net — another plugin holding the
  // bridge, or a future wiring that calls `applyToAgent` from its own try-less
  // path. There, `warnSafely` is the only containment.
  const bridge = createWakeUpBridge({
    readTable: () => ({ [CHILD]: CHOSEN }),
    listAgents: () => [],
    logger: { warn() { throw new Error('logger sink exploded'); }, debug() {} },
  });
  const agent = fakeAgent(CHILD, { throwsOnSelect: true });
  assert.doesNotThrow(() => bridge.applyToAgent(agent), 'a throwing log inside the catch must not escape the bridge');
  assert.doesNotThrow(() => bridge.applyPreStep(agent, DISPATCH));
  assert.doesNotThrow(() => bridge.restoreAgent(agent));

  const explodingConfig = createWakeUpBridge({
    readTable: () => { throw new Error('volatile ref gone'); },
    logger: { warn() { throw new Error('logger sink exploded'); }, debug() {} },
  });
  assert.doesNotThrow(() => explodingConfig.refresh());
});

test('agent/created ignores an agent that has no model facade', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  assert.doesNotThrow(() => emit(ctx, AGENT_CREATED, { agent: { id: CHILD }, source: 'resume' }));
});

// ---------------------------------------------------------------------------
// loader/volatile-update: the hot path
// ---------------------------------------------------------------------------

test('volatile-update applies a changed override to the live teammate', () => {
  const agent = fakeAgent(CHILD);
  const config = fakeConfig({ overrides: {} });
  const ctx = fakeContext({ liveAgents: [agent] });
  createPlugin(ctx, config);

  config.state.overrides = { [CHILD]: CHOSEN };
  const results = emit(ctx, VOLATILE_UPDATE, [['overrides']]);
  assert.deepEqual(agent.selected, [CHOSEN]);
  assert.deepEqual(results, [undefined]);
});

test('volatile-update does not act when the table is unchanged (showSelector-only edit)', () => {
  const agent = fakeAgent(CHILD);
  const config = fakeConfig({ overrides: { [CHILD]: CHOSEN } });
  const ctx = fakeContext({ liveAgents: [agent] });
  createPlugin(ctx, config, {});

  config.state.showSelector = false;
  emit(ctx, VOLATILE_UPDATE, [['showSelector']]);
  assert.deepEqual(agent.selected, [], 'a display switch edit must not touch the route');
});

test('volatile-update does not re-apply the same table twice', () => {
  const agent = fakeAgent(CHILD);
  const config = fakeConfig({ overrides: {} });
  const ctx = fakeContext({ liveAgents: [agent] });
  createPlugin(ctx, config);

  config.state.overrides = { [CHILD]: CHOSEN };
  emit(ctx, VOLATILE_UPDATE, [['overrides']]);
  emit(ctx, VOLATILE_UPDATE, [['overrides']]);
  assert.equal(agent.selected.length, 1, 'the second event carries an identical table');
});

test('volatile-update applies to each live teammate independently', () => {
  const a = fakeAgent('child-a');
  const b = fakeAgent('child-b');
  const config = fakeConfig({ overrides: { 'child-a': DISPATCH } });
  const ctx = fakeContext({ liveAgents: [a, b] });
  createPlugin(ctx, config);

  config.state.overrides = { 'child-a': DISPATCH, 'child-b': CHOSEN };
  emit(ctx, VOLATILE_UPDATE, [['overrides']]);
  assert.deepEqual(a.selected, [], 'child-a kept its previous override');
  assert.deepEqual(b.selected, [CHOSEN]);
});

test('volatile-update restores the dispatch route when an override row is removed', () => {
  const agent = fakeAgent(CHILD, { current: CHOSEN, options: DISPATCH });
  const config = fakeConfig({ overrides: { [CHILD]: CHOSEN } });
  const ctx = fakeContext({ liveAgents: [agent] });
  createPlugin(ctx, config);

  config.state.overrides = {};
  emit(ctx, VOLATILE_UPDATE, [['overrides']]);
  assert.deepEqual(agent.selected, [DISPATCH], 'a restore must write the dispatch route back (B-1)');
});

test('a cold restore is completed on the next wake-up (B-1, A7 decision 1)', () => {
  // The row was deleted while the teammate was not live: the persisted log still
  // ends with `request/header` = the old override, so `current()` is the override.
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: {} }));
  const agent = fakeAgent(CHILD, { current: CHOSEN, options: DISPATCH });
  emit(ctx, AGENT_CREATED, { agent, source: 'resume' });
  assert.deepEqual(agent.selected, [DISPATCH]);
});

test('a teammate already on its dispatch route is not touched on wake-up', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: {} }));
  const agent = fakeAgent(CHILD, { current: DISPATCH, options: DISPATCH });
  emit(ctx, AGENT_CREATED, { agent, source: 'resume' });
  assert.deepEqual(agent.selected, [], 'no restore is needed, so nothing is written (A9)');
});

test('the restore path never touches a mainline session (A9/A12)', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: {} }));
  const mainline = fakeMainlineAgent('sess-main', DISPATCH);
  mainline.model.currentValue = CHOSEN;
  emit(ctx, AGENT_CREATED, { agent: mainline, source: 'startup' });
  assert.deepEqual(mainline.selected, [], 'a mainline session has model.options too; the header gate must hold');
});

// ---------------------------------------------------------------------------
// agent/pre-step: the mid-turn fallback (M-1)
// ---------------------------------------------------------------------------

test('agent/pre-step applies an override the step has not picked up and continues the chain', async () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = fakeAgent(CHILD, { current: DISPATCH, options: DISPATCH });
  const decision = { kind: 'enter', messages: [] };
  const next = async () => decision;
  const [result] = await Promise.all(emit(ctx, PRE_STEP, { agent, modelSelection: DISPATCH }, next));
  assert.deepEqual(agent.selected, [CHOSEN], 'the next step must move to the override route');
  assert.equal(result, decision, 'the listener does not own the decision: it returns next() verbatim');
});

test('agent/pre-step is a pure pass-through when the step already carries the override', () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = fakeAgent(CHILD, { current: CHOSEN, options: DISPATCH });
  const decision = { kind: 'enter', messages: [] };
  const listener = ctx.listeners.get(PRE_STEP)[0];
  const result = listener({ agent, modelSelection: CHOSEN }, () => decision);
  assert.deepEqual(agent.selected, []);
  return Promise.resolve(result).then((value) => assert.equal(value, decision));
});

test('agent/pre-step still continues the chain when its own application throws', async () => {
  const ctx = fakeContext();
  createPlugin(ctx, fakeConfig({ overrides: { [CHILD]: CHOSEN } }));
  const agent = { id: CHILD, model: { current: () => null, get select() { throw new Error('facade detached'); } } };
  const decision = { kind: 'enter', messages: [] };
  const [result] = await Promise.all(emit(ctx, PRE_STEP, { agent, modelSelection: DISPATCH }, async () => decision));
  assert.equal(result, decision, 'practices.md:16 — a listener that does not own the decision must return next()');
});

test('volatile-update sees an override added while no teammate is live and stores the baseline', () => {
  const config = fakeConfig({ overrides: {} });
  const ctx = fakeContext({ liveAgents: [] });
  const plugin = createPlugin(ctx, config);

  config.state.overrides = { [CHILD]: CHOSEN };
  emit(ctx, VOLATILE_UPDATE, [['overrides']]);
  assert.deepEqual(plugin.bridge.appliedTable(), { [CHILD]: CHOSEN });

  // The teammate wakes later and picks the override up through `agent/created`.
  const agent = fakeAgent(CHILD);
  ctx.liveAgents = [agent];
  emit(ctx, AGENT_CREATED, { agent, source: 'resume' });
  assert.deepEqual(agent.selected, [CHOSEN]);
});

test('volatile-update contains a throwing agent list and still resolves', () => {
  const config = fakeConfig({ overrides: {} });
  const ctx = fakeContext();
  createPlugin(ctx, config);
  ctx.agents.list = () => { throw new Error('registry disposed'); };

  config.state.overrides = { [CHILD]: CHOSEN };
  let results;
  assert.doesNotThrow(() => { results = emit(ctx, VOLATILE_UPDATE, [['overrides']]); });
  assert.deepEqual(results, [undefined]);
  assert.equal(ctx.warnings.length, 1);
  assert.match(ctx.warnings[0], /listing live agents failed/);
});

test('volatile-update contains a throwing model.select on the hot path', () => {
  const agent = fakeAgent(CHILD, { throwsOnSelect: true });
  const config = fakeConfig({ overrides: {} });
  const ctx = fakeContext({ liveAgents: [agent] });
  createPlugin(ctx, config);

  config.state.overrides = { [CHILD]: CHOSEN };
  assert.doesNotThrow(() => emit(ctx, VOLATILE_UPDATE, [['overrides']]));
  assert.equal(ctx.warnings.length, 1);
  assert.match(ctx.warnings[0], /agent\.model\.select\(\) failed/);
});

// ---------------------------------------------------------------------------
// the bridge as a unit
// ---------------------------------------------------------------------------

test('createWakeUpBridge needs a reader and seeds its baseline without acting', () => {
  assert.throws(() => createWakeUpBridge({}), TypeError);
  const agent = fakeAgent(CHILD);
  const bridge = createWakeUpBridge({
    readTable: () => ({ [CHILD]: CHOSEN }),
    listAgents: () => [agent],
  });
  assert.deepEqual(bridge.appliedTable(), { [CHILD]: CHOSEN });
  assert.deepEqual(agent.selected, [], 'constructing the bridge must not select anything');
});

test('the applied table only ever holds normalized overrides', () => {
  const bridge = createWakeUpBridge({ readTable: () => ({ [CHILD]: CHOSEN, bad: { provider: 'p' } }) });
  assert.deepEqual(bridge.appliedTable(), { [CHILD]: CHOSEN });
});

