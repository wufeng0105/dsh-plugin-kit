/**
 * Tests for the browser half's *non-visual* logic, loaded in a fake page.
 *
 * `client.js` is a classic script that registers a factory with
 * `window.__ModuleLoader__`. We stub that one global, capture the factory, and
 * hand it a minimal React — which is enough to prove the three things that can
 * be checked without a browser:
 *
 * 1. the registration shape (`inject`, `apply`) and the slot options,
 * 2. that the render predicate agrees with the tested copy in `lib/core.js`
 *    (the predicate is duplicated on purpose; drift must fail this suite),
 * 3. the "settings unavailable" degradation when the Host's entry id is absent.
 *
 * What this file deliberately does NOT prove: that the slot renders in a
 * teammate view, or that a click writes anything. Those need a live page and
 * are listed as unverified in `07-selfcheck.md`.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

import { ENTRY_GLOBAL, shouldRenderPicker } from '../lib/core.js';

const CLIENT_PATH = fileURLToPath(new URL('../client.js', import.meta.url));
const CLIENT_SOURCE = readFileSync(CLIENT_PATH, 'utf8');

/** Minimal React stand-in: `createElement` records what the component returned. */
function fakeReact() {
  return {
    createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  };
}

/** Set one global property and return the function that restores it. */
function setGlobal(key, value) {
  const had = Object.hasOwn(globalThis, key);
  const previous = Reflect.get(globalThis, key);
  Reflect.defineProperty(globalThis, key, { value, configurable: true, writable: true, enumerable: true });
  return () => {
    if (had) Reflect.defineProperty(globalThis, key, { value: previous, configurable: true, writable: true, enumerable: true });
    else Reflect.deleteProperty(globalThis, key);
  };
}

/** Load `client.js` in a fake page and return the factory product. */
function loadClient() {
  let registration;
  const restoreWindow = setGlobal('window', { __ModuleLoader__: { load: (entry) => { registration = entry; } } });
  try {
    // eslint-disable-next-line no-new-func
    new Function('requireSource', CLIENT_SOURCE)(undefined);
  } finally {
    restoreWindow();
  }
  assert.equal(globalThis.window, undefined, 'the fake page must be restored');
  assert.ok(registration, 'client.js must call window.__ModuleLoader__.load');
  const exported = registration.factory((specifier) => {
    if (specifier === 'react') return fakeReact();
    throw new Error(`unexpected module request: ${specifier}`);
  });
  return { exported, registration };
}

/**
 * Run `body` with the Host's published global in place, the way the real page
 * does (the boot payload's `globalThis[name] = value` script runs before the
 * Client modules activate, and stays on the page for its whole life).
 *
 * @param {object|null} published the `globalThis[ENTRY_GLOBAL]` value, or null for none
 * @param {() => void} body assertions to run with the global alive
 */
function withPublished(published, body) {
  const restore = published === null ? () => {} : setGlobal(ENTRY_GLOBAL, published);
  try {
    body();
  } finally {
    restore();
  }
}

/** A Client context stand-in that records slot/locale registrations. */
function fakeClientContext({ configForms } = {}) {
  const slotEntries = [];
  const localeRegistrations = [];
  const effects = [];
  const ctx = {
    slotEntries,
    localeRegistrations,
    effects,
    configForms: configForms === undefined ? { get: () => ({ mutate: async () => true }) } : configForms,
    effect: (fn) => {
      const disposer = fn();
      effects.push(disposer);
      return disposer;
    },
    locale: {
      register: (ns, dictionaries) => { localeRegistrations.push({ ns, dictionaries }); },
    },
    slots: {
      inject: (key, callback) => { ctx.slotEntries.push({ kind: 'inject', key, callback }); },
      register: (options, component) => {
        ctx.slotEntries.push({ kind: 'register', options, component });
        return () => {};
      },
    },
  };
  return ctx;
}

/** Trigger the `conversation.input.right` injection and return its registration. */
function registerPicker(ctx) {
  const injection = ctx.slotEntries.find((entry) => entry.kind === 'inject' && entry.key === 'conversation.input.right');
  assert.ok(injection, 'must inject into conversation.input.right');
  injection.callback(() => ({ dispose() {} }));
  const registration = ctx.slotEntries.find((entry) => entry.kind === 'register');
  assert.ok(registration, 'the injection callback must register the picker');
  return registration;
}

// ---------------------------------------------------------------------------
// module shape
// ---------------------------------------------------------------------------

test('client.js registers one factory under the package name', () => {
  const { registration } = loadClient();
  assert.equal(registration.id, '@local/dsh-teammate-picker');
  assert.equal(typeof registration.factory, 'function');
});

test('the factory injects the three services it uses and exposes apply()', () => {
  const { exported } = loadClient();
  assert.deepEqual(exported.inject, ['slots', 'locale', 'configForms']);
  assert.equal(typeof exported.apply, 'function');
});

// ---------------------------------------------------------------------------
// slot registration
// ---------------------------------------------------------------------------

test('apply registers into conversation.input.right with its OWN cell id', () => {
  const { exported } = loadClient();
  const ctx = fakeClientContext();
  withPublished({ entryId: 'teammate-picker' }, () => {
    exported.apply(ctx);
    const registration = registerPicker(ctx);
    const { options } = registration;
    assert.equal(options.name, 'conversation.input.right');
    assert.equal(options.id, 'teammate-picker', 'a shipped id would replace that shipped cell');
    assert.notEqual(options.id, '@local/dsh-teammate-picker', 'the cell id is not the package name');
    assert.equal(options.locale, 'teammatePicker');
    assert.equal(typeof options.inject, 'function');
    assert.equal(typeof registration.component, 'function', 'the component is passed as the second argument');
    assert.equal(typeof options.inject(), 'object');
  });
});

test('apply registers the locale namespace with both zh and en baselines', () => {
  const { exported } = loadClient();
  const ctx = fakeClientContext();
  withPublished({ entryId: 'teammate-picker' }, () => exported.apply(ctx));
  const registered = ctx.localeRegistrations.find((entry) => entry.ns === 'teammatePicker');
  assert.ok(registered, 'the locale namespace must be registered');
  assert.deepEqual(Object.keys(registered.dictionaries).sort(), ['en', 'zh']);
  assert.equal(typeof registered.dictionaries.en['seat.label'], 'string');
  assert.equal(typeof registered.dictionaries.zh['seat.label'], 'string');
  assert.equal(typeof registered.dictionaries.en['seat.unavailable'], 'string');
  assert.equal(typeof registered.dictionaries.zh['seat.unavailable'], 'string');
});

// ---------------------------------------------------------------------------
// settings degradation
// ---------------------------------------------------------------------------

test('the injected face reports settings available when both the id and the form resolve', () => {
  const requested = [];
  const { exported } = loadClient();
  const ctx = fakeClientContext({
    configForms: { get: (entryId) => { requested.push(entryId); return { mutate: async () => true }; } },
  });
  withPublished({ entryId: 'teammate-picker' }, () => {
    exported.apply(ctx);
    const face = registerPicker(ctx).options.inject();
    assert.deepEqual(face, { entryId: 'teammate-picker', settingsAvailable: true });
  });
  assert.deepEqual(requested, ['teammate-picker'], 'configForms.get() must receive the published entry id');
});

test('a missing entry id degrades to settings-unavailable instead of throwing', () => {
  const { exported } = loadClient();
  const ctx = fakeClientContext();
  assert.doesNotThrow(() => withPublished(null, () => exported.apply(ctx)));
  const face = registerPicker(ctx).options.inject();
  assert.deepEqual(face, { entryId: null, settingsAvailable: false });
});

test('a missing configForms service degrades instead of throwing', () => {
  const { exported } = loadClient();
  const ctx = fakeClientContext({ configForms: undefined });
  assert.doesNotThrow(() => withPublished({ entryId: 'teammate-picker' }, () => exported.apply(ctx)));
  const face = registerPicker(ctx).options.inject();
  assert.equal(face.settingsAvailable, false);
});

test('a throwing configForms.get degrades instead of throwing', () => {
  const { exported } = loadClient();
  const ctx = fakeClientContext({ configForms: { get() { throw new Error('namespace not served yet'); } } });
  assert.doesNotThrow(() => withPublished({ entryId: 'teammate-picker' }, () => exported.apply(ctx)));
  assert.equal(registerPicker(ctx).options.inject().settingsAvailable, false);
});

test('the form is retried on the next injection call rather than latched unavailable', () => {
  // The real renderer caches `inject` per session binding, so in production this
  // retry covers the cases that re-assemble the seat (a blank shell adopting its
  // first session, a remount after a slot declaration collapses). The point of
  // the test is that a first-attempt failure is not memoized as "unavailable".
  let attempt = 0;
  const { exported } = loadClient();
  const ctx = fakeClientContext({
    configForms: {
      get: () => {
        attempt += 1;
        return attempt === 1 ? null : { mutate: async () => true };
      },
    },
  });
  withPublished({ entryId: 'teammate-picker' }, () => {
    exported.apply(ctx);
    const inject = registerPicker(ctx).options.inject;
    assert.equal(inject().settingsAvailable, false, 'first call: service not ready yet');
    assert.equal(inject().settingsAvailable, true, 'second call: the retry succeeded');
    assert.equal(inject().settingsAvailable, true, 'and the success is memoized');
    assert.equal(attempt, 2, 'a successful resolution must stop calling configForms.get()');
  });
});

// ---------------------------------------------------------------------------
// parity: the duplicated predicate must not drift from the tested copy
// ---------------------------------------------------------------------------

/**
 * Extract the `rendersIn` body from the client source and rebuild it as a
 * function. Rebuilding from source (instead of eyeballing) is what makes the
 * parity test meaningful: it exercises the shipped text, not a copy of it.
 */
function extractRendersIn() {
  const start = CLIENT_SOURCE.indexOf('function rendersIn(');
  assert.notEqual(start, -1, 'client.js must still define rendersIn');
  const end = CLIENT_SOURCE.indexOf('\n    }', start);
  assert.notEqual(end, -1, 'rendersIn must be a closed function');
  const body = CLIENT_SOURCE.slice(start, end + '\n    }'.length);
  // eslint-disable-next-line no-new-func
  return new Function(`${body}; return rendersIn;`)();
}

test('the client render predicate agrees with lib/core.js on every documented state', () => {
  const rendersIn = extractRendersIn();
  const cases = [
    [null, 'mainline session'],
    [undefined, 'no snapshot yet'],
    [{ address: { mode: 'continuable' } }, 'warm teammate'],
    [{ address: { mode: 'continuable' }, parentAvailable: true }, 'warm teammate, explicit parent'],
    [{ address: { mode: 'continuable' }, parentAvailable: false }, 'parent offline'],
    [{ address: { mode: 'unknown' } }, 'cold teammate (official read-only composer)'],
    [{ address: { mode: 'one-shot' } }, 'one-shot child'],
    [{ address: { mode: 'external' } }, 'external backend child'],
    [{ address: {} }, 'mode missing'],
    [{}, 'address missing'],
    [{ address: { mode: 'continuable' }, parentAvailable: null }, 'parent unknown'],
  ];
  for (const [subagent, label] of cases) {
    assert.equal(rendersIn(subagent), shouldRenderPicker(subagent).render, `predicate drift on: ${label}`);
  }
});

test('the client reads the entry id from the published global, never from a package name', () => {
  assert.match(CLIENT_SOURCE, /Reflect\.get\(globalThis, ENTRY_GLOBAL\)/);
  assert.match(CLIENT_SOURCE, /__DSH_TEAMMATE_PICKER__/);
  assert.doesNotMatch(CLIENT_SOURCE, /fiber\.entry/, 'the Client has no fiber.entry');
});

// ---------------------------------------------------------------------------
// M-4: the unimplemented Client surface must stay declared, not implied
// ---------------------------------------------------------------------------

/**
 * The five Client surfaces the verifier found absent (08-verification.md M-4).
 * Each entry is the literal the code WOULD contain once implemented.
 */
const MISSING_SURFACE = [
  ['modelCatalog', /modelCatalog/],
  ['session/events', /session\/events|remote\.session\.events/],
  ['mutate', /\.mutate\s*\(/],
  ['showSelector', /showSelector/],
  ['restore', /data-dsh-teammate-picker-restore/],
];

/**
 * Strip everything that only *mentions* a name (comments, and the declaration
 * that lists the missing surfaces on purpose) so the parity test inspects real
 * code paths rather than documentation.
 *
 * @param {string} source `client.js` text
 * @returns {string} the code with documentation removed
 */
function codeOnly(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, '')          // block comments
    .replace(/(^|[^:'"\\])\/\/[^\n]*/g, '$1')  // line comments (not 'https://')
    .replace(/const MISSING_SURFACE = Object\.freeze\(\[[\s\S]*?\]\);/, '');
}

test('the five unimplemented Client surfaces are still absent from client.js (M-4)', () => {
  const code = codeOnly(CLIENT_SOURCE);
  for (const [name, pattern] of MISSING_SURFACE) {
    assert.doesNotMatch(code, pattern,
      `${name} is documented as NOT implemented; implementing it means updating the header and this test`);
  }
});

test('the seat publishes the unimplemented list instead of pretending to work (M-4)', () => {
  const { exported } = loadClient();
  const ctx = fakeClientContext();
  withPublished({ entryId: 'teammate-picker' }, () => exported.apply(ctx));
  const component = registerPicker(ctx).component;
  const seat = component({ useSession: (selector) => selector({ subagent: { address: { mode: 'continuable' } } }), t: (key) => key });
  assert.equal(seat.props['data-dsh-teammate-picker-implemented'], 'seat');
  const missing = seat.props['data-dsh-teammate-picker-missing'].split(' ');
  assert.deepEqual(missing, ['modelCatalog', 'session/events', 'mutate', 'showSelector', 'restore']);
  assert.equal(seat.props.disabled, true, 'a seat with no menu must not look operable');
});

test('the seat renders nothing outside a teammate view (A1/A12 parity, live shape)', () => {
  const { exported } = loadClient();
  const ctx = fakeClientContext();
  withPublished({ entryId: 'teammate-picker' }, () => exported.apply(ctx));
  const component = registerPicker(ctx).component;
  for (const subagent of [null, undefined, { address: { mode: 'one-shot' } }, { address: { mode: 'external' } }, { address: { mode: 'unknown' } }, { address: { mode: 'continuable' }, parentAvailable: false }]) {
    const result = component({ useSession: (selector) => selector({ subagent }), t: (key) => key });
    assert.equal(result, null, `must not render for ${JSON.stringify(subagent)}`);
  }
});
