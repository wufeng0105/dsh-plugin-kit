/**
 * Tests for the Config declaration and the schemastery loading seam.
 *
 * A recording fake stands in for schemastery: the point is not to re-test the
 * schema library, it is to prove that this plugin's declaration says what the
 * implementation assumes — both fields volatile, the switch boolean with a
 * `true` default, and the override table a dictionary of route objects.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { CONFIG_SPEC, createConfigSchema, loadSchemastery, schemasterySpecifiers } from '../lib/schema.js';

/** A schemastery-shaped recorder. Every call is logged for assertions. */
function recordingSchemastery() {
  const calls = [];
  const make = (kind) => {
    const node = {
      kind,
      calls,
      meta: {},
      children: undefined,
      element: undefined,
    };
    node.required = () => { calls.push({ kind, op: 'required' }); return node; };
    node.optional = () => { calls.push({ kind, op: 'optional' }); return node; };
    node.default = (value) => { calls.push({ kind, op: 'default', value }); node.defaultValue = value; return node; };
    node.volatile = () => { calls.push({ kind, op: 'volatile' }); node.isVolatile = true; return node; };
    node.object = (dict) => { const child = make('object'); child.children = dict; return child; };
    return node;
  };
  const z = {
    object: (dict) => { const node = make('object'); node.children = dict; return node; },
    boolean: () => make('boolean'),
    string: () => make('string'),
    dict: (inner) => { const node = make('dict'); node.element = inner; return node; },
  };
  return { z, calls };
}

test('createConfigSchema declares both fields volatile', () => {
  const { z, calls } = recordingSchemastery();
  const schema = createConfigSchema(z);

  assert.equal(schema.kind, 'object');
  assert.deepEqual(Object.keys(schema.children).sort(), ['overrides', 'showSelector']);

  const volatiles = calls.filter((call) => call.op === 'volatile');
  assert.equal(volatiles.length, 2, 'showSelector and overrides must both be volatile');
  assert.deepEqual(volatiles.map((call) => call.kind).sort(), ['boolean', 'dict']);

  assert.equal(schema.children.showSelector.isVolatile, true);
  assert.equal(schema.children.showSelector.defaultValue, true);
  assert.equal(schema.children.overrides.isVolatile, true);
  assert.deepEqual(schema.children.overrides.defaultValue, {});
});

test('createConfigSchema declares the override route as provider/model/reasoningEffort', () => {
  const { z } = recordingSchemastery();
  const schema = createConfigSchema(z);
  const route = schema.children.overrides.element;

  assert.equal(schema.children.overrides.kind, 'dict');
  assert.equal(route.kind, 'object');
  assert.deepEqual(Object.keys(route.children), ['provider', 'model', 'reasoningEffort']);
  assert.equal(route.children.provider.kind, 'string');
  assert.equal(route.children.model.kind, 'string');
  assert.equal(route.children.reasoningEffort.kind, 'string');
});

test('createConfigSchema refuses an incomplete schemastery namespace', () => {
  assert.throws(() => createConfigSchema(undefined), TypeError);
  assert.throws(() => createConfigSchema({}), TypeError);
  assert.throws(() => createConfigSchema({ object: () => {}, boolean: () => {}, string: () => {} }), /z\.dict/);
});

test('CONFIG_SPEC mirrors the schema declaration', () => {
  const names = CONFIG_SPEC.map((field) => field.name);
  assert.deepEqual(names, ['showSelector', 'overrides']);
  assert.equal(CONFIG_SPEC[0].type, 'boolean');
  assert.equal(CONFIG_SPEC[0].default, true);
  assert.equal(CONFIG_SPEC[1].type, 'dict');
  assert.equal(CONFIG_SPEC[1].volatile, true);
  assert.ok(CONFIG_SPEC.every((field) => field.volatile === true), 'every field must be volatile');
  assert.deepEqual(Object.keys(CONFIG_SPEC[1].entry), ['provider', 'model', 'reasoningEffort']);
});

test('loadSchemastery returns the namespace object from a default export', async () => {
  const fake = { object: () => {} };
  assert.equal(await loadSchemastery(async () => ({ default: fake })), fake);
});

test('loadSchemastery returns the module itself when there is no default export', async () => {
  const fake = { object: () => {} };
  assert.equal(await loadSchemastery(async () => fake), fake);
});

test('loadSchemastery degrades to null instead of throwing when the package is missing', async () => {
  assert.equal(await loadSchemastery(async () => { throw new Error('ERR_MODULE_NOT_FOUND'); }), null);
  assert.equal(await loadSchemastery(async () => null), null);
  assert.equal(await loadSchemastery(async () => ({ default: 'not-an-object' })), null);
  assert.equal(await loadSchemastery(async () => ({ default: null })), null);
  assert.equal(await loadSchemastery(async () => ({ default: 42 })), null);
});

test('loadSchemastery accepts the REAL package shape: a callable namespace (B-2)', async () => {
  // schemastery's default export is a function with builder properties:
  //   typeof default === 'function'
  // The old guard (`typeof namespace === 'object'`) rejected it, so Config was
  // undefined in every installation shape and dsh-settings threw
  // "No configurable plugin entry" (08-verification.md §3.3 / B-2).
  const callable = Object.assign(function z() {}, {
    object: () => {},
    boolean: () => {},
    string: () => {},
    dict: () => {},
  });
  assert.equal(typeof callable, 'function', 'the fixture must really be a function');
  assert.equal(await loadSchemastery(async () => ({ default: callable })), callable);
  assert.equal(await loadSchemastery(async () => callable), callable, 'a CJS-style default is the module itself');
});

test('loadSchemastery still rejects a function that has no builders', async () => {
  // A bare function cannot build the schema; accepting it would make index.js
  // throw at import time instead of degrading.
  assert.equal(await loadSchemastery(async () => ({ default: () => {} })), null);
});

test('loadSchemastery falls back to the profile anchors when the bare specifier fails (link install)', async () => {
  // A junction install resolves imports from the SOURCE directory (Node
  // realpaths the module), so `<profile>/node_modules` is not an ancestor and
  // the bare specifier misses. The Host publishes DSH_PROFILE_DIR for exactly
  // this kind of anchored lookup.
  const callable = Object.assign(function z() {}, { object: () => {} });
  const tried = [];
  const loaded = await loadSchemastery(async (specifier) => {
    tried.push(specifier);
    if (specifier === '@deepseek-ai/schemastery') throw new Error('ERR_MODULE_NOT_FOUND');
    return { default: callable };
  }, { DSH_PROFILE_DIR: 'C:\\Users\\x\\.dsh\\profiles\\desktop' });
  assert.equal(loaded, callable);
  assert.deepEqual(tried, [
    '@deepseek-ai/schemastery',
    'file:///C:/Users/x/.dsh/profiles/desktop/node_modules/@deepseek-ai/schemastery/lib/index.mjs',
  ]);
});

test('loadSchemastery derives the profile anchor from DSH_HOME + DSH_PROFILE', async () => {
  const tried = [];
  await loadSchemastery(async (specifier) => {
    tried.push(specifier);
    throw new Error('missing');
  }, { DSH_HOME: 'C:/Users/x/.dsh', DSH_PROFILE: 'desktop' });
  assert.deepEqual(tried, [
    '@deepseek-ai/schemastery',
    'file:///C:/Users/x/.dsh/profiles/desktop/node_modules/@deepseek-ai/schemastery/lib/index.mjs',
  ]);
});

test('schemasterySpecifiers puts the bare specifier first and deduplicates', () => {
  assert.deepEqual(schemasterySpecifiers({}), ['@deepseek-ai/schemastery']);
  const both = schemasterySpecifiers({
    DSH_PROFILE_DIR: 'C:\\a\\profiles\\desktop',
    DSH_HOME: 'C:\\a',
    DSH_PROFILE: 'desktop',
  });
  assert.equal(both[0], '@deepseek-ai/schemastery');
  assert.equal(both.length, 2, 'the same anchor discovered twice must be deduplicated');
});

test('loadSchemastery resolves the real package when this deployment provides it', async () => {
  // Informational, not a requirement: the plugin must load either way. When the
  // package is absent (a profile without its dependency set) this branch is
  // skipped and the "degrades to null" test above already covers the behaviour.
  const loaded = await loadSchemastery();
  if (loaded === null) return;
  assert.equal(typeof loaded.object, 'function');
  assert.equal(typeof loaded.boolean, 'function');
  assert.equal(typeof loaded.dict, 'function');
});
