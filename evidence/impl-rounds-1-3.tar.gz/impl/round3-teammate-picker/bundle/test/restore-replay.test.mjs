/**
 * B-1 regression: "restore the dispatch route" must be observable in the
 * OFFICIAL `modelSelection` projection, not just in the plugin's own table.
 *
 * The fold below is a verbatim translation of the installed projection
 * (`dsh-agent/lib/index.js:102-174` @ this machine's app.asar):
 *
 *   apply(state, event):
 *     'model/selection' -> pending = data            (:152-155)
 *     'request/header'  -> lastUsed = selectionOfHeader(header)   (:157)
 *                          pending  = pending === lastUsed ? null : pending (:158)
 *   current() = pending ?? lastUsed ?? options       (:190-195, :200-203)
 *
 * It is a copy, not an import: the package is not a dependency of this plugin,
 * and the point of the test is that our *writes* satisfy that projection's
 * rules. The replay drives the real `createPlugin` listeners and the real
 * `planRestore` decision, then feeds the events a fake Session recorded into the
 * fold — so "restore works" is decided by the official rules, not by ours.
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import { createPlugin } from '../lib/host.js';
import { planRestore, planVolatileApply, setOverride, deleteOverride } from '../lib/core.js';

// --- the official fold, copied from dsh-agent/lib/index.js:102-203 -----------

function sameRoute(left, right) {
  return left.provider === right.provider && left.model === right.model;
}

function sameModelSelection(left, right) {
  return left === right
    || (left !== null && right !== null && sameRoute(left, right) && left.reasoningEffort === right.reasoningEffort);
}

function toSelection(provider, model, reasoningEffort) {
  return { provider, model, ...(reasoningEffort === undefined ? {} : { reasoningEffort }) };
}

function selectionOfHeader({ config, adapterDefaults }) {
  return toSelection(
    config.provider,
    config.model,
    adapterDefaults?.reasoningEffort === true ? undefined : config.reasoningEffort,
  );
}

/** The projection's `apply`, verbatim in effect. */
function applyEvent(state, event) {
  if (event.type === 'model/selection') {
    return sameModelSelection(state.pending, event.data) ? state : { ...state, pending: event.data };
  }
  if (event.type !== 'request/header') return state;
  const lastUsed = selectionOfHeader(event.data.header);
  const pending = sameModelSelection(state.pending, lastUsed) ? null : state.pending;
  return sameModelSelection(state.lastUsed, lastUsed) && pending === state.pending
    ? state
    : { lastUsed, pending };
}

const INIT = Object.freeze({ lastUsed: null, pending: null });
const replay = (events) => events.reduce(applyEvent, INIT);

/** `AgentModel.current()` (:190-195, :200-203). */
function current(state, options) {
  const recorded = state.pending ?? state.lastUsed;
  if (recorded !== null) return { ...recorded };
  return options.provider && options.model
    ? toSelection(options.provider, options.model, options.reasoningEffort)
    : undefined;
}

// --- a fake Session + AgentModel that records what the plugin writes ---------

const DISPATCH = Object.freeze({ provider: 'deepseek', model: 'deepseek-chat' });
const OVERRIDE = Object.freeze({ provider: 'deepseek', model: 'deepseek-reasoner', reasoningEffort: 'high' });
const CHILD = 'sess-child-1';

/**
 * A teammate as the Host sees it: `model.options` = the descriptor triple
 * (`dsh-subagent/lib/index.js:2186-2190`), `model.current()` = the fold of its
 * own log, `model.select()` = the official `session.append('model/selection')`.
 */
function fakeTeammate({ id = CHILD, events = [], options = DISPATCH } = {}) {
  const log = [...events];
  const agent = {
    id,
    session: { header: { origin: 'subagent' } },
    log,
    model: {
      options: { ...options },
      current: () => current(replay(log), options),
      select: (route) => {
        // `AgentModel.select()` skips an equal recorded selection (:196-199).
        if (sameModelSelection(current(replay(log), options) ?? null, route)) return;
        log.push({ type: 'model/selection', data: toSelection(route.provider, route.model, route.reasoningEffort) });
      },
    },
  };
  return agent;
}

/** One finished turn under `route` leaves a `request/header` behind. */
function headerEvent(route) {
  return { type: 'request/header', data: { header: { config: { ...route } } } };
}

function fakeContext(liveAgents) {
  const listeners = new Map();
  const ctx = {
    listeners,
    warnings: [],
    fiber: { entry: { options: { id: 'teammate-picker' } } },
    agents: { list: () => liveAgents },
    logger: {
      warn: (...args) => ctx.warnings.push(args.map((item) => String(item)).join(' ')),
      debug: () => {},
    },
    on(event, listener) {
      if (!listeners.has(event)) listeners.set(event, []);
      listeners.get(event).push(listener);
    },
  };
  return ctx;
}

function configWith(overrides) {
  const state = { overrides };
  return { state, overrides: { get: () => state.overrides }, showSelector: { get: () => true } };
}

function fire(ctx, event, ...args) {
  return Promise.all((ctx.listeners.get(event) ?? []).map((listener) => listener(...args)));
}

// --- the scenario the verifier proved unreachable ----------------------------

test('A7/B-1: after override -> turn -> restore -> resume, current() is the descriptor route', async () => {
  const agent = fakeTeammate({ events: [headerEvent(DISPATCH)] });
  const config = configWith({ [CHILD]: OVERRIDE });
  const ctx = fakeContext([agent]);
  createPlugin(ctx, config);

  // 1. The override is applied (here: as a hot apply would, via the bridge).
  await fire(ctx, 'agent/created', { agent, source: 'resume' });
  assert.deepEqual(current(replay(agent.log), DISPATCH), { ...OVERRIDE },
    'precondition: the override route is what current() answers');

  // 2. A turn runs under the override: `lastUsed` becomes the override route.
  agent.log.push(headerEvent(OVERRIDE));
  assert.deepEqual(current(replay(agent.log), DISPATCH), { ...OVERRIDE });

  // 3. Restore: drop the row, then write the descriptor route back (B-1a).
  config.state.overrides = {};
  await fire(ctx, 'loader/volatile-update', [['overrides']]);

  // 4. Resume replays the same log with the descriptor as AgentOptions.
  const resumed = replay(agent.log);
  assert.deepEqual(current(resumed, DISPATCH), { ...DISPATCH },
    'A7 decision 1: the first step after a restore must use the descriptor route');
});

test('A7/B-1 control: deleting the row alone would NOT restore the route', () => {
  // This is the failure the verifier reproduced (08-verification.md §3.2): the
  // delete produces no event, so `lastUsed` still names the override.
  const log = [
    headerEvent(DISPATCH),
    { type: 'model/selection', data: { ...OVERRIDE } },
    headerEvent(OVERRIDE),
  ];
  assert.deepEqual(current(replay(log), DISPATCH), { ...OVERRIDE },
    'without the write-back, current() keeps answering the override route');
  // ...and the write-back is exactly what fixes it.
  assert.deepEqual(current(replay([...log, { type: 'model/selection', data: { ...DISPATCH } }]), DISPATCH), { ...DISPATCH });
});

test('A7/B-1: a restored row cannot come back on the next volatile update', async () => {
  const agent = fakeTeammate({ events: [headerEvent(DISPATCH)] });
  const config = configWith({ [CHILD]: OVERRIDE });
  const ctx = fakeContext([agent]);
  createPlugin(ctx, config);
  await fire(ctx, 'agent/created', { agent, source: 'resume' });
  agent.log.push(headerEvent(OVERRIDE));

  config.state.overrides = {};
  await fire(ctx, 'loader/volatile-update', [['overrides']]);
  // The Loader emits for any volatile path; a second event with the same table
  // must not re-apply anything (the bridge compares against its baseline).
  config.state.showSelector = { get: () => false };
  await fire(ctx, 'loader/volatile-update', [['showSelector']]);
  assert.deepEqual(current(replay(agent.log), DISPATCH), { ...DISPATCH });
});

test('planRestore is what makes the replay pass, and plan-on-delete is what makes it fail', () => {
  // The pure decision, checked against the same two states the replay uses.
  assert.equal(planRestore({ isTeammate: true, dispatchRoute: DISPATCH, recordedRoute: { ...OVERRIDE } }).action, 'select');
  assert.equal(planRestore({ isTeammate: true, dispatchRoute: DISPATCH, recordedRoute: { ...DISPATCH } }).action, 'noop');

  // And the table half alone produces no action at all under the old rule.
  const before = setOverride({}, CHILD, OVERRIDE);
  const after = deleteOverride(before, CHILD);
  const oldStyle = [];
  for (const [id] of Object.entries(before)) {
    if (after[id] === undefined) continue; // the old "restore = silence" behaviour
    oldStyle.push(id);
  }
  assert.deepEqual(oldStyle, [], 'the delete alone contributes nothing to the log — hence B-1');
});

test('A6/A7: a restore mid-turn does not invalidate the step already prepared', async () => {
  const agent = fakeTeammate({ events: [headerEvent(DISPATCH)] });
  const config = configWith({ [CHILD]: OVERRIDE });
  const ctx = fakeContext([agent]);
  createPlugin(ctx, config);
  await fire(ctx, 'agent/created', { agent, source: 'resume' });
  agent.log.push(headerEvent(OVERRIDE));

  // `dsh-agent-loop` fixes this step's selection BEFORE the waterfall
  // (`:671`), and `prepareRequest` reuses that captured value (`:842,986-1001`):
  // a route change after that point is a *hard error* if it reaches the
  // proposal. The restore therefore must not rewrite the in-flight step.
  const prepared = current(replay(agent.log), DISPATCH);
  assert.deepEqual(prepared, { ...OVERRIDE });

  config.state.overrides = {};
  await fire(ctx, 'loader/volatile-update', [['overrides']]);

  // The already-captured step selection is untouched: the guard at `:1000-1001`
  // compares the proposal (seeded from this value) against this value.
  assert.deepEqual(prepared, { ...OVERRIDE }, 'an in-flight step keeps the route it was prepared with');
  assert.deepEqual(current(replay(agent.log), DISPATCH), { ...DISPATCH },
    'the next step reads model.current() again and now gets the dispatch route');

  // And the pre-step listener still continues the waterfall untouched.
  const preStep = ctx.listeners.get('agent/pre-step')[0];
  const decision = { kind: 'enter', messages: [] };
  const result = await preStep({ agent, modelSelection: prepared }, async () => decision);
  assert.equal(result, decision, 'practices.md:16 — the listener never owns the decision');
});

test('A9: without an override the plugin writes no selection at all', async () => {
  const agent = fakeTeammate({ events: [headerEvent(DISPATCH)] });
  const ctx = fakeContext([agent]);
  createPlugin(ctx, configWith({}));
  await fire(ctx, 'agent/created', { agent, source: 'resume' });
  assert.deepEqual(agent.log, [headerEvent(DISPATCH)], 'zero intervention: the log must not gain an event');
});

test('A15: the only event type the restore writes is the official model/selection', async () => {
  const agent = fakeTeammate({ events: [headerEvent(DISPATCH)] });
  const config = configWith({ [CHILD]: OVERRIDE });
  const ctx = fakeContext([agent]);
  createPlugin(ctx, config);
  await fire(ctx, 'agent/created', { agent, source: 'resume' });
  config.state.overrides = {};
  await fire(ctx, 'loader/volatile-update', [['overrides']]);
  const added = agent.log.slice(1).map((event) => event.type);
  assert.deepEqual(added, ['model/selection', 'model/selection']);
  assert.ok(added.every((type) => type === 'model/selection'), 'no custom event type is introduced');
});
