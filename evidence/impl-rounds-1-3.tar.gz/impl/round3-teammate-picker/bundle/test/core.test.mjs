/**
 * Unit tests for the pure core. No third-party dependency: `node --test` only.
 *
 * Coverage map (see `06-implementation.md`):
 * - override table read/write/validate (per teammate: childSessionId + provider/model/reasoningEffort)
 * - route decision: override wins; no override = zero intervention (same reference back)
 * - restore = delete the entry, not write the descriptor
 * - Config volatile field read/write helpers (pure ops + unwrapping)
 * - the fold helpers the Client will use over `session/events`
 */

import test from 'node:test';
import assert from 'node:assert/strict';

import {
  CONFIG_FIELDS,
  ENTRY_GLOBAL,
  decideRoute,
  deepEqualJson,
  deleteOverride,
  dispatchRouteOfAgent,
  dispatchRouteOfDescriptor,
  effectiveRouteOf,
  foldSessionRouteFacts,
  isPlainObject,
  isTeammateAgent,
  isUsableKey,
  normalizeRoute,
  normalizeTable,
  overrideDeleteOps,
  overrideSetOps,
  planAgentCreatedApply,
  planPreStepApply,
  planRestore,
  planVolatileApply,
  readEntryId,
  readOverride,
  readOverrides,
  readShowSelector,
  sameRoute,
  setOverride,
  shouldRenderPicker,
  showSelectorOps,
  unwrapVolatile,
} from '../lib/core.js';

const DISPATCH = Object.freeze({ provider: 'deepseek', model: 'deepseek-chat' });
const CHOSEN = Object.freeze({ provider: 'deepseek', model: 'deepseek-reasoner', reasoningEffort: 'high' });
const CHILD = 'sess-child-1';

// ---------------------------------------------------------------------------
// route validation
// ---------------------------------------------------------------------------

test('normalizeRoute accepts a complete triple and detaches it', () => {
  const input = { provider: 'p', model: 'm', reasoningEffort: 'low', extra: 'ignored' };
  const route = normalizeRoute(input);
  assert.deepEqual(route, { provider: 'p', model: 'm', reasoningEffort: 'low' });
  assert.notEqual(route, input, 'the returned route must be a copy');
  assert.equal(Object.hasOwn(route, 'extra'), false, 'unknown fields are dropped');
});

test('normalizeRoute drops an absent or empty effort', () => {
  assert.deepEqual(normalizeRoute({ provider: 'p', model: 'm' }), { provider: 'p', model: 'm' });
  assert.deepEqual(normalizeRoute({ provider: 'p', model: 'm', reasoningEffort: '' }), { provider: 'p', model: 'm' });
  assert.deepEqual(normalizeRoute({ provider: 'p', model: 'm', reasoningEffort: 3 }), { provider: 'p', model: 'm' });
});

test('normalizeRoute rejects everything that is not a usable route', () => {
  for (const bad of [null, undefined, 'deepseek', 42, [], { provider: 'p' }, { model: 'm' }, { provider: '', model: 'm' }, { provider: 'p', model: '' }]) {
    assert.equal(normalizeRoute(bad), null, `expected null for ${JSON.stringify(bad)}`);
  }
});

test('sameRoute compares provider, model and effort, treating absent effort as a value', () => {
  assert.equal(sameRoute({ provider: 'p', model: 'm' }, { provider: 'p', model: 'm' }), true);
  assert.equal(sameRoute({ provider: 'p', model: 'm' }, { provider: 'p', model: 'm', reasoningEffort: 'high' }), false);
  assert.equal(sameRoute({ provider: 'p', model: 'm', reasoningEffort: 'high' }, { provider: 'p', model: 'm', reasoningEffort: 'high' }), true);
  assert.equal(sameRoute(null, null), true);
  assert.equal(sameRoute(null, { provider: 'p', model: 'm' }), false);
});

test('deepEqualJson compares JSON values structurally and never mutates', () => {
  assert.equal(deepEqualJson({ a: [1, { b: 2 }] }, { a: [1, { b: 2 }] }), true);
  assert.equal(deepEqualJson({ a: [1, 2] }, { a: [2, 1] }), false);
  assert.equal(deepEqualJson({ a: 1 }, { a: 1, b: undefined }), false);
  assert.equal(deepEqualJson({}, []), false);
  assert.equal(deepEqualJson(null, null), true);
});

test('isPlainObject and isUsableKey gate the dictionary writes', () => {
  assert.equal(isPlainObject({}), true);
  assert.equal(isPlainObject(Object.create(null)), true);
  assert.equal(isPlainObject([]), false);
  assert.equal(isPlainObject(null), false);
  assert.equal(isPlainObject(new Date()), false);

  assert.equal(isUsableKey('sess-1'), true);
  assert.equal(isUsableKey(''), false);
  assert.equal(isUsableKey(7), false);
  for (const unsafe of ['__proto__', 'prototype', 'constructor']) {
    assert.equal(isUsableKey(unsafe), false, `${unsafe} must never be a table key`);
  }
});

// ---------------------------------------------------------------------------
// override table: read / write / delete
// ---------------------------------------------------------------------------

test('normalizeTable keeps valid entries and drops corrupt ones instead of throwing', () => {
  const table = normalizeTable({
    [CHILD]: CHOSEN,
    'sess-child-2': { provider: 'p' },          // missing model
    'sess-child-3': 'not-a-route',
    '': { provider: 'p', model: 'm' },          // empty key
    __proto__: { provider: 'p', model: 'm' },   // unsafe key
  });
  assert.deepEqual(Object.keys(table), [CHILD]);
  assert.deepEqual(table[CHILD], { ...CHOSEN });
});

test('normalizeTable tolerates any non-object input', () => {
  for (const bad of [null, undefined, 'x', 1, [], true]) {
    assert.deepEqual(normalizeTable(bad), {});
  }
});

test('setOverride adds an entry without mutating the input table', () => {
  const before = {};
  const after = setOverride(before, CHILD, CHOSEN);
  assert.deepEqual(after, { [CHILD]: { ...CHOSEN } });
  assert.deepEqual(before, {}, 'the input table must be untouched');
  assert.deepEqual(readOverride(after, CHILD), { ...CHOSEN });
});

test('setOverride replaces an existing entry for the same teammate only', () => {
  const base = setOverride({}, CHILD, DISPATCH);
  const two = setOverride(base, 'sess-child-2', CHOSEN);
  const replaced = setOverride(two, CHILD, CHOSEN);
  assert.deepEqual(readOverride(replaced, CHILD), { ...CHOSEN });
  assert.deepEqual(readOverride(replaced, 'sess-child-2'), { ...CHOSEN });
  assert.deepEqual(readOverride(two, CHILD), { ...DISPATCH }, 'the older table keeps the old value');
});

test('setOverride rejects an unusable key or route', () => {
  assert.throws(() => setOverride({}, '', CHOSEN), TypeError);
  assert.throws(() => setOverride({}, '__proto__', CHOSEN), TypeError);
  assert.throws(() => setOverride({}, CHILD, { provider: 'p' }), TypeError);
  assert.throws(() => setOverride({}, CHILD, null), TypeError);
});

test('setOverride cannot shadow the prototype of the table', () => {
  for (const unsafe of ['__proto__', 'prototype', 'constructor']) {
    assert.throws(() => setOverride({}, unsafe, CHOSEN), TypeError, `${unsafe} must be rejected`);
  }
  // A normalized table also refuses to be polluted by a raw dictionary.
  const table = normalizeTable(JSON.parse('{"__proto__": {"provider": "p", "model": "m"}}'));
  assert.deepEqual(Object.keys(table), []);
  assert.equal(Object.getPrototypeOf(table), Object.prototype, 'the table keeps a normal prototype');
});

test('deleteOverride removes exactly one entry and is a no-op for absent keys', () => {
  const base = setOverride(setOverride({}, CHILD, CHOSEN), 'sess-child-2', DISPATCH);
  const removed = deleteOverride(base, CHILD);
  assert.deepEqual(Object.keys(removed), ['sess-child-2']);
  assert.equal(readOverride(removed, CHILD), null, 'an absent entry means no override');
  assert.deepEqual(base, {
    [CHILD]: { ...CHOSEN },
    'sess-child-2': { ...DISPATCH },
  }, 'the input table must be untouched');

  const same = deleteOverride(removed, 'missing-child');
  assert.deepEqual(same, removed);
});

test('readOverride returns null for missing, unsafe or corrupt entries', () => {
  const table = setOverride({}, CHILD, CHOSEN);
  assert.equal(readOverride(table, 'missing'), null);
  assert.equal(readOverride(table, ''), null);
  assert.equal(readOverride(table, '__proto__'), null);
  assert.equal(readOverride(null, CHILD), null);
  assert.equal(readOverride({ [CHILD]: { provider: 'p' } }, CHILD), null);
});

// ---------------------------------------------------------------------------
// routing decision
// ---------------------------------------------------------------------------

test('decideRoute prefers the override and reports intervention', () => {
  const decision = decideRoute({ override: CHOSEN, dispatchRoute: DISPATCH });
  assert.equal(decision.source, 'override');
  assert.equal(decision.intervened, true);
  assert.deepEqual(decision.route, { ...CHOSEN });
});

test('decideRoute without an override returns the input route by identity (zero intervention)', () => {
  const decision = decideRoute({ override: null, dispatchRoute: DISPATCH, currentRoute: DISPATCH });
  assert.equal(decision.intervened, false);
  assert.equal(decision.source, 'dispatch');
  assert.equal(decision.route, DISPATCH, 'must be the same object, not an equal copy');
});

test('decideRoute falls back through dispatch -> current -> fallback -> none', () => {
  const current = { provider: 'p', model: 'm' };
  const fallback = { provider: 'f', model: 'f' };
  assert.equal(decideRoute({ currentRoute: current, fallbackRoute: fallback }).source, 'current');
  assert.equal(decideRoute({ fallbackRoute: fallback }).source, 'fallback');
  const none = decideRoute({});
  assert.equal(none.route, null);
  assert.equal(none.source, 'none');
  assert.equal(none.intervened, false);
});

test('decideRoute ignores a corrupt override instead of trusting it', () => {
  const decision = decideRoute({ override: { provider: 'p' }, dispatchRoute: DISPATCH });
  assert.equal(decision.intervened, false);
  assert.equal(decision.route, DISPATCH);
});

// ---------------------------------------------------------------------------
// wake-up / hot-apply planning
// ---------------------------------------------------------------------------

test('planAgentCreatedApply selects only when an override exists and differs', () => {
  const table = setOverride({}, CHILD, CHOSEN);
  assert.deepEqual(planAgentCreatedApply({ table, agentId: CHILD }), {
    action: 'select', route: { ...CHOSEN }, reason: 'override-present',
  });
  assert.deepEqual(planAgentCreatedApply({ table, agentId: 'other' }), { action: 'noop', reason: 'no-override' });
  assert.deepEqual(planAgentCreatedApply({ table, agentId: CHILD, current: CHOSEN }), {
    action: 'noop', reason: 'already-selected',
  });
  assert.deepEqual(planAgentCreatedApply({ table, agentId: CHILD, current: DISPATCH }).action, 'select');
});

test('planAgentCreatedApply is safe with an empty table, a bad id or a corrupt table', () => {
  assert.equal(planAgentCreatedApply({ table: {}, agentId: CHILD }).action, 'noop');
  assert.equal(planAgentCreatedApply({ table: {}, agentId: '' }).action, 'noop');
  assert.equal(planAgentCreatedApply({ table: 'garbage', agentId: CHILD }).action, 'noop');
});

test('planVolatileApply reports no change for an identical table (idempotent event)', () => {
  const table = setOverride({}, CHILD, CHOSEN);
  const live = [{ id: CHILD }];
  const first = planVolatileApply({ previous: {}, next: table, liveAgents: live });
  assert.equal(first.changed, true);
  assert.equal(first.actions.length, 1);

  const second = planVolatileApply({ previous: first.table, next: table, liveAgents: live });
  assert.equal(second.changed, false, 're-applying the same table must not act');
  assert.deepEqual(second.actions, []);
});

test('planVolatileApply only touches teammates whose effective override changed', () => {
  const before = setOverride(setOverride({}, 'child-a', DISPATCH), 'child-b', DISPATCH);
  const after = setOverride(before, 'child-a', CHOSEN); // child-b unchanged
  const plan = planVolatileApply({ previous: before, next: after, liveAgents: [{ id: 'child-a' }, { id: 'child-b' }] });
  assert.equal(plan.changed, true);
  assert.deepEqual(plan.actions, [
    { agentId: 'child-a', action: 'select', route: { ...CHOSEN }, reason: 'override-changed' },
  ]);
});

test('planVolatileApply turns a vanished row into a restore action, not silence', () => {
  const before = setOverride({}, 'child-a', CHOSEN);
  const plan = planVolatileApply({ previous: before, next: deleteOverride(before, 'child-a'), liveAgents: [{ id: 'child-a' }] });
  assert.equal(plan.changed, true);
  assert.deepEqual(plan.actions, [
    { agentId: 'child-a', action: 'restore', reason: 'override-removed' },
  ], 'a removed row must reach the Host so it can write the dispatch route back');
});

test('planVolatileApply never emits a restore for a teammate that had no row', () => {
  const plan = planVolatileApply({
    previous: setOverride({}, 'child-a', CHOSEN),
    next: setOverride({}, 'child-b', CHOSEN),
    liveAgents: [{ id: 'child-a' }, { id: 'child-b' }, { id: 'child-c' }],
  });
  assert.deepEqual(plan.actions.map((item) => [item.agentId, item.action]), [
    ['child-a', 'restore'],
    ['child-b', 'select'],
  ], 'child-c never had a row: it stays zero-intervention');
});

test('planRestore picks the dispatch route and is a no-op when it is already current', () => {
  assert.deepEqual(planRestore({ isTeammate: true, dispatchRoute: DISPATCH, recordedRoute: CHOSEN }), {
    action: 'select', route: { ...DISPATCH }, reason: 'restore-dispatch-route',
  });
  assert.deepEqual(planRestore({ isTeammate: true, dispatchRoute: DISPATCH, recordedRoute: DISPATCH }), {
    action: 'noop', reason: 'already-on-dispatch-route',
  });
  assert.deepEqual(planRestore({ isTeammate: true, dispatchRoute: DISPATCH, recordedRoute: null }), {
    action: 'select', route: { ...DISPATCH }, reason: 'restore-dispatch-route',
  });
});

test('planRestore refuses a mainline agent and an unreadable descriptor', () => {
  assert.deepEqual(planRestore({ isTeammate: false, dispatchRoute: DISPATCH, recordedRoute: CHOSEN }), {
    action: 'noop', reason: 'not-a-teammate',
  });
  assert.deepEqual(planRestore({ isTeammate: true, dispatchRoute: null, recordedRoute: CHOSEN }), {
    action: 'noop', reason: 'no-dispatch-route',
  });
});

test('dispatchRouteOfAgent reads the descriptor triple off AgentModel options', () => {
  assert.deepEqual(dispatchRouteOfAgent({ model: { options: { provider: 'p', model: 'm', maxTokens: 7 } } }), {
    provider: 'p', model: 'm',
  });
  assert.deepEqual(dispatchRouteOfAgent({ model: { options: { provider: 'p', model: 'm', reasoningEffort: 'high' } } }), {
    provider: 'p', model: 'm', reasoningEffort: 'high',
  });
  assert.equal(dispatchRouteOfAgent({}), null);
  assert.equal(dispatchRouteOfAgent(null), null);
  assert.equal(dispatchRouteOfAgent({ get model() { throw new Error('detached'); } }), null);
});

test('isTeammateAgent reads the official session header, not a guess', () => {
  assert.equal(isTeammateAgent({ session: { header: { origin: 'subagent' } } }), true);
  assert.equal(isTeammateAgent({ session: { header: { parentSession: 'sess-parent' } } }), true);
  assert.equal(isTeammateAgent({ session: { header: { id: 'sess-main' } } }), false);
  assert.equal(isTeammateAgent({ session: {} }), false);
  assert.equal(isTeammateAgent({}), false);
  assert.equal(isTeammateAgent(null), false);
  assert.equal(isTeammateAgent({ get session() { throw new Error('detached'); } }), false);
});

test('planPreStepApply moves the next step onto the override, never the current one', () => {
  const table = setOverride({}, CHILD, CHOSEN);
  assert.deepEqual(planPreStepApply({ table, agentId: CHILD, selection: DISPATCH }), {
    action: 'select', route: { ...CHOSEN }, reason: 'override-not-yet-in-step',
  });
  assert.deepEqual(planPreStepApply({ table, agentId: CHILD, selection: CHOSEN }), {
    action: 'noop', reason: 'step-already-uses-override',
  });
  assert.deepEqual(planPreStepApply({ table, agentId: 'other', selection: DISPATCH }), {
    action: 'noop', reason: 'no-override',
  });
});

test('planVolatileApply tolerates live agents without an id', () => {
  const before = {};
  const after = setOverride({}, CHILD, CHOSEN);
  const plan = planVolatileApply({ previous: before, next: after, liveAgents: [null, {}, { id: '' }, { id: CHILD }] });
  assert.deepEqual(plan.actions.map((item) => item.agentId), [CHILD]);
});

// ---------------------------------------------------------------------------
// Config field helpers (volatile read/write, pure)
// ---------------------------------------------------------------------------

test('unwrapVolatile reads a schemastery reference and ignores plain values', () => {
  const ref = { get: () => ({ a: 1 }) };
  assert.deepEqual(unwrapVolatile(ref), { a: 1 });
  assert.equal(unwrapVolatile(true), true);
  assert.deepEqual(unwrapVolatile({ a: 1 }), { a: 1 });
  const throwing = { get() { throw new Error('boom'); } };
  assert.throws(() => unwrapVolatile(throwing), /boom/, 'an unreadable reference must not look like an empty value');
});

test('readShowSelector reads the switch and falls back on a corrupt or unreadable value', () => {
  assert.equal(readShowSelector(true), true);
  assert.equal(readShowSelector(false), false);
  assert.equal(readShowSelector({ get: () => false }), false);
  assert.equal(readShowSelector('true', true), true, 'a non-boolean falls back');
  assert.equal(readShowSelector(undefined, false), false, 'the caller decides the fallback');
  assert.equal(readShowSelector({ get() { throw new Error('boom'); } }, true), true, 'an unreadable reference falls back');
  assert.equal(readShowSelector({ get() { throw new Error('boom'); } }, false), false);
});

test('readOverrides unwraps the volatile reference and normalizes the table', () => {
  const ref = { get: () => ({ [CHILD]: CHOSEN, bad: { provider: 'p' } }) };
  assert.deepEqual(readOverrides(ref), { [CHILD]: { ...CHOSEN } });
  assert.deepEqual(readOverrides(undefined), {});
});

test('overrideSetOps and overrideDeleteOps build volatile-path mutations', () => {
  assert.deepEqual(overrideSetOps(CHILD, CHOSEN), [{
    op: 'set',
    path: [CONFIG_FIELDS.overrides, CHILD],
    value: { ...CHOSEN },
  }]);
  assert.deepEqual(overrideDeleteOps(CHILD), [{ op: 'unset', path: [CONFIG_FIELDS.overrides, CHILD] }]);
  assert.equal(CONFIG_FIELDS.overrides, 'overrides');
  assert.throws(() => overrideSetOps('', CHOSEN), TypeError);
  assert.throws(() => overrideDeleteOps(''), TypeError);
  assert.throws(() => overrideSetOps(CHILD, { provider: 'p' }), TypeError);
});

test('showSelectorOps writes the boolean at its own top-level volatile path', () => {
  assert.deepEqual(showSelectorOps(false), [{ op: 'set', path: ['showSelector'], value: false }]);
  assert.throws(() => showSelectorOps('false'), TypeError);
});

// ---------------------------------------------------------------------------
// session folding (what the Client reads through official namespaces)
// ---------------------------------------------------------------------------

const EVENTS = [
  { type: 'turn/start', data: { turn: 1 } },
  { type: 'subagent/descriptor', data: { version: 1, mode: 'continuable', label: 't', agentProvider: 'deepseek', agentModel: 'deepseek-chat', agentReasoningEffort: 'medium' } },
  { type: 'request/header', data: { header: { config: { provider: 'deepseek', model: 'deepseek-chat', reasoningEffort: 'medium' } }, reason: 'initial' } },
  { type: 'model/selection', data: { provider: 'deepseek', model: 'deepseek-reasoner', reasoningEffort: 'high' } },
  { type: 'turn/end', data: { turn: 1, reason: { kind: 'completed' } } },
];

test('dispatchRouteOfDescriptor reads the descriptor triple, effort optional', () => {
  assert.deepEqual(dispatchRouteOfDescriptor({ agentProvider: 'p', agentModel: 'm' }), { provider: 'p', model: 'm' });
  assert.deepEqual(dispatchRouteOfDescriptor({ agentProvider: 'p', agentModel: 'm', agentReasoningEffort: 'low' }), {
    provider: 'p', model: 'm', reasoningEffort: 'low',
  });
  assert.equal(dispatchRouteOfDescriptor(null), null);
  assert.equal(dispatchRouteOfDescriptor({ agentModel: 'm' }), null);
});

test('foldSessionRouteFacts extracts descriptor, newest header and newest selection', () => {
  const facts = foldSessionRouteFacts(EVENTS);
  assert.equal(facts.isTeammate, true);
  assert.deepEqual(facts.dispatchRoute, { provider: 'deepseek', model: 'deepseek-chat', reasoningEffort: 'medium' });
  assert.deepEqual(facts.lastRequestRoute, { provider: 'deepseek', model: 'deepseek-chat', reasoningEffort: 'medium' });
  assert.deepEqual(facts.lastSelection, { provider: 'deepseek', model: 'deepseek-reasoner', reasoningEffort: 'high' });
});

test('foldSessionRouteFacts reports a mainline session as not a teammate', () => {
  const facts = foldSessionRouteFacts([{ type: 'turn/start', data: { turn: 1 } }]);
  assert.equal(facts.isTeammate, false);
  assert.equal(facts.dispatchRoute, null);
});

test('foldSessionRouteFacts keeps the first descriptor and the newest of the rest', () => {
  const facts = foldSessionRouteFacts([
    { type: 'subagent/descriptor', data: { agentProvider: 'p', agentModel: 'first' } },
    { type: 'subagent/descriptor', data: { agentProvider: 'p', agentModel: 'second' } },
    { type: 'request/header', data: { header: { config: { provider: 'p', model: 'one' } } } },
    { type: 'request/header', data: { header: { config: { provider: 'p', model: 'two' } } } },
  ]);
  assert.equal(facts.dispatchRoute.model, 'first', 'the first descriptor is authoritative');
  assert.equal(facts.lastRequestRoute.model, 'two');
});

test('foldSessionRouteFacts survives malformed events', () => {
  const facts = foldSessionRouteFacts([null, 7, {}, { type: 'request/header' }, { type: 'request/header', data: { header: {} } }]);
  assert.equal(facts.isTeammate, false);
  assert.equal(facts.lastRequestRoute, null);
  assert.deepEqual(foldSessionRouteFacts('nope'), { isTeammate: false, dispatchRoute: null, lastRequestRoute: null, lastSelection: null });
});

test('effectiveRouteOf prefers the pending selection, then the header, then the descriptor', () => {
  const facts = foldSessionRouteFacts(EVENTS);
  assert.deepEqual(effectiveRouteOf(facts), {
    route: { provider: 'deepseek', model: 'deepseek-reasoner', reasoningEffort: 'high' },
    source: 'selection',
  });

  const headerOnly = foldSessionRouteFacts(EVENTS.slice(0, 3));
  assert.deepEqual(effectiveRouteOf(headerOnly), {
    route: { provider: 'deepseek', model: 'deepseek-chat', reasoningEffort: 'medium' },
    source: 'request-header',
  });

  const descriptorOnly = foldSessionRouteFacts([EVENTS[1]]);
  assert.deepEqual(effectiveRouteOf(descriptorOnly), {
    route: { provider: 'deepseek', model: 'deepseek-chat', reasoningEffort: 'medium' },
    source: 'descriptor',
  });

  assert.deepEqual(effectiveRouteOf(foldSessionRouteFacts([])), { route: null, source: 'none' });
});

// ---------------------------------------------------------------------------
// render predicate and entry-id publication
// ---------------------------------------------------------------------------

test('shouldRenderPicker renders for a continuable teammate with a live parent', () => {
  assert.deepEqual(shouldRenderPicker({ address: { mode: 'continuable' } }), { render: true, reason: 'continuable' });
  assert.deepEqual(shouldRenderPicker({ address: { mode: 'continuable' }, parentAvailable: true }), { render: true, reason: 'continuable' });
});

test('shouldRenderPicker refuses every official read-only state (P1.5 U-4)', () => {
  assert.deepEqual(shouldRenderPicker(null), { render: false, reason: 'not-a-subagent' });
  assert.deepEqual(shouldRenderPicker(undefined), { render: false, reason: 'not-a-subagent' });
  assert.deepEqual(shouldRenderPicker({ address: { mode: 'unknown' } }), { render: false, reason: 'unknown-readonly-composer' });
  assert.deepEqual(shouldRenderPicker({ address: { mode: 'one-shot' } }), { render: false, reason: 'one-shot' });
  assert.deepEqual(shouldRenderPicker({ address: { mode: 'external' } }), { render: false, reason: 'external' });
  assert.deepEqual(shouldRenderPicker({ address: {} }), { render: false, reason: 'mode-not-continuable' });
  assert.deepEqual(shouldRenderPicker({ address: { mode: 'continuable' }, parentAvailable: false }), { render: false, reason: 'parent-unavailable' });
});

test('readEntryId reads the published global and rejects anything else', () => {
  assert.equal(readEntryId({ [ENTRY_GLOBAL]: { entryId: 'teammate-picker' } }), 'teammate-picker');
  assert.equal(readEntryId({ [ENTRY_GLOBAL]: { entryId: null } }), null, 'the Host publishes null when it cannot resolve the id');
  assert.equal(readEntryId({ [ENTRY_GLOBAL]: {} }), null);
  assert.equal(readEntryId({ [ENTRY_GLOBAL]: 'teammate-picker' }), null, 'a bare string is not the contract');
  assert.equal(readEntryId({}), null);
  assert.equal(readEntryId(null), null);
  assert.equal(ENTRY_GLOBAL, '__DSH_TEAMMATE_PICKER__');
});
