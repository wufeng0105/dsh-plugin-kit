/**
 * Client half of the teammate model picker.
 *
 * This file is a classic browser script, not an ES module: the Harness page
 * evaluates it and it registers one lazy factory into the shared module table
 * (`window.__ModuleLoader__.load({ id, factory })`), exactly like the shipped
 * Client bundles. React comes from that table — never from a second install.
 *
 * ## What this half actually implements
 *
 * 1. it registers into `conversation.input.right` (a `list`, `session`-scoped
 *    slot) under its OWN entry id, because reusing a shipped id would claim
 *    and replace that cell ("Your cell key… reusing a shipped id puts you in
 *    THAT cell and replaces it", `Slots` catalog);
 * 2. it renders only for teammate sessions — the `subagent` field of the session
 *    snapshot is the official source (`SessionSnapshot.subagent`), and the
 *    P1.5 verdict narrows that further: this slot is not mounted at all under
 *    the official read-only composer (`unknown`/one-shot/external/parent
 *    unavailable), so the predicate below never widens rendering;
 * 3. it reads its Loader entry id from `globalThis.__DSH_TEAMMATE_PICKER__`,
 *    which the Host publishes through `webserver/index-inject`. The id cannot
 *    be derived in the browser: `settings.describe()` namespaces are Loader
 *    entry ids while the Client module graph is keyed by package name;
 * 4. it reports whether the Config form could be resolved, and renders a
 *    disabled seat with an explanation when it could not.
 *
 * ## NOT implemented in this file (P3 verdict: state it, do not imply it)
 *
 * The verifier's M-4 finding was that the missing Client surface had been
 * described as "structurally in place". It is not. These five things are
 * **absent**, and the acceptance criteria that depend on them (A2, A3, A7 判定 3,
 * A10, A13) cannot pass until they are written:
 *
 * | missing | what it would need | blocked acceptance |
 * |---|---|---|
 * | `modelCatalog` | `remote.session.modelCatalog()` → the two-level menu, `P_ok`/`E`/`P_fail` | A3 |
 * | `session/events` | `remote.session.events()` + `foldSessionRouteFacts` → current provider/model/effort text | A2 |
 * | `mutate` | `configForms.get(id).mutate(...)` with `overrideSetOps`/`showSelectorOps` | A4, A13 |
 * | `showSelector` | read the switch out of the form snapshot and return `null` from the seat when false | A10 |
 * | `restore` | `data-dsh-teammate-picker-restore`, `overrideDeleteOps`, disabled when no row | A7 判定 3 |
 *
 * `test/client.test.mjs` asserts that these five names are still absent, so the
 * day one is implemented the "unimplemented" note cannot silently become a lie.
 */
window.__ModuleLoader__.load({
  id: '@local/dsh-teammate-picker',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    /** Locale namespace owned by this plugin. */
    const NS = 'teammatePicker';
    /** Runtime key the Host publishes its entry id under. */
    const ENTRY_GLOBAL = '__DSH_TEAMMATE_PICKER__';
    /** This entry's own cell key inside `conversation.input.right`. */
    const ENTRY_ID = 'teammate-picker';
    /**
     * The Client surfaces this build does NOT implement. Kept as data (not a
     * comment) so the seat can publish it and `test/client.test.mjs` can assert
     * both directions: absent from the code today, and impossible to forget here.
     */
    const MISSING_SURFACE = Object.freeze(['modelCatalog', 'session/events', 'mutate', 'showSelector', 'restore']);

    /**
     * Mirror of `shouldRenderPicker` in `lib/core.js`.
     *
     * It is duplicated here because a classic script cannot import the module
     * half. `test/client-half.test.mjs` runs both over the same case table, so
     * drift between the two copies fails the suite instead of shipping.
     *
     * @param {object|null|undefined} subagent session snapshot `subagent` field
     * @returns {boolean} whether the picker belongs in this view
     */
    function rendersIn(subagent) {
      if (subagent == null) return false;
      const mode = subagent.address && subagent.address.mode;
      if (mode === 'one-shot' || mode === 'external' || mode === 'unknown') return false;
      if (mode !== 'continuable') return false;
      if (subagent.parentAvailable === false) return false;
      return true;
    }

    /**
     * Read the Host-published entry id.
     *
     * @returns {string|null} the id, or null when the Host could not publish one
     */
    function readEntryIdFromGlobal() {
      const published = Reflect.get(globalThis, ENTRY_GLOBAL);
      if (published === null || typeof published !== 'object') return null;
      const id = published.entryId;
      return typeof id === 'string' && id.length > 0 ? id : null;
    }

    /**
     * Resolve the Config form for this plugin, or `null` when it cannot be
     * reached. A missing entry id or a missing `configForms` service both land
     * here: the picker then renders a disabled seat with an explanation instead
     * of failing silently (`02-plan.md` R9 / `01-requirements.md` A10 decision 6).
     *
     * @param {object} ctx Client plugin context
     * @returns {object|null} the form controller
     */
    function resolveForm(ctx) {
      const entryId = readEntryIdFromGlobal();
      if (entryId === null) return null;
      const forms = ctx.configForms;
      if (forms === undefined || forms === null || typeof forms.get !== 'function') return null;
      try {
        return forms.get(entryId);
      } catch (error) {
        ctx.logger?.warn?.('teammate-picker: configForms.get() failed', error);
        return null;
      }
    }

    /**
     * The picker seat.
     *
     * Renders a disabled seat when the Config form is unavailable, and a
     * placeholder label otherwise. It intentionally does **not** show the
     * current model/effort (A2), open a menu (A3), or offer restore (A7 判定 3) —
     * see the file header for what those need and why they are absent.
     *
     * @param {object} props slot props: standard selector hooks, `t`, and the
     *   face injected below
     * @returns {object|null} the seat, or null outside a teammate view
     */
    function TeammatePicker(props) {
      const { useSession, t, settingsAvailable, entryId } = props;
      const subagent = useSession((snapshot) => snapshot.subagent);
      if (!rendersIn(subagent)) return null;

      const label = typeof t === 'function' ? t('seat.label') : 'Model';
      const unavailable = !settingsAvailable;
      return h('button', {
        type: 'button',
        'data-dsh-teammate-picker': '',
        'data-dsh-teammate-picker-state': unavailable ? 'unavailable' : 'idle',
        'data-dsh-teammate-picker-entry': entryId ?? '',
        // Machine-readable honesty: this build has no menu, no restore item and
        // no switch, so it advertises exactly that instead of an empty control
        // that looks clickable.
        'data-dsh-teammate-picker-implemented': 'seat',
        'data-dsh-teammate-picker-missing': MISSING_SURFACE.join(' '),
        'aria-label': label,
        title: unavailable
          ? (typeof t === 'function' ? t('seat.unavailable') : 'Settings unavailable')
          : (typeof t === 'function' ? t('seat.not-implemented') : 'Model switching is not part of this build'),
        // No menu exists yet, so the seat is never operable. A disabled button
        // is the honest rendering; a clickable one that does nothing is not.
        disabled: true,
      }, h('span', { 'data-dsh-teammate-picker-label': '' }, label));
    }

    return {
      inject: ['slots', 'locale', 'configForms'],
      apply(ctx) {
        // Locale: register the namespace this entry declares. Keeping the
        // `locale` option on the registration is what binds `t` to it.
        ctx.effect(() => ctx.locale.register(NS, {
          en: {
            'seat.label': 'Teammate model',
            'seat.unavailable': 'Model settings are unavailable in this session',
            'seat.not-implemented': 'Model switching is not part of this build',
          },
          zh: {
            'seat.label': '队友模型',
            'seat.unavailable': '本会话无法读写模型设置',
            'seat.not-implemented': '本版本不提供切换模型',
          },
        }));

        // Resolved once and memoized: the first successful `configForms.get()`
        // is kept, and a null result is retried on the next render. Boot order
        // between the page's inject rows and this module is not something the
        // Client can assume, so a one-shot read at apply time could latch a
        // false "unavailable".
        let form = null;
        let entryId = null;
        const ensureForm = () => {
          if (form !== null) return form;
          const resolved = resolveForm(ctx);
          if (resolved !== null) {
            form = resolved;
            entryId = readEntryIdFromGlobal();
          }
          return form;
        };

        ctx.slots.inject('conversation.input.right', () => ctx.slots.register({
          name: 'conversation.input.right',
          id: ENTRY_ID,
          order: 100,
          locale: NS,
          inject: () => {
            const ready = ensureForm();
            return {
              entryId: entryId ?? readEntryIdFromGlobal(),
              settingsAvailable: ready !== null,
            };
          },
        }, TeammatePicker));
      },
    };
  },
});
