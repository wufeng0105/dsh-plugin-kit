# fix-proofs.ps1 — one red -> green demonstration per fix.
#
# Each case: back up a file, apply ONE literal mutation that undoes the fix, run
# the check (must FAIL), restore byte-for-byte, run it again (must PASS).
# Literal string replacement, so an anchor that drifts throws instead of
# silently "passing".
#
# M-3 has no unit test of its own (it is a manifest fix), so its check is the
# real one: `npm pack` and look at the packed file list.
#
# Usage: pwsh -NoProfile -NonInteractive -File .\fix-proofs.ps1
$ErrorActionPreference = 'Stop'
$bundle = Join-Path $PSScriptRoot 'bundle'

function Run-Suite {
  Push-Location $bundle
  try {
    $text = (node --test 2>&1 | Out-String)
    return [pscustomobject]@{ Text = $text; Exit = $LASTEXITCODE }
  } finally { Pop-Location }
}

function Get-SuiteSummary {
  param([string]$Text)
  return (@($Text -split "`r?`n") | Where-Object { $_ -match '^\u2139 (tests|pass|fail) ' } | ForEach-Object { $_.Trim() }) -join ' ; '
}

function Get-FailingNames {
  param([string]$Text)
  return @($Text -split "`r?`n" | Where-Object { $_ -match '^\u2716 ' } | ForEach-Object { $_.Trim() } | Select-Object -Unique)
}

function Run-PackFileList {
  Push-Location $bundle
  try {
    $raw = (npm pack --dry-run --json 2>&1 | Out-String)
    $exit = $LASTEXITCODE
  } finally { Pop-Location }
  $json = $null
  try { $json = $raw | ConvertFrom-Json } catch { }
  $files = if ($json) { @($json[0].files | ForEach-Object { $_.path }) } else { @() }
  return [pscustomobject]@{ Exit = $exit; Files = $files; Raw = $raw }
}

function Invoke-Case {
  param(
    [string]$Id,
    [string]$Title,
    [string]$RelativePath,
    [string]$Anchor,
    [string]$Mutant,
    [string]$MustFailPattern
  )

  $target = Join-Path $bundle $RelativePath
  $backup = "$target.fixproof"
  Copy-Item -LiteralPath $target -Destination $backup -Force
  $original = [System.IO.File]::ReadAllText($target)
  if (-not $original.Contains($Anchor)) {
    Copy-Item -LiteralPath $backup -Destination $target -Force
    Remove-Item -LiteralPath $backup -Force
    throw "[$Id] anchor not found in $RelativePath"
  }

  Write-Host ''
  Write-Host ('=' * 78)
  Write-Host "CASE $Id  $Title"
  Write-Host "file: bundle/$RelativePath"
  Write-Host ('-' * 78)

  $red = $null
  try {
    [System.IO.File]::WriteAllText($target, $original.Replace($Anchor, $Mutant))
    $red = Run-Suite
  } finally {
    Copy-Item -LiteralPath $backup -Destination $target -Force
    Remove-Item -LiteralPath $backup -Force
  }

  $redNames = Get-FailingNames -Text $red.Text
  $hitExpected = ($redNames | Where-Object { $_ -like "*$MustFailPattern*" }).Count -gt 0

  Write-Host '--- RED (fix undone) ---'
  Write-Host "  $(Get-SuiteSummary -Text $red.Text)"
  foreach ($line in $redNames) { Write-Host "  $line" }
  Write-Host "  exit=$($red.Exit)"
  $verdictRed = if ($red.Exit -ne 0 -and $hitExpected) { 'OK (red as expected)' } else { 'PROBLEM (did not fail as expected)' }
  Write-Host "  -> $verdictRed"

  $green = Run-Suite
  Write-Host '--- GREEN (fix restored) ---'
  Write-Host "  $(Get-SuiteSummary -Text $green.Text)"
  Write-Host "  exit=$($green.Exit)"
  $verdictGreen = if ($green.Exit -eq 0) { 'OK (all pass)' } else { 'PROBLEM' }
  Write-Host "  -> $verdictGreen"

  return [pscustomobject]@{
    Id           = $Id
    Title        = $Title
    File         = "bundle/$RelativePath"
    RedExit      = $red.Exit
    RedFailures  = ($redNames -join ' | ')
    RedMatched   = $hitExpected
    GreenExit    = $green.Exit
    RedSummary   = (Get-SuiteSummary -Text $red.Text)
    GreenSummary = (Get-SuiteSummary -Text $green.Text)
    RedVerdict   = $verdictRed
    GreenVerdict = $verdictGreen
  }
}

function Invoke-ManifestCase {
  Write-Host ''
  Write-Host ('=' * 78)
  Write-Host 'CASE M-3  files[] must include lib/schema.js — checked by a real npm pack'
  Write-Host 'file: bundle/package.json'
  Write-Host ('-' * 78)

  $target = Join-Path $bundle 'package.json'
  $backup = "$target.fixproof"
  Copy-Item -LiteralPath $target -Destination $backup -Force
  $original = [System.IO.File]::ReadAllText($target)
  $anchor = '"lib/schema.js",'
  if (-not $original.Contains($anchor)) {
    Copy-Item -LiteralPath $backup -Destination $target -Force
    Remove-Item -LiteralPath $backup -Force
    throw '[M-3] anchor not found in package.json'
  }

  $red = $null
  try {
    [System.IO.File]::WriteAllText($target, $original.Replace($anchor, ''))
    $red = Run-PackFileList
  } finally {
    Copy-Item -LiteralPath $backup -Destination $target -Force
    Remove-Item -LiteralPath $backup -Force
  }
  $green = Run-PackFileList

  $redHasSchema = $red.Files -contains 'lib/schema.js'
  $greenHasSchema = $green.Files -contains 'lib/schema.js'

  Write-Host '--- RED (lib/schema.js removed from files[]) ---'
  Write-Host ("  packed: " + ($red.Files -join ', '))
  Write-Host "  lib/schema.js packed = $redHasSchema  (expected: False)"
  Write-Host '--- GREEN (files[] restored) ---'
  Write-Host ("  packed: " + ($green.Files -join ', '))
  Write-Host "  lib/schema.js packed = $greenHasSchema  (expected: True)"

  $verdictRed = if (-not $redHasSchema -and ($red.Files.Contains('lib/host.js'))) { 'OK (red as expected)' } else { 'PROBLEM' }
  Write-Host "  -> red: $verdictRed ; green: $(if ($greenHasSchema) { 'OK' } else { 'PROBLEM' })"

  return [pscustomobject]@{
    Id           = 'M-3'
    Title        = 'files[] lists lib/schema.js (verified by npm pack file list)'
    File         = 'bundle/package.json'
    RedExit      = if ($redHasSchema) { 0 } else { 1 }
    RedFailures  = ("packed without lib/schema.js: " + ($red.Files -join ', '))
    RedMatched   = (-not $redHasSchema)
    GreenExit    = if ($greenHasSchema) { 0 } else { 1 }
    RedSummary   = "lib/schema.js in tarball = $redHasSchema"
    GreenSummary = "lib/schema.js in tarball = $greenHasSchema"
    RedVerdict   = $verdictRed
    GreenVerdict = if ($greenHasSchema) { 'OK' } else { 'PROBLEM' }
  }
}

$results = @()

$results += Invoke-Case -Id 'B-1' `
  -Title 'restore writes model/selection(dispatch); undoing the decision breaks the A7 replay' `
  -RelativePath 'lib/core.js' `
  -Anchor "  if (!isTeammate) return { action: 'noop', reason: 'not-a-teammate' };" `
  -Mutant "  if (!isTeammate) return { action: 'noop', reason: 'not-a-teammate' }; return { action: 'noop', reason: 'restore-disabled-by-mutant' };" `
  -MustFailPattern 'A7/B-1'

$results += Invoke-Case -Id 'B-2' `
  -Title 'loadSchemastery accepts a function namespace; reverting to object-only breaks every install shape' `
  -RelativePath 'lib/schema.js' `
  -Anchor "    if (typeof namespace !== 'object' && typeof namespace !== 'function') continue;" `
  -Mutant "    if (typeof namespace !== 'object') continue;" `
  -MustFailPattern 'callable namespace'

$results += Invoke-Case -Id 'M-1' `
  -Title 'agent/pre-step fallback applies the override before continuing; skipping the apply breaks it' `
  -RelativePath 'lib/host.js' `
  -Anchor "        bridge.applyPreStep(payload?.agent, payload?.modelSelection);" `
  -Mutant "        void bridge;" `
  -MustFailPattern 'agent/pre-step applies an override'

$results += Invoke-Case -Id 'M-2' `
  -Title 'containment logging is try/catch-wrapped; bypassing that wrapper lets a throwing log sink escape' `
  -RelativePath 'lib/host.js' `
  -Anchor "function warnSafely(logger, message, detail) {" `
  -Mutant "function warnSafely(logger, message, detail) { logger?.warn?.(message, detail); return;" `
  -MustFailPattern 'never throws through a broken log sink'

$results += Invoke-ManifestCase

$results += Invoke-Case -Id 'M-4' `
  -Title 'the seat publishes what is missing; deleting the declaration breaks the M-4 test' `
  -RelativePath 'client.js' `
  -Anchor "'data-dsh-teammate-picker-missing': MISSING_SURFACE.join(' ')," `
  -Mutant '' `
  -MustFailPattern 'publishes the unimplemented list'

Write-Host ''
Write-Host ('=' * 78)
Write-Host 'SUMMARY (this text is pasted into 10-fix-report.md)'
Write-Host ('=' * 78)
foreach ($r in $results) {
  Write-Host ("{0,-4} red={1,-6} green={2,-6} [{3}]" -f $r.Id, $r.RedVerdict, $r.GreenVerdict, $r.RedSummary)
  if ($r.RedFailures) { Write-Host ("      failing: {0}" -f $r.RedFailures) }
}

Write-Host ''
$failed = @($results | Where-Object { -not $_.RedMatched -or $_.GreenExit -ne 0 })
if ($failed.Count -gt 0) {
  Write-Host "RESULT: $($failed.Count) case(s) did not show red -> green."
  exit 1
}
Write-Host 'RESULT: every case showed red -> green.'
exit 0
