// P3b read-only probe: extract a single file out of app.asar so the official
// Host sources can be read as ground truth (no writes outside %TEMP%).
// Usage: node _p3b-asar-read.mjs <asarPath> <innerPath> [outFile]
import { open } from 'node:fs/promises';
import { writeFile } from 'node:fs/promises';

const [asarPath, innerPath, outFile] = process.argv.slice(2);
if (!asarPath || !innerPath) {
  console.error('usage: node _p3b-asar-read.mjs <asarPath> <innerPath> [outFile]');
  process.exit(2);
}

const handle = await open(asarPath, 'r');
try {
  const sizeBuf = Buffer.alloc(8);
  await handle.read(sizeBuf, 0, 8, 0);
  const sizePicklePayload = sizeBuf.readUInt32LE(0); // should be 4
  const headerSize = sizeBuf.readUInt32LE(4);

  const headerPickle = Buffer.alloc(headerSize);
  await handle.read(headerPickle, 0, headerSize, 8);
  const headerPayloadSize = headerPickle.readUInt32LE(0);
  const jsonLength = headerPickle.readUInt32LE(4);
  const json = JSON.parse(headerPickle.subarray(8, 8 + jsonLength).toString('utf8'));

  const normalized = innerPath.replace(/\\/g, '/').replace(/^\/+/, '');
  const parts = normalized.split('/');
  let node = json;
  for (const part of parts) {
    if (!node || !node.files || !node.files[part]) {
      console.error('not found:', normalized, '| failed at', part);
      process.exit(3);
    }
    node = node.files[part];
  }
  if (node.files) {
    console.error('that path is a directory');
    process.exit(4);
  }
  const baseOffset = 8 + headerPayloadSize;
  const start = baseOffset + Number(node.offset);
  const buf = Buffer.alloc(Number(node.size));
  await handle.read(buf, 0, buf.length, start);
  if (outFile) {
    await writeFile(outFile, buf);
    console.log('wrote', outFile, buf.length, 'bytes');
  } else {
    process.stdout.write(buf);
  }
} finally {
  await handle.close();
}
