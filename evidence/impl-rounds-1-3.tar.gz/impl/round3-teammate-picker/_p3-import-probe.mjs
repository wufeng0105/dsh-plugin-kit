// P3 probe: does the bundle's lazy schemastery load resolve when the package is
// installed into a profile (linked OR copied), and does Config degrade?
const target = process.argv[2];
const url = new URL('file:///' + target.replace(/\\/g, '/')).href;
try {
  const m = await import(url);
  console.log('exports =', Object.keys(m));
  console.log('Config =', m.Config === undefined ? 'undefined (DEGRADED)' : 'schema object (' + typeof m.Config + ')');
  if (m.Config !== undefined && typeof m.Config.toJSON === 'function') {
    const json = m.Config.toJSON();
    const refs = json.refs ?? {};
    const root = refs[json.uid];
    console.log('root dict:', JSON.stringify(root?.dict));
    for (const [k, v] of Object.entries(root?.dict ?? {})) {
      const node = typeof v === 'string' ? refs[v] : v;
      console.log(`  ${k}: type=${node?.type} volatile=${node?.meta?.volatile === true}`);
    }
  }
} catch (e) {
  console.log('IMPORT FAIL', e.code, '|', String(e.message).split('\n')[0]);
}
