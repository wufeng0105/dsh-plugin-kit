# 02-plan.md — dsh-teammate-model-picker 开发计划（P1）

> 入口：P0 重审通过（`01-requirements.md` r2）+ P1.5 探针门已清零（`05-p1.5-probes.md`：已验 3 条 + U-6b / 已定降级 3 条 + U-6a / 无法判定 0 条）。
> 版本：**r3**（2026-11-08）。r2 → r3 = 按 M1–M9 回填 P1.5 结论（见 §8）；r2 的返工对象 = `03-gate-P0P1.md`（见 §7）。
> 出处引用沿用 `probes.md` 的 P-xx 索引；依赖编号 D-xx（D19 为 P1.5 新增）；UNVERIFIED 编号 U-xx（已全部出结论）。
> **本文件已按 `05-p1.5-probes.md` §3 定形**：单 bundle 双半 + 路径 B + 全官方通道。

## 1. 形态判断

**结论：单个 bundle，双半（Host + Web Client）插件；通道 = 全官方通道；存储 = 路径 B（插件侧覆盖表，落 Config volatile）。**

- 需要 Host 半：因为唯一的合规写入路径是宿主侧 `agent.model.select()`（P-14）——官方 RPC `session.selectModel` 对 `origin==='subagent'` 会话硬拒绝（P-13）且附带全局默认写入（P-13），两条硬约束都不允许走它。**注意（P1.5 回填）**：模型目录与推理等级**不再**从宿主 `ctx.llm` 取，改由 Client 侧官方 `session/modelCatalog()` 取（§1 落点表第二/三行；D6 已改写）。
- 需要 Client 半：UI 必须落在队友会话的输入行工具区（`conversation.input.right`，P-4/P-5），且要按会话是否为可继续子代理做条件渲染（P-6/P-7）；读通道与写通道也都在 Client 侧（官方 namespace + `configForms`）。
- 不需要：MCP、独立页面、新事件类型、自建 RPC、HTTP 路由。

**通道判定（U-1 显式改写；结论见 `05-p1.5-probes.md` §1/§3）**：

> 单个 bundle、双半插件。**通道 = 官方 Client 服务 / namespace；存储 = 路径 B（Q8「下一次唤醒生效」）的插件侧覆盖表，落在本插件 Config 的 volatile 字段；生效 = Host 端 `agent/created`（冷回填）+ `loader/volatile-update`（热应用）。不实现自建 Client→Host RPC，不注册 HTTP 路由，不对冷队友做 resume。**

具体落点（S2–S6 的实现口径）：

| 层 | 采用 | 官方出处 |
|---|---|---|
| 读「当前生效路由」 | Client 读官方 `modelSelection` 投影（`useProjection`）；冷会话由 `session/projections` 冷读兜底 | `dsh-api-remotes/lib/client.js:23629-23673`；`dsh-api-session-controller/lib/index.js:1833-1868` |
| 读「派发路由 descriptor」 | Client 调官方 `session/events`：先取尾页拿 `cursor`，再取 `{address:{kind:'subagent',…}, throughSeq:min(cursor,64)}` 的首段事件（descriptor 在子日志开头），自行 fold；冷安全（`throughSeq` 超过 `cursor` 会 bad-request，故先取尾页） | `dsh-api-remotes/lib/client.js:22451-22663`；`dsh-api-session-controller/lib/index.js:1789-1798,1924-1957,1154-1171`；descriptor 写入点 `dsh-subagent/lib/index.js:1806` |
| 读「模型目录 + 推理等级」 | Client 调官方 `session/modelCatalog()`（含 `reasoning.efforts[]`、`failures[]`） | `dsh-api-remotes/lib/client.js:22970-22987`；`dsh-api-session-controller/lib/index.js:473-522` |
| 写覆盖 / 恢复 / 开关 | Client `ctx.configForms.get(entryId).mutate([...])` → 官方 `settings.mutate`；目标 = 本插件 Config 的 **volatile** 字段 `overrides`（per-teammate 表）与 `showSelector`。**`entryId` 不在 Client 可见面内**，由 Host 半经 `webserver/index-inject` 下发（M9） | `dsh-client-ui-settings/lib/client.js:1252-1301,1165-1180`；`dsh-settings/lib/index.js:501-537`；`dsh-client-shortcuts/lib/index.js:13-21` |
| 下发本插件 entry id | Host `apply()`：`ctx.on("webserver/index-inject", table => table.push({kind:'global', name:'__DSH_TEAMMATE_PICKER__', value:{entryId: ctx.fiber.entry?.options.id}}))`；Client `Reflect.get(globalThis,'__DSH_TEAMMATE_PICKER__')` | `dsh-client-shortcuts/lib/index.js:13-21`；`dsh-client-ui-settings-models/lib/index.js:16-24`；读侧 `dsh-api-remote-access/lib/client.js:807` |
| 热队友生效 | Host `apply()` 监听 `loader/volatile-update`，重读 `config.overrides.get()`、`deepEqual` 比对后再对 live agent 调 `agent.model.select()`（同值 no-op） | `cordis-plugin-loader/lib/index.js:526-557`；`dsh-llm-deepseek/lib/index.js:2737-2748`（官方安全形态：重读 + try/catch + 比对） |
| 冷队友生效 | Host `agent/created` 监听内回填 `agent.model.select()`（首 step 前；串行 await） | `dsh-agent/lib/index.js:703-718`；`dsh-agent-loop/lib/index.js:1565-1593,586-609,618-622,666-672` |

**存储形态：定为路径 B（插件侧覆盖表 + 唤醒回填）。路径 A 作废。**

- **路径 B（采用）**：插件侧 per-teammate 覆盖表，落点 = 本插件 Config 的 **volatile** 字段 `overrides`（`z.dict(z.object({provider, model, reasoningEffort?}))`）；冷队友的待生效值先存这里，唤醒时由 `agent/created` 回填（D8/U-3）。客户 Q8 已裁定「下一次唤醒生效即可」（`00-client-answers.md:6`），因此这是**客户认可的现实路径**，不是降级绕路。持有条件（U-6b 已验（源码级）与 U-3 已验（源码级））：volatile 嵌套表可经 `settings.mutate` 写回并持久（`dsh-settings/lib/index.js:501-537`），且 `agent/created` 串行监听在 maintenance 相位内被 await，首 step 的 `model.current()` 在回填之后读取。
- **路径 A（作废，不再作为候选）**：原本设想对冷队友 `resume → select → dispose` 立即写入子会话日志。U-2 已定降级——官方冷继续 `coldResume` **要求父级 live**（`dsh-subagent/lib/index.js:2171-2172,2181-2203`），`resume()` 还会为未闭合回合补写 `turn/end`（`dsh-agent-loop/lib/index.js:1739-1740`），直接违反 U-2 自身的判据（无 turn/step 新增）。因此**「无需自建存储」的表述正式作废**：本插件有插件侧持久状态。
- 生效写入只用官方事件类型（`model/selection`），不新增事件；恢复派发路由 = 删除该条 override，下次唤醒按 descriptor 三元组路由（A7）。

**硬约束自查**：不改官方包（两半只使用既有 Service/Slot/namespace，P-1/P-4/P-24）；不引入新会话事件类型（`model/selection` 为官方既有类型，P-15）；无覆盖零介入（插件侧表为空时不注册任何写入、不调 `select`）；不动全局默认（绝不调用 `agentDefaultModel.saveSelection` 与 `session.selectModel`，P-13）。

## 2. 开发顺序与每步完成标志

| # | 步骤 | 内容 | 完成标志 |
|---|---|---|---|
| S1 | P1.5 探针门 | 清零 U-1…U-7（`probes.md` §4 回填 + `02-plan.md` §3.5 计划表） | `probes.md` 每条 UNVERIFIED 变为 已验 / 已定降级 / 明确接受者；SPEC P1.5 出口判据逐条过。**S1 期间除探针 bundle（`@local/t3-probe-*`，探完即删）外不写任何交付代码** |
| S2 | Host 骨架（**含 entryId 下发，M9**） | package.json + cordis.patch.yml + `apply()`（inject: agents）+ Config（**`showSelector` + `overrides` 全 volatile**）。**仅在 S1 清零后开始**；S1 期间为探针所建的 bundle/脚本属探针脚手架，探完即删，不进入本步交付物。**新增能力（M9）**：`ctx.on("webserver/index-inject", table => table.push({kind:'global', name:'__DSH_TEAMMATE_PICKER__', value:{entryId: ctx.fiber.entry?.options.id}}))`，把 Loader entry id 下发给 Client；`entryId === undefined`（非 Loader 装载）时记 warn，由 Client 落「设置不可用」态（R5） | `Config.listConfigs` 能查到本插件 entry 且 schema 含 `showSelector`/`overrides`（approval-free 探测）；页面 `globalThis.__DSH_TEAMMATE_PICKER__.entryId` 存在（R3 机判）；插件行 meta.title/description 与图标就绪（P-21） |
| S3 | 读路径（**Client 直连官方 namespace，不再有 Host RPC**） | 显示源 = Client 侧三路只读：① `ctx.sessions`/`useProjection('modelSelection')` 取当前生效路由；② 官方 `session/events`（先尾页拿 cursor，再 `throughSeq:min(cursor,64)` 首段）fold `subagent/descriptor` 三元组；③ 官方 `session/modelCatalog()` 取目录与 `reasoning.efforts`。**不实现 `describeTeammateRoute` RPC**（U-1 否证自建 namespace）。纯折叠逻辑（descriptor 三元组、最后一跳 `request/header`、覆盖判定）做成可单测纯函数 | 对一个已知队友（live 与 cold 各一）折叠结果与日志人工比对一致；主线会话无 `subagent/descriptor` → 明确「非队友」而非猜测 |
| S4 | 写路径 + 生效（**路径 B 唯一实现**） | ① `agent/created` 监听（serial）内做冷回填：从 `config.overrides.get()` 取该 `agent.id` 的条目 → `agent.model.select(三元组)`；**整段 listener 必须 try/catch，只记日志不外抛**（R4 硬要求：listener 抛错会使 `announce()` 拒绝 → 冷队友唤醒失败）。② `loader/volatile-update` 监听做热应用：重读 `config.overrides.get()` → `deepEqual` 与上次已应用值比对 → 变化才 `select()`；同样 try/catch。③ 不注册任何 resume+select 写入（路径 A 已作废）。④ 恢复派发路由 = 删除该条 override（下一跳按 descriptor 路由） | 代码评审确认两个 listener 均 try/catch（R4）；切换后（live）子会话日志新增 **恰好 1 条** `model/selection`（A4，选不同路由）；主线/全局默认 diff 为空；冷队友按 01-A8 判定 3 时点判（唤醒后首条 diff） |
| S5 | Client 骨架 | `client.js` 注册 `conversation.input.right`（`kind:'list'`、`scope:'session'`，**必须给自己的 `id`**，见 `Slots` 目录：list 座位复用 shipped id 会**替换**该格）；条件渲染 `useSession(s=>s.subagent)`：**`subagent !== null` 即渲染占位**，不得先按 `mode==='continuable'` 过滤（D14）；`mode==='unknown'`/one-shot/父级离线时官方只读 composer 顶替整条 composer chain，**slot 根本不渲染** → 选择器自然缺席（01 §3 第 13 条，M4）；挂 `data-dsh-teammate-picker` | A1/A12 机判通过；开关关闭后 A10 通过；`mode='unknown'` 时「不渲染」与「渲染但禁用」二者以 live 复核为准（`Slots.listSubTree` 在 P2 仍未通，T-3/T-4） |
| S6 | Client 菜单 | 两级菜单 + 「恢复派发路由」；**显示源 = Client 侧官方 namespace（S3），不再有 `describeTeammateRoute`**；写入口 = `ctx.configForms.get(entryId)`（entryId 来自 `Reflect.get(globalThis,'__DSH_TEAMMATE_PICKER__')`，M9）→ `settings.mutate`；`entryId` 缺失 → 控件渲染为「设置不可用」禁用态并给文案，不静默失败（R5）；文本走 `ctx.locale`（P-22，U-5 已验） | A2/A3/A7 机判通过；写入口接通；`entryId` 缺失路径有可见降级 |
| S7 | 端到端场景 | 按 A5/A6/A8/A9/A13 实跑（真实队友 + 模拟耗尽路由；A8 按选定路径的口径，见 01-A8 判定 3） | 每条机判命令与输出进自验说明；A8 重启复测通过 |
| S8 | 交付整理 | 逐条验收命令固化、`files` 校验、已知问题清单 | SPEC P2 出口判据逐条过；交接给 P3 |

**顺序约束（改自 03 报告 P1-M3）**：S1 → S2/S3 → S4/S5 → S6 → S7 → S8 严格串行进入功能开发；**S1 未清零前不写任何功能代码**（探针除外）。原计划「S2/S3 可先行（纯读）」作废：S2 是 Host 骨架、S3 是读路径，都是功能代码，一律排在 S1 之后。S1 已清零（`05-p1.5-probes.md` §0/§6：已验 3 条 + U-6b，已定降级 3 条 + U-6a，无法判定 0 条）。**回填后的依赖链**：S2 ← U-6b（Config 落点）+ M9（entryId 下发）+ U-1（通道形态）；S3 ← U-1（Client 可直连官方 namespace）+ U-4（slot 与 props）；S4 ← U-3（`agent/created` 先于首 step，已验）+ U-6b；S5 ← U-1 + U-4；S6 ← S4+S5+U-5。

## 3. 依赖清单

格式：引用点 → 为什么非它不可 → 探测结论（已验 / UNVERIFIED→U-xx）→ 不成立时降级。**结论列已按 `05-p1.5-probes.md` 回填（M2）；每条都回指 §1 的「通道 = 官方 namespace / 存储 = 路径 B」。**

**Host 侧**

| D | 引用点 | 不可替代性 | 结论（P1.5 回填后） | 降级 |
|---|---|---|---|---|
| D1 | `ctx.agents.get(id)`（P-1） | 定位 live Agent —— 热应用时把 `select()` 打到正确的 agent 上 | 已验（Service 目录 + 类型契约）；**不再承担 `resume()` 冷恢复职责**（路径 A 已作废） | 无（无 agents 服务 = 本插件整体不可用，报安装前提） |
| D2 | `agent.model.select()/current()`、`agent.options`（P-14） | 路径 B 的唯一写入机制（回填/热应用）；恢复派发路由 = 删条目而非写回 descriptor | 已验（README + loop/agent 源码） | 无 |
| D3 | `model/selection` 投影语义（pending→lastUsed，P-15） | 路径 B 下「重启后控件显示」与「无覆盖零介入」的宿主机制基础；**U-2 已定降级后，A8/A9 的日志侧断言改由 `agent/created` 回填 + `select()` 同值 no-op 承担** | 已验 | 无 |
| D4 | `subagent/descriptor` 事件（`agentProvider/agentModel/agentReasoningEffort`，P-15；fold 语义见 `dsh-subagent/lib/index.js:691-707`） | 「派发路由」的唯一持久出处，恢复动作的基准 | 已验 | 缺 descriptor（老日志）→ 恢复项置灰 + 提示，不伪造路由 |
| D5 | 官方 Client namespace `remote.session`（`session/events`、`session/projections`、`session/modelCatalog`） | 冷会话读路由/选择/目录，**不得为此唤醒 Agent**；P1.5 把读通道从 Host `sessionQuery` 改为 Client 侧官方 namespace（M3） | 已验（源码/契约级，`dsh-api-remotes/lib/client.js:22451-22663,22970-22987,23629-23673`） | namespace 不可得 → 冷会话只显示「未知」，切换按钮禁用（S5/D14 的 unknown 收口） |
| D6 | 官方 Client namespace `remote.session.modelCatalog()`（含 `reasoning.efforts[]`、`failures[]`） | 全量目录 + 推理等级的唯一来源（REQ 边界；A3 机判的基准集合来源）；P1.5 改为 Client 侧取（M3） | 已验（源码级，`dsh-api-session-controller/lib/index.js:473-522`） | 某 provider 列目录失败 → 单列「加载失败」条目（01-A3 判定 3 的 `P_fail`），不拖垮整目录 |
| D7 | 切换前能力校验 | A13「失败干净」 | **已定降级**：Widget 侧不做预检（Client 半无 `ctx.llm`），失败由回合自然报错；A13 判据不要求预检 | 无进一步降级 |
| D8 | `agent/created`（serial，`source: SessionStartSource`，P-16；契约原文「A throw or rejection fails creation」） | **路径 B 的冷回填入口**（唯一实现） | **已验（源码级）→ U-3 成立**：监听在 maintenance 相位内被 await，首 step 的 `model.current()` 在其后读取（`dsh-agent/lib/index.js:703-718`、`dsh-agent-loop/lib/index.js:1565-1593,586-609,618-622,666-672`） | **listener 必须 try/catch（R4 硬要求，客户已批准）**：抛错会拒绝 `announce()` → 冷队友唤醒失败 |
| D9 | Host Config（`showSelector` + `overrides`）+ 安装 meta（P-21） | 显示开关与覆盖表的持久化落点（客户 Q2 已裁定 Config 层；A10 已获客户批准放插件自带 UI，见 `00-client-answers-2.md:5`） | **U-6 拆分：6b 已验（源码级）**（volatile 嵌套 dict 可经 `settings.mutate` 写回并持久，`dsh-settings/lib/index.js:501-537`）；**6a 已定降级**（Settings 不再自动呈现 → 开关移入插件自带 UI） | 6a 的降级**已获客户批准**（A10 呈现位）；6b 不成立 → 路径 B 无落点，须回客户（本项已验，不触发） |
| D10 | `ctx.agents.resume` 对 subagent-origin 会话的可用性 | ~~路径 A 前提~~ | **已定降级（弃用）**：官方 `coldResume` 要求父级 live，且 `resume()` 会为未闭合回合补写 `turn/end`（`dsh-subagent/lib/index.js:2171-2172,2181-2203`；`dsh-agent-loop/lib/index.js:1739-1740`）→ 路径 A 作废，D10 从依赖清单移除（保留行仅为留痕） | 不适用（不再走该路径） |
| D11 | `ctx.webServer.register`（HTTP 路由兜底通道，P-23） | ~~U-1 兜底~~ | **已定降级（不需要）**：官方 namespace 已覆盖读写，**不注册任何 HTTP 路由**（U-7 结论） | 不适用（保留行仅为留痕；未来确需 HTTP 时单独立项重探） |

**Client 侧**

| D | 引用点 | 不可替代性 | 结论（P1.5 回填后） | 降级 |
|---|---|---|---|---|
| D12 | Slot `conversation.input.right`（`kind:'list'`、`scope:'session'`，P-4/P-5；目录原文见 `Slots` provider） | REQ 指定的「输入行工具区」官方落点 | **契约 = 已验**（`dsh-client-ui-conversation/lib/client.js:22958-22998`、渲染点 `:22107-22110`；`Slots` 目录：list 座位「reusing a shipped id puts you in THAT cell and replaces it」→ **必须给自己的 `id`**）；**队友视图渲染 = 已定降级（契约已验、live 未测，U-4）**：普通 composer 挂载时渲染；`mode='unknown'`/one-shot/父级离线时官方只读 composer **顶替整条 composer chain**，slot 不渲染（`dsh-client-ui-subagent/lib/client.js:1220-1228,1273-1278`、`dsh-client-ui-conversation/lib/client.js:20583-20591`） | 队友视图不渲染的场景 = 官方只读态（01 §3 第 13 条范围收窄），**不做降级绕路**；P2 live 用 `Slots.listSubTree` 复核（T-3/T-4 仍超时） |
| D13 | Slot 标准 props（`useSession`/`sessionId`/`useProjection`，P-5；目录原文：`conversation.input.right` 的 `standardProps` 含这三项） | 条件渲染与当前会话定位 | **契约 = 已验**（`dsh-cordis-client-runner/lib/client.js:4063-4083` 列出 `useSession`、`sessionId`、`useProjection`）；**live 未测并入 U-4 降级** | 不可用 → 由 Client 侧 `ctx.sessions` 直接判定（同在本进程，无需 Host 通道） |
| D14 | `useSession` 快照 `subagent`（`{address, parentAvailable?} | null`，P-6/P-7）+ `ctx.sessions.subagentAddress`（`dsh-api-session-controller/lib/client.js:3036-3054`） | 客户端判定「队友会话」的官方事实源 | 已验（源码级） | **渲染规则（按 U-4 收口，M4）**：`s.subagent !== null` → 渲染；`null` → 不渲染；**禁止**先按 `mode==='continuable'` 过滤（否则 `mode='unknown'` 的冷会话根本不渲染）。**删除旧规则「unknown 也渲染占位」**：`mode='unknown'` 与 one-shot、父级离线同属「官方只读 composer 顶替」，slot 不渲染（与 01 §3 第 13 条一致，04-O1 收口） |
| D15 | Client 模块装载契约（`dsh.client` manifest + `__ModuleLoader__` + `ctx.slots`，P-24） | 第三方 bundle 前端进场的唯一官方形态 | 已验（官方模板） | 无 |
| D16 | `ctx.locale.register/bind`（P-22） | REQ 要求文案本地化 | **已验（源码/契约级）**：官方 `ui-subagent` 以 `inject:['locale']` + `register(NS,{zh,en,…})` 使用（`dsh-client-ui-subagent/lib/client.js:1213-1219,1234-1243`） | live 未测（client inspect 超时）；兜底 = zh/en 双语硬编码（Q10 仍满足 REQ） |
| D17 | Client→Host 通道 | UI 触发的所有读写 | **已验（源码/契约级）**：**不自建 namespace**（Client `ctx.remote.$mount()` 只接受生成物）；改用官方 namespace：读 `remote.session.*`，写 `ctx.configForms.get(entryId)` → `settings.mutate`（`dsh-client-ui-settings/lib/client.js:1252-1301,1165-1180`） | 无（官方通道即通道）；`entryId` 缺失走 R5 可见降级 |
| D18 | 插件侧 per-teammate 覆盖表（**落点定为 Config volatile `overrides`**，`z.dict(z.object({provider, model, reasoningEffort?}))`） | 冷队友没有 live Agent，覆盖的待生效值必须先有落点，否则 Q8 的「下次唤醒生效」无处可存 | **U-6b 已验（源码级）**：`z.dict(...).volatile()` 是官方既有形态（`dsh-llm-deepseek-account/lib/index.js:15`）；嵌套路径 `set/unset` 经 `settings.mutate` 会被 `isVolatilePath` 逐段放行（`dsh-settings/lib/index.js:153-158,488-537`）；持久经 `configEditor.edit` → profile patch | 不可用 → 路径 B 不成立 = 形态不成立（须回客户）；本项已验，不触发 |
| **D19（新增）** | `webserver/index-inject` + `ctx.fiber.entry?.options.id`（M9） | **把 Loader entry id 送到 Client 的唯一官方机制**：Client 侧无 `fiber.entry`，boot graph 行 id 是**包名**而非 entry id（`dsh-client-modules/lib/index.js:957-961`），而 `configForms.get(entryId)` 要的正是 entry id | 已验（源码级）：官方普通插件先例 `dsh-client-shortcuts/lib/index.js:13-21`、`dsh-client-ui-settings-models/lib/index.js:16-24`；读侧先例 `dsh-api-remote-access/lib/client.js:807`；渲染侧 `dsh-host-webserver/lib/index.js:31-33` 把 `{kind:'global'}` 渲染成 `globalThis[name]=value` | `entryId === undefined`（非 Loader 装载）→ Host 记 warn，Client 落「设置不可用」禁用态，不静默失败（R5） |

> D8 与 D10 曾是同一条「冷路径」的两个分支。P1.5 已定：**只保留 D8（路径 B），D10（路径 A）作废**。S4 只注册 `agent/created` 回填 + `loader/volatile-update` 热应用，**不得注册任何 resume+select 写入**，否则同一次切换可能产生两条 `model/selection`，违反 A4「新增 1 条」。
> 新增 **D19** 是 M9 的落点：上一轮写路径隐含「`entryId` 在 Client 可见面内」这一未验证前提，P1.5 第二轮补探证明不成立，故补入依赖清单（依赖总数 18 → 19）。

### 3.5 P1.5 探针门计划（每条 UNVERIFIED：探什么 / 怎么探 / 清零判据 / 不成立时降级 / **对验收的影响**）

> **状态：已清零（2026-11-08）。** 逐条结论见 `05-p1.5-probes.md` §2/§4；三态分布 = **已验 3 条（U-1、U-3、U-5）+ U-6b** ／ **已定降级 3 条（U-2、U-4、U-7）+ U-6a** ／ **无法判定 0 条**。下表保留为「探针计划」原样（计划与结论分开，不把结论写成事后计划），每行末尾加「**结论**」标注回填后的实际结果。注意：本轮**全部证据等级为源码/契约级，无运行时证据**；运行时缺口见 §4 R1–R5。

| U | 探什么 | 怎么探 | 清零判据 | 不成立时降级 | 对验收的影响 | **结论（回填）** |
|---|---|---|---|---|---|---|
| U-1 | bundle 的 Client 半能否调用本包 Host 半（`ctx.remote.<本服务>`） | ①只读：查 `dsh-cordis-client-runner` client.js 对 bundle 型 client 的 ctx 注入面（P-25 已列旁证）；②最小验证：装探针 bundle（仅一个 @Remote 方法 + 一个调用它的 client 按钮），观察返回 | 探针按钮拿到 Host 返回值（命令+输出记录） | 兜底 D11：`ctx.webServer.register` HTTP 路由 + 同源 fetch（先探 U-7）；两路均不通 → 形态不成立，上报客户 | **不成立且 U-7 也不成立 → 形态不成立，A1–A16 全部不可交付**；U-1 成立但走了 HTTP 兜底 → A2/A3/A7 判定改经 HTTP 取数（判据不变，取数方式记入自验说明） | **已验（源码/契约级）**：自建 namespace **不成立**（`$mount` 只接受生成物），但**官方 namespace 足够**（`inject:['remote','remote.settings','remote.session']` 即可用，30+ 处官方先例）。通道层改为官方 namespace（§1），HTTP 兜底**不需要**（D11 关闭） |
| U-2 | 对 subagent-origin 冷会话能否安全 `ctx.agents.resume`（root 身份）并 `select` 后 `dispose` | 构造一个可继续测试队友并使其非驻留；探针顺序：读会话存在 → resume(descriptor agentOptions) → `agent.model.select(测试值)` → dispose → `sessionQuery.readSession` 读日志 | 日志新增恰好 1 条 `model/selection`；无 turn/step/assistant 新增；无写锁错误；再次正常唤醒不受影响 | 转路径 B（§1）：下一次唤醒生效（**客户裁定 Q8，非降级**）= 插件侧 pending 存储 + `agent/created` 回填（D8+U-3）；冷会话 UI 明示「下次唤醒生效」 | **决定形态**：成立 → A8/A5 冷场景按路径 A 口径，A9 零介入含 resume 探针残留为零；不成立 → A8 首个唤醒路由口径依赖 U-3（01-A8 判定 3），且插件出现持久状态（§1 路径 B），A9 判据需把 pending 存储写入排除在「会话日志 diff」之外（存储在插件侧、不进子会话日志，A9 判据本身不受影响，但须在自验说明记录存储内容） | **已定降级（弃用路径 A）**：官方 `coldResume` 要求父级 live，且 `resume()` 会补写 `turn/end` → 自毁判据。**转路径 B**（客户 Q8 已裁定），不再探 |
| U-3 | `agent/created` 监听内 `select()` 是否先于首 step（冷唤醒补齐路径，仅路径 B） | 探针：冷唤醒前注入待回填值，唤醒时队列一条消息；对比首跳 `request/header.config` | 首跳路由 = 回填值；监听异常时不影响回合（失败可观察） | **不设普通降级**：回填晚于首 step → 触发 P1-B2 流程（书面向客户申请「第二次唤醒」豁免，或改其他首跳前生效机制）；未获豁免 → 路径 B 不具备交付条件，回到 U-2 换角度重探或上报客户 | **不成立 → A8 判定 2（首个 `request/header.config` = 覆盖路由）不可达**；A5 冷场景的「换后可继续」退化为「第二次唤醒才继续」，与客户 Q8 冲突，必须豁免或改机制 | **已验（源码级）**：监听在 `runMaintenance` 相位内被 await，wake 被挂起，首 step 的 `model.current()` 在回填之后读取。**同时得到 R4 硬要求**：listener 抛错会拒绝 `announce()`（`agents` 契约原文）→ 必须 try/catch |
| U-4 | `conversation.input.right` 内 `useSession` 可用且 `subagent` 快照形态成立；队友视图确实渲染该 slot（**D12 的 live 缺口并入本条**） | live 探测优先：重试 client Slots.listSubTree（换页面焦点/重连后）；不行则最小探针 bundle 注册该 slot 并 `console.log(props)`（探针可用 console，交付代码不含） | 探针组件在主线会话不渲染、在队友会话渲染且 props 含 subagent.address（mode 值记录）；记录 slot 容器选择器常量（01 §6 `SLOT_CONTAINER`） | 降级：不依赖 useSession，由 Host 通道（U-1）下发「当前会话是否队友」判定；slot 若在队友视图不渲染 → 换 `conversation.composer.bar` 系其他 session-scoped slot（D12 降级） | **不成立 → A1/A11/A12 全部不可判**（DOM 判据依赖该 slot 的渲染）；成立 → A16 判定 1 的 `SLOT_CONTAINER` 固化，判定 1 才能完整执行 | **已定降级（契约已验 + 范围收窄）**：普通 composer 挂载时**会**渲染；`mode='unknown'`/one-shot/父级离线时官方只读 composer 顶替整条 chain → slot 不渲染（与 01 §3 第 13 条一致，04-O1 收口）。`SLOT_CONTAINER` 建议 = `[data-conversation-region="composer"]`。**live 未测（T-3/T-4 超时）** |
| U-5 | `ctx.locale` 可被第三方 bundle client 注入并生效 | 探针 bundle：`inject:['locale']` + `register('t3-picker',{zh,en})` + 渲染 `bind('t3-picker')('key')` | 渲染文本随 Settings 语言切换 | 降级：zh/en 硬编码（Q10 仍满足 REQ） | 不成立 → A2 判定 3 的占位值改为硬编码同值（判据不变）；其余验收不受影响（locale 是 REQ 要求 4 之外的实现项） | **已验（源码/契约级）**：`ctx.locale` 是官方 Client 服务，`inject:['locale']`+`register` 与官方 `ui-subagent` 同构；无需双语硬编码。live 未测 |
| U-6 | 插件 Config 布尔字段在 Settings/插件页自动呈现并可改 | 装探针 bundle 带 `showSelector` Config → `Config.listConfigs` 查 schema → 在 Settings 页观察表单（若不可视，检查 settings/document-updated 事件）。**第二项（D18 前置）**：同一探针 bundle 加一个嵌套对象/数组字段（模拟 per-teammate pending map），经 `configEditor` 写回后重启读取 | schema 可查 + 表单可见可改 + 重启保持；嵌套字段写回后值保持（D18 能力面） | 降级：开关移入菜单内 + `configEditor` 写回——**与客户 Q2 裁定不符，启用前必须取得客户同意**（A10 的落点口径也会变）；嵌套字段不支持 → D18 不可用，走 D18 降级 | 不成立且客户不同意降级 → A10 不可交付；同意 → A10 判定 3 的读取方式改为 `configEditor` 读回，口径记入自验说明；嵌套项不成立 → A8/A5 冷场景依赖的路径 B 不可交付（D18 降级） | **6a 已定降级**：Settings 表单不会自动呈现 `showSelector`（`autoGenerate` 无 shipped client 使用）→ 开关移入**插件自带 UI**，**客户已批准**（`00-client-answers-2.md:5`；仍写 Config volatile、仍持久）。**6b 已验（源码级）**：volatile 嵌套 dict 可经 `settings.mutate` 写回、持久、重启保持（官方 `modelOverrides: z.dict(...).volatile()` 为同款先例） |
| U-7 | `ctx.webServer.register` 的路由可被 GUI 页面同源 fetch 调用（路径、鉴权、返回码） | 探针 bundle 注册 `/x-probe/ping` 返回 `{ok:true}`；页面 fetch 并记录状态码 | fetch 200 且带宿主鉴权语义（401/403 行为记录） | 通道判不可用 → 若 U-1 首选也不通，形态不成立（R1 兜底失败） | **不成立且 U-1 也不成立 → 形态不成立，A1–A16 全部不可交付**（同 U-1）；仅 U-7 不成立而 U-1 成立 → 无影响 | **已定降级（不需要）**：官方 namespace 已覆盖读写 → **不注册 HTTP 路由**。`webServer` 契约无鉴权语义、同源 fetch 未实测，但已不再是形态依赖 |

探针纪律（SPEC P1.5）：只装探针、不写功能代码；探针 bundle 用一次性命名（`@local/t3-probe-*`），探完即删并在 `probes.md` §4 记录；需要安装前先向负责人申请。**本轮执行情况**：未安装任何探针 bundle，全部结论为源码/契约级（`05-p1.5-probes.md` §7 合规记录）。

## 4. 风险清单

> 编号口径：本节 **R1–R7 沿用 P1 原编号**（便于与 §7 返工记录对照）；**R8–R12 为 P1.5 新增**，对应 `05-p1.5-probes.md` §5 的缺口表（05 报告里用 R1–R5 编号，**两套编号不同名，引用时必须写「05-R4」或「本表 R8」**）。

| # | 风险 | 等级 | 应对 |
|---|---|---|---|
| R1 | ~~Client→Host 通道对第三方 bundle 不成立（U-1）~~ **已关闭**：自建 namespace 不成立，但官方 namespace 足够 | 已关闭（原高） | 形态改为「全官方通道」（§1）。剩余风险转入 R8（`entryId` 下发）与 R9（运行时缺口） |
| R2 | ~~冷队友无法写入（U-2）~~ **已转化为设计**：路径 A 作废，改路径 B | 已关闭（原高） | 路径 B = 覆盖表 + `agent/created` 回填（§1）。**不再设「冷时禁选」分支**（客户 Q8 未裁定禁选） |
| R3 | 回填时序（U-3，仅路径 B）：`agent/created` 监听内的 select 晚于首 step → 覆盖第一跳失效 | 已关闭（原中） | U-3 已验（源码级）：监听在 maintenance 相位内被 await。若运行时反证 → P1-B2 流程（客户豁免），**不得用「再发一次继续」替代** |
| R4 | 队友会话 UI 形态：`mode='unknown'`/one-shot/父级离线时官方只读 composer 顶替整条 composer chain，`conversation.input.right` **不渲染** | 低（已收窄） | 需求侧范围收窄（01 §3 第 13 条），不做降级绕路；A1/A5 等均在普通 composer 挂载（父级在线）场景执行 |
| R5 | 官方升级破坏 slot/字段/事件假设 | 中 | 全部断言带 `文件:行` 出处；P5 复检脚本按出处重探（SPEC P5） |
| R6 | 误触全局默认（官方 `selectModel` 的附带行为，P-13） | 低 | 代码禁用 `ctx.remote.session.selectModel` 与 `agentDefaultModel.saveSelection`；A4 机判兜底 |
| R7 | ~~两条路径并行启用导致重复写入~~ **已消除**：路径 A 作废 | 已关闭（原低） | S4 只注册 `agent/created` 回填 + `loader/volatile-update` 热应用；`select()` 同值 no-op 由官方保证（`dsh-agent/lib/index.js:196-199`） |
| **R8** | **`agent/created` listener 抛错会拒绝冷队友唤醒**（**05 报告 R4，客户已批准为硬要求**，`00-client-answers-2.md:7`）：`announce()` 契约原文「a listener failure rejects」（`dsh-agent/lib/index.js` 契约 + `cordis_inspect_query(Event,'agent/created')`：「A throw or rejection fails creation and skips later listeners」） | **高（P2 硬要求）** | **S4 的 `agent/created` 监听体必须整段 `try/catch`，错误只写日志、绝不外抛**；S4 完成标志含此项；S7 加「注入故障仍能唤醒」反向用例。`loader/volatile-update` 监听同样 try/catch（照抄 `dsh-llm-deepseek/lib/index.js:2737-2748` 的官方安全形态：重读 config + try/catch + `deepEqual` 比对后再动作） |
| **R9** | **`entryId` 只能经 `webserver/index-inject` 下发**（Client 侧无 `fiber.entry`；boot graph 行 id 是包名，`dsh-client-modules/lib/index.js:957-961`） | 中 | M9/S2 实现下发（D19）；`ctx.fiber.entry?.options.id === undefined` → Host 记 warn，Client 落「设置不可用」禁用态 + 文案，**不静默失败**；S7 覆盖 |
| **R10** | **热应用依赖 `loader/volatile-update` 能到达本插件 ctx**（05 报告 R1，风险已下调为「低」） | 低 | 6 个官方 Host 插件在本 ctx 直接监听该事件（`dsh-experimental-speech-to-text/lib/index.js:21-23` 等，`05-p1.5-probes.md` §4.8(4)）→ 非本插件特例。兜底：若事件不到达，live 队友退化为「下次唤醒生效」（仍满足客户 Q8）。S7 机判 |
| **R11** | **U-6a 呈现位变化**：`showSelector` 不在 Settings 自动表单，改为插件自带开关 | 已解决（客户已批准） | `00-client-answers-2.md:5` 明确批准「插件自带 UI（挂官方座位）」；A10 判据改为「功能存在 + Config volatile 持久」，不按 Settings 页可见判（01-A10 已回填） |
| **R12** | **构建期缺运行时验证**：读通道（`session/events`/投影冷读）、写通道（`settings.mutate` 对嵌套 dict 的接受度）、`configForms` 服务可用性、slot 实际 DOM、index-inject 是否到达页面 | 中 | P2 各项机判：`Config.listConfigs {"entry":<本插件 entry>}` 查 schema、`settings.describe` 读回嵌套表、`Slots.listSubTree` 查 slot、页面 `globalThis.__DSH_TEAMMATE_PICKER__` 存在；S7 用真实队友复测。**由 P2 执行、P3 验收；本轮（P2 最小切片）只做离线可验部分，运行时项显式留空** |

## 5. 内部一致性自检（P1 + P1.5 回填后）

- 数字口径：验收 16 条（A1–A16）＝`01-requirements.md` §2；依赖 **19 条（D1–D19，D19 为 P1.5 新增，见 §8-M9）**；UNVERIFIED **7 条全部出结论（U-1…U-7：已验 3 + 已定降级 3 + U-6 拆分 6a降级/6b已验，无法判定 0）**；歧义 10 条。`01-requirements.md` 与本文一致；`probes.md` §4 的 U 表同为 7 条（04-O8 措辞已改）。
- **客户裁定回填状态：Q2、Q8 已裁定、已回填；A10 呈现位（U-6a 降级）已获客户批准（`00-client-answers-2.md:5`）；U-4 收窄已获接受（`:6`）；U-2 路径 B 已获接受（`:7`）；R4/R8 try/catch 已升为硬要求（`:7`）。待客户裁定 0 条。**
- 「队友」口径（`origin==='subagent'` 且 `mode==='continuable'`，父级在线）与 Q1/A11/A12/01 §3 第 13 条一致。
- `model/selection` 定性（官方既有事件、会话级持久）在 D3/A15/§1 路径 B/S4 处一致。
- **存储口径**：§1 已改为**无条件句**——路径 B 是唯一实现，插件有插件侧持久状态（Config volatile `overrides`）。「无需自建存储」已作废（M1）；D3/D8/D18/R2/R3/R10 的表述均回指 §1，无残留条件分支。
- **通道口径**：全篇无「自建 RPC / `describeTeammateRoute` / `ctx.remote.<本服务>` / HTTP 路由」作为实现的表述；读 = 官方 `remote.session.*`，写 = `configForms` → `settings.mutate`，下发 = `webserver/index-inject`（M9）。S3/S4/S6/D5/D6/D11/D17 均已改写。
- 官方 `session.selectModel` 的定性（拒绝子代理会话 + 附带全局默认写入）在 01 §1、A4、R6 一致（P-13）。
- **误引裁定清理**：「冷时禁选（客户裁定 Q8）」已从 D10/R2 删除；Q8 裁定内容 = 下一次唤醒生效 + 恢复派发路由同规则（`00-client-answers.md:6`）。
- **渲染规则收口（04-O1）**：01 §3 第 13 条「不提供选择器」与 02-D14「不得按 mode 预过滤」不再冲突——D14 已改为「`s.subagent !== null` 渲染；`mode='unknown'` 属官方只读态、slot 不渲染」，与 01 §3 第 13 条同义。
- **R4 硬要求可见性**：`agent/created` listener 必须 try/catch 已在 §1 表（冷队友生效行）、S4、D8、R8 四处出现，并在 01-A8 旁注（§8-M6）。

## 6. 依赖 → 验收 / 步骤 / 存储路径 映射（一致性保证机制）

> 用途：P1.5 清零后回填本表即可完成「依赖清单 ↔ 形态判断 ↔ 验收口径」三方一致；每行与 §1/§3/§3.5 可交叉核对。结论列 = 该依赖当前证据等级（已验 / U-xx）。

| D | 服务的步骤 | 决定的验收 | 涉及路径 | 结论（P1.5 回填后） |
|---|---|---|---|---|
| D1 `ctx.agents` | S4 | A5/A8（热应用定位 live agent） | 仅 B（不直接依赖 resume） | 已验 |
| D2 `agent.model.*` | S4 | A4/A6/A8（写入与读取基准） | 仅 B（回填/热应用写） | 已验 |
| D3 `model/selection` 投影 | S3/S6 | A8/A9（重启仍在/零介入） | 仅 B（待生效值先进插件表，不直接进日志） | 已验 |
| D4 `subagent/descriptor` | S3/S6 | A7（恢复基准）/A2 | B | 已验 |
| D5 官方 `remote.session`（events/projections） | S3 | A2/A8（冷会话读） | B | 已验（源码/契约级） |
| D6 官方 `session.modelCatalog` | S6 | A3（基准集合） | B | 已验（源码级） |
| D7 切换前能力校验 | （不实现） | A13 | — | **已定降级**（不做预检，失败由回合自然报错） |
| D8 `agent/created` 回填 | S4 | A8 判定 2（首跳口径） | **仅 B** | **已验（U-3 成立）**；listener 必须 try/catch（R8） |
| D9 Host Config/meta | S2 | A10 | B | **6b 已验 / 6a 已定降级（客户已批准插件自带 UI）** |
| D10 `agents.resume` 冷写 | （不使用） | A5/A8 冷场景 | **A（作废）** | **已定降级（弃用）** |
| D11 `webServer.register` | （不使用） | 通道层 | — | **已定降级（不需要）** |
| D12 `conversation.input.right` | S5 | A1/A11/A12/A16-1 | B | 契约已验；**队友视图 = 已定降级（范围收窄：只读态不渲染）** |
| D13 Slot 标准 props | S5 | A1/A2（渲染与取数） | B | 契约已验（`standardProps` 含 `useSession`/`sessionId`/`useProjection`）；live 未测 |
| D14 `subagent` 快照 + 渲染规则 | S5 | A1（冷场景）/A11/A12 | B | 已验（含收口后的渲染规则） |
| D15 Client 装载契约 | S5 | 通道层 | B | 已验 |
| D16 `ctx.locale` | S6 | A2 占位口径 | B | **已验**（U-5，源码/契约级） |
| D17 通道（官方 namespace） | S3/S6 | 全部 UI 验收的取数/写入 | B | **已验**（U-1；自建 namespace 不可用，官方通道足够） |
| D18 插件侧覆盖表（Config volatile `overrides`） | S4 | A8/A5 冷场景 | **仅 B** | **已验（U-6b，源码级）** |
| **D19 entryId 下发（index-inject）** | S2/S6 | A10（开关写入）/A4/A7（覆盖写入） | B | 已验（源码级，M9） |

一致性维护规则（后续返工/回填时执行）：① §1 的路径结论已唯一化（路径 B），改动必须同步本表与 §5 计数；② 依赖清单每条改动必须同步本表与 §5 计数；③ 任何「客户裁定」引用必须逐字对照 `00-client-answers.md` 与 `00-client-answers-2.md`；④ 证据等级只允许写「源码/契约级」或「运行时」，不得把源码级写成运行时。

## 7. 返工记录：针对 `03-gate-P0P1.md` 的逐条回应

> 格式：编号（03 报告缺陷 ID）→ 修了什么 → 落点（`02-plan.md:行`）。行号以本次交付的文件为准。
> 说明：MINOR P1-m1/m2（P-13 出处链、P-15 漏 `:1418`）属 `probes.md`。`probes.md` 是 P0/P1 阶段的探测记录，本轮返工范围 = 更新 01/02 两份文件，故未追溯改写记录文件；待补内容写在下方表格末两行，留待 probes.md 下一次更新合并（只补出处、不改结论）。

| ID | 回应 | 落点（文件:行） |
|---|---|---|
| **P1-B1** | §1 删除「不需要独立存储后端」的绝对表述，改为**「存储形态（条件成立，二选一）」**：路径 A（选择已进子会话日志 → 无需插件存储，成立条件 = U-2）/ 路径 B（Q8 下次唤醒 → 插件侧 per-teammate pending 存储 + `agent/created` 回填，明说此路径下「无需自建存储」不成立）。依赖清单同步：新增 **D18**（插件侧 pending 存储，仅路径 B）并把它的 schema 探针并入 U-6；D3/D8/D10 与风险 R2/R3、U-2 降级全部回指 §1。 | `02-plan.md:15-19`（存储形态块；路径 A `:17`、路径 B `:18`）、`:48`（D3）、`:53`（D8）、`:55`（D10）、`:68`（**D18 新增行**）、`:81`（U-6 第二项）、`:91-96`（R2/R3/R7）、`:131`（§6 映射 D18）、`:100`（§5 计数 18 条） |
| **P1-B2** | U-3/R3 的「提示用户再发一次继续」不再作为降级：改为 **P1-B2 流程**——要么 U-3 证明首跳前完成 select，要么改其他首跳前生效机制，要么**书面向客户申请「第二次唤醒」豁免**；未获豁免前路径 B 不具备交付条件。01-A8 判定 3 同步（首个唤醒路由不可达时的处理）。 | `02-plan.md:53`（D8 降级列）、`:78`（U-3 降级+影响列）、`:92`（R3 应对列）；`01-requirements.md:118`（A8 判定 3） |
| **P1-M1（D12）** | 结论列拆分：slot 契约存在且 session-scoped = 已验（补四处源码引用 `22958-22998`/`22107-22110`/`786-803`/`1220-1228`）；**队友视图确实渲染该 slot = `UNVERIFIED → U-4`**（T-2 live 超时记录在 probes §1）。不新增 U-8，并入 U-4 探针范围。 | `02-plan.md:62`（D12 结论列+降级列）、`:79`（U-4「探什么」补 D12 live 缺口） |
| **P1-M2（§3.5 影响列）** | §3.5 表新增「对验收的影响」列：U-1/U-7 → 形态级（A1–A16 全体）；U-2 → 决定路径 A/B 与 A8/A9 口径；U-3 → A8 判定 2 可达性；U-4 → A1/A11/A12 可判性 + A16 判定 1 完整性；U-5 → A2 占位口径；U-6 → A10 落点与路径 B 存储可行性。 | `02-plan.md:72-74`（标题+表头含第 6 列）、`:76-82`（U-1…U-7 逐行影响列） |
| **P1-M3（S2/S3 顺序）** | §2 删除「S2/S3 可先行（纯读）」；新顺序约束：S1 → S2/S3 → …，**S1 清零（U-1…U-7 全出结论）前不写任何功能代码**，探针 bundle 除外且探完即删；S2/S3 完成标志补「探针脚手架不进入交付物」口径；依赖链重写（S2←U-6、S3←U-2、S4←U-2、S5←U-1+U-4、S6←S4+S5+U-5）。 | `02-plan.md:27`（S1）、`:28`（S2）、`:36`（「顺序约束」整段，原「可先行」句在此明确作废） |
| **P1-M4（D11）** | 结论列拆分为「Service 存在 = 已验（inspect 契约）」与「路由可被同源 fetch 调用 = `UNVERIFIED → U-7`」两条；降级句改按「路由可用性」表述。 | `02-plan.md:56`（D11 结论列+降级列）、`:82`（U-7 影响列） |
| **P1-M5（D14 unknown 渲染规则）** | D14 结论列补「冷会话 `mode='unknown'` 渲染规则」：`s.subagent` 快照存在即渲染占位（含 unknown），mode 由 Host `describeTeammateRoute` 决定可用/禁用；`subagent` 为 null 不渲染；**禁止 Client 侧先按 mode==='continuable' 过滤**。S5 行同步。 | `02-plan.md:64`（D14 结论列）、`:31`（S5 行） |
| **P1-M6（冷时禁选误引）** | D10 降级列删除「或冷时禁选（客户裁定 Q8）」；R2 应对列删除「冷时禁选」分支；改为「Q8 只裁定下一次唤醒生效，禁选如需保留须单独取得客户同意」。U-2 降级同步为「转路径 B（客户裁定 Q8，非降级）」。 | `02-plan.md:55`（D10 降级列）、`:91`（R2）、`:77`（U-2 降级列）、`:106`（§5「误引裁定清理」） |
| MINOR P1-m3（双写互斥） | §3 尾注新增：D8 与 D10 互斥启用，不得同时注册回填监听与 resume+select，否则两条 `model/selection` 违反 U-2「恰好 1 条」/A4「新增 1 条」；新增风险 R7 与 S4 互斥实现约束。 | `02-plan.md:70`（§3 尾注）、`:96`（R7）、`:30`（S4 行） |
| MINOR P1-m4（显示源） | S6 明写「显示源 = Host `describeTeammateRoute` RPC，Client `useProjection('modelSelection')` 只作辅助、不得作为显示源」（重启/冷会话投影可能是旧值）。 | `02-plan.md:32`（S6 行） |
| MINOR P1-m1（待并入 probes，本轮未改） | 待补：P-13 的调用链 `selectModel → resolveAgent → resolve`（`dsh-api-session-controller/lib/index.js:704-728`、`:967-970`、`:192-217`）。结论不变（拒绝子代理会话 + 附带全局默认写入）。 | 目标位置 `probes.md:117-120`（P-13） |
| MINOR P1-m2（待并入 probes，本轮未改） | 待补：P-15 另见 `dsh-agent-loop/lib/index.js:1418`（第二处 `applyConfiguredRoute`），避免「只有 `:1371`」的误读。结论不变。 | 目标位置 `probes.md:127-130`（P-15） |

> **§7 的行号说明（诚实标注）**：§7 记录的是 r2 → r3 那次返工的落点行号。本轮 P1.5 回填（§8）已改动 §1/§2/§3/§4/§5/§6，**§7 第 2/3 列的旧行号相对当前文件已经漂移**。§7 保留不动是为了留痕，不做行号重算；需要「当前落点」请看 §8。

## 8. 回填记录：M1–M9 落点（`05-p1.5-probes.md` §3 的改动清单）

> 回填依据：`05-p1.5-probes.md` §3（形态结论 + 落点表）与 §3 尾部的 M1–M9 清单；客户补充裁定见 `00-client-answers-2.md`。
> 回填原则：**只改形态 / 落点 / 呈现位 / 新增下发能力，不改验收的真假性与判据**（`05` §6）。凡涉及验收措辞的地方，只补「取数方式」与「呈现位」，不放松任何机判条件。
> 版本：`02-plan.md` r3（2026-11-08）。下表的「落点」列指向**当前文件**的章节，不写绝对行号（避免再次漂移）。

| # | `05` 建议 | 实际改了什么 | 落点（本章节） | 状态 |
|---|---|---|---|---|
| **M1** | §1「存储形态（条件成立，二选一）」改为**定为路径 B**，删路径 A 候选，「无自建存储」作废，补「通道 = 官方 namespace」一段 | 新增「通道判定（U-1 显式改写）」引用块 + 7 行落点表（读三路 / 写一路 / entryId 下发 / 热生效 / 冷生效）；「存储形态」标题改为**定为路径 B**，路径 A 明写**作废**并给出否证出处；「无需自建存储」正式作废；硬约束自查按新通道重写 | §1 全节 | ✅ 完成 |
| **M2** | D10/D11/D17/D18 结论列；D10 = 已定降级（不冷 resume）；D11/U-7 = 不需要；D17 = 官方 namespace + configForms，注明自有 namespace 不可用；D18 落点定为 Config volatile `overrides` | 依赖表整体重写（含结论列标注证据等级）：D1 去掉 resume 职责、D5/D6 改为 Client 侧官方 namespace、D7 标已定降级、D8 标已验(U-3)+try/catch、D9 拆分 6a/6b、D10 标已定降级（弃用）、D11 标已定降级（不需要）、D14 渲染规则收口、D16 已验、D17 已验（官方通道）、D18 落点 = Config volatile `overrides`；**新增 D19**（entryId 下发） | §3 依赖表（Host/Client 两表）+ 表尾注 | ✅ 完成 |
| **M3** | S3/S4/S6：S3 读路径改 Client 调官方 `session/events`/`modelCatalog` + `modelSelection` 投影，不再实现 `describeTeammateRoute` RPC；S4 写路径改「Client 写 volatile Config → host `agent/created`/`loader/volatile-update` 应用」；S6 显示源改为官方投影 + `session/events` 首/尾页 | S2–S6 五行全部重写：S2 加 entryId 下发；S3 改为 Client 三路只读并去掉 RPC；S4 改为路径 B 唯一实现（含 try/catch 硬要求、deepEqual 比对、不注册 resume+select）；S5 补 list 座位 id 唯一性与只读态不渲染；S6 显示源改官方 namespace、写入口用下发的 entryId + R5 可见降级 | §2 表 S2–S6 + 「顺序约束」段 | ✅ 完成 |
| **M4** | D14/S5 与 01 §3-13 的冲突（04-O1）：`mode='unknown'`/one-shot/父级离线时官方只读 composer 顶替、**不渲染**；删除「unknown 也渲染占位」规则 | D14 结论列改写：`s.subagent !== null` → 渲染；`null` → 不渲染；**删除「unknown 也渲染占位」**，明确 `mode='unknown'` 与 one-shot/父级离线同属「官方只读 composer 顶替整条 chain → slot 不渲染」；S5 行同步；§5 增「渲染规则收口（04-O1）」条 | §3-D14、§2-S5、§5 | ✅ 完成 |
| **M5** | 01 侧 A10 判定 3（读取方式 / 呈现位）—— **01 文件** | 见 `01-requirements.md` §8-M5；本文侧同步：D9 降级列注明 6a 已定降级且**客户已批准**插件自带 UI；§4-R11 记录该批准 | §3-D9、§4-R11 | ✅ 完成（01 侧见 §8-M5） |
| **M6** | 01 §3 第 13 条 / 02 S5：保留「父级离线只读态不提供选择器」，补「`unknown` 与 one-shot 同理」—— **01 文件为主** | 01 侧见 §8-M6；本文侧：S5 与 D14 均已按此口径改写；另在 §1「冷队友生效」行与 §4-R8 写入 **R4 硬要求：`agent/created` listener 必须 try/catch（否则拒绝 resume）** | §2-S5、§3-D14、§1 表、§4-R8 | ✅ 完成 |
| **M7** | `probes.md` P1-m1/P1-m2 补出处（只补出处、不改结论） | **本轮不改 `probes.md`**（范围限定为 01/02 回填 + P2 最小切片）；本行留痕：P-13 待补 `dsh-api-session-controller/lib/index.js:704-728,967-970,192-217`，P-15 待补 `dsh-agent-loop/lib/index.js:1418`。§7 末两行仍指向目标位置 | §7 末两行（未改） | ⏸ 未做（本轮范围外，留待 probes.md 下次更新） |
| **M8** | 04-O2…O8 措辞级观察，顺手修 | 已修：**O1**（D14 与 01 §3-13 冲突收口，见 M4）；**O2**（依赖边改齐：S3 不再依赖 U-2，改为 U-1+U-4，与 §6 的 D5/D12/D13 一致）；**O3**（A4/S4 补「冷队友按 01-A8 判定 3 时点判」——本文 S4 已写）；**O4**（01 侧父级在线列举改为场景式）；**O5**（01 侧 A9 两态措辞统一）；**O8**（§5 数字口径改为「01 与本文件一致；probes §4 的 U 表同为 7 条」）。**O6/O7 未改**：O6 是纯时序措辞（入口句），O7 在 01 的 §7 旧行号区，已由本文件 §7 顶部「行号说明」覆盖同类问题 | §5、§2-S4、§3-D14、§2 顺序约束段；01 侧见其 §8 | ✅ 完成（O6/O7 有意不改，理由如上） |
| **M9**（第二轮新增） | S2/S4：S2 补 **Host 经 `webserver/index-inject` 以 `{kind:'global'}` 下发本插件 entry id**（`ctx.fiber.entry?.options.id`），Client 用 `Reflect.get(globalThis, …)` 读回；S4 的 `configForms.get()` 用下发值 | 三处落地：① §1 落点表新增「下发本插件 entry id」行与「写覆盖」行引用；② S2 完成标志 + S6 写入口；③ §3 新增 **D19**（含 3 条官方先例：`dsh-client-shortcuts/lib/index.js:13-21`、`dsh-client-ui-settings-models/lib/index.js:16-24`、读侧 `dsh-api-remote-access/lib/client.js:807`；渲染侧 `dsh-host-webserver/lib/index.js:31-33`）；④ §4-R9 记录失败姿态（`entryId` 缺失 → warn + Client 禁用态） | §1 表、§2-S2/S6、§3-D19、§4-R9 | ✅ 完成 |

**回填后的口径变化汇总（供 04 复查/下一轮对照）**

1. 依赖数 **18 → 19**（新增 D19）；U 数仍 7 条，但**全部出结论**（已验 3 + 已定降级 3 + U-6 拆分）。
2. 路径 A、自建 RPC、HTTP 路由三条**全部作废/不需要**，§1 从「二选一条件句」变为「唯一路径 + 官方通道」的直陈句。
3. `unknown` 渲染规则口径反转（从「渲染占位」改为「不渲染，属官方只读态」），与 01 §3 第 13 条收口。
4. 新增两条**实现级硬要求**：① `agent/created` listener 必须 try/catch（§4-R8，客户批准）；② `entryId` 必须经 index-inject 下发、缺失即可见降级（§4-R9）。
5. 证据等级全篇统一为「源码/契约级」；**运行时缺口集中在 §4-R10/R12**，由 P2/P3 闭环。
