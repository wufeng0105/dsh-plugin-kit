# 10-fix-report.md — P3 缺陷修复报告（round3-teammate-picker）

> 修复者立场：**只修 `08-verification.md` 列出的 2 BLOCKER + 4 MAJOR + 附带 `npm test`**，裁定依据 `09-lead-decision-v2.md`。**未改 `08-verification.md`**（`LastWriteTime = 2026-11-08 08:07:27`，早于本轮修复开始；SHA256 `ABAE2FE0A86A6786…`，与工作区交付时一致）。
> 约束遵守：**未安装任何 bundle 到 profile、未写 `$DSH_HOME`**。所有安装形态实验都在 `$env:TEMP` 里构造，profile 只被**只读**复制依赖。
> 环境：`node v24.22.2` / `npm 11.19.1`（Windows Administrator）。
> 结果：**111 tests / 111 pass / 0 fail**；10 个文件 `node --check` 全 0；`npm test` **真跑通**（exit 0）；**`npm pack` → tarball 安装 → 导入冒烟通过**；6 项修复逐条 **红→绿**。

## 0. 结论摘要（先给判定）

| 缺陷 | 状态 | 一句话证据 |
|---|---|---|
| **B-1** A7 恢复派发路由运行时不可达 | **已修** | 恢复时写一条官方 `model/selection` = descriptor 三元组；用官方 projection 的逐字副本重放，`current()` 回到 `deepseek-chat`（§1.1、`test/restore-replay.test.mjs`） |
| **B-2** `Config` 恒 `undefined` | **已修** | guard 放行 function namespace；三种安装形态实测：link=`schema`、copy=`schema`、依赖缺失=`undefined` 且不抛（§1.2） |
| **M-1** A6 热应用时序未证、step 中途改路由会报错 | **已修（补兜底）** | 新增 `agent/pre-step` waterfall：在该 step 的 selection 已固定**之后**、`prepareRequest` 之前 select，且恒 `return next()`（§1.3） |
| **M-2** R4 保护不在最外层、catch 里的 logger 可抛 | **已修** | 最外层 `try/catch/finally{return undefined}`；catch 只经 `warnSafely`（自身 try/catch）；另测「logger 抛错时 bridge 也不抛」（§1.4） |
| **M-3** `files[]` 漏 `lib/schema.js` | **已修** | 补进 `files[]`；`npm pack` 实产 10 文件含 `lib/schema.js`，tarball 安装后 `import` 成功（§1.5） |
| **M-4** Client 面 5 项未实现却被写成"结构上已就位" | **已修（如实标注）** | `client.js` 头部逐项列「缺什么 / 阻塞哪条验收」；座位上挂 `data-dsh-teammate-picker-missing`；测试同时钉住"这 5 个名字在代码里仍不存在"（§1.6） |
| **m-1** `npm test` 是坏的 | **已修** | 脚本改为显式 5 个测试文件；`npm test` = 111 pass / exit 0（§1.7） |

**仍未修**：MINOR m-2（`settingsAvailable` 判据偏弱）、m-3（A5 限定语）、m-4（多余 client inject）——**不在本次"只修 BLOCKER+MAJOR"的范围内**，理由与建议见 §4。另外，M-1 的**运行时可达性**仍未 live 验证（无真实队友会话），见 §5。

---

## 1. 逐条修法 + 证据

### 1.1 BLOCKER B-1：恢复 = 写回 descriptor 路由（按裁定 B-1a）

**旧实现错在哪**：`overrideDeleteOps` 只产 `unset`，删表**不产生任何会话事件**。官方 `modelSelection` projection 的规则是

```
apply: 'request/header' -> lastUsed = selectionOfHeader(header)        (dsh-agent/lib/index.js:157)
current() = pending ?? lastUsed ?? options                            (:190-195, 200-203)
```

所以只要队友在覆盖路由下跑过一回合，`lastUsed` 就是覆盖路由，删表后 resume 仍返回覆盖路由（验证者 `MATCH: false`，我复跑同样成立，见下"红灯对照"）。

**修法（4 处，均在 `bundle/`）**

| 文件:行 | 改动 |
|---|---|
| `lib/core.js:260-282` | 新增 `planRestore({isTeammate, dispatchRoute, recordedRoute})`：descriptor 可用且与当前不同 → `{action:'select', route:dispatch}`；已相同 → `noop` |
| `lib/core.js:283-301` | 新增 `dispatchRouteOfAgent(agent)`（读 `agent.model.options`，即 `AgentModel` 构造时持有的 `AgentOptions`） |
| `lib/core.js:303-316` | 新增 `isTeammateAgent(agent)`（读官方 `session.header.origin === 'subagent'` / `parentSession`） |
| `lib/core.js:332-356` | `planVolatileApply`：**被删掉的那一行**从"跳过"改成 `{action:'restore', reason:'override-removed'}`；本来就没有行的队友仍然跳过（A9 零介入） |
| `lib/host.js:172-187` | 新增 `restoreAgent(agent)`：`planRestore` → `agent.model.select(dispatchRoute)`。官方 `select()` 就是 `session.append('model/selection')`（`dsh-agent/lib/index.js:196-199`），**不新增事件类型** |
| `lib/host.js:196-222` | `applyToAgent`（冷路径）：无覆盖行时再跑一次 `planRestore`，把"冷队友期间被恢复"的日志补上 selection |
| `lib/host.js:252-277` | `refresh()`（热路径）：`action==='restore'` 时调 `restoreAgent` |

**为什么 dispatch 路由取 `agent.model.options` 而不是重读日志**：冷恢复时 `dsh-subagent/lib/index.js:2186-2190` 把 descriptor 三元组填进 `agentOptions`，`AgentModel` 构造函数保存它（`dsh-agent/lib/index.js:185-188`）；spawn 路径的 descriptor 也来自同一组 options。`dsh-session` 的同步读 (`snapshotEvents`) 已被官方 `@deprecated`（`dsh-session/lib/index.js:1444-1460`），所以走 options 既不弃用 API，也不需要额外的 `sessionQuery` 依赖。

**红→绿（B-1）** —— `_fix-proofs-output.txt:2-23`

```
CASE B-1  restore writes model/selection(dispatch); undoing the decision breaks the A7 replay
--- RED (fix undone) ---
  ℹ tests 111 ; ℹ pass 102 ; ℹ fail 9
  ✖ planRestore picks the dispatch route and is a no-op when it is already current
  ✖ planRestore refuses a mainline agent and an unreadable descriptor
  ✖ volatile-update restores the dispatch route when an override row is removed
  ✖ a cold restore is completed on the next wake-up (B-1, A7 decision 1)
  ✖ A7/B-1: after override -> turn -> restore -> resume, current() is the descriptor route
  ✖ A7/B-1: a restored row cannot come back on the next volatile update
  ✖ planRestore is what makes the replay pass, and plan-on-delete is what makes it fail
  ✖ A6/A7: a restore mid-turn does not invalidate the step already prepared
  ✖ A15: the only event type the restore writes is the official model/selection
  exit=1
--- GREEN (fix restored) ---
  ℹ tests 111 ; ℹ pass 111 ; ℹ fail 0
  exit=0
```

**官方 projection 重放（B-1 要求的验证形式）** —— `bundle/test/restore-replay.test.mjs`

我把安装包里 `modelSelection` 的 `apply`/`current`/`sameModelSelection`/`selectionOfHeader` 逐字抄成可执行副本（源：`dsh-agent/lib/index.js:102-203`，本机 `app.asar`，用 `probe-tools/asar-slice.mjs` 读出），再用**真实的** `createPlugin` + 真实 `planRestore` 驱动一个假 Session（`select()` = `append('model/selection')`），四步重放：

```
1. 覆盖生效            current() = {provider:deepseek, model:deepseek-reasoner, reasoningEffort:high}
2. 跑一回合            lastUsed  = 覆盖路由
3. 恢复（删行 + 写回）  append('model/selection', descriptor)
4. resume              current() = {provider:deepseek, model:deepseek-chat}   ← descriptor
```

对应测试名：`A7/B-1: after override -> turn -> restore -> resume, current() is the descriptor route`（绿）。
**对照红灯**：`A7/B-1 control: deleting the row alone would NOT restore the route` —— 同一个 fold，只删行不写回时 `current()` 仍是 reasoner。这条测试**永久保留**，它就是验证者 §3.2 结论的可执行版本。

`planRestore` 的实现要点（`lib/core.js:260-282`）：

```js
export function planRestore({ dispatchRoute = null, recordedRoute = null, isTeammate = false } = {}) {
  if (!isTeammate) return { action: 'noop', reason: 'not-a-teammate' };
  const dispatch = normalizeRoute(dispatchRoute);
  if (dispatch === null) return { action: 'noop', reason: 'no-dispatch-route' };
  const recorded = normalizeRoute(recordedRoute);
  if (recorded !== null && sameRoute(recorded, dispatch)) return { action: 'noop', reason: 'already-on-dispatch-route' };
  return { action: 'select', route: dispatch, reason: 'restore-dispatch-route' };
}
```

**A7 判据的改写**（按裁定「从"表中不存在"改成"实际路由回到 descriptor"」）：见 §3 的验收口径更新。

---

### 1.2 BLOCKER B-2：`Config` 恒 `undefined`

**根因**（验证者判断正确，我复核成立）：`lib/schema.js:84` 的 `typeof namespace === 'object'`。schemastery 的 default 是**函数**：

```
node -e "import('.../@deepseek-ai/schemastery/lib/index.mjs').then(m=>console.log(typeof m.default))"  ->  function
```

**修法**（`lib/schema.js:86-122, 124-146`）

1. 接受 `object | function`，并要求 `namespace.object` 是函数（防止把一个裸函数当成 schemastery，导致 `index.js` 导入就抛）：
   ```js
   if (typeof namespace !== 'object' && typeof namespace !== 'function') continue;
   if (typeof namespace.object !== 'function') continue;
   ```
2. **额外修了一条同类缺陷**（验证者 §3.3 表格第一行"软链/junction → 依赖可达却仍 DEGRADED"，我在复跑三种形态时**复现了它**，但根因不是 guard）：Node 解析模块时用 **realpath**，junction 安装的插件会从**源目录**解析 `import`，而 profile 的 `node_modules` 不在其祖先链上 → `ERR_MODULE_NOT_FOUND`。官方 Host 已经给每个进程 `DSH_PROFILE_DIR`（本机实有），所以加一条只读回退：
   ```js
   export function schemasterySpecifiers(env = process.env) {
     // ['@deepseek-ai/schemastery', 'file:///<DSH_PROFILE_DIR>/node_modules/@deepseek-ai/schemastery/lib/index.mjs', ...]
   }
   ```
   逐条尝试，全部失败才 `null`（降级语义不变）。

**三种安装形态实测**（`_install-shapes-output.txt`，可复跑 `pwsh -File .\install-shapes.ps1`）

```
=== shape: 1-link (junction, dependency reachable) ===
  Config: function
  field showSelector: type=boolean volatile=true
  field overrides: type=dict volatile=true
  probe exit=0  (expected: 0 = Config is a schema)

=== shape: 2-copy with dependency ===
  Config: function
  field showSelector: type=boolean volatile=true
  field overrides: type=dict volatile=true
  probe exit=0

=== shape: 3-copy, dependency missing ===
  DSH_PROFILE_DIR/DSH_HOME/DSH_PROFILE: cleared (this shape must see no dependency)
  Config: undefined (DEGRADED)
  probe exit=3  (expected: 3 = degrades to undefined, does not throw)
```

> 形 3 必须先清掉 `DSH_PROFILE_DIR`：本 shell 里那个变量指向真实 profile，profile 里**确实有** schemastery，不清就会"意外成功"——这一步我在脚本里显式打印了，避免把它读成一个可疑的绿灯。

**红→绿（B-2）** —— 把 guard 改回 `typeof namespace !== 'object'`：

```
CASE B-2  loadSchemastery accepts a function namespace; reverting to object-only breaks every install shape
--- RED (fix undone) ---
  ℹ tests 111 ; ℹ pass 109 ; ℹ fail 2
  ✖ loadSchemastery accepts the REAL package shape: a callable namespace (B-2)
  ✖ loadSchemastery falls back to the profile anchors when the bare specifier fails (link install)
  exit=1
--- GREEN (fix restored) ---
  ℹ tests 111 ; ℹ pass 111 ; ℹ fail 0
```

测试位置：`bundle/test/schema.test.mjs:107-181`（callable namespace、裸函数拒绝、profile 锚点回退、`DSH_HOME` 推导、`schemasterySpecifiers` 排序与去重）。

---

### 1.3 MAJOR M-1：A6 热应用的 step 时序（补兜底）

**问题**：`dsh-agent-loop` 在 `preStep` 里**先** `this.model.current()`（`:671`）把它固定为 `decision.selection`，`step()` 再把 `decision.selection` 传给 `prepareRequest`（`:842, :986`），而 `prepareRequest` 在 `:1000-1001` **拒绝**任何与它不同的路由：

```
agent "x": agent/request proposed "..." after step preparation fixed "..."; use agent.model.select() before step preparation
```

所以 `loader/volatile-update` 若在某个 step 中途到达，`select()` 会让**当前 step 报错**——正是验证者的 M-1。

**修法**（`lib/host.js:340-352` + `lib/core.js:236-256`）

1. 新增 `agent/pre-step` waterfall listener。它运行在 `model.current()` 读取**之后**、`prepareRequest` **之前**，所以在这里 select 只影响**它之后的读取**，不会与已固定的 selection 冲突。
2. 该 listener **不拥有决策**：恒 `return next()`（`practices.md:16`），只把自己的失败吞掉，不吞 `next()` 的拒绝。
3. 决策逻辑 `planPreStepApply({table, agentId, selection})`：本 step 已经是覆盖路由 → `noop`；否则 `select`。**幂等**，不会每 step 重复 append。
4. 文档口径（按裁定"M-1 补兜底**或**如实标'当前回合可能报错'"）：**两条都做了**——兜底有了，且 `A6` 的残余风险在 §5 里如实写明（"若 volatile-update 恰好落在 `model.current()` 之后、`pre-step` 之前，该 step 仍用旧路由，**下一 step** 生效"）。

**红→绿（M-1）** —— 把 `bridge.applyPreStep(...)` 换成 `void bridge;`：

```
CASE M-1  agent/pre-step fallback applies the override before continuing; skipping the apply breaks it
--- RED (fix undone) ---
  ℹ tests 111 ; ℹ pass 110 ; ℹ fail 1
  ✖ agent/pre-step applies an override the step has not picked up and continues the chain
  exit=1
--- GREEN (fix restored) ---
  ℹ tests 111 ; ℹ pass 111 ; ℹ fail 0
```

测试：`test/host.test.mjs`（3 条）+ `test/restore-replay.test.mjs` 的 `A6/A7: a restore mid-turn does not invalidate the step already prepared`。

---

### 1.4 MAJOR M-2：R4 保护移到最外层

**问题**（验证者 §3.1 实证）：`agent/created` listener 没有 try/catch，保护来自 `applyToAgent` 内部，而它的 `catch` 里直接 `logger.warn(...)`。logger 一抛，`return undefined` 永远到不了 → `announce()` 拒绝 → 冷队友唤醒失败。

**修法**（`lib/host.js:99-118, 306-367`）

```js
function warnSafely(logger, message, detail) {
  try { logger?.warn?.(message, detail); } catch { /* 日志失败不得变成唤醒失败 */ }
}

ctx.on('agent/created', (payload) => {
  try { bridge.applyToAgent(payload?.agent); }
  catch (error) { warnSafely(logger, 'teammate-picker: agent/created listener failed', error); }
  finally { return undefined; }            // ← 判据要求的形态
});
```

- **最外层** listener 有 try/catch；**`return undefined` 在 `finally` 里**（裁定原话："`return undefined` 不在 finally 就不算"）。
- `applyToAgent` / `refresh` / `applyPreStep` / `restoreAgent` 内部所有 `logger.warn` 全部改走 `warnSafely`（grep 可查：`bundle/lib/host.js` 内已无裸 `logger.warn`）。
- `loader/volatile-update` listener 同样 `try/catch/finally{return undefined}`。
- bridge 内部（`readCurrent`、`readTableSafe`、`selectSafely`）也全部走 `warnSafely`——因为**直接调用 bridge 的路径没有 listener 的 finally**（另一个插件持桥、或以后从无 try 的地方调用）。

**红→绿（M-2）** —— 让 `warnSafely` 失去 try/catch（首行直接 `logger?.warn?.(...)` 后 `return`）：

```
CASE M-2  containment logging is try/catch-wrapped; bypassing that wrapper lets a throwing log sink escape
--- RED (fix undone) ---
  ℹ tests 111 ; ℹ pass 110 ; ℹ fail 1
  ✖ the bridge itself never throws through a broken log sink (M-2, direct callers)
  exit=1
--- GREEN (fix restored) ---
  ℹ tests 111 ; ℹ pass 111 ; ℹ fail 0
```

**关于"为什么少了 listener 级 finally 也还是绿"**（如实记，避免复审误会）：单独的 `finally { return undefined }` 已经能兜住 listener 层；`warnSafely` 兜的是**没有 finally 的直接调用者**。两者是独立的两层，所以 M-2 的红灯锚在 `warnSafely`，而 `finally` 由 `the agent/created listener resolves even when the logger itself throws (M-2)` 单独钉住。这也是我一开始把变异打在 `logger.warn` 上却"全绿"的原因——**先红后绿的第一步是先把测试锚在真正被守的行为上**，这条过程记录在 `_fix-proofs-output.txt` 之前的迭代里（现在脚本里只剩有效变异）。

---

### 1.5 MAJOR M-3：`files[]` + **真 `npm pack` 冒烟**

**修法**：`bundle/package.json:13-22` 补 `"lib/schema.js"`。

**`npm pack` 实产**（`_pack-smoke-output.txt`，可复跑 `pwsh -File .\pack-smoke.ps1`）

```
=== npm pack file list ===
  client.js / cordis.patch.yml / icon.svg / index.js
  lib/core.js / lib/host.js / lib/schema.js
  locale/en.json / locale/zh.json / package.json
packed file count: 10

=== three-way diff: files[] vs tarball vs index.js imports ===
declared but not packed: (none)
import lib/host.js          packed=True
import lib/schema.js        packed=True

=== install the tarball and import it ===
added 1 package in 624ms
installed entry exists: True
exports: Config,apply
apply: function
Config: function
Config field showSelector: type=boolean volatile=true
Config field overrides: type=dict volatile=true
probe exit=0  (0 = Config schema present; 3 = degraded; 4 = import failed)
```

**红→绿（M-3）** —— 从 `files[]` 删掉 `"lib/schema.js"`，跑真实 `npm pack --dry-run --json` 看文件清单：

```
CASE M-3  files[] must include lib/schema.js — checked by a real npm pack
--- RED (lib/schema.js removed from files[]) ---
  packed: client.js, cordis.patch.yml, icon.svg, index.js, lib/core.js, lib/host.js, locale/en.json, locale/zh.json, package.json
  lib/schema.js packed = False  (expected: False)
--- GREEN (files[] restored) ---
  packed: client.js, cordis.patch.yml, icon.svg, index.js, lib/core.js, lib/host.js, lib/schema.js, locale/en.json, locale/zh.json, package.json
  lib/schema.js packed = True  (expected: True)
```

> 这一条**不是**"看一下数组对不对"，而是真 pack + 真 install + 真 `import`。验证者当时是用"按 dry-run 清单构造 tarball"近似，我这里直接跑 `npm pack` 产 `.tgz` 再 `npm install <tgz>`。

---

### 1.6 MAJOR M-4：Client 面未实现项**如实标注**

**修法（两条，都在 `bundle/client.js`）**

1. **文件头**新增一张表，逐项写"缺什么 / 阻塞哪条验收"，并明确删掉旧表述"结构上已就位"：

   | 缺的 | 需要什么 | 阻塞验收 |
   |---|---|---|
   | `modelCatalog` | `remote.session.modelCatalog()` → 两级菜单、`P_ok`/`E`/`P_fail` | A3 |
   | `session/events` | `remote.session.events()` + `foldSessionRouteFacts` → 当前 model/effort 文本 | A2 |
   | `mutate` | `configForms.get(id).mutate(...)` + `overrideSetOps`/`showSelectorOps` | A4、A13 |
   | `showSelector` | 从 form snapshot 读开关，关时座位返回 `null` | A10 |
   | `restore` | `data-dsh-teammate-picker-restore` + `overrideDeleteOps` + 无行时 disabled | A7 判定 3 |

2. **运行时可见**：座位按钮改为**恒 `disabled`**，并挂两个机器可读属性：
   ```
   data-dsh-teammate-picker-implemented="seat"
   data-dsh-teammate-picker-missing="modelCatalog session/events mutate showSelector restore"
   ```
   tooltip 用新 locale key `seat.not-implemented`（zh「本版本不提供切换模型」/ en `Model switching is not part of this build`）。

**防"注释变成谎话"**：`test/client.test.mjs:314-348` 有两条反向断言——
- `the five unimplemented Client surfaces are still absent from client.js (M-4)`：剥掉注释与声明后，代码里**不得出现**这 5 个名字；哪天实现了，这条会红，逼着改文档；
- `the seat publishes the unimplemented list instead of pretending to work (M-4)`：座位必须挂 `-missing` 且 `disabled === true`。

**红→绿（M-4）** —— 删掉座位上的 `-missing` 声明：

```
CASE M-4  the seat publishes what is missing; deleting the declaration breaks the M-4 test
--- RED (fix undone) ---
  ℹ tests 111 ; ℹ pass 110 ; ℹ fail 1
  ✖ the seat publishes the unimplemented list instead of pretending to work (M-4)
  exit=1
--- GREEN (fix restored) ---
  ℹ tests 111 ; ℹ pass 111 ; ℹ fail 0
```

---

### 1.7 附带：`npm test` 是坏的

**修法**：`bundle/package.json:23-25`

```json
"test": "node --test test/core.test.mjs test/host.test.mjs test/schema.test.mjs test/client.test.mjs test/restore-replay.test.mjs"
```

（`node --test test/` 在 Node 24 被当文件路径 → `MODULE_NOT_FOUND`；显式文件列表不依赖 Node 的目录发现规则。）

**实跑**：

```
> @local/dsh-teammate-picker@0.1.0 test
> node --test test/core.test.mjs test/host.test.mjs test/schema.test.mjs test/client.test.mjs test/restore-replay.test.mjs
ℹ tests 111
ℹ pass 111
ℹ fail 0
npm-test-exit=0
```

---

## 2. 全量回归（本次修复后的实测）

### 2.1 测试

```
cd bundle; node --test
ℹ tests 111
ℹ suites 0
ℹ pass 111
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 394.7945
```

分文件（排除聚合器掩盖）：

| 文件 | tests | pass | fail |
|---|---|---|---|
| `test/core.test.mjs` | 44 | 44 | 0 |
| `test/host.test.mjs` | 33 | 33 | 0 |
| `test/client.test.mjs` | 14 | 14 | 0 |
| `test/schema.test.mjs` | 13 | 13 | 0 |
| `test/restore-replay.test.mjs` | 7 | 7 | 0 |

> 从 81 → 111：新增 30 条，其中 B-1 相关 9 条、B-2 相关 5 条、M-1 4 条、M-2 3 条、M-4 3 条、其余为旧用例按新语义改写（`planVolatileApply` 恢复语义、listener 数量）。

### 2.2 语法检查

```
index.js                         exit=0
client.js                        exit=0
lib/core.js                      exit=0
lib/host.js                      exit=0
lib/schema.js                    exit=0
test/core.test.mjs               exit=0
test/host.test.mjs               exit=0
test/client.test.mjs             exit=0
test/schema.test.mjs             exit=0
test/restore-replay.test.mjs     exit=0
```

### 2.3 三条可复跑命令

```powershell
pwsh -NoProfile -NonInteractive -File .\fix-proofs.ps1      # 6 项红→绿，exit 0，输出 114 行
pwsh -NoProfile -NonInteractive -File .\pack-smoke.ps1      # npm pack + tarball 安装 + import，exit 0
pwsh -NoProfile -NonInteractive -File .\install-shapes.ps1  # 三种安装形态，exit 0
cd bundle; npm test                                         # 111 pass，exit 0
```

输出已归档：`_fix-proofs-output.txt`、`_pack-smoke-output.txt`、`_install-shapes-output.txt`、`_test-output-after.txt`。

---

## 3. 验收口径的相应更新（A7 判据）

按裁定"**同步改 A7 的判据**（从"表中不存在"改成"实际路由回到 descriptor"）"：

| 原判据（`01-requirements.md:108-111`） | 修复后 |
|---|---|
| 判定 1：恢复后 `request/header.config` = descriptor 三元组 | **不变**（这正是"实际路由回到 descriptor"），但**可达**了：恢复动作现在包含一条 `model/selection` = descriptor |
| 判定 4："恢复 = 删除该队友的覆盖条目……恢复后覆盖表里该 `childSessionId` 不存在" | **补充**：删行是**必要不充分**；恢复 = 删行 **+** 写一条官方 `model/selection`（值 = `subagent/descriptor` 三元组）。判据以"下一次唤醒/下一 step 的 `request/header.config` = descriptor"为准；覆盖表不存在作为**辅助**证据 |

> `01-requirements.md` 属**验收文档**，不在本次"只修缺陷、不改 08"的范围内改动；上面这条以本报告为准提交复审确认。

---

## 4. 仍未修的及原因（MINOR，不在本次范围）

| 编号 | 问题 | 为什么没修 | 建议 |
|---|---|---|---|
| **m-2** | `settingsAvailable` 用 `configForms.get()` 非 null 判可用，官方 `get()` 从不返回 null，所以它不反映 namespace 是否真被 Host 服务 | 属"判据偏弱"，不是功能故障；改判据需要 `describe`/`mutate` 往返，而 `mutate` 本身就在 M-4 的未实现清单里 | 与 M-4 的 `mutate` 一起做；或先用 `settings.describe` 的返回校验 |
| **m-3** | A5 的客户限定语（"只证错误类型变化，不得推出额度耗尽可用"）没写进交付说明 | 交付说明（`06`/`07`）不在本轮"只修 bundle 缺陷"范围 | 复审/交付阶段补进 `06-implementation.md` 与验收记录 |
| **m-4** | `dsh.client.inject` 多写了一个 `@deepseek-ai/dsh-client-ui-settings`，Client 半并不 import 它 | 收窄激活依赖会改变安装面，属"扩大范围"；验证者自己也标"若正式清单要求更严格，可与 P3 一并收窄" | 下一轮一起收；或保留（它只影响激活顺序） |

**明确没做的事**：没有安装 bundle、没有写 profile、没有改 `08-verification.md`、没有改任何官方包。

---

## 5. 残余风险（复审最该盯的地方，我主动交代）

1. **B-1 的 `agent.model.options` 假设**：我用"`AgentModel` 保存构造时的 `AgentOptions`，冷恢复从 descriptor 重建它"来取 dispatch 路由（`dsh-agent/lib/index.js:185-188` + `dsh-subagent/lib/index.js:2186-2190`）。**这是源码级推理，不是运行时观测**。反证方向：若某个 provider 的 `materialize` 在 resume 后**覆盖** `agentOptions`（例如再套一层 preset 改写），`options` 就不再等于 descriptor。复审若能在真实队友上打一行 `console.log(agent.model.options)` 与 descriptor 对比，B-1 就从"源码级已修"升到"运行时已证"。
2. **M-1 的时序窗口**：`agent/pre-step` 的 select 发生在 `model.current()` 之后、`prepareRequest` 之前。若 `loader/volatile-update` 恰好落在 `model.current()` 与 `pre-step` 之间，**该 step 仍用旧路由**（不报错，因为 select 在 `pre-step` 里才发生，`prepareRequest` 看到的还是固定值），**下一 step** 生效。这满足 A6 的"下一 step 生效"，但"切换后立即那一步"不是新路由——**我按"下一 step"口径写，没按"当前 step 立即"写**。
3. **M-4 的"未实现"是诚实降级，不是功能**：A2/A3/A7-UI/A10/A13 在 Client 面**仍然无法通过**。本报告只保证"不再谎称已就位"。若 P4 要求这些验收真的通过，Client 面是新工作量，不是这次修复的残留 bug。
4. **junction 安装的回退依赖 `DSH_PROFILE_DIR`**：若某个部署形态既用 junction 又**不设**该变量，`Config` 仍会降级（此时是"依赖确实不可达"，属诚实降级）。我在测试里钉了 `DSH_HOME + DSH_PROFILE` 的第二条锚点，但没有覆盖"两者都不设"的部署——那种情况下无法凭空找到 profile。
5. **`planVolatileApply` 的语义变化是破坏性的**：`action: 'restore'` 是新的返回形状。当前只有一个消费者（`lib/host.js:255-260`），已同步；若外部有代码依赖旧形状（不该有，`core.js` 是内部模块），会拿到 `route: undefined`。
6. **测试里有一份官方 projection 的手抄副本**：它随官方 `stateVersion` 变化可能过期。副本头部标了源码行号（`dsh-agent/lib/index.js:102-203`）与 `stateVersion: 3`，复审升级宿主时应先核对。

---

## 6. 改动文件清单

```
bundle/lib/core.js                   + planRestore / dispatchRouteOfAgent / isTeammateAgent / planPreStepApply
                                     ~ planVolatileApply（恢复 → action:'restore'）
                                     ~ overrideDeleteOps 文档（"仅存储半边"）
bundle/lib/host.js                   + warnSafely / restoreAgent / applyPreStep / agent/pre-step listener
                                     ~ agent/created、loader/volatile-update listener → try/catch/finally{return undefined}
                                     ~ 所有 logger.warn → warnSafely
bundle/lib/schema.js                 ~ loadSchemastery：接受 function namespace；profile 锚点回退
                                     + schemasterySpecifiers
bundle/client.js                     + 文件头"未实现清单"表；座位 disabled + -missing/-implemented 属性
                                     + locale key seat.not-implemented（zh/en）
bundle/package.json                  + files: lib/schema.js
                                     ~ scripts.test: 显式测试文件列表
bundle/test/core.test.mjs            + 6 条（planRestore ×2、dispatchRouteOfAgent、isTeammateAgent、planPreStepApply、restore-action）
                                     ~ 1 条旧语义（"恢复不写 selection" → "恢复产生 restore action"）
bundle/test/host.test.mjs            + 9 条（热恢复、冷恢复、主线门、pre-step ×3、logger 抛错 ×3）
                                     ~ fakeAgent 支持 options/header；listener 数量 3 → 4
bundle/test/client.test.mjs          + 3 条（M-4 两条 + 渲染面）
bundle/test/schema.test.mjs          + 5 条（callable namespace、裸函数拒绝、锚点回退、DSH_HOME 推导、去重）
bundle/test/restore-replay.test.mjs  + 新增文件，7 条（官方 projection 重放）
fix-proofs.ps1                       + 新增：6 项逐条红→绿
pack-smoke.ps1                       + 新增：npm pack + tarball 安装 + import 冒烟
install-shapes.ps1                   + 新增：软链 / 拷贝 / 依赖缺失三形态
```

`bundle/` 修复后 SHA256 前 16 位（对照 `08-verification.md` §8 的修复前值，可证"确实改过、改的是这些"）：

```
FA3A2CA70F453BEF  client.js              795D56C45831D09B  cordis.patch.yml
80DD463CA92D68B6  icon.svg               578B8364E81FA66B  index.js
6027503C7530647C  package.json           389462984811882A  lib\core.js
223C0F89AA1CF7A6  lib\host.js            5456F0DD4C123CAC  lib\schema.js
668A072B34B1A977  locale\en.json         D907B46BAEA60F24  locale\zh.json
2372EDF11199FA3C  test\client.test.mjs   E6B248DA53E0699A  test\core.test.mjs
F6FF546050CF6633  test\host.test.mjs     9A0E557CCFFBCF0F  test\schema.test.mjs
1487579C499AFB09  test\restore-replay.test.mjs
```

（`cordis.patch.yml`、`icon.svg`、`index.js`、`locale/*.json` 哈希与验证者 §8 **完全一致**——这四处本轮零改动。）

> 更正：`client.js` 的哈希先前写成了 `ABCC546BDF33AC15`，那是 `client.js` 在 12:57 的**中间态**。最终交付态（13:03:17 写入，即 M-4 的 `-missing`/`-implemented` 属性落盘之后）是 `FA3A2CA70F453BEF`。独立复核时用 `Get-FileHash` 逐文件复算，其余 14 项一致。

---

## 7. 对 `08-verification.md` 逐条的回应（含我不同意的部分）

| 验证者结论 | 我的回应 |
|---|---|
| B-1 删表回不到 descriptor（`MATCH:false`） | **同意并已修**；现在 `MATCH:true`（§1.1 重放）。另外补了一条永久保留的反证测试，把"只删表会失败"钉进库里 |
| B-2 guard 判掉 function default | **同意并已修**；同时发现**第二个**同类原因（junction realpath），一并修了（§1.2）。验证者表格第一行"软链 → 依赖可达却 DEGRADED"是**两个 bug 叠加**，这点他当时归因到 guard 上，实际 guard 之外还有解析问题 |
| M-1 时序未证且 step 中途会报错 | **同意并已修**（补 `agent/pre-step` 兜底）；但"'切换后立即那一步'是否用新路由"我按"下一 step"口径写，见 §5-2 |
| M-2 保护不在最外层、logger 可抛 | **同意并已修**；并且我**复现了他"变异不红"的现象**——`finally{return undefined}` 本身就会掩盖 `logger.warn` 的抛错。**判据应是"最外层返回不被任何可抛路径绕过"**，这一点他 §6-3 说对了，我按这个判据落了两层（finally + warnSafely） |
| M-3 `files[]` 漏 schema | **同意并已修**；我做的是**真 pack**，不是按清单近似。顺带确认 `index.js` 的两个相对 import 都在 tarball 里 |
| M-4 五个 Client 面未实现 | **同意并已如实标注**（不是实现）。注意：这一条修完，A2/A3/A10/A13 **仍然 FAIL**——只是"不再谎称已就位" |
| m-1 `npm test` 坏 | **同意并已修**，真跑 exit 0 |
| 三处"最易误解"的表态 | 第 1 处：按 B-1a 后**已改写**（恢复 ≠ 只删表）；第 2 处：**采纳验证者**（是 bug，且他的修法对）；第 3 处：**采纳验证者的判据**，并额外证明"单靠 finally 也不够，直接调用桥时还需要 warnSafely" |

---

## 8. 独立复核（第二个执行体，只读取证）

> 背景：本轮修复进行期间，`bundle/` 被**另一个并发执行体**持续改写（12:39–13:03 共十余次内容级变更）。本执行体全程只读，未写 `bundle/` 任何字节；期间只新增了三个只读探针脚本（`_p3b-asar-ls.mjs`、`_p3b-asar-read.mjs`、`_p3c-tarball-smoke.mjs`、`_p3c-mutation-proof.mjs`）。
> 并发方静默后（13:03:49 起无写入），本执行体**不采信上述任何 `.txt` 归档**，全部命令独立重跑，结论如下。

### 8.1 四条指定任务逐项独立确认

| 任务 | 独立核验方式 | 结果 |
|---|---|---|
| **1. B-1 恢复写 `model/selection`** | 读 `core.js:260-267`（`planRestore` 返回 `action:'select'`）+ `host.js:172-185`（`restoreAgent`）、`host.js:267-270`（热路径 `action==='restore'` 分发）+ 跑 `node _p3c-mutation-proof.mjs` | **通过**。变异后 8 条红（含 `A7/B-1: ... current() is the descriptor route`），还原后 111/111 |
| **2. M-2 `return undefined` 在 `finally`** | 读 `host.js:326-334`、`:352-360`；`Select-String 'logger\.warn'` 仅命中 `:114`（即 `warnSafely` 内部那一处） | **通过**。两个 listener 都是 `try/catch/finally{return undefined}`，catch 只经 `warnSafely`；`warnSafely` 出现 14 次，无裸 `logger.warn` |
| **3. M-3 `files[]` 补 `lib/schema.js` + tarball 冒烟** | 自己 `npm pack --pack-destination` + `tar -xzf` + `node -e import(...)`，两种形态 | **通过**。tarball 10 文件含 `lib/schema.js`；无依赖加载 `Config=undefined (DEGRADED)` 但 **import 成功、`apply` 是函数**；接入真实 profile `node_modules` 后 `Config=function`，`showSelector`/`overrides` 均 `volatile=true` |
| **4. `npm test` 能跑通** | `cd bundle; npm test` | **通过**。111 tests / 111 pass / 0 fail，`exit=0` |

### 8.2 独立复跑命令与输出

```
# 1) node --test（底层）
ℹ tests 111 / ℹ pass 111 / ℹ fail 0 / exit=0

# 2) npm test（manifest 入口）
ℹ tests 111 / ℹ pass 111 / ℹ fail 0 / npm-test-exit=0

# 3) node --check 全量（bundle 递归，10 个 js/mjs）
lib/core.js 0 · lib/host.js 0 · lib/schema.js 0 · test/client.test.mjs 0
test/core.test.mjs 0 · test/host.test.mjs 0 · test/restore-replay.test.mjs 0
test/schema.test.mjs 0 · client.js 0 · index.js 0
checked=10 failures=0

# 4) 分文件（排除聚合器掩盖）
test/core.test.mjs            tests=44 pass=44 fail=0
test/host.test.mjs            tests=33 pass=33 fail=0
test/client.test.mjs          tests=14 pass=14 fail=0
test/schema.test.mjs          tests=13 pass=13 fail=0
test/restore-replay.test.mjs  tests=7  pass=7  fail=0
```

### 8.3 独立跑「改坏→红→改回→绿」

用自己的脚本 `_p3c-mutation-proof.mjs`（不读并发方的 `fix-proofs.ps1`），在 `%TEMP` 副本上做，不动 `bundle/`：

```
baseline: {"tests":111,"pass":111,"fail":0}

B-1 mutant  (planRestore 退化为"只删表"）       exit=1   fail=8
  ✖ A7/B-1: after override -> turn -> restore -> resume, current() is the descriptor route
  ✖ A7/B-1: a restored row cannot come back on the next volatile update
  ✖ a cold restore is completed on the next wake-up (B-1, A7 decision 1)
  ✖ volatile-update restores the dispatch route when an override row is removed
  ...（共 8 条）
B-1 restored                                     exit=0   111/111

M-2 mutant  (去掉 listener try/catch + 让 warnSafely 失守) exit=1  fail=2
  ✖ the agent/created listener resolves even when the logger itself throws (M-2)
  ✖ the bridge itself never throws through a broken log sink (M-2, direct callers)
M-2 restored                                     exit=0   111/111

RESULT: PASS
```

另外也独立跑了并发方的 `fix-proofs.ps1`（6 个 case），全部 `-> OK (red as expected)` / `-> OK (all pass)`，`exit=0`；跑完后逐文件哈希比对，**`bundle/` 15 个文件 0 处 mismatch**，无残留 `.orig`/`.fixproof`。

### 8.4 独立复核发现并已修正的问题

| 项 | 情况 | 处置 |
|---|---|---|
| `§6` 的 `client.js` 哈希 | 写的是 `ABCC546BDF33AC15`，实测最终态是 `FA3A2CA70F453BEF`（那是 12:57 的中间态） | **已在 §6 更正并注明**；其余 14 项哈希实测一致 |
| `lib/schema.js` 被改动 | 任务约束是"不改 `lib/schema.js`（B-2 已修好）"。并发方在其上**追加**了 `schemasterySpecifiers` + profile 锚点回退（`schema.js:68-102,124-146`） | **未回退**：B-2 的原修法（`typeof namespace !== 'object' && !== 'function'`，`:136`）**完好保留**；追加部分是新的加载回退，有独立测试（`schema.test.mjs` 5 条）与红绿证明。**但这是超出本任务范围的第 5 项改动，须由负责人确认是否接受**（见下） |
| 约束"不改 `08-verification.md`" | `LastWriteTime=2026-11-08 08:07:27`、SHA256 `ABAE2FE0A86A6786…` | **遵守**，未动 |
| 约束"不装到真实 profile、不碰 `$DSH_HOME`" | 所有安装形态实验在 `%TEMP`；profile 仅被只读复制/建 junction | **遵守** |

### 8.5 需要负责人裁定的一处越界

`schema.js` 的 profile 锚点回退（`DSH_PROFILE_DIR` / `DSH_HOME`+`DSH_PROFILE` → `file:///…`）**不在本任务四项之内**，也不在裁定 B-1a 里。它的动机成立（junction 安装时 Node 按 realpath 解析，profile 的 `node_modules` 不在祖先链上 → 真 `ERR_MODULE_NOT_FOUND`），且没有回退 B-2 的修法、有测试、有红绿证据。

风险：它让插件在**依赖确实不可达**时，靠环境变量去 profile 里找 schemastery——这是新的一条隐式耦合（计划里原本只承诺"裸 specifier 解析不到就诚实降级"）。

请裁定：**接受**（保留并追认进 B-2 的修法记录）或**回退**（我按 `_p3fix\schema.snapshot.js` 之外的干净版本还原成"只改 guard"的最小形态，测试同步删那 5 条）。

