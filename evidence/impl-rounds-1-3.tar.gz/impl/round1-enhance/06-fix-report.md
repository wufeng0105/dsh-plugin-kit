# 06 修复报告：dsh-enhance（round 1 缺陷修复）

> 输入：`05-verification.md`（缺陷清单）、`00-client-answers.md`（客户裁定）、`03-implementation.md` / `04-selfcheck.md`、`bundle/`。
> 修复范围：**MAJOR-1 / MAJOR-2 / MAJOR-3 必修；MINOR-1 / MINOR-3 / MINOR-4 / MINOR-5 按常识修**。B1、MINOR-2、MINOR-6 按任务要求本轮不修。
> 约束遵守：**未修改 `05-verification.md`；未安装任何插件；未写入 `$DSH_HOME` 下任何内容**。全部读写只发生在 `bundle/`、`%TEMP%`，以及只读打开 DSH 安装包的 `app.asar`。
> 环境：Windows，Node **v24.22.2**；修复时间 2026-11-08 ~00:20–00:41（Asia/Shanghai）。

---

## 0. 结论摘要

| 项 | 结果 |
|---|---|
| BLOCKER B1 | **未修**（任务明确留到 round 2；原因见 §2） |
| MAJOR-1（catalog 身份段名） | **已修**，并用宿主真实注册名补了回归用例 |
| MAJOR-2（检查假成功） | **已修**：无「变换确实发生」的证据时不判 success，原始 sections 一定判 not-effective |
| MAJOR-3（preset description 类型） | **已修**：字符串 + 安全闸能拦 name/description 类型错误 |
| MINOR-1（审批 toolName） | **已修** |
| MINOR-2（跨文件 I/O 部分写入） | **未修**（任务明确不修，见 §2） |
| MINOR-3（字段损坏 status） | **已修**：新增 `degraded` 状态，横幅有触发依据 |
| MINOR-4（决定环无页面通道） | **已修**：`status()` / `check()` / `ctx.enhance.recentApprovals` 三个出口都有，且首调即存在 |
| MINOR-5（currentApprovalPolicy 恒 undefined） | **已修**：按宿主契约 `permissionPresets.current(session)` + `resolve(name).approval` 实现，session 可从页面 / Agent / sessionId / initiator 解析 |
| MINOR-6（backups 排序） | **未修**（任务明确不修，见 §2） |
| 测试 | **153 / 153 通过**（修复前 138） |
| 语法检查 | **40 files checked, 0 failed** |
| 红→绿证明 | **7 / 7 组全部成立**（每组：改坏 → 定向测试 exit=1；恢复 → exit=0，见 §4） |

---

## 1. 逐条修复

### MAJOR-1：`DEFAULT_CATALOG` 用了错的宿主段名

**修法**（`bundle/lib/sections.js:40-57`）

| 字段 | 修复前 | 修复后 | 依据 |
|---|---|---|---|
| `identityNames` | `['harness-identity']` | `['harness:identity']` | `dsh-system-prompt/lib/index.js:230-234`：`name: "harness:identity"`，order `HARNESS_IDENTITY`（-1000），文本就是品牌句；不是 `complete` section（`complete` 只在 `dsh-system-prompt/lib/index.js:383-384` 生效，该段未标） |
| `hostNoteNames` | `[]` | `['harness:source', 'app:web-surface']` | `dsh-harness-dev-context/lib/index.js:25-27` 定义两个名字；`:99-122` 同时用这两个名字注册 **section** 和 **runtime context** |
| `runtimeContextNames` | `['runtime-context']`（不存在） | `['harness:source', 'app:web-surface']` | 同上，C2 说的「两条 runtime context」就是这两条 |
| `hostNoteMarkers` | `[]` | 两段宿主自述的开头句 | `dsh-harness-dev-context/lib/index.js:28-29` 的 `HARNESS_SOURCE_PROMPT` / `WEB_SURFACE_PROMPT` |
| `runtimeContextMarkers` | `['Current runtime context']` | `['Current DeepSeek Harness implementation checkout:', 'Current DeepSeek Harness Web GUI URL:']` | `dsh-harness-dev-context/lib/index.js:109,121`。**不能**用通用表头：required 的 `working-directory:current`（`dsh-working-directory/lib/index.js:46-48`）会保留表头，用它判断会导致 hide 永远判「可见」 |

交叉核对来源（未安装、只读）：
- host inspect `Service.listService {service:"systemPrompt"}`：`section(section)` / `context(context)` / `suppressRuntimeContext()`，`PromptSection.complete?: boolean`；
- host inspect `Service.listService {service:"permissionPresets"}`（MAJOR-3 用）；
- 安装包 `app.asar` 内 `@deepseek-ai/dsh-system-prompt`、`dsh-harness-dev-context`、`dsh-working-directory` 的 `lib/index.js`（只读抽取到 `%TEMP%` 后核对）。

**测试**
- `bundle/test/sections.test.js:142` `DEFAULT_CATALOG names match the installed host (MAJOR-1)`：逐字断言四个名单和两个 marker，并断言 `working-directory:current` 不在名单里。
- `bundle/test/sections.test.js:157` `hideHostNotes with the real names removes identity and both host-note sections/contexts`：真实名字喂入 `transformPresentation`，身份段 + 两条 host-note section + 两条 context 全部移除，required 的 working-directory 保留。
- `bundle/test/check.test.js:173` 与 `:189`：原始宿主 sections 判 not-effective；transform 后用 baseline 判 effective。

**红→绿证据**

改坏：`identityNames: ['harness:identity']` → `['harness-identity']`；跑 `node --test test/sections.test.js`：

```text
✖ DEFAULT_CATALOG names match the installed host (MAJOR-1)
  actual: [ 'harness-identity' ]
  expected: [ 'harness:identity' ]
✖ hideHostNotes with the real names removes identity and both host-note sections/contexts
  AssertionError: identity + both host-note sections go
  actual: [ 'harness:identity', 'workspace' ]
ℹ pass 12
ℹ fail 2
```

恢复后：

```text
ℹ pass 14
ℹ fail 0
```

> 附带修正：`runtimeContextMarkers` 从通用表头改成两条真实 value 前缀。这是逐项核对 catalog「其余名字」时发现的同类问题——用表头做 marker 会在 required context 保留时误报「宿主自述仍可见」。

---

### MAJOR-2：检查函数把未经变换的原始 sections 判成已生效

**修法**（`bundle/lib/check.js`）

核心原则：**「没有残留」≠「变换发生过」**。hide 项成功必须两者同时成立：
1. 当前 surface 里没有任何 catalog 可识别的宿主自述（`lib/check.js:214-242` 的 `leftovers`，原始 sections 在这里就失败）；
2. 有直接证据证明变换确实删除过东西（二选一）：
   - `transformLog`：`transformPresentation()` 返回的 change log 里有 `{op:'hide-host-notes', matched:true}`（`lib/check.js:164-167`）；
   - `baseline`：变换前的宿主 assembly（或文本）里本来有宿主自述，现在没了（`lib/check.js:183-191`）。

两者都没有时返回 `ok:null` + `no-baseline` / `no-change-evidence`，**永远不可能拼出 `effective`**。相关位置：

- `lib/check.js:131-137`：catalog 连身份段都识别不了时返回 `no-catalog`，拒绝空真判成功（旧实现这里会判 hidden）；
- `lib/check.js:193-212`：文本路径同样要求 baseline / transformLog；
- `lib/check.js:59-73`：`finish()` 把 `ok:null` 但 `enabled:true` 的项计为 `unproven`，写进 `reasons`（如 `hostNotes:no-baseline`），并且只有 `reasons.length===0` 才可能 `effective`；有成功项 + 未证明项 → `partial`，无成功项 → `not-effective`；
- `host/check-service.js:30-50`：把快照里的 `baseline` / `transformLog` 透传给纯比对（round 2 的 bridge 只要放进 snapshot 即可）。

成功码从旧的 `host-notes-hidden` 改为 `host-notes-removed`（带 `detail.evidence: 'baseline' | 'transform'`），避免把「本来就空」和「删掉了」混在同一个码里。

**测试**
- `bundle/test/check.test.js:113`：有 baseline / 有 transformLog 才算成功，且 `detail.evidence` 区分来源。
- `bundle/test/check.test.js:148`：**无证据必须拒绝成功**——`no-baseline`、baseline 与输入相同 → `no-change-evidence`、`matched:false` 的 log 不算证据；三种情况 verdict 都是 `not-effective` 且 reasons 具名。
- `bundle/test/check.test.js:173`：**验证者原探针的回归**——把未经任何 transform 的真实宿主 sections + contexts 喂进去，`hostNotes.ok=false`、`code='host-notes-visible'`、verdict `not-effective`。
- `bundle/test/check.test.js:189`：同一份真实 surface 经 `transformPresentation` 后带 baseline 检查 → `effective`、`host-notes-removed`。
- `bundle/test/check.test.js:213`：catalog 无法识别宿主自述时 `no-catalog`，不判成功。
- `bundle/test/check-service.test.js:53`：`snapshot.baseline` 真的从 service 层透传到比对结果。

**红→绿证据**

改坏：把文本路径的 `ok:null, code:'no-change-evidence'` 改回旧的 `ok:true, code:'host-notes-hidden'`；跑 `node --test test/check.test.js`：

```text
✖ without evidence the hide check refuses success (MAJOR-2: no fake success)
  actual: { key: 'hostNotes', enabled: true, ok: true, code: 'host-notes-hidden' }
  expected: { key: 'hostNotes', enabled: true, ok: null, code: 'no-change-evidence' }
ℹ pass 16
ℹ fail 1
```

恢复后：

```text
ℹ pass 17
ℹ fail 0
```

> 行为变化（有意为之）：hide 开启但既无 baseline 也无 transformLog 时，「检查」会显示 `partial` / `not-effective` + `hostNotes:no-baseline`，而不是假的 `effective`。这是需求 7 要求的方向；round 2 接线时必须把二者之一放进 `SessionSurfaceSnapshot`（已在 `host/check-service.js` 留好通道）。

---

### MAJOR-3：Enhanced 档 `description` 是对象，且安全闸不查类型

**修法**（`bundle/lib/preset.js`）

- `bundle/lib/preset.js:20-32`：`description` 改为字符串 `'Full sandbox access, but out-of-band actions still ask.'`。宿主 `dsh-permission-presets` Config 是 `name: z.string()`、`description: z.string()`（`dsh-permission-presets/lib/index.js:139-160`；inspect `PresetSpec` 同样 `description?: string`）。A6 的双语描述改放界面文案：`bundle/locale/zh.json` / `en.json` 的 `preset.description`。
- `bundle/lib/preset.js:60-68`：`validatePresetTable` 补查 `name` / `description` 必须是字符串，issue path 分别是 `presets.<key>.name` / `presets.<key>.description`。
- `bundle/lib/preset.js:155-162`：`assertSafeWrite` 原有的 `presets.*` → `invalid-preset` blocker 映射自动覆盖这两个新 issue；`host/preset-service.js:34-47` 的 `preparePresetWrite` 本来就在写前调用它，所以服务层也被拦住。

**测试**
- `bundle/test/preset.test.js:30`：`enhanced preset ...` 增加 `typeof description === 'string'` 断言。
- `bundle/test/preset.test.js:51`：对象 description / 非字符串 name 都被 `validatePresetTable` 报出（`invalid-description` / `invalid-name`）。
- `bundle/test/preset.test.js:130`：即使 merge“成功”，`assertSafeWrite` 也必须在 `presets.enhanced.description` 处 block。
- `bundle/test/preset-service.test.js:57`：`preparePresetWrite` 对对象 description 返回 `ok:false`（端到端到写前闸）。
- 既有 fixture 补上真实宿主形状的 `name` / `description`（`preset.test.js`、`preset-service.test.js`）。

**红→绿证据**

改坏：`description` 改回对象 + `validatePresetTable` 的描述类型检查短路（`if (false && ...)`）；跑 `node --test test/preset.test.js test/preset-service.test.js`：

```text
✖ an object description in the merged table is blocked before any write (MAJOR-3)
  actual: true
  expected: false
✖ enhanced preset is sandbox wide open but still asks (requirement 4)
  actual: 'object'
  expected: 'string'
✖ validatePresetTable rejects non-string name/description (MAJOR-3)
✖ assertSafeWrite blocks an object description even when the merge itself "succeeded" (MAJOR-3)
ℹ pass 14
ℹ fail 4
```

恢复后：

```text
ℹ pass 18
ℹ fail 0
```

---

### MINOR-1：审批环记录读 `request.tool`，宿主字段是 `toolName`

**修法**：`bundle/host/approval-service.js:17-25` 改读 `request.toolName`，仍写入 `request.tool`（保持页面记录形状稳定），`callId` 不变。

**测试**：`bundle/test/approval-service.test.js:16` 用真实 `ApprovalRequestEvent` 形状（`{agent,toolName,callId,reason}`），断言 `recentDecisions(...)[0].request.tool === 'bash'`。

**红→绿**

改坏：`request.toolName` → `request.tool`；跑 `node --test test/approval-service.test.js`：

```text
✖ allow answers allowed-once without consulting the user (C8)
  AssertionError: the ring records the host toolName (MINOR-1)
  actual: null
  expected: 'bash'
ℹ pass 6
ℹ fail 1
```

恢复后：`ℹ pass 7 / ℹ fail 0`。

---

### MINOR-3：字段级损坏时 `status` 仍是 `ok`，横幅会漏触发

**修法**：`bundle/host/state-store.js:64-73` 增加 `degraded`：JSON 解不开 → `corrupt`；能解开但有字段 issue → `degraded`；无 issue → `ok`。文件仍不自动改写，`corrupt` 语义不变。页面横幅条件应使用 `status === 'corrupt' || status === 'degraded'`（等价于 `issues.length > 0`）；`bannerCorrupt` 文案本来描述的就是字段回落场景，可直接复用。

**测试**
- `bundle/test/state-store.test.js:75` 的字段损坏用例新增 `assert.equal(r.status,'degraded',...)`（L81）。
- `bundle/test/state-store.test.js:88`：只有未知 extra 字段（合法保留）时仍为 `ok`，不误报损坏。

**红→绿**

改坏：`status` 三元退回 `parsed.corrupt ? 'corrupt' : 'ok'`；跑 `node --test test/state-store.test.js`：

```text
✖ per-field fallback comes from the file, and the issues travel to the page (C7)
  AssertionError: a field-level fallback must trip the damage banner (MINOR-3)
  actual: 'ok'
  expected: 'degraded'
ℹ pass 12
ℹ fail 1
```

恢复后：`ℹ pass 13 / ℹ fail 0`。

---

### MINOR-4：决定环形缓冲没有通向页面的数据通道

**修法**
- `bundle/host/controller.js:29,32-41`：控制器新增注入 `getRecentApprovals`，读取失败/非数组一律返回 `[]`。
- `bundle/host/controller.js:84`：`status()` 返回 `recentApprovals`。
- `bundle/host/controller.js:126-134`：`check()` 的返回值也带 `recentApprovals`（C8 要求检查面板同屏展示最近决定）。
- `bundle/index.js:41-50`：ring 在控制器创建**之前**声明，`getRecentApprovals: () => recentDecisions(ring)`，闭包读的是 reassign 后的最新 ring。
- `bundle/index.js:82`：`ctx.enhance.recentApprovals` 在插件 apply 时就存在（首调返回 `[]`），不再只在第一次审批后才出现。

**测试**：`bundle/test/controller.test.js:46` 注入一条决定，断言 `status.recentApprovals` 与 `check.recentApprovals` 都等于该条；`controller.test.js:30` 断言首次 `status()` 为 `[]`。

**红→绿**

改坏：`const value = getRecentApprovals();` → `const value = [];`；跑 `node --test test/controller.test.js`：

```text
✖ status and check expose the recent approval decisions (MINOR-4)
  actual: []
  expected: [ { at: '2026-11-07T15:28:53.000Z', decision: 'allow', ... } ]
ℹ pass 8
ℹ fail 1
```

恢复后：`ℹ pass 9 / ℹ fail 0`。

---

### MINOR-5：`currentApprovalPolicy` 恒 `undefined`

**修法**
- `bundle/host/approval-service.js:36-55`：新增 `approvalPolicyOf(presets, session)`，严格按宿主契约：`current(session)` → preset 名 → `resolve(name)` → `spec.approval`；只接受 `'ask' | 'never'`。`custom` / resolve 抛错 / 未知值 / 无 service / 无 session 一律 `undefined`，绝不编造。
- `bundle/index.js:133-141`：`currentApprovalPolicy(ctx, sessionRef)` 读取 `permissionPresets` 并调用上面的纯函数。
- `bundle/index.js:143-152`：没有显式 session 时取 `agents.currentInitiator()`。
- `bundle/index.js:154-175`：Agent → Session 走公开契约 `sessions.get(agent.id)`，**不假设** `agent.session`（公开 `Agent` 接口只保证 `{ id }`）；同时接受 Session / Agent / sessionId 字符串 / `{sessionId}`。
- `bundle/host/controller.js:72-83`：`status({session|sessionId})` 把页面给的 session 引用传给 resolver；resolver 报 `'never'` 时 `explainTristate` 返回 `{active:false, code:'preset-never'}`（C1 的「此档从不询问」终于有数据来源）。

**测试**
- `bundle/test/approval-service.test.js:70`：fake `current/resolve` 返回 `never` / `ask`，并断言 `current()` 收到的就是传入 session。
- `bundle/test/approval-service.test.js:90`：无 service、无 session、`custom`（resolve 抛错）、未知 approval 值 → 全部 `undefined`。
- `bundle/test/controller.test.js:62`：保存 `masterSwitch+approvalOverride` 后，`status({session})` 与 `status({sessionId})` 都得到 `preset-never`，且 resolver 收到对应 session 引用。

**红→绿**

改坏：`approvalPolicyOf` 的有效返回改成 `return undefined;`，且控制器 `getSessionPolicy(options.session ?? options.sessionId)` → `getSessionPolicy()`；跑 `node --test test/approval-service.test.js test/controller.test.js`：

```text
✖ approvalPolicyOf resolves the session preset approval through the host contract (MINOR-5)
  actual: undefined
  expected: 'never'
✖ status reports preset-never when the session policy resolver finds one (MINOR-5)
  AssertionError: the page session reaches the resolver
  actual: [ undefined ]
  expected: [ { id: 'session-1' } ]
ℹ pass 14
ℹ fail 2
```

恢复后：`ℹ pass 16 / ℹ fail 0`。

---

## 2. 明确未修的项（及原因）

### B1：端到端接线仍是空壳

**状态**：未修，按任务要求留到 round 2。

理由：`host/prompt-service.js` 的 `createPromptBridge` 仍是 `sync(){}/dispose(){}`，`index.js:115` 的 `readSurfaceSnapshot` 仍返回 `null`。真实接线需要安装进 profile 后用 `sessionQuery.readSurface` 核对字段映射、用 `systemPrompt.section()` 动态注册/注销、用 `suppressRuntimeContext()` 挂 C2；本轮明令不许安装、不许碰 `$DSH_HOME`，离线无法验证。

本轮为 round 2 留好的接口：
- `check-service.js` 已接受 `snapshot.baseline` / `snapshot.transformLog`；
- `DEFAULT_CATALOG` 已是真实名字；
- `approvalPolicyOf` / `currentApprovalPolicy` 已有真实数据路径。

### MINOR-2：跨文件 I/O 失败会留下部分写入

**状态**：未修（任务明确本轮不做，记入交付说明）。

`host/controller.js` 的 `save()` 只保证「校验全有或全无」：persona 写成功、boundary 写失败时 persona 已落盘。验收 4 只约束超限（超限在写盘前拦截），因此不影响本轮验收；真正的修复需要临时文件 + 多文件事务/回滚，超出「修验证缺陷」范围。

### MINOR-6：`listBackups` 按文件名字符串排序，不是时间序

**状态**：未修（任务明确本轮不做，记入交付说明）。

`host/state-store.js:145-158` 的 `.sort()` 在同一秒的 `state-….bak` 与 `state-…-2.bak` 之间顺序可能反（`'-' < '.'`）。只影响 `status().backups` 的展示顺序，不影响备份/恢复正确性。修复方向：按 `parseBackupName` 解析出的时间戳 + 避撞序号排序。

---

## 3. 复跑验证（本轮亲手跑）

工作目录：`bundle/`。

```text
> node --test "test/*.test.js"

ℹ tests 153
ℹ suites 0
ℹ pass 153
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 771.6726
```

```text
> node scripts/check-syntax.mjs

40 files checked, 0 failed
```

文件数核对：`Get-ChildItem -Recurse -File -Include *.js,*.mjs` = **40**，与脚本统计一致。

> 修复前基线（本轮开始时跑）：138 tests / 138 pass；40 files / 0 failed。新增 15 个用例（含改写的旧用例），全部只碰 `os.tmpdir()`。

---

## 4. 红→绿证明（7 组，全部亲手执行）

方法：对每处修复，先把代码精确改回缺陷形态 → 跑**定向测试文件**，要求 `exit=1` 且失败断言正是本次新增的用例 → 从备份恢复 → 同一命令 `exit=0`。脚本与每轮日志在 `%TEMP%\dsh-fix-redgreen\`（bundle 之外，不随交付）。

| 组 | 改坏点 | 定向命令 | 红 | 绿 |
|---|---|---|---|---|
| MAJOR-1 | `identityNames` 改回 `harness-identity` | `node --test test/sections.test.js` | exit=1, fail=2 | exit=0, pass=14 |
| MAJOR-2 | 无证据分支改回 `ok:true / host-notes-hidden` | `node --test test/check.test.js` | exit=1, fail=1 | exit=0, pass=17 |
| MAJOR-3 | `description` 改回对象 + 类型检查短路 | `node --test test/preset.test.js test/preset-service.test.js` | exit=1, fail=4 | exit=0, pass=18 |
| MINOR-1 | `toolName` 改回 `tool` | `node --test test/approval-service.test.js` | exit=1, fail=1 | exit=0, pass=7 |
| MINOR-3 | `degraded` 改回 `'ok'` | `node --test test/state-store.test.js` | exit=1, fail=1 | exit=0, pass=13 |
| MINOR-4 | ring getter 改成 `[]` | `node --test test/controller.test.js` | exit=1, fail=1 | exit=0, pass=9 |
| MINOR-5 | policy 解析恒 undefined + 不传 session | `node --test test/approval-service.test.js test/controller.test.js` | exit=1, fail=2 | exit=0, pass=16 |

关键失败断言原文（摘录，均来自当次真实运行）：

```text
MAJOR-1  actual: [ 'harness-identity' ]            expected: [ 'harness:identity' ]
MAJOR-2  actual: ok: true, code:'host-notes-hidden' expected: ok: null, code:'no-change-evidence'
MAJOR-3  actual: true (preparePresetWrite ok)       expected: false
         actual: 'object' (typeof description)      expected: 'string'
MINOR-1  actual: null (request.tool)                expected: 'bash'
MINOR-3  actual: 'ok' (load status)                 expected: 'degraded'
MINOR-4  actual: [] (recentApprovals)               expected: [ { decision:'allow', ... } ]
MINOR-5  actual: undefined (approvalPolicyOf)       expected: 'never'
         actual: [ undefined ] (resolver arg)       expected: [ { id:'session-1' } ]
```

---

## 5. 改动文件清单（相对 `bundle/`）

| 文件 | 改动 |
|---|---|
| `lib/sections.js` | MAJOR-1：catalog 全部真实宿主名 + 真实 marker；更新来源注释 |
| `lib/check.js` | MAJOR-2：证据链（baseline / transformLog）、`no-catalog`、`finish()` 不再吞未证明项、新成功码 `host-notes-removed` |
| `lib/preset.js` | MAJOR-3：description 字符串；validate 补 name/description 类型；注释说明双语改走界面 |
| `host/approval-service.js` | MINOR-1：读 `toolName`；MINOR-5：新增 `approvalPolicyOf` |
| `host/state-store.js` | MINOR-3：新增 `degraded` 状态 |
| `host/controller.js` | MINOR-4：`status/check` 返回 `recentApprovals`；MINOR-5：`status({session/sessionId})` 透传 |
| `host/check-service.js` | MAJOR-2：透传 `snapshot.baseline` / `snapshot.transformLog` |
| `index.js` | MINOR-4：ring 提前声明、首调即可读；MINOR-5：真实 policy 解析（presets → sessions → Agent） |
| `locale/zh.json` / `locale/en.json` | MAJOR-3 的 A6 双语描述落到界面文案 `preset.description` |
| `test/check.test.js` | 新增/改写 6 个用例（证据链、原始 sections 回归、真实 catalog transform、no-catalog） |
| `test/sections.test.js` | 新增 2 个真实宿主名用例，强化 key 断言 |
| `test/preset.test.js` | 新增类型/安全闸用例，fixture 补 name/description |
| `test/preset-service.test.js` | 新增对象 description 的写前拦截用例，fixture 补 name/description |
| `test/approval-service.test.js` | 真实 request 形状；新增 policy 解析与 undefined 用例 |
| `test/state-store.test.js` | degraded 断言 + 未知 extra 不降级用例 |
| `test/controller.test.js` | recentApprovals 两个出口 + preset-never 两个入参形态 |
| `test/check-service.test.js` | baseline 从 snapshot 透传的用例 |

未改动：`05-verification.md`、`03-implementation.md`、`04-selfcheck.md`、`00-client-answers.md`、`bundle/client.js`、`bundle/cordis.patch.yml`、`package.json`。

> 说明：`03-implementation.md` 的 §2-9（preset.description 双语对象）、§3（catalog 待探针）、§7-1（catalog 名字未定）现在都已过期；本报告是这些点的最新事实来源。按「05 是历史记录」的同类原则，未回写 03/04。

---

## 6. 如果验证者再来一次，我最可能在哪一处被他抓住

**最可能在 MAJOR-2 的「证据链」上：我把「假成功」改成了「没有证据就不判成功」，但真实 runtime 的 `readSurface` 仍是 `null`（B1 未修）；round 2 接线时如果没有把 `baseline` 或 `transformLog` 放进 `SessionSurfaceSnapshot`，hide 项会一直停在 `no-baseline`，验证者会说「你只是把假成功换成了永远不成功」。**

次要候选（如实列出）：
1. **MINOR-5 的真实触发路径**：`status()` 在真实 GUI 里能否拿到 session（页面显式传 / initiator 存在）仍未安装验证；离线只能证明「有 session 时能解析出 `never`」和「拿不到时如实 undefined」。
2. **MAJOR-1 对 `hostNoteNames` 的归类**：我把 `harness:source` / `app:web-surface` 的 section 与 context 都列为「宿主自述」；验证者可能只认 identity 段为「自述」，从而质疑隐藏范围偏大。依据是 C2 原文「那两段讲宿主自己的说明……连同两条 runtime context 一起隐去」，这两段正是这两个名字的 section + context。
3. **MINOR-4 的「页面通道」**：控制器三个出口都有数据了，但页面/Remote 仍未实现（B1）；验证者若按「页面拿不到」字面判定，会认为只修了服务端一半。

---

## 7. 约束与可复现性声明

- **未修改 `05-verification.md`**（只读）。
- **未安装任何插件**；**本轮未写入 `$DSH_HOME`**。注：`%USERPROFILE%\.dsh\enhance` 在本轮开始前就已存在（创建于 2026-10-31，最后修改 2026-11-07，均早于本轮的 2026-11-08 00:20），不是本轮创建或修改的；本轮所有集成测试仍只使用 `os.tmpdir()`。
- 对 DSH 安装包只做了只读访问：从 `app.asar` 抽取了 `@deepseek-ai/dsh-system-prompt`、`dsh-harness-dev-context`、`dsh-working-directory`、`dsh-permission-presets` 的 `lib/index.js` 到 `%TEMP%\dsh-asar\` 供核对。
- 测试全部在 `os.tmpdir()` 下真读写临时目录，结束递归删除；红/绿脚本的备份与日志在 `%TEMP%\dsh-fix-redgreen\`。
- 复跑命令（与 03 §4 一致，无第三方依赖）：

```powershell
cd bundle
node --test "test/*.test.js"
node scripts/check-syntax.mjs
```
