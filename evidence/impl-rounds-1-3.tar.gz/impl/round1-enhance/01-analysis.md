# 01 需求分析：dsh-enhance

> 阶段一产出。输入：`process-lab/requirements/REQ-01-dsh-enhance.md`（29 行）。  
> 探测方式：只读 `cordis_inspect_list` / `cordis_inspect_query`。宿主侧契约均已核实；客户端 inspect 全部 10s 超时（`Service` / `Event` / `Slots` / `Builtin` 共试 6 次，页面未连上），设置页槽位**未核实**，见 R4。  
> 未读取 process-lab 之外的任何目录（含 DSH 源码、包 README、技能模板目录），因此下文所有「宿主能做什么」都以探测到的契约为准，不以源码推断为准。

---

## 1. 逐条理解（用自己的话复述，顺带暴露我可能误解的地方）

**1）品牌人设三态。**  
我理解「保留」就是完全不动宿主系统提示；「去掉开头那句」是只删掉系统提示第一段里的**品牌自述那一句/那一段**，不是把整个系统提示清空；「自定义」是用用户写的 ≤2KB 文本**替掉**那一句。可能误解点：我一开始以为可以直接重写整个系统提示，需求实际只允许动「开头那句」。另外「首次保存时创建」我理解为：三段式里选自定义并第一次保存时，才真正在状态文件里落一条 `persona` 文本（此前不预置空文本）。

**2）内容边界。**  
我理解为一段 ≤8KB 的文本，追加在**每一条**系统提示的**末尾**（每轮每个 step 重新拼装时都在），而不是只在会话开头加一次。可能误解点：「末尾」是指所有 section 之后、还是运行环境上下文之后——我按「整段系统提示的最后」理解。

**3）越界审批三态。**  
我理解为：当宿主要就某个动作弹审批时，插件抢在用户之前按状态做决定——自动放行（直接允许一次）/ 先问我（照常弹给用户）/ 自动回绝（直接拒绝并给出理由）。不是「所有工具调用都先过插件」，只处理宿主本来就要问的那些。

**4）Enhanced 权限档（可选）。**  
我理解为：在宿主的权限档位表里**新增**一个「沙箱全开 + 越界仍先问」的档位（即 `sandbox: danger-full-access` + `approval: ask`），写进宿主配置。关键约束我理解为：写之前必须把**现有整张档位表**读出来、把新档并进去、整表写回（宿主配置按整块替换处理，只写新档会把内置档抹掉）；写之前留带时间戳的 `.bak`；不碰 `defaultPreset`；只有用户点按钮才发生，插件启动/保存状态时绝不写宿主配置。

**5）五个开关。**  
总开关 / 内容边界 / 越界审批 / 品牌人设 / 隐藏宿主说明，存状态文件。布尔值接受字符串形式（`"true"` 之类）。状态文件损坏时**不能静默放行**：审批回落「先问我」，人设回落「保留」。隐藏宿主说明是有代价的：宿主自述和操作约定会一起消失，界面必须把代价写清楚。

**6）设置页。**  
五组分别对应上面五项。页面写的东西和用户手改的文件必须是**同一份**（同一路径、同一格式，不搞双写同步）。人设改动**下一条消息**生效，不需要重启宿主。

**7）检查。**  
读回会话日志，证明写进去的东西真的出现在系统提示里；没出现就明说「未生效」，不能显示成功。

**8）存盘即生效、不改宿主文件、随时一键退回。**  
除 #4 的档位写入外不碰宿主文件；提供一键退回（回到全部默认：全关 + 保留）。

---

## 2. 歧义 / 缺口清单

标注：**[澄清]** = 需要客户拍板（已进第 4 节）；**[自决]** = 我按合理默认处理并给出决定。

| # | 问题 | 类型 | 我的决定 / 建议 |
|---|---|---|---|
| A1 | 「开头那句品牌声明」具体指哪一段？是身份段第一句、整段身份，还是宿主 `includeHarnessIdentity` 控制的那整块？ | 澄清 | 按「身份段的首段」实现，替换后其余身份说明保留；界面提供替换前后预览，实施时用探针确认段落边界 |
| A2 | 自定义人设是**只替换开头句**，还是整段身份都换成用户的？ | 澄清 | 默认只替换开头段；若客户要整段接管，保留成可选开关会显著增加行为面，建议不做 |
| A3 | 「末尾追加」是加在所有内容之后，还是只加在用户内容之后、运行环境上下文之前？ | 自决 | 加在整段系统提示最后（最高 order），用一个独立 section 承载 |
| A4 | 「越界」的判定标准是什么？我按「宿主已经决定要弹审批」来判定，不自己重算沙箱边界。 | 自决 | 以 `approval/request` 事件为唯一触发；不挂 `tools/pre-execute` 自己判越界（重算沙箱边界必然与宿主不一致） |
| A5 | 三态只在宿主会问的时候生效；如果用户档位本身就是「从不询问」（内置 danger-full-access），宿主根本不发审批请求，三态等于不存在。 | 澄清 | 建议接受这个语义并在界面说明；若客户要求必达，只能改为拦截所有工具调用（改变宿主语义，风险大） |
| A6 | Enhanced 档的名字、显示名、描述文案、语言？ | 自决 | key `enhanced`，显示名「Enhanced」，描述中英双语，写进配置的 `name`/`description` 字段 |
| A7 | 点「写档」后如果用户已在别处改过配置，整表以哪边为准？ | 自决 | 写入前重新读取实时配置（`permissionPresets.catalog` + `settings.describe`），以实时表为基准合并；写入用 revision 校验，冲突则提示重试 |
| A8 | 卸载或「一键退回」时，是否删除已写入宿主配置的 Enhanced 档？需求只说卸载后用户文件和宿主正常。 | 澄清 | 建议：卸载不动宿主配置（档位是宿主配置，不是用户文件）；「一键退回」提供两步——先把当前配置备份，再删除 Enhanced 档 |
| A9 | 状态文件放哪、什么格式？ | 澄清 | 建议固定路径 `%USERPROFILE%\.dsh\enhance\state.json`（不随包卸载），JSON + `version` 字段；设置页显示完整路径与「复制路径」 |
| A10 | 2KB / 8KB 是 UTF-8 字节还是字符？超限是拒绝保存还是截断？ | 澄清 | 建议按 UTF-8 字节；超限**拒绝保存**并提示，不落盘（保证「写入超限文本不损坏任何文件」）。中文 1 字 3 字节，按字符算会误导 |
| A11 | 「损坏」的判定粒度：单字段坏（比如布尔写成 `"maybe"`）算整文件损坏，还是只该字段回落？ | 自决 | 按字段回落 + 顶部常驻「状态文件异常」横幅；文件本身不自动改写，等用户修或点重置 |
| A12 | 「布尔值认字符串」认到什么程度？ | 自决 | `true/false` 大小写不敏感，另认 `1/0`、`on/off`、`yes/no`；其余值按该字段损坏处理（回落） |
| A13 | 「隐藏宿主说明」到底隐藏什么？运行环境事实（cwd、模型、权限档）也是宿主自指的注册项。 | 澄清 | 建议只隐藏宿主自述（身份 + 操作约定），保留运行环境事实；全隐藏会让模型失去路径与权限信息 |
| A14 | 「检查」检查哪个会话？需要开着的回合吗？ | 自决 | 检查当前会话最新一步的 `system/message`；会话还没有系统消息时报「未生效/暂无记录」 |
| A15 | 「随时一键退回」的粒度：只关开关，还是把改写过的宿主配置也回滚？ | 自决 | 两级：普通「全部恢复默认」= 状态回默认；「回滚档位写入」= 从最近 `.bak` 恢复宿主配置，两步都留痕 |
| A16 | 包名与旧包名迁移。 | 自决 | 新包用带 scope 的名字（具体名待定），README 写「先卸旧包再装新包」；插件检测到旧包线索时不自动迁移，只在界面提示 |
| A17 | 全部开关关闭时，系统提示必须与宿主**逐字节**一致，意味着我们不能留任何固定标记（marker）。 | 自决 | 「检查」不靠 marker，靠内容比对（开头段替换后的文本 / 末尾追加文本的精确匹配） |
| A18 | 用户文本里如果带控制字符/伪造的段落标题怎么办？ | 自决 | 保存时拒绝控制字符（除换行/制表符），提示用户；不做内容审查（这是用户自己的提示词） |

---

## 3. 技术风险（哪里最难、哪里可能碰墙）

**R1（最大风险）身份段可能被注册成「complete section」，瀑布改不动。**  
`systemPrompt` 服务文档明确：`assemble()` 跑完 `system-prompt/assemble` 瀑布后，**如果该 scope 有生效的 complete section，会被恢复成唯一的系统提示**，注释原话是「listeners cannot add to or replace that scope's system prompt」。如果宿主的身份段是 complete section，我们既不能改它、也不能在它后面追加——需求 #1/#2 全部落空。  
退路只有写宿主 `system-prompt` 配置（`includeHarnessIdentity=false`、`personaPrefix/personaSuffix`），但这违反「不改宿主文件」；或者接受降级（只能追加、不能替换）。**必须先探针验证**。

**R2 审批三态在「从不询问」档位下失效。**  
`ApprovalPolicy` 只有 `'ask' | 'never'` 两态，没有 `'deny'`；「自动回绝」只能在 `approval/request` 瀑布里提前返回 `'rejected'`。如果会话策略是 `never`，宿主不发请求，三态全部无效。这不是实现问题，是宿主语义，必须让客户知情（A5/C1）。

**R3 宿主配置整表替换 + 加载器重载的副作用。**  
`permission-presets` 配置是 `presets` 映射 + `defaultPreset`（标记 volatile）。写回必须整表；写配置会触发 Loader 重载（`app-boot/config-reload`），重载可能**卸载并重挂插件**，如果写档逻辑不幂等，会出现「写到一半自己被卸载」。另外并发：设置页的 settings 写入和我们的写入可能互相覆盖，需要 revision 校验与写前重读。

**R4 客户端能力完全没核实。**  
客户端 inspect 6 次全部 10s 超时（`Service`/`Event`/`Slots`/`Builtin`）。这意味着：设置页该注册到哪个 Slot、客户端插件清单怎么声明、Remote 命名空间怎么生成，全都只有「按 DSH 惯例推断」。风险是计划里 S7 的工作量可能被低估，或者页面上不了。

**R5 状态存储不能寄生在宿主配置里。**  
`settings` 服务会按 Config schema **自动生成**设置页并把值写进 profile 配置。如果拿插件自己的 Config 当状态存储，就违反「不改宿主文件」和「页面与手改文件同一份」。必须自建状态文件 + 自绘设置页。

**R6 提示拼装的性能与「不重启生效」。**  
每个 step 都会重新 assemble；如果每次都读盘校验，会拖慢首 token。需要「内存缓存 + 文件 watch 失效」；`fs.watch` 存在，但异步初始化，且某些后端可能不支持。降级方案是每次 assemble 做一次轻量 stat 比对。

**R7 关闭态一致性是最容易被验收打回的点。**  
验收第 1 条要求「全部开关关闭时，系统提示与宿主原样一致」。任何全局常驻的 section/context/变量都会破坏它。测试要在四个开关组合下逐字节比对。

**R8 隐藏宿主说明可能让模型行为退化。**  
需求自己承认「连同操作约定一起消失」。隐藏后模型可能不知道工具用法约定、不遵守汇报格式。这是产品副作用，不是 bug，但界面必须提示，且**检查**结果要能看出当前处于隐藏态。

**R9 改写提示与审计的相互作用。**  
`approval` 服务声称「logs every ask/outcome pair」到会话日志。如果我们在 `approval/request` 瀑布最前面直接返回 `allowed-once`/`rejected`，是否仍产生审计事件未知——可能用户事后在日志里看不到「这次是谁放行的」。需要验证；如果没有，就得自己在检查结果里记录最近 N 次拦截决定（放内存/单独日志文件，不伪造会话事件）。

**R10 超限文本的原子性。**  
`fs.writeText` 是原子替换，但「超限不损坏文件」要求**先校验后写**，任何校验失败都不能走到写盘。`.bak` 也要先复制成功再写主文件。

**R11 审批监听的作用域。**  
`approval/request` 是 `Scoped<Agent>` 瀑布，插件注册的监听器是全局生效还是只在插件 scope 内生效，未验证。如果不生效，三态需要换实现点（例如每个 agent 创建时注入），复杂度上升。

**R12 设置页的实时性。**  
用户手改文件后，页面要能感知（同一份文件的承诺）。需要宿主侧 watch + 客户端订阅（Remote 流或轮询），这条链路未验证。

---

## 4. 待客户澄清

以下 8 条会改变外部行为或不可逆，**请客户拍板**；每条都带我的建议默认值，客户不答时我按建议推进。

**C1. 审批三态与「从不询问」档位的关系。**  
当用户选的档位本身就是「从不询问」（内置 danger-full-access 档），宿主不会发审批请求，插件无法「先问」或「回绝」。是接受「此时三态不生效，只在界面说明」，还是要求插件拦截**所有**工具调用自行判定越界（需重算沙箱边界，行为可能与宿主不一致）？  
建议：接受前者，界面明示。

**C2. 「隐藏宿主说明」的边界。**  
是只隐藏宿主的自我描述（品牌 + 操作约定），还是连运行环境事实（工作目录、模型、当前权限档）一起隐藏？后者会让模型失去干活必需的信息。  
建议：只隐藏自述，保留运行环境事实。

**C3. 品牌替换的粒度。**  
「换成自定义文本」是只替换开头那一句，还是把整段身份说明都换成用户的文本？  
建议：只替换开头段，其余身份说明保留，界面给替换前后预览。

**C4. 卸载 / 回退时 Enhanced 档怎么处理。**  
卸载后是否要自动删除写进宿主配置的 Enhanced 档？「一键退回」是否应该回滚宿主配置（从 `.bak` 恢复）？  
建议：卸载不动宿主配置；「一键退回」提供「回滚档位写入」，回滚前再备一次份。

**C5. 状态文件的位置与可见性。**  
放在用户主目录固定路径（如 `%USERPROFILE%\.dsh\enhance\state.json`，方便手改、卸载后保留），还是放进程数据目录（更隐蔽、不易误删）？  
建议：主目录固定路径，界面显示完整路径。

**C6. 2KB / 8KB 的单位与超限行为。**  
按 UTF-8 字节还是字符计？超限时拒绝保存，还是截断保存？  
建议：UTF-8 字节；拒绝保存并提示，不落盘。

**C7. 状态文件损坏时的粒度与提示。**  
单个字段写坏（如 `"maybe"`）算整文件损坏全量回落，还是只回落该字段？是否需要界面常驻告警直到修好？  
建议：按字段回落 + 常驻横幅 + 检查结果里注明回落原因。

**C8. 「自动放行」的范围边界。**  
是**所有**审批请求一律放行（包括执行外部命令、下载、写系统目录），还是要按工具名/路径做白名单？  
建议：一律放行，但界面红字提示风险，并保留最近拦截/放行记录供检查。

---

## 5. 探测记录附录（关键契约摘要）

| 能力 | 探测结论（原文要点） |
|---|---|
| `approval` | `ApprovalPolicy = 'ask' \| 'never'`；`ApprovalOutcome = 'allowed-once' \| 'rejected' \| 'cancelled' \| 'unavailable'`；`request()` 要求回合打开，审计成对写日志；`setPolicy(agent, policy)`、`overrideOf(session)` |
| `approval/request` 事件 | 瀑布：`(this: Scoped<Agent>, req: ApprovalRequestEvent, next) => Promise<ApprovalOutcome>`；详情接口报错，签名取自事件目录 |
| `permissionPresets` | `PresetSpec = { sandbox: 'read-only' \| 'workspace-write' \| 'danger-full-access'; approval: 'ask' \| 'never' }`；`catalog()` 返回 `{options, defaultOptions, defaultPreset}`；`current(session)`、`resolve(name)`、`set(session,name)`；未匹配报 `CUSTOM_PRESET` |
| `permission-presets` 配置 | `presets` 映射 + `defaultPreset`（volatile）；内置默认两档：`workspace-write`（workspace-write + ask）、`danger-full-access`（danger-full-access + never）；整块替换语义 |
| `systemPrompt` | `section({ name, order, text, complete? })`；`context()`、`variable()`、`suppressRuntimeContext()`；`assemble()`；scoped section 同名覆盖全局；同层重名抛错 |
| `system-prompt/assemble` 事件 | 瀑布，可改 `sections/contexts/variables`；**但 complete section 会在瀑布后恢复为唯一系统提示** |
| `system-prompt` 配置 | `includeHarnessIdentity`(默认 true)、`includeRuntimeContext`(默认 true)、`personaPrefix`、`personaSuffix`（这正是需求说的「品牌声明」和「宿主说明」的宿主开关） |
| `fs` | `resolve`、`stat`、`readText`、`writeText`（原子、可带版本守卫）、`editText`、`deleteFile`、`moveFile`、`watch`（异步初始化） |
| `sessionQuery` | `readSurface(sessionId)`（当前模型表面，含 system 消息）、`readSession`、`listEvents`、`readEvent`、`searchEvents`、`observeSession` |
| `settings` | `describe()`（含 revision）、`update(ns, patch, expectedRevision)`、`replace()`、`mutate()`、`prepareDocument()`（定位 profile patch 文件）、`configure({auto})`（本插件页面策略） |
| `configEditor` | `entries()`、`configuration()`、`edit(entry, change)`（走正常 Loader 路径持久化完整配置） |
| `tools` / `tools/pre-execute` | `register(definition)`；瀑布可 `allow/deny/cancel/ask`；`deny` 带 `reason` 与 `ToolErrorInfo`（三态的备用接缝，但判定越界要自己重算，不建议） |
| 客户端 | `Service`/`Event`/`Slots`/`Builtin` 全部超时，**无结论**；设置页槽位与 Remote 命名空间待验 |

---

## 6. 本轮未做 / 未验的事（诚实清单）

- 未安装任何插件、未改任何 DSH 配置（遵守任务边界），因此没有运行时证据，只有契约证据。
- 未读取 DSH 源码与包文档（遵守「只读 process-lab」），R1 的 complete section 问题只能靠实施期探针确认。
- 客户端设置页的槽位、注册 API、Remote 生成方式全部未验证。
- `approval/request` 的完整参数类型未取到（inspect 报错），只拿到目录签名与请求/结果类型名。
