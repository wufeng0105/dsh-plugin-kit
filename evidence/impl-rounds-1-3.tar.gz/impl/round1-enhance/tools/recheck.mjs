#!/usr/bin/env node
/**
 * recheck.mjs — 「DSH 升级后，我的触点还成立吗？」
 *
 * 输入：
 *   09-touchpoints.json     触点清单（本仓根目录）
 *   <snapshot>.json         宿主探测快照（由会话用 cordis_inspect_query 导出，见 tools/host-snapshot.sample.json）
 *
 * 输出：逐条 OK / MISSING / CHANGED / UNVERIFIABLE；有 MISSING 或 CHANGED 时退出码 1，否则 0
 *       （--strict 时 UNVERIFIABLE 也算失败）。
 *
 * 约束：不联网、不安装、不读不写 $DSH_HOME；只读清单、快照与本仓 bundle 内的文件。
 *
 * 用法：
 *   node tools/recheck.mjs                                   # 默认清单 + 样本快照
 *   node tools/recheck.mjs --snapshot tools/host-2026-12.json
 *   node tools/recheck.mjs --json | --strict | --no-scan
 *   node tools/recheck.mjs --self-test                        # 自造反例，证明会变红
 *
 * 四种结论的语义（与清单里的 status 不是一回事）：
 *   OK           快照/文件里能找到该触点，且签名/内容与清单期望一致
 *   MISSING      触点整个不见了（服务/方法/事件/类型/文件/清单键缺失）
 *   CHANGED      还在，但形状变了（签名不含期望片段、类型声明变了、文件 hash 变了、宿主补上了 absent 字段）
 *   UNVERIFIABLE 机器判不了：清单标了 probe.kind=none（需人工/读安装源码），或快照缺该小节
 */

import { readFileSync, existsSync, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, '..');

// ---------------------------------------------------------------- 参数

function parseArgs(argv) {
  const opts = {
    touchpoints: path.join(ROOT, '09-touchpoints.json'),
    snapshot: path.join(HERE, 'host-snapshot.sample.json'),
    json: false,
    strict: false,
    scan: true,
    selfTest: false,
    help: false,
  };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--touchpoints') opts.touchpoints = path.resolve(argv[++i]);
    else if (arg === '--snapshot') opts.snapshot = path.resolve(argv[++i]);
    else if (arg === '--json') opts.json = true;
    else if (arg === '--strict') opts.strict = true;
    else if (arg === '--no-scan') opts.scan = false;
    else if (arg === '--self-test') opts.selfTest = true;
    else if (arg === '--help' || arg === '-h') opts.help = true;
    else throw new Error(`未知参数：${arg}（--help 看用法）`);
  }
  return opts;
}

// ---------------------------------------------------------------- 工具

const norm = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();

function readJson(file) {
  if (!existsSync(file)) throw new Error(`文件不存在：${file}`);
  try {
    return JSON.parse(readFileSync(file, 'utf8'));
  } catch (error) {
    throw new Error(`不是合法 JSON：${file}（${error.message}）`);
  }
}

function typeDeclaration(holder, name) {
  const raw = holder?.types?.[name];
  if (raw === undefined || raw === null) return undefined;
  return Array.isArray(raw) ? raw.join('\n') : String(raw);
}

// ---------------------------------------------------------------- 单条判定

/**
 * @returns {{ code: 'OK'|'MISSING'|'CHANGED'|'UNVERIFIABLE', detail: string }}
 */
function checkTouchpoint(tp, snapshot, root) {
  const probe = tp.probe ?? {};
  const kind = probe.kind ?? 'none';

  if (kind === 'none') {
    return { code: 'UNVERIFIABLE', detail: probe.manual ?? '清单未给出可机器判定的探针' };
  }

  if (kind === 'service') {
    const service = snapshot?.services?.[probe.service];
    if (service === undefined) {
      return { code: 'MISSING', detail: `快照里没有服务 ${probe.service}（宿主可能改名/移除）` };
    }
    if (probe.method === undefined) return { code: 'OK', detail: `服务 ${probe.service} 存在` };
    const actual = service?.methods?.[probe.method];
    if (actual === undefined) {
      return { code: 'MISSING', detail: `服务 ${probe.service} 上没有方法 ${probe.method}()` };
    }
    for (const want of probe.signatureIncludes ?? []) {
      if (!norm(actual).includes(norm(want))) {
        return { code: 'CHANGED', detail: `${probe.service}.${probe.method} 签名不含「${want}」；实际：${norm(actual)}` };
      }
    }
    return { code: 'OK', detail: `${probe.service}.${probe.method}() 存在且签名匹配` };
  }

  if (kind === 'event') {
    const event = snapshot?.events?.[probe.event];
    if (event === undefined) {
      return { code: 'MISSING', detail: `快照里没有事件 ${probe.event}` };
    }
    if (probe.mode !== undefined && event.mode !== probe.mode) {
      return { code: 'CHANGED', detail: `${probe.event} 的 mode 从 ${probe.mode} 变成 ${event.mode}` };
    }
    for (const want of probe.signatureIncludes ?? []) {
      if (!norm(event.signature).includes(norm(want))) {
        return { code: 'CHANGED', detail: `${probe.event} 签名不含「${want}」；实际：${norm(event.signature)}` };
      }
    }
    return { code: 'OK', detail: `${probe.event} 存在（mode=${event.mode}）且签名匹配` };
  }

  if (kind === 'type') {
    const via = probe.via ?? {};
    const holder = via.event !== undefined
      ? snapshot?.events?.[via.event]
      : via.service !== undefined
        ? snapshot?.services?.[via.service]
        : undefined;
    if (holder === undefined) {
      return { code: 'MISSING', detail: `找不到类型 ${probe.type} 的来源（via=${JSON.stringify(via)}）` };
    }
    const declaration = typeDeclaration(holder, probe.type);
    if (declaration === undefined) {
      return { code: 'MISSING', detail: `来源里没有类型 ${probe.type}` };
    }
    for (const want of probe.contains ?? []) {
      if (!norm(declaration).includes(norm(want))) {
        return { code: 'CHANGED', detail: `${probe.type} 不再含「${want}」；实际：${norm(declaration).slice(0, 240)}` };
      }
    }
    for (const bad of probe.absent ?? []) {
      if (norm(declaration).includes(norm(bad))) {
        return { code: 'CHANGED', detail: `${probe.type} 现在含「${bad}」——宿主补了这个字段，代码端可以/需要改` };
      }
    }
    return { code: 'OK', detail: `${probe.type} 形状符合期望` };
  }

  if (kind === 'file') {
    const file = path.resolve(root, probe.path);
    if (!existsSync(file) || !statSync(file).isFile()) {
      return { code: 'MISSING', detail: `文件不存在：${probe.path}` };
    }
    const bytes = readFileSync(file);
    if (probe.sizeBytes !== undefined && bytes.length !== probe.sizeBytes) {
      return { code: 'CHANGED', detail: `${probe.path} 大小 ${bytes.length}B ≠ 期望 ${probe.sizeBytes}B` };
    }
    if (probe.sha1 !== undefined) {
      const actual = createHash('sha1').update(bytes).digest('hex');
      if (actual !== probe.sha1) {
        return { code: 'CHANGED', detail: `${probe.path} sha1 ${actual} ≠ 期望 ${probe.sha1}（包被重打或替换）` };
      }
    }
    const text = bytes.toString('utf8');
    for (const want of probe.contains ?? []) {
      if (!norm(text).includes(norm(want))) {
        return { code: 'CHANGED', detail: `${probe.path} 里找不到「${want}」` };
      }
    }
    return { code: 'OK', detail: `${probe.path} 存在${probe.sha1 ? '且 sha1 匹配' : '且内容匹配'}` };
  }

  if (kind === 'package') {
    const file = path.resolve(root, probe.file ?? 'bundle/package.json');
    if (!existsSync(file)) return { code: 'MISSING', detail: `包清单不存在：${probe.file ?? 'bundle/package.json'}` };
    let manifest;
    try {
      manifest = JSON.parse(readFileSync(file, 'utf8'));
    } catch (error) {
      return { code: 'CHANGED', detail: `包清单不是合法 JSON（${error.message}）` };
    }
    let cursor = manifest;
    for (const key of probe.path ?? []) {
      if (cursor === null || typeof cursor !== 'object' || !(key in cursor)) {
        return { code: 'MISSING', detail: `package.json 缺少 ${(probe.path ?? []).join('.')}` };
      }
      cursor = cursor[key];
    }
    if (probe.equals !== undefined && cursor !== probe.equals) {
      return { code: 'CHANGED', detail: `${(probe.path ?? []).join('.')} = ${JSON.stringify(cursor)} ≠ ${JSON.stringify(probe.equals)}` };
    }
    return { code: 'OK', detail: `package.json ${(probe.path ?? []).join('.')} = ${JSON.stringify(cursor)}` };
  }

  throw new Error(`触点 ${tp.id} 的 probe.kind "${kind}" 不认识（清单写错了）`);
}

// ---------------------------------------------------------------- 漂移扫描（清单 vs 代码）

const SCAN_FILES = (root) => [
  'bundle/index.js',
  'bundle/client.js',
  'bundle/host/approval-service.js',
  'bundle/host/atomic-file.js',
  'bundle/host/check-service.js',
  'bundle/host/controller.js',
  'bundle/host/paths.js',
  'bundle/host/preset-service.js',
  'bundle/host/prompt-service.js',
  'bundle/host/state-store.js',
].map((rel) => path.resolve(root, rel));

/** 从生产代码里抽出宿主引用字面量，找出清单没写到的那些。 */
export function scanDrift(touchpoints, root) {
  const haystack = norm(touchpoints.map((tp) => `${tp.ref} ${tp.code} ${tp.why}`).join('  '));
  const found = new Set();
  for (const file of SCAN_FILES(root)) {
    if (!existsSync(file)) continue;
    const text = readFileSync(file, 'utf8');
    for (const match of text.matchAll(/ctx\.get\(\s*'([^']+)'/g)) found.add(`ctx.get('${match[1]}'`);
    for (const match of text.matchAll(/ctx\.on\(\s*'([^']+)'/g)) found.add(`ctx.on('${match[1]}'`);
    const inject = text.match(/export const inject\s*=\s*\[([^\]]*)\]/);
    if (inject) {
      for (const match of inject[1].matchAll(/'([^']+)'/g)) found.add(`inject:${match[1]}`);
    }
    if (/ctx\.slots\./.test(text)) found.add('ctx.slots.*');
    if (/ctx\.remote\./.test(text)) found.add('ctx.remote.*');
  }
  const missingFromList = [];
  for (const ref of found) {
    if (ref.startsWith('inject:')) {
      const name = ref.slice('inject:'.length);
      if (!haystack.includes(`'${name}'`)) missingFromList.push(ref);
    } else if (ref === 'ctx.slots.*') {
      if (!haystack.includes('ctx.slots')) missingFromList.push(ref);
    } else if (ref === 'ctx.remote.*') {
      if (!haystack.includes('ctx.remote')) missingFromList.push(ref);
    } else if (!haystack.includes(ref)) {
      missingFromList.push(ref);
    }
  }
  return missingFromList;
}

// ---------------------------------------------------------------- 主流程

const ORDER = { MISSING: 0, CHANGED: 1, UNVERIFIABLE: 2, OK: 3 };

function run(touchpoints, snapshot, { root = ROOT, scan = true } = {}) {
  const rows = touchpoints.map((tp) => {
    const { code, detail } = checkTouchpoint(tp, snapshot, root);
    return {
      id: tp.id,
      surface: tp.surface,
      declared: tp.status,
      code,
      detail,
      ref: tp.ref,
      fallback: tp.fallback,
    };
  });
  const counts = { OK: 0, MISSING: 0, CHANGED: 0, UNVERIFIABLE: 0 };
  for (const row of rows) counts[row.code] += 1;
  const drift = scan ? scanDrift(touchpoints, root) : [];
  const exitCode = counts.MISSING + counts.CHANGED + drift.length > 0 ? 1 : 0;
  return { rows, counts, drift, exitCode, total: rows.length };
}

function strictExit(result) {
  return result.exitCode === 1 || result.counts.UNVERIFIABLE > 0 ? 1 : 0;
}

function printHuman(result, { strict, snapshotPath, touchpointsPath, hostHeader }) {
  console.log(`触点复检 — 宿主 ${hostHeader ?? '未知版本'}`);
  console.log(`清单：${path.relative(ROOT, touchpointsPath) || touchpointsPath}`);
  console.log(`快照：${path.relative(ROOT, snapshotPath) || snapshotPath}`);
  console.log('');
  const width = Math.max(...result.rows.map((row) => row.id.length), 4);
  for (const row of result.rows.sort((a, b) => ORDER[a.code] - ORDER[b.code])) {
    console.log(`${row.code.padEnd(13)} ${row.id.padEnd(width)}  ${row.detail}`);
  }
  if (result.drift.length > 0) {
    console.log('');
    console.log('DRIFT（代码里有引用，清单没写）');
    for (const ref of result.drift) console.log(`  - ${ref}`);
  }
  console.log('');
  console.log(
    `合计 ${result.total} 条：OK ${result.counts.OK} / MISSING ${result.counts.MISSING} / CHANGED ${result.counts.CHANGED} / UNVERIFIABLE ${result.counts.UNVERIFIABLE}` +
      `（DRIFT ${result.drift.length}）→ 退出码 ${strict ? strictExit(result) : result.exitCode}${strict ? '（strict）' : ''}`,
  );
}

// ---------------------------------------------------------------- 自检：造两条反例

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function selfTest(touchpoints, snapshot) {
  const results = [];
  const base = run(touchpoints, snapshot, { scan: false });
  results.push({
    name: '基线（不改快照）',
    expect: 'exit=0 且无 MISSING/CHANGED',
    pass: base.exitCode === 0 && base.counts.MISSING === 0 && base.counts.CHANGED === 0,
    detail: `exit=${base.exitCode} MISSING=${base.counts.MISSING} CHANGED=${base.counts.CHANGED}`,
  });

  // 反例 1：从快照里删掉一条触点（宿主升级把某个方法删了）
  const deleted = clone(snapshot);
  delete deleted.services.systemPrompt.methods.suppressRuntimeContext;
  const afterDelete = run(touchpoints, deleted, { scan: false });
  const deleteRow = afterDelete.rows.find((row) => row.id === 'svc.systemPrompt.suppressRuntimeContext');
  results.push({
    name: '反例 1：删掉 services.systemPrompt.methods.suppressRuntimeContext',
    expect: 'svc.systemPrompt.suppressRuntimeContext = MISSING，整体 exit=1',
    pass: deleteRow?.code === 'MISSING' && afterDelete.exitCode === 1,
    detail: `该条=${deleteRow?.code} exit=${afterDelete.exitCode}（${deleteRow?.detail}）`,
  });

  // 反例 2：改一处签名（宿主把参数名 req 改成 request）
  const renamed = clone(snapshot);
  renamed.events['approval/request'].signature = renamed.events['approval/request'].signature.replace(
    'req: ApprovalRequestEvent',
    'request: ApprovalRequestEvent',
  );
  const afterRename = run(touchpoints, renamed, { scan: false });
  const renameRow = afterRename.rows.find((row) => row.id === 'evt.approval-request');
  results.push({
    name: '反例 2：approval/request 签名 req → request',
    expect: 'evt.approval-request = CHANGED，整体 exit=1',
    pass: renameRow?.code === 'CHANGED' && afterRename.exitCode === 1,
    detail: `该条=${renameRow?.code} exit=${afterRename.exitCode}（${renameRow?.detail}）`,
  });

  // 反例 3（附加）：改类型声明字段名，证明 type 探针也有效
  const retyped = clone(snapshot);
  retyped.events['approval/request'].types.ApprovalRequestEvent =
    "export interface ApprovalRequestEvent {\n readonly agent: Agent;\n readonly tool: string;\n readonly callId?: ToolCallId;\n}";
  const afterRetype = run(touchpoints, retyped, { scan: false });
  const retypeRow = afterRetype.rows.find((row) => row.id === 'type.ApprovalRequestEvent');
  results.push({
    name: '反例 3：ApprovalRequestEvent.toolName → tool',
    expect: 'type.ApprovalRequestEvent = CHANGED，整体 exit=1',
    pass: retypeRow?.code === 'CHANGED' && afterRetype.exitCode === 1,
    detail: `该条=${retypeRow?.code} exit=${afterRetype.exitCode}（${retypeRow?.detail}）`,
  });

  const allPass = results.every((row) => row.pass);
  console.log('recheck 自检（反例证明）');
  for (const row of results) {
    console.log(`${row.pass ? 'PASS' : 'FAIL'}  ${row.name}`);
    console.log(`      期望：${row.expect}`);
    console.log(`      实际：${row.detail}`);
  }
  console.log('');
  console.log(allPass ? '自检通过：脚本确实会变红。' : '自检失败：脚本没有按预期变红。');
  return allPass ? 0 : 1;
}

// ---------------------------------------------------------------- 入口

function main() {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) {
    console.log('用法：node tools/recheck.mjs [--touchpoints <清单>] [--snapshot <快照>] [--json] [--strict] [--no-scan] [--self-test]');
    return 0;
  }
  const doc = readJson(opts.touchpoints);
  const touchpoints = doc.touchpoints ?? doc;
  if (!Array.isArray(touchpoints) || touchpoints.length === 0) {
    throw new Error(`清单里没有 touchpoints 数组：${opts.touchpoints}`);
  }
  const snapshot = readJson(opts.snapshot);

  if (opts.selfTest) return selfTest(touchpoints, snapshot);

  const result = run(touchpoints, snapshot, { scan: opts.scan });
  if (opts.json) {
    console.log(JSON.stringify({ host: snapshot.host, ...result, exitCode: opts.strict ? strictExit(result) : result.exitCode }, null, 2));
  } else {
    printHuman(result, {
      strict: opts.strict,
      snapshotPath: opts.snapshot,
      touchpointsPath: opts.touchpoints,
      hostHeader: snapshot?.host?.version,
    });
  }
  return opts.strict ? strictExit(result) : result.exitCode;
}

try {
  process.exitCode = main();
} catch (error) {
  console.error(`recheck 失败：${error.message}`);
  process.exitCode = 2;
}
