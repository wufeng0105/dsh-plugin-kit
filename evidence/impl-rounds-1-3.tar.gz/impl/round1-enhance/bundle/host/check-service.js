/**
 * Step 8 glue: read the session surface back, hand it to the pure comparison.
 *
 * `readSurface` is injected so this module needs no Host service and can be
 * tested; in index.js it is `() => ctx.sessionQuery.readSurface(agent.session.id)`.
 * A throwing or empty reader becomes "no-data", never a fake success
 * (requirement 7 / analysis A14).
 *
 * If the snapshot carries `baseline` (pre-transform assembly or text) or
 * `transformLog` (the change log from `transformPresentation`), they are handed
 * to the comparison so the hide item can prove the transform really removed
 * something; see lib/check.js (MAJOR-2).
 */
import { checkEffectiveness } from '../lib/check.js';

/**
 * @param {{ state: object, personaText?: string, boundaryText?: string, catalog?: object,
 *   flags?: object, sessionId?: string, readSurface?: (input: { sessionId?: string }) => Promise<object|null> }} input
 * @returns {Promise<{ verdict: string, items: object[], reasons: string[] }>}
 */
export async function runCheck(input) {
  const { state, personaText = '', boundaryText = '', catalog, flags, sessionId, readSurface } = input;
  if (typeof readSurface !== 'function') {
    return { verdict: 'no-data', items: [], reasons: ['read-failed'] };
  }
  let snapshot;
  try {
    snapshot = await readSurface({ sessionId });
  } catch {
    return { verdict: 'no-data', items: [], reasons: ['read-failed'] };
  }
  if (snapshot === null || snapshot === undefined) {
    return { verdict: 'no-data', items: [], reasons: ['no-system-surface'] };
  }
  return checkEffectiveness({
    text: snapshot.systemText,
    sections: snapshot.sections,
    contexts: snapshot.contexts,
    // The surface snapshot should carry the pre-transform assembly and/or the
    // transform change log once the prompt bridge is wired; without them the
    // hide item stays unproven instead of claiming a fake success (MAJOR-2).
    baseline: snapshot.baseline,
    transformLog: snapshot.transformLog,
    state,
    personaText,
    boundaryText,
    catalog,
    flags,
  });
}
