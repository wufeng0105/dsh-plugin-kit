/**
 * Step 3: the state-file service.
 *
 * One directory (`<home>/.dsh/enhance` by default, client decision C5), three
 * files: `state.json`, `identity.txt`, `content-scope.txt`. The page and the
 * user's text editor touch the same files (requirement 6), so nothing here is
 * cached or mirrored.
 *
 * Error classification (02-plan Step 3):
 * - missing file      -> defaults, status `missing`
 * - unparseable file  -> defaults + issues, status `corrupt`
 * - bad field(s)      -> that field falls back + issues, status `degraded`
 *                        (the banner must fire for this too: C7/A11)
 * - unreadable        -> status `unreadable`, code `readonly` (the page shows a
 *                        banner and keeps the controls disabled)
 * A load never writes and never creates the directory; only a save does.
 *
 * All writes go through host/atomic-file.js: validate first, back up second,
 * write third. An over-limit text therefore cannot damage any file
 * (acceptance 4).
 */
import * as nodeFs from 'node:fs/promises';
import * as pathModule from 'node:path';
import { LIMITS } from '../lib/constants.js';
import { defaultState, normalizeState, parseState, serializeState } from '../lib/state.js';
import { validateText } from '../lib/text.js';
import { parseBackupName } from '../lib/backup.js';
import { statePaths } from './paths.js';
import { classifyIoError, readFileOrNull, saveWithBackup } from './atomic-file.js';

const TEXT_CONTENT = 'text/plain';

/**
 * @param {{ fs?: object, dir: string, now?: () => Date, limits?: typeof LIMITS,
 *   offsetMinutes?: number }} input
 */
export function createEnhanceStore(input) {
  const { fs = nodeFs, dir, now = () => new Date(), limits = LIMITS, offsetMinutes } = input;
  const paths = statePaths({ dir, join: pathModule.join });

  async function ensureDir() {
    await fs.mkdir(paths.dir, { recursive: true });
  }

  /**
   * @returns {Promise<{ status: 'ok'|'missing'|'degraded'|'corrupt'|'unreadable', state: object,
   *   issues: object[], extra: Record<string, unknown>, corrupt: boolean, code?: string }>}
   */
  async function load() {
    let raw;
    try {
      raw = await readFileOrNull(fs, paths.state);
    } catch (error) {
      return {
        status: 'unreadable',
        state: defaultState(),
        issues: [{ field: '*', code: 'unreadable', message: String(error?.message ?? error), fellBackTo: 'defaults' }],
        extra: {},
        corrupt: false,
        code: classifyIoError(error),
      };
    }
    if (raw === null) {
      return { status: 'missing', state: defaultState(), issues: [], extra: {}, corrupt: false };
    }
    const parsed = parseState(raw);
    // Per-field fallback is not "ok": the page's damage banner keys off this
    // status, and C7/A11 require it exactly when one field was thrown away
    // (verification MINOR-3).
    const status = parsed.corrupt ? 'corrupt' : parsed.issues.length > 0 ? 'degraded' : 'ok';
    return { status, ...parsed };
  }

  /**
   * @param {object} patch partial state from the page
   * @returns {Promise<{ ok: true, state: object, backup: string|null }
   *   | { ok: false, code: string, issues?: object[] }>}
   */
  async function saveState(patch = {}) {
    const loaded = await load();
    if (loaded.status === 'unreadable') return { ok: false, code: loaded.code ?? 'readonly' };
    if (loaded.issues.some((issue) => issue.code === 'unsupported-version')) {
      return { ok: false, code: 'version-conflict' };
    }
    const normalized = normalizeState({ ...loaded.state, ...patch });
    if (normalized.issues.length > 0) {
      return { ok: false, code: 'invalid-patch', issues: normalized.issues };
    }
    const text = serializeState(normalized.state, { ...loaded.extra, ...normalized.extra });
    await ensureDir();
    const written = await saveWithBackup({
      fs,
      file: paths.state,
      text,
      base: 'state',
      now,
      offsetMinutes,
    });
    if (!written.ok) return { ok: false, code: written.code };
    return { ok: true, state: normalized.state, backup: written.backup };
  }

  const textLimits = { persona: limits.personaBytes, boundary: limits.boundaryBytes };

  async function saveText(kind, text) {
    const validated = validateText(text, textLimits[kind]);
    if (!validated.ok) return { ok: false, ...validated };
    await ensureDir();
    const written = await saveWithBackup({
      fs,
      file: paths[kind],
      text: validated.text,
      base: kind,
      now,
      offsetMinutes,
    });
    if (!written.ok) return { ok: false, code: written.code };
    return { ok: true, bytes: validated.bytes, backup: written.backup, contentType: TEXT_CONTENT };
  }

  /** @param {'persona'|'boundary'} kind */
  async function readTextFile(kind) {
    try {
      return await readFileOrNull(fs, paths[kind]);
    } catch {
      return null;
    }
  }

  /** C4 ①: switches back to defaults, user text kept. */
  async function resetStateToDefault() {
    return saveState(defaultState());
  }

  /** Backup files present in the state directory, grouped by base name. */
  async function listBackups() {
    let names = [];
    try {
      names = await fs.readdir(paths.dir);
    } catch {
      return { state: [], persona: [], boundary: [] };
    }
    const pick = (base) =>
      names
        .filter((name) => name.startsWith(`${base}-`) && name.endsWith('.bak'))
        .filter((name) => parseBackupName(name, { base }) !== null)
        .sort();
    return { state: pick('state'), persona: pick('persona'), boundary: pick('boundary') };
  }

  return { paths, load, saveState, savePersonaText: (text) => saveText('persona', text), saveBoundaryText: (text) => saveText('boundary', text), readTextFile, resetStateToDefault, listBackups };
}
