/**
 * Step 5: the approval tristate, host-facing half.
 *
 * The decision itself is pure (lib/approval.js). This module adds what the
 * waterfall needs: call `next()` for "ask", answer directly for allow/deny, and
 * keep the bounded record the Check panel shows (client decision C8).
 *
 * The listener signature is the one recorded in 01-analysis §5:
 *   ctx.on('approval/request', async (request, next) => ApprovalOutcome)
 * UNVERIFIED: whether a plugin-level listener fires for every agent's approval
 * request (analysis R11). If it turns out to be scoped per agent, the wiring in
 * index.js must move to an `agent/created` listener; the logic below does not
 * change.
 */
import { createRing, decideApproval, approvalDirective, pushDecision } from '../lib/approval.js';

function summarizeRequest(request) {
  // Host contract (`ApprovalRequestEvent`): the tool name field is `toolName`.
  // `callId` is optional. Reading `request.tool` recorded null for every entry
  // (verification MINOR-1).
  return {
    tool: typeof request?.toolName === 'string' ? request.toolName : null,
    callId: typeof request?.callId === 'string' ? request.callId : null,
  };
}

/**
 * Resolve the approval policy the session's permission preset carries (C1).
 *
 * Host contract (`permissionPresets`): `current(session)` returns the preset
 * name (or `custom`), `resolve(name)` returns `PresetSpec` with `approval:
 * 'ask' | 'never'`. `custom` means no configured preset matches, so this
 * function answers `undefined` instead of guessing - `explainTristate` then
 * simply does not claim `preset-never`. Every failure is `undefined`, never a
 * made-up policy (verification MINOR-5).
 *
 * @param {{ current?: Function, resolve?: Function } | undefined | null} presets
 * @param {object | undefined | null} session
 * @returns {'ask'|'never'|undefined}
 */
export function approvalPolicyOf(presets, session) {
  if (presets === undefined || presets === null) return undefined;
  if (session === undefined || session === null) return undefined;
  if (typeof presets.current !== 'function' || typeof presets.resolve !== 'function') return undefined;
  try {
    const name = presets.current(session);
    if (typeof name !== 'string' || name === '') return undefined;
    const spec = presets.resolve(name);
    if (spec?.approval === 'ask' || spec?.approval === 'never') return spec.approval;
    return undefined;
  } catch {
    return undefined;
  }
}

/**
 * @param {{ state: object, request: object, next: () => Promise<string>,
 *   now?: () => Date, ring: object }} input
 * @returns {Promise<{ outcome: string, usedNext: boolean, ring: object, decision: string, entry: object }>}
 */
export async function handleApprovalRequest(input) {
  const { state, request, next, now = () => new Date(), ring = createRing() } = input;
  const decision = decideApproval(state);
  const directive = approvalDirective(decision);
  const entry = {
    at: now().toISOString(),
    decision,
    reasonCode: directive.reasonCode,
    request: summarizeRequest(request),
  };
  const nextRing = pushDecision(ring, entry);
  if (directive.callNext) {
    const outcome = await next();
    return { outcome, usedNext: true, ring: nextRing, decision, entry };
  }
  return { outcome: directive.outcome, usedNext: false, ring: nextRing, decision, entry };
}
