/**
 * Step 4: the prompt runtime bridge - deliberately NOT wired this round.
 *
 * Why: the only working seam depends on facts a probe must establish first
 * (02-plan Step 0, analysis R1):
 *   P1. the real names/orders of the host sections, and whether the identity
 *       paragraph is a `complete` section (the assemble waterfall cannot rewrite
 *       one - "listeners cannot add to or replace that scope's system prompt");
 *   P2. whether a plugin waterfall listener sees `{ sections, contexts,
 *       variables }` and can return a replacement payload;
 *   P5. how `systemPrompt.suppressRuntimeContext()` interacts with the two
 *       runtime-context blocks (client decision C2 hides them together).
 * Guessing these would produce a plugin that either does nothing or damages the
 * prompt. The pure transform (lib/sections.js) is finished and tested; only the
 * wiring is missing, and `planRegistrations` below is the tested decision of
 * what the wiring will register. (`flags` is `effectiveFlags(state)` from
 * lib/state.js.)
 */

/**
 * What must be registered for the current flags?
 *
 * All off must register nothing at all, so that the assembled prompt stays
 * byte-identical to the host's own (acceptance 1).
 *
 * @param {object} flags output of `effectiveFlags(state)` (lib/state.js)
 * @returns {{ needsAssembleListener: boolean, needsBoundarySection: boolean }}
 */
export function planRegistrations(flags) {
  const master = flags?.master === true;
  return {
    needsAssembleListener:
      master && (flags?.persona?.enabled === true || flags?.hideHostNotes?.enabled === true),
    needsBoundarySection: master && flags?.boundary?.enabled === true,
  };
}

/**
 * WIRING SKETCH (not executed this round; kept here so the next implementer sees
 * the intended shape next to the plan):
 *
 *   const bridge = createPromptBridge({
 *     getState:     () => store.load().then((r) => r.state),
 *     getPersona:   () => store.readTextFile('persona'),
 *     getBoundary:  () => store.readTextFile('boundary'),
 *     systemPrompt: ctx.systemPrompt,       // section() / suppressRuntimeContext()
 *     on:           (event, handler) => ctx.on(event, handler),
 *     catalog:      probeCatalog,           // filled from probe P1
 *   });
 *   ctx.effect(() => bridge.sync());          // re-run after every state change
 *   ctx.effect(() => bridge.dispose);
 *
 * sync() must:
 *   1. compute flags and call planRegistrations;
 *   2. register/unregister the boundary section from the effective text;
 *   3. add/remove the `system-prompt/assemble` listener;
 *   4. inside the listener, call transformPresentation(payload, {...}) and
 *      return the rewritten payload, then apply `effects.suppressRuntimeContext`
 *      through the host's own method (never by editing strings).
 *
 * @returns {{ sync: () => void, dispose: () => void, status: () => object }}
 */
export function createPromptBridge() {
  return {
    sync() {},
    dispose() {},
    status() {
      return { wired: false, reason: 'probe-required' };
    },
  };
}
