/**
 * Step 6 preparation: everything that can be decided before the host config is
 * touched.
 *
 * Requirement 4 / decision C4: read the live table, merge, back up, write the
 * whole table, and make the rollback restore from the newest `.bak` after taking
 * one more backup. The pure merge lives in lib/preset.js; this module only adds
 * the backup naming and the safety verdict.
 *
 * Writing the profile configuration is NOT implemented this round (project
 * constraint: no host-config writes without authorisation). host/preset-host.js
 * is the deliberate stub for it; see 03-implementation.md.
 */
import { backupName } from '../lib/backup.js';
import { assertSafeWrite, diffPresetTables, enhancedPreset, mergePresetTable } from '../lib/preset.js';

/**
 * @param {{ table: object, preset?: object, key?: string, overwrite?: boolean,
 *   now?: Date, offsetMinutes?: number, taken?: string[] }} input
 * @returns {{ ok: boolean, changed: boolean, conflict: boolean, blockers: object[],
 *   issues: object[], table: object, diff: object, backup: string }}
 */
export function preparePresetWrite(input) {
  const {
    table,
    preset = enhancedPreset(),
    key = 'enhanced',
    overwrite = false,
    now = new Date(),
    offsetMinutes,
    taken = [],
  } = input;
  const before = table ?? {};
  const merge = mergePresetTable(before, preset, { key, overwrite });
  const safety = assertSafeWrite(before, merge.table);
  const diff = diffPresetTables(before, merge.table);
  const backup = backupName({ base: 'config', now, offsetMinutes, taken });
  return {
    ok: merge.changed && safety.ok,
    changed: merge.changed,
    conflict: merge.conflict,
    blockers: safety.blockers,
    issues: merge.issues,
    table: merge.table,
    diff,
    backup,
  };
}

/**
 * C4 ②: roll the host config back from the newest `.bak`, taking one more backup
 * of the current text first. The caller does the file IO; this returns the exact
 * text to write and the name of the backup it must copy first.
 *
 * @param {{ currentText: string|null, backupText: string|null, now?: Date,
 *   offsetMinutes?: number, taken?: string[], base?: string }} input
 * @returns {{ ok: true, restoreText: string, backup: string } | { ok: false, code: 'no-backup' }}
 */
export function planRollback(input) {
  const { backupText, now = new Date(), offsetMinutes, taken = [], base = 'config' } = input;
  if (typeof backupText !== 'string') return { ok: false, code: 'no-backup' };
  return {
    ok: true,
    restoreText: backupText,
    backup: backupName({ base, now, offsetMinutes, taken }),
  };
}
