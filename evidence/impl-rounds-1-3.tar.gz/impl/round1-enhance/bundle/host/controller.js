/**
 * The controller the settings page talks to.
 *
 * This is the Host-side surface the Client half will reach through the Remote
 * mechanism (02-plan 3.8, still unverified: the client inspect timed out every
 * time). The methods are plain async functions so the same object can be exposed
 * as a Remote service or, if Remote is unavailable, through a local route later.
 *
 * Deliberate boundary this round:
 * - `writePreset` / `rollbackPreset` answer `{ ok: false, code: 'unauthorized' }`
 *   and touch nothing. Writing the host permission table needs the owner's
 *   authorisation (project constraint in 00-client-answers.md).
 * - No caching: every call reads the three files, so the page and a text editor
 *   always see the same truth (requirement 6).
 */
import { effectiveFlags } from '../lib/state.js';
import { explainTristate } from '../lib/approval.js';
import { validateText } from '../lib/text.js';
import { LIMITS } from '../lib/constants.js';
import { DEFAULT_CATALOG } from '../lib/sections.js';
import { runCheck } from './check-service.js';

/**
 * @param {{ store: object, readSurface?: Function, catalog?: object,
 *   getSessionPolicy?: (session?: object) => ('ask'|'never'|undefined),
 *   getRecentApprovals?: () => object[] }} input
 */
export function createEnhanceController(input) {
  const { store, readSurface, catalog = DEFAULT_CATALOG, getSessionPolicy, getRecentApprovals = () => [] } = input;

  // The decision ring lives in index.js; the page needs a copy of the newest
  // decisions (C8) and it must exist before the first approval too
  // (verification MINOR-4).
  function recentApprovals() {
    try {
      const value = getRecentApprovals();
      return Array.isArray(value) ? value : [];
    } catch {
      return [];
    }
  }

  async function read() {
    const [loaded, personaText, boundaryText] = await Promise.all([
      store.load(),
      store.readTextFile('persona'),
      store.readTextFile('boundary'),
    ]);
    return {
      status: loaded.status,
      state: loaded.state,
      issues: loaded.issues,
      extra: loaded.extra,
      personaText,
      boundaryText,
      effective: effectiveFlags(loaded.state),
    };
  }

  /**
   * @param {{ session?: object, sessionId?: string }} [options] the session (or
   *   id) whose permission preset should be resolved for the tristate banner
   *   (C1); without one the policy is simply unknown and `explainTristate`
   *   never claims `preset-never`.
   */
  async function status(options = {}) {
    const current = await read();
    return {
      ok: current.status !== 'unreadable',
      paths: store.paths,
      status: current.status,
      state: current.state,
      issues: current.issues,
      effective: current.effective,
      tristate: explainTristate({
        state: current.state,
        sessionPolicy:
          typeof getSessionPolicy === 'function'
            ? getSessionPolicy(options.session ?? options.sessionId)
            : undefined,
      }),
      // The page must show this: writing the host preset table is not armed.
      presetWrite: 'unauthorized',
      recentApprovals: recentApprovals(),
      backups: await store.listBackups(),
    };
  }

  /**
   * All-or-nothing save: validate every text first, then write. An over-limit
   * text must leave every file exactly as it was (acceptance 4).
   *
   * @param {{ state?: object, personaText?: string, boundaryText?: string }} patch
   */
  async function save(patch = {}) {
    const { state: statePatch = {}, personaText, boundaryText } = patch;
    if (personaText !== undefined) {
      const validated = validateText(personaText, LIMITS.personaBytes);
      if (!validated.ok) return { ok: false, ...validated, field: 'personaText' };
    }
    if (boundaryText !== undefined) {
      const validated = validateText(boundaryText, LIMITS.boundaryBytes);
      if (!validated.ok) return { ok: false, ...validated, field: 'boundaryText' };
    }
    if (personaText !== undefined) {
      const written = await store.savePersonaText(personaText);
      if (written.ok !== true) return written;
    }
    if (boundaryText !== undefined) {
      const written = await store.saveBoundaryText(boundaryText);
      if (written.ok !== true) return written;
    }
    if (statePatch !== null && typeof statePatch === 'object' && Object.keys(statePatch).length > 0) {
      const written = await store.saveState(statePatch);
      if (written.ok !== true) return written;
    }
    return { ok: true, ...(await read()) };
  }

  /** @param {{ sessionId?: string }} [options] */
  async function check(options = {}) {
    const current = await read();
    const checked = await runCheck({
      state: current.state,
      personaText: current.personaText ?? '',
      boundaryText: current.boundaryText ?? '',
      catalog,
      sessionId: options.sessionId,
      readSurface,
    });
    // C8: the Check panel shows the recent allow/deny decisions next to the
    // effectiveness items (verification MINOR-4).
    return { ...checked, recentApprovals: recentApprovals() };
  }

  /** C4 ①: switches back to defaults, user text kept. */
  async function reset() {
    const written = await store.resetStateToDefault();
    if (written.ok !== true) return written;
    return { ok: true, ...(await read()) };
  }

  /** C4 ② / requirement 4: needs the host-config authorisation. */
  async function writePreset() {
    return { ok: false, code: 'unauthorized' };
  }

  async function rollbackPreset() {
    return { ok: false, code: 'unauthorized' };
  }

  return { paths: store.paths, read, status, save, check, reset, writePreset, rollbackPreset };
}
