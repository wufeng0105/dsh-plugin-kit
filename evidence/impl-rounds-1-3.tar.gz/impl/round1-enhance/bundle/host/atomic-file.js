/**
 * Atomic file writes with a timestamped backup.
 *
 * Client decision R10 (analysis) requires: validate and back up BEFORE the main
 * file is touched, and never leave a half-written file behind. The `.bak` is a
 * byte copy of the previous file, so even a corrupt file is preserved for the
 * user instead of being silently replaced.
 *
 * The `fs` argument is an adapter object with the `node:fs/promises` shape
 * (`readFile`, `writeFile`, `rename`, `copyFile`, `readdir`, `unlink`). Keeping
 * it injectable means the same code runs against the Host's `fs` service later
 * and against a real temp directory in tests.
 */
import { dirname, join } from 'node:path';
import { backupName } from '../lib/backup.js';

let tmpCounter = 0;

/**
 * @param {unknown} error
 * @returns {'readonly'|'missing'|'no-space'|'io-error'}
 */
export function classifyIoError(error) {
  const code = error?.code;
  if (code === 'EACCES' || code === 'EPERM' || code === 'EROFS') return 'readonly';
  if (code === 'ENOENT') return 'missing';
  if (code === 'ENOSPC') return 'no-space';
  return 'io-error';
}

/** @returns {Promise<string|null>} null when the file does not exist */
export async function readFileOrNull(fs, file) {
  try {
    return await fs.readFile(file, 'utf8');
  } catch (error) {
    if (error?.code === 'ENOENT') return null;
    throw error;
  }
}

/** Write through a temp file and rename, so readers never see a partial file. */
export async function atomicWrite(fs, file, text) {
  tmpCounter += 1;
  const tmp = `${file}.tmp-${process.pid}-${tmpCounter}`;
  await fs.writeFile(tmp, text, 'utf8');
  try {
    await fs.rename(tmp, file);
  } catch (error) {
    try {
      await fs.unlink(tmp);
    } catch {
      // the temp file is already gone; the rename error is the one worth reporting
    }
    throw error;
  }
}

/**
 * @param {{ fs: object, file: string, text: string, base: string, ext?: string,
 *   now?: () => Date, offsetMinutes?: number }} input
 * @returns {Promise<{ ok: true, backup: string|null } | { ok: false, code: string, error: unknown }>}
 */
export async function saveWithBackup(input) {
  const { fs, file, text, base, ext = '.bak', now = () => new Date(), offsetMinutes } = input;
  try {
    const previous = await readFileOrNull(fs, file);
    let backup = null;
    if (previous !== null) {
      const dir = dirname(file);
      const taken = await fs.readdir(dir);
      backup = backupName({ base, ext, now: now(), offsetMinutes, taken });
      await fs.copyFile(file, join(dir, backup));
    }
    await atomicWrite(fs, file, text);
    return { ok: true, backup };
  } catch (error) {
    return { ok: false, code: classifyIoError(error), error };
  }
}
