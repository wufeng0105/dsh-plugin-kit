/**
 * Where the three state files live (client decision C5):
 * `<home>/.dsh/enhance/{state.json,identity.txt,content-scope.txt}`.
 *
 * `join` is injected so the function is testable on any OS and so callers can
 * decide which path flavour to use. `resolveBaseDir` returns a result object
 * instead of throwing, because a plugin that cannot find a home directory must
 * degrade to "state unavailable" rather than break the Host.
 */

export const STATE_FILES = {
  state: 'state.json',
  persona: 'identity.txt',
  boundary: 'content-scope.txt',
};

/**
 * @param {{ override?: string, home?: string, join?: (...parts: string[]) => string }} input
 * @returns {{ ok: true, dir: string } | { ok: false, code: 'no-home' }}
 */
export function resolveBaseDir(input = {}) {
  const { override, home, join = defaultJoin } = input;
  if (typeof override === 'string' && override.trim() !== '') {
    return { ok: true, dir: override };
  }
  if (typeof home !== 'string' || home.trim() === '') {
    return { ok: false, code: 'no-home' };
  }
  return { ok: true, dir: join(home, '.dsh', 'enhance') };
}

/**
 * @param {{ dir: string, join?: (...parts: string[]) => string }} input
 * @returns {{ dir: string, state: string, persona: string, boundary: string }}
 */
export function statePaths(input) {
  const { dir, join = defaultJoin } = input;
  return {
    dir,
    state: join(dir, STATE_FILES.state),
    persona: join(dir, STATE_FILES.persona),
    boundary: join(dir, STATE_FILES.boundary),
  };
}

function defaultJoin(...parts) {
  return parts
    .filter((part) => part !== '')
    .join('/')
    .replace(/\/{2,}/g, '/');
}
