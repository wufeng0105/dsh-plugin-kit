/**
 * `npm run check` — syntax-check every shipped and test JavaScript file.
 *
 * Uses `node --check` per file (parse only, no execution). Output is streamed
 * through inherited stdio instead of a pipe: the DSH sandbox forbids capturing a
 * child process's output through pipes, while inherited stdio is allowed.
 */
import { readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');

async function collect(dir) {
  const entries = await readdir(join(root, dir), { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const rel = join(dir, entry.name);
    if (entry.isDirectory()) files.push(...(await collect(rel)));
    else if (entry.name.endsWith('.js') || entry.name.endsWith('.mjs')) files.push(rel);
  }
  return files;
}

const files = ['index.js', 'client.js', ...(await collect('lib')), ...(await collect('host')), ...(await collect('test')), ...(await collect('scripts'))];
files.sort();

let failed = 0;
for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', join(root, file)], { stdio: 'inherit' });
  if (result.status !== 0) {
    failed += 1;
    console.error(`syntax FAILED: ${relative(root, join(root, file))}`);
  }
}
console.log(`\n${files.length} files checked, ${failed} failed`);
process.exit(failed === 0 ? 0 : 1);
