# dsh-enhance

Changes what the model reads at the start of every turn, without touching the
model: the opening brand sentence of the system prompt can be replaced, a content
boundary can be appended to the end of every system prompt, out-of-band approvals
can be gated, and an optional **Enhanced** permission preset (full sandbox access,
out-of-band actions still ask) can be added to the host's permission table.

> **Status of this build (round 1).** The pure logic and the local state service
> are finished and tested. The settings page, the prompt wiring, the host-config
> write and any runtime verification are **not** implemented yet — they need a
> probe against a live profile and an explicit authorisation to write host
> configuration. See `../03-implementation.md`.

## What it writes

The plugin owns exactly one folder and never writes host configuration by itself:

| File | Content |
|---|---|
| `%USERPROFILE%\.dsh\enhance\state.json` | `version` plus five switches (`masterSwitch`, `contentBoundary`, `approvalOverride`, `personaRewrite`, `hideHostNotes`), `personaMode` (`keep`/`strip`/`custom`) and `approvalMode` (`allow`/`ask`/`deny`) |
| `%USERPROFILE%\.dsh\enhance\identity.txt` | the custom persona text (≤ 2048 UTF-8 bytes) |
| `%USERPROFILE%\.dsh\enhance\content-scope.txt` | the content boundary text (≤ 8192 UTF-8 bytes) |

The settings page and a text editor read and write the same files. Booleans in
`state.json` also accept `"true"`/`"false"`, `1`/`0`, `on`/`off`, `yes`/`no`.
A damaged field falls back on its own (approval → `ask`, persona → `keep`); the
file is never rewritten automatically. A text over the byte limit is refused, not
truncated. Every save leaves a timestamped `.bak` next to the file.

The only host write this plugin will ever do is the Enhanced preset, and only
after the user presses the button. It is **not authorised in this build**: the
button reports `unauthorized` and nothing is written.

## Install (after authorisation)

Do not copy files into the profile. Use the plugin manager:

```
plugin_manager install_bundle  target=<absolute path to this folder>
```

Then confirm the row is `applied` in bundle details. This build installs without
writing anything; the settings page stays absent until the Client half is built.

## Uninstall

`plugin_manager remove_bundle`. The state folder is **not** deleted (the user's
text and switches survive, requirement 8). The Enhanced preset, once written in a
future build, also stays in host configuration; roll it back from the page first
or restore the `.bak` by hand.

## Migrating from the old, unscoped package

Remove the old bundle first, then install this one; do not keep both enabled.
The plugin does not detect or migrate old settings.

## Rollback in two levels

1. **Restore defaults** — every switch off, `personaMode: keep`. Your written text
   is kept, not deleted.
2. **Roll the preset back** — restore the host permission table from the newest
   `.bak`, taking one more backup first. Not available in this build.

## Tests

```
node --test "test/*.test.js"
node scripts/check-syntax.mjs
```

No third-party dependencies; everything uses Node's built-in test runner and
`node:fs/promises`. The integration tests use OS temp directories and never touch
`$DSH_HOME`.
