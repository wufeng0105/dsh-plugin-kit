/**
 * Host half of dsh-enhance.
 *
 * This round only wires what can be justified without a probe:
 * - the state store + controller (Step 3, fully implemented and tested);
 * - the approval tristate listener (Step 5 host half; decision logic tested);
 * - the prompt bridge is a no-op stub until probe P1/P2 answers how the host
 *   sections are named and whether the identity paragraph is a `complete`
 *   section (see host/prompt-service.js and 03-implementation.md).
 *
 * Nothing here writes host configuration. `writePreset`/`rollbackPreset` answer
 * `unauthorized` by design.
 *
 * UNVERIFIED, must be checked after installation:
 * - the `approval/request` listener signature and whether a plugin-level
 *   listener fires for every agent (analysis R11);
 * - how a `SessionSurfaceSnapshot` exposes the system prompt (probe P7);
 * - how a Host service becomes reachable from the Client half (Remote, 02-plan
 *   3.8; the client inspect timed out during analysis).
 */
import * as nodeFs from 'node:fs/promises';
import * as path from 'node:path';
import { homedir } from 'node:os';
import { createRing, recentDecisions } from './lib/approval.js';
import { defaultState } from './lib/state.js';
import { resolveBaseDir } from './host/paths.js';
import { createEnhanceStore } from './host/state-store.js';
import { createEnhanceController } from './host/controller.js';
import { createPromptBridge } from './host/prompt-service.js';
import { approvalPolicyOf, handleApprovalRequest } from './host/approval-service.js';

// The two services this plugin cannot work without. `approval` and
// `permissionPresets` are read through `ctx.get` so a profile without them still
// loads the plugin and simply keeps the corresponding feature inactive.
export const inject = ['systemPrompt', 'sessionQuery'];

export function apply(ctx, config = {}) {
  const resolved = resolveBaseDir({ override: config?.stateDir, home: homedir(), join: path.join });
  const store = resolved.ok ? createEnhanceStore({ fs: nodeFs, dir: resolved.dir }) : null;

  // Step 5 record. Declared before the controller so the page can read it from
  // the very first status() call, not only after one approval (MINOR-4).
  let ring = createRing();

  const controller = store
    ? createEnhanceController({
        store,
        readSurface: (input) => readSurfaceSnapshot(ctx, input),
        getSessionPolicy: (session) => currentApprovalPolicy(ctx, session),
        getRecentApprovals: () => recentDecisions(ring),
      })
    : {
        paths: null,
        async status() {
          return { ok: false, status: 'unavailable', code: resolved.code, presetWrite: 'unauthorized' };
        },
        async read() {
          return { status: 'unavailable', code: resolved.code };
        },
        async save() {
          return { ok: false, code: 'no-home' };
        },
        async check() {
          return { verdict: 'no-data', items: [], reasons: ['no-state-dir'] };
        },
        async reset() {
          return { ok: false, code: 'no-home' };
        },
        async writePreset() {
          return { ok: false, code: 'unauthorized' };
        },
        async rollbackPreset() {
          return { ok: false, code: 'unauthorized' };
        },
      };

  // The Client half reaches this object through the Remote mechanism, which is
  // still unverified. Keeping it on the plugin context means the wiring change is
  // one line once the probe says how.
  // `recentApprovals` reads the live ring (the closure sees the reassignment
  // below), so it is available before the first approval and never goes stale.
  ctx.enhance = { controller, recentApprovals: () => recentDecisions(ring) };

  // Step 5. A read per approval request is deliberate: the user may edit the
  // state file between requests (requirement 6), and a stale cache would decide
  // with old switches.
  ctx.effect(() =>
    ctx.on('approval/request', async (request, next) => {
      let state = defaultState();
      if (store !== null) {
        try {
          state = (await store.load()).state;
        } catch {
          state = defaultState(); // unreadable state must fall back to "ask", never to allow/deny
        }
      }
      const outcome = await handleApprovalRequest({ state, request, next, ring });
      ring = outcome.ring;
      return outcome.outcome;
    }),
  );

  // Step 4 stub: registers nothing this round (see host/prompt-service.js).
  const bridge = createPromptBridge();
  ctx.effect(() => () => bridge.dispose());
}

/**
 * Probe P7: map the host's `SessionSurfaceSnapshot` onto
 * `{ systemText, sections, contexts }`. Returning null makes the Check panel say
 * "no data" instead of claiming success, which is the honest answer until this
 * mapping exists.
 */
async function readSurfaceSnapshot() {
  return null;
}

/**
 * Which approval policy does the session's permission preset carry?
 *
 * `permissionPresets.current(session)` + `resolve(name).approval` is the host
 * contract (service inspect, 2026-11-08). The caller may hand in a Session, an
 * Agent, a session id or `{ sessionId }`; without one the initiator of the
 * current driver chain is resolved through the `sessions` service. No session /
 * no service / `custom` (no configured preset matches) all answer `undefined` -
 * the tristate then simply does not claim `preset-never`, instead of inventing a
 * policy (verification MINOR-5).
 *
 * @param {object} ctx
 * @param {object|string} [sessionRef]
 * @returns {'ask'|'never'|undefined}
 */
function currentApprovalPolicy(ctx, sessionRef) {
  try {
    const presets = ctx.get('permissionPresets');
    if (presets === undefined) return undefined;
    return approvalPolicyOf(presets, resolveSession(ctx, sessionRef ?? currentInitiator(ctx)));
  } catch {
    return undefined;
  }
}

/** The Agent driving the current async chain, if any (public `agents` contract). */
function currentInitiator(ctx) {
  try {
    const agents = ctx.get('agents');
    if (agents === undefined || typeof agents.currentInitiator !== 'function') return undefined;
    return agents.currentInitiator();
  } catch {
    return undefined;
  }
}

/**
 * Agent -> Session through the public `sessions.get(id)` contract: the public
 * `Agent` interface only guarantees `{ id }`, so `agent.session` is not assumed.
 */
function resolveSession(ctx, ref) {
  if (ref === undefined || ref === null) return undefined;
  if (typeof ref === 'string') return lookupSession(ctx, ref);
  if (typeof ref.id === 'string') {
    return lookupSession(ctx, ref.id) ?? (typeof ref.session === 'object' ? ref.session : ref);
  }
  if (typeof ref.sessionId === 'string') return lookupSession(ctx, ref.sessionId);
  return undefined;
}

function lookupSession(ctx, id) {
  try {
    const sessions = ctx.get('sessions');
    if (sessions === undefined || typeof sessions.get !== 'function') return undefined;
    return sessions.get(id);
  } catch {
    return undefined;
  }
}
