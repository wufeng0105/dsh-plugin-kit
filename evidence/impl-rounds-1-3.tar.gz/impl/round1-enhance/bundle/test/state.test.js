// state.test.js — 状态文件解析/回落（C7 按字段回落，A12 字符串布尔，验收 5）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { defaultState, parseState, normalizeState, serializeState, effectiveFlags } from '../lib/state.js';

test('default state: all switches off, persona keeps, approval asks (C7)', () => {
  assert.deepEqual(defaultState(), {
    version: 1,
    masterSwitch: false,
    contentBoundary: false,
    approvalOverride: false,
    personaRewrite: false,
    hideHostNotes: false,
    personaMode: 'keep',
    approvalMode: 'ask',
  });
});

test('missing version is fine, but a wrong version is reported without blocking fields', () => {
  const a = parseState('{"masterSwitch":true}');
  assert.deepEqual(a.issues, []);
  assert.equal(a.state.version, 1);

  const b = parseState('{"version":2,"masterSwitch":"true"}');
  assert.equal(b.issues.length, 1);
  assert.equal(b.issues[0].code, 'unsupported-version');
  assert.equal(b.state.version, 2, 'unsupported version is echoed, never downgraded silently');
  assert.equal(b.state.masterSwitch, true, 'fields still parse per-field');
});

test('string booleans are recognised (A12)', () => {
  const { state, issues } = parseState(
    '{"masterSwitch":"true","contentBoundary":"1","approvalOverride":"ON","personaRewrite":"yes","hideHostNotes":false}',
  );
  assert.deepEqual(issues, []);
  assert.deepEqual(
    { ...state, version: undefined },
    { ...defaultState(), version: undefined, masterSwitch: true, contentBoundary: true, approvalOverride: true, personaRewrite: true, hideHostNotes: false },
  );
});

test('corrupt fields fall back per field, valid neighbours survive (C7)', () => {
  const { state, issues } = parseState(
    '{"masterSwitch":"maybe","personaMode":"EXTERMINATE","approvalMode":true,"contentBoundary":"true"}',
  );
  assert.equal(state.masterSwitch, false, 'master falls back to off');
  assert.equal(state.personaMode, 'keep', 'persona falls back to keep (C7)');
  assert.equal(state.approvalMode, 'ask', 'approval falls back to ask (C7)');
  assert.equal(state.contentBoundary, true, 'valid field untouched');
  const fields = issues.map((i) => i.field).sort();
  assert.deepEqual(fields, ['approvalMode', 'masterSwitch', 'personaMode']);
  for (const issue of issues) {
    assert.equal(typeof issue.code, 'string');
    assert.ok('fellBackTo' in issue, 'the check page must be able to say why a field fell back');
  }
});

test('unparseable JSON means whole-file corrupt fallback, never silent (C7)', () => {
  const { state, issues, corrupt } = parseState('{ this is not json');
  assert.deepEqual(state, defaultState());
  assert.equal(corrupt, true);
  assert.equal(issues[0].code, 'invalid-json');
});

test('a JSON value that is not an object is also corrupt', () => {
  const { state, issues, corrupt } = parseState('[1,2,3]');
  assert.deepEqual(state, defaultState());
  assert.equal(corrupt, true);
  assert.equal(issues[0].code, 'not-an-object');
});

test('unknown top-level fields are preserved for the round trip', () => {
  const raw = '{"customNote":"hi","masterSwitch":true}';
  const { state, extra } = parseState(raw);
  assert.deepEqual(extra, { customNote: 'hi' });
  const out = serializeState(state, extra);
  const reparsed = JSON.parse(out);
  assert.equal(reparsed.customNote, 'hi');
  assert.equal(reparsed.masterSwitch, true);
});

test('serialize is deterministic and ends with a newline', () => {
  const { state, extra } = parseState('{"masterSwitch":"true"}');
  const a = serializeState(state, extra);
  const b = serializeState(state, extra);
  assert.equal(a, b);
  assert.ok(a.endsWith('\n'));
  assert.equal(JSON.parse(a).version, 1);
});

test('effectiveFlags: master off beats switch off', () => {
  const flags = effectiveFlags({ ...defaultState() });
  assert.deepEqual(flags, {
    master: false,
    persona: { enabled: false, mode: 'keep', reason: 'master-off' },
    boundary: { enabled: false, reason: 'master-off' },
    approval: { enabled: false, mode: 'ask', reason: 'master-off' },
    hideHostNotes: { enabled: false, reason: 'master-off' },
  });
});

test('effectiveFlags: master on with switches off', () => {
  const flags = effectiveFlags({ ...defaultState(), masterSwitch: true });
  assert.equal(flags.master, true);
  for (const key of ['persona', 'boundary', 'approval', 'hideHostNotes']) {
    assert.equal(flags[key].enabled, false, key);
    assert.equal(flags[key].reason, 'switch-off', key);
  }
});

test('effectiveFlags: master on, everything on, modes pass through', () => {
  const flags = effectiveFlags({
    ...defaultState(),
    masterSwitch: true,
    contentBoundary: true,
    approvalOverride: true,
    personaRewrite: true,
    hideHostNotes: true,
    personaMode: 'custom',
    approvalMode: 'deny',
  });
  assert.deepEqual(flags.persona, { enabled: true, mode: 'custom', reason: 'ok' });
  assert.deepEqual(flags.boundary, { enabled: true, reason: 'ok' });
  assert.deepEqual(flags.approval, { enabled: true, mode: 'deny', reason: 'ok' });
  assert.deepEqual(flags.hideHostNotes, { enabled: true, reason: 'ok' });
});

test('normalizeState agrees with parseState on the same data', () => {
  const obj = { masterSwitch: 'true', personaMode: 'bogus', junk: 1 };
  const a = normalizeState(obj);
  const b = parseState(JSON.stringify(obj));
  assert.deepEqual(a.state, b.state);
  assert.deepEqual(a.issues, b.issues);
  assert.deepEqual(a.extra, b.extra);
});

test('the keep fallback keeps approval at ask even if the file also says deny (acceptance 5)', () => {
  // 损坏文件绝不能按损坏值执行：approvalMode 坏 → ask，而不是放行
  const { state } = parseState('{"masterSwitch":"true","approvalOverride":"true","approvalMode":"bogus"}');
  const flags = effectiveFlags(state);
  assert.equal(flags.approval.mode, 'ask');
  assert.equal(flags.approval.reason, 'ok');
});
