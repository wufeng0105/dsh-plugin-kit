// paths.test.js — C5: 固定路径 %USERPROFILE%\.dsh\enhance\
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resolveBaseDir, statePaths, STATE_FILES } from '../host/paths.js';

test('default base dir is <home>/.dsh/enhance', () => {
  const r = resolveBaseDir({
    home: 'C:\\Users\\Administrator',
    join: (...parts) => parts.join('\\'),
  });
  assert.deepEqual(r, { ok: true, dir: 'C:\\Users\\Administrator\\.dsh\\enhance' });
});

test('an explicit override wins over the fixed path', () => {
  const r = resolveBaseDir({
    override: 'D:\\tmp\\enhance-test',
    home: 'C:\\Users\\Administrator',
    join: (...parts) => parts.join('\\'),
  });
  assert.deepEqual(r, { ok: true, dir: 'D:\\tmp\\enhance-test' });
});

test('missing home yields an error instead of a relative path', () => {
  const r = resolveBaseDir({ home: '', join: (...p) => p.join('/') });
  assert.deepEqual(r, { ok: false, code: 'no-home' });
});

test('the three state files have the agreed names (C5)', () => {
  assert.deepEqual(STATE_FILES, {
    state: 'state.json',
    persona: 'identity.txt',
    boundary: 'content-scope.txt',
  });
});

test('statePaths joins the three file names onto the base dir', () => {
  const r = statePaths({ dir: 'C:\\x\\.dsh\\enhance', join: (...parts) => parts.join('\\') });
  assert.deepEqual(r, {
    dir: 'C:\\x\\.dsh\\enhance',
    state: 'C:\\x\\.dsh\\enhance\\state.json',
    persona: 'C:\\x\\.dsh\\enhance\\identity.txt',
    boundary: 'C:\\x\\.dsh\\enhance\\content-scope.txt',
  });
});
