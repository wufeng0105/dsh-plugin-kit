// backup.test.js — 时间戳 .bak 命名与清理（需求 4：每次写档留时间戳 .bak）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { timestampStamp, backupName, parseBackupName, pruneBackups } from '../lib/backup.js';

const NOW = new Date('2026-11-07T15:28:53Z'); // UTC；加 480 分钟 = 北京时间 23:28:53

test('timestampStamp formats local time with an explicit offset', () => {
  assert.equal(timestampStamp(NOW, 480), '20261107-232853');
  assert.equal(timestampStamp(NOW, 0), '20261107-152853');
});

test('backupName appends the stamp and the extension', () => {
  const name = backupName({ base: 'state', now: NOW, offsetMinutes: 480, taken: [] });
  assert.equal(name, 'state-20261107-232853.bak');
});

test('backupName avoids collisions with -2, -3 suffixes', () => {
  const base = { base: 'state', now: NOW, offsetMinutes: 480, ext: '.bak' };
  assert.equal(backupName({ ...base, taken: ['state-20261107-232853.bak'] }), 'state-20261107-232853-2.bak');
  assert.equal(
    backupName({ ...base, taken: ['state-20261107-232853.bak', 'state-20261107-232853-2.bak'] }),
    'state-20261107-232853-3.bak',
  );
});

test('backupName is filename-safe on Windows (no colons, no plus signs)', () => {
  const name = backupName({ base: 'config', now: NOW, offsetMinutes: 330, taken: [] });
  assert.ok(!/[:+\\/*?"<>|]/.test(name), name);
});

test('parseBackupName reads stamp and sequence back', () => {
  assert.deepEqual(parseBackupName('state-20261107-232853.bak', { base: 'state' }), { stamp: '20261107-232853', seq: 1 });
  assert.deepEqual(parseBackupName('state-20261107-232853-2.bak', { base: 'state' }), { stamp: '20261107-232853', seq: 2 });
  assert.equal(parseBackupName('state.json', { base: 'state' }), null);
  assert.equal(parseBackupName('other-20261107-232853.bak', { base: 'state' }), null);
});

test('pruneBackups keeps the newest N and never touches unrecognised files', () => {
  const names = [
    'state.json',
    'state-20261107-100000.bak',
    'state-20261107-090000.bak',
    'state-20261107-110000.bak',
    'notes.txt',
  ];
  const r = pruneBackups(names, { base: 'state', ext: '.bak', keep: 2 });
  assert.deepEqual(r.keep.sort(), ['notes.txt', 'state-20261107-100000.bak', 'state-20261107-110000.bak', 'state.json']);
  assert.deepEqual(r.remove, ['state-20261107-090000.bak']);
});
