// preset-service.test.js — 写档前的准备（Step 6 纯逻辑 + 接口位；本轮不写宿主配置）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { preparePresetWrite, planRollback } from '../host/preset-service.js';
import { enhancedPreset } from '../lib/preset.js';

const NOW = new Date('2026-11-07T15:28:53Z');

const TABLE = {
  presets: {
    'workspace-write': {
      sandbox: 'workspace-write',
      approval: 'ask',
      name: 'workspace-write',
      description: 'Write inside the workspace and permitted temporary directories.',
    },
    'danger-full-access': {
      sandbox: 'danger-full-access',
      approval: 'never',
      name: 'danger-full-access',
      description: 'Full file access without approval prompts.',
    },
  },
  defaultPreset: 'workspace-write',
};

test('a normal write prepares the merged table, the diff and a timestamped backup name', () => {
  const r = preparePresetWrite({ table: TABLE, now: NOW, offsetMinutes: 480, taken: [] });
  assert.equal(r.ok, true);
  assert.equal(r.changed, true);
  assert.deepEqual(r.diff.added, ['enhanced']);
  assert.equal(r.backup, 'config-20261107-232853.bak');
  assert.equal(r.table.presets.enhanced.sandbox, 'danger-full-access');
  assert.equal(r.table.defaultPreset, 'workspace-write');
});

test('the backup name steps aside when the same second already has one', () => {
  const r = preparePresetWrite({ table: TABLE, now: NOW, offsetMinutes: 480, taken: ['config-20261107-232853.bak'] });
  assert.equal(r.backup, 'config-20261107-232853-2.bak');
});

test('a user-edited enhanced preset is reported as a conflict, not overwritten', () => {
  const edited = { ...TABLE, presets: { ...TABLE.presets, enhanced: { ...enhancedPreset(), approval: 'never' } } };
  const r = preparePresetWrite({ table: edited, now: NOW });
  assert.equal(r.ok, false);
  assert.equal(r.conflict, true);
  assert.equal(r.changed, false);
});

test('blockers from assertSafeWrite stop the write', () => {
  const broken = { ...TABLE, presets: { ...TABLE.presets, 'danger-full-access': { sandbox: 'wat', approval: 'never', name: 'danger-full-access', description: 'x' } } };
  const r = preparePresetWrite({ table: broken, now: NOW });
  assert.equal(r.ok, false);
  assert.ok(r.blockers.some((b) => b.code === 'invalid-preset'));
});

test('an object description in the merged table is blocked before any write (MAJOR-3)', () => {
  const r = preparePresetWrite({ table: TABLE, preset: { ...enhancedPreset(), description: { en: 'a', zh: 'b' } }, now: NOW });
  assert.equal(r.ok, false);
  assert.ok(r.blockers.some((b) => b.path === 'presets.enhanced.description'), JSON.stringify(r.blockers));
});

test('a table without presets cannot be written at all', () => {
  const r = preparePresetWrite({ table: {}, now: NOW });
  assert.equal(r.ok, false);
  assert.ok(r.issues.some((i) => i.code === 'presets-missing'));
});

test('rollback restores the backup text and takes a fresh backup first (C4 ②)', () => {
  const r = planRollback({ currentText: 'current', backupText: 'old', now: NOW, offsetMinutes: 480, taken: [] });
  assert.equal(r.ok, true);
  assert.equal(r.restoreText, 'old');
  assert.equal(r.backup, 'config-20261107-232853.bak');
});

test('rollback without a backup says so instead of restoring empty text', () => {
  assert.deepEqual(planRollback({ currentText: 'current', backupText: null, now: NOW }), { ok: false, code: 'no-backup' });
});
