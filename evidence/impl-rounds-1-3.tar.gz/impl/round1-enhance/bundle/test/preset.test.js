// preset.test.js — Enhanced 档整表合并（Step 6 纯函数层，需求 4）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  enhancedPreset,
  validatePresetTable,
  mergePresetTable,
  diffPresetTables,
  assertSafeWrite,
} from '../lib/preset.js';

const BASE_TABLE = {
  presets: {
    'workspace-write': {
      sandbox: 'workspace-write',
      approval: 'ask',
      name: 'workspace-write',
      description: 'Write inside the workspace and permitted temporary directories.',
    },
    'danger-full-access': {
      sandbox: 'danger-full-access',
      approval: 'never',
      name: 'danger-full-access',
      description: 'Full file access without approval prompts.',
    },
  },
  defaultPreset: 'workspace-write',
};

test('enhanced preset is sandbox wide open but still asks (requirement 4)', () => {
  const preset = enhancedPreset();
  assert.equal(preset.sandbox, 'danger-full-access');
  assert.equal(preset.approval, 'ask');
  assert.equal(preset.name, 'Enhanced');
  assert.equal(typeof preset.description, 'string', 'host schema requires z.string() (MAJOR-3)');
  assert.ok(preset.description.length > 0);
});

test('validatePresetTable accepts the built-in shape and flags bad entries', () => {
  assert.deepEqual(validatePresetTable(BASE_TABLE), { ok: true, issues: [] });
  const bad = validatePresetTable({
    presets: { x: { sandbox: 'yolo', approval: 'ask', name: 'x', description: 'x' }, y: 'oops' },
    defaultPreset: 'nope',
  });
  assert.equal(bad.ok, false);
  assert.ok(bad.issues.some((i) => i.path === 'presets.x.sandbox'));
  assert.ok(bad.issues.some((i) => i.path === 'presets.y'));
  assert.ok(bad.issues.some((i) => i.path === 'defaultPreset'), 'defaultPreset must point at a known preset');
});

test('validatePresetTable rejects non-string name/description (MAJOR-3)', () => {
  const r = validatePresetTable({
    presets: {
      x: { sandbox: 'danger-full-access', approval: 'ask', name: 'X', description: { en: 'a', zh: 'b' } },
      y: { sandbox: 'danger-full-access', approval: 'ask', name: 42, description: 'ok' },
    },
    defaultPreset: 'x',
  });
  assert.equal(r.ok, false);
  assert.ok(r.issues.some((i) => i.path === 'presets.x.description' && i.code === 'invalid-description'));
  assert.ok(r.issues.some((i) => i.path === 'presets.y.name' && i.code === 'invalid-name'));
});

test('merge adds the enhanced preset and keeps every existing one untouched', () => {
  const r = mergePresetTable(BASE_TABLE, enhancedPreset(), { key: 'enhanced' });
  assert.equal(r.changed, true);
  assert.equal(r.conflict, false);
  assert.deepEqual(r.table.presets['workspace-write'], BASE_TABLE.presets['workspace-write']);
  assert.deepEqual(r.table.presets['danger-full-access'], BASE_TABLE.presets['danger-full-access']);
  assert.deepEqual(r.table.presets.enhanced.sandbox, 'danger-full-access');
  assert.equal(r.table.defaultPreset, 'workspace-write', 'defaultPreset untouched (requirement 4)');
});

test('merge is idempotent: merging the same preset twice changes nothing', () => {
  const first = mergePresetTable(BASE_TABLE, enhancedPreset(), { key: 'enhanced' });
  const second = mergePresetTable(first.table, enhancedPreset(), { key: 'enhanced' });
  assert.equal(second.changed, false);
  assert.deepEqual(second.table, first.table);
});

test('merge keeps the user-edited enhanced entry unless overwrite is requested', () => {
  const edited = mergePresetTable(BASE_TABLE, { ...enhancedPreset(), approval: 'never' }, { key: 'enhanced' }).table;
  const ours = mergePresetTable(edited, enhancedPreset(), { key: 'enhanced' });
  assert.equal(ours.changed, false);
  assert.equal(ours.conflict, true);
  assert.equal(ours.table.presets.enhanced.approval, 'never', 'user edit wins by default');

  const forced = mergePresetTable(edited, enhancedPreset(), { key: 'enhanced', overwrite: true });
  assert.equal(forced.changed, true);
  assert.equal(forced.conflict, true);
  assert.equal(forced.table.presets.enhanced.approval, 'ask');
});

test('merge reports a table without presets instead of inventing one', () => {
  const r = mergePresetTable({}, enhancedPreset(), { key: 'enhanced' });
  assert.ok(r.issues.some((i) => i.code === 'presets-missing'));
  assert.equal(r.changed, false);
  assert.equal(r.table.presets, undefined, 'a table without presets is refused, never rebuilt from scratch');
});

test('diffPresetTables reports exactly what a write would change', () => {
  const merged = mergePresetTable(BASE_TABLE, enhancedPreset(), { key: 'enhanced' }).table;
  const d = diffPresetTables(BASE_TABLE, merged);
  assert.deepEqual(d.added, ['enhanced']);
  assert.deepEqual(d.removed, []);
  assert.deepEqual(d.modified, []);
  assert.equal(d.defaultPresetChanged, false);
});

test('assertSafeWrite blocks any write that would drop a preset or change defaultPreset', () => {
  const merged = mergePresetTable(BASE_TABLE, enhancedPreset(), { key: 'enhanced' }).table;
  assert.deepEqual(assertSafeWrite(BASE_TABLE, merged), { ok: true, blockers: [] });

  const dropped = { presets: { enhanced: merged.presets.enhanced }, defaultPreset: 'workspace-write' };
  const r1 = assertSafeWrite(BASE_TABLE, dropped);
  assert.equal(r1.ok, false);
  assert.ok(r1.blockers.some((b) => b.code === 'preset-removed' && b.key === 'workspace-write'));

  const moved = { ...merged, defaultPreset: 'enhanced' };
  const r2 = assertSafeWrite(BASE_TABLE, moved);
  assert.equal(r2.ok, false);
  assert.ok(r2.blockers.some((b) => b.code === 'default-preset-changed'));

  const invalid = { presets: { ...merged.presets, 'danger-full-access': { sandbox: 'wat', approval: 'ask', name: 'danger-full-access', description: 'x' } }, defaultPreset: 'workspace-write' };
  const r3 = assertSafeWrite(BASE_TABLE, invalid);
  assert.equal(r3.ok, false);
  assert.ok(r3.blockers.some((b) => b.code === 'invalid-preset' && b.key === 'danger-full-access'));
});

test('assertSafeWrite blocks an object description even when the merge itself "succeeded" (MAJOR-3)', () => {
  const objectPreset = { ...enhancedPreset(), description: { en: 'a', zh: 'b' } };
  const merged = mergePresetTable(BASE_TABLE, objectPreset, { key: 'enhanced' }).table;
  const r = assertSafeWrite(BASE_TABLE, merged);
  assert.equal(r.ok, false, 'the last gate before a host write must catch the type error');
  assert.ok(r.blockers.some((b) => b.path === 'presets.enhanced.description'), JSON.stringify(r.blockers));
});
