// bytes.test.js — UTF-8 byte counting (C6: 按 UTF-8 字节计)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { utf8ByteLength } from '../lib/bytes.js';

test('ascii text counts one byte per char', () => {
  assert.equal(utf8ByteLength('hello'), 5);
});

test('CJK text counts three bytes per char', () => {
  // 中 = U+4E2D = 3 UTF-8 bytes; A10: 按字符算会误导
  assert.equal(utf8ByteLength('中文'), 6);
});

test('emoji counts four bytes', () => {
  // U+1F6E1 是单码位，UTF-8 四字节（不能用 .slice 切代理对，那会变成替换字符）
  assert.equal(utf8ByteLength('\u{1F6E1}'), 4);
});

test('empty string is zero bytes', () => {
  assert.equal(utf8ByteLength(''), 0);
});

test('non-string input throws TypeError', () => {
  assert.throws(() => utf8ByteLength(null), TypeError);
  assert.throws(() => utf8ByteLength(123), TypeError);
});
