// sections.test.js — 提示变换快照（Step 4 纯函数层，验收 1/2 的离线部分）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BRAND_SENTENCE } from '../lib/constants.js';
import { effectiveFlags } from '../lib/state.js';
import { transformPresentation, matchesCatalogEntry, DEFAULT_CATALOG } from '../lib/sections.js';

const CATALOG = {
  identityNames: ['identity'],
  hostNoteNames: ['instructions'],
  hostNoteMarkers: [],
  runtimeContextNames: ['runtime-context'],
  runtimeContextMarkers: ['Current runtime context'],
  boundarySectionName: 'enhance.content-boundary',
  personaSectionName: 'enhance.persona',
};

const HOST_SECTIONS = [
  { name: 'identity', order: 10, text: `${BRAND_SENTENCE} Tokens prefixed with @ are paths.` },
  { name: 'instructions', order: 20, text: 'Follow workspace rules.' },
  { name: 'workspace', order: 30, text: 'Working directory: /tmp' },
];
const HOST_CONTEXTS = [{ name: 'runtime-context', order: 40, text: 'Current runtime context. Browser time zone...' }];

function hostPresentation() {
  return { sections: HOST_SECTIONS.map((s) => ({ ...s })), contexts: HOST_CONTEXTS.map((c) => ({ ...c })) };
}

const ALL_ON = {
  master: true,
  persona: { enabled: true, mode: 'strip', reason: 'ok' },
  boundary: { enabled: true, reason: 'ok' },
  approval: { enabled: true, mode: 'ask', reason: 'ok' },
  hideHostNotes: { enabled: true, reason: 'ok' },
};

test('all flags off returns the identical presentation object (acceptance 1)', () => {
  const presentation = hostPresentation();
  const flags = effectiveFlags({
    masterSwitch: false,
    contentBoundary: false,
    approvalOverride: false,
    personaRewrite: false,
    hideHostNotes: false,
    personaMode: 'keep',
    approvalMode: 'ask',
  });
  const r = transformPresentation(presentation, { flags, catalog: CATALOG });
  assert.equal(r.presentation, presentation, 'must be the same reference, not a rebuilt copy');
  assert.deepEqual(r.changes, []);
  assert.equal(r.noop, true);
});

test('persona strip rewrites the identity section and leaves other sections untouched', () => {
  const presentation = hostPresentation();
  const flags = effectiveFlags({ masterSwitch: true, personaRewrite: true, personaMode: 'strip' });
  const r = transformPresentation(presentation, { flags, catalog: CATALOG });
  assert.ok(!r.presentation.sections[0].text.includes(BRAND_SENTENCE));
  assert.ok(r.presentation.sections[0].text.includes('Tokens prefixed with @ are paths.'), 'rest of identity stays (C3)');
  assert.equal(r.presentation.sections[1], presentation.sections[1], 'untouched section keeps its reference');
  assert.ok(r.changes.some((c) => c.op === 'persona' && c.matched === true));
});

test('persona custom replaces the sentence with the user text in place', () => {
  const flags = effectiveFlags({ masterSwitch: true, personaRewrite: true, personaMode: 'custom' });
  const r = transformPresentation(hostPresentation(), { flags, catalog: CATALOG, personaText: '你是小助手。' });
  assert.ok(r.presentation.sections[0].text.startsWith('你是小助手。'));
  assert.ok(r.presentation.sections[0].text.includes('Tokens prefixed with @ are paths.'));
});

test('boundary is appended as the last section with the exact user text', () => {
  const flags = effectiveFlags({ masterSwitch: true, contentBoundary: true });
  const r = transformPresentation(hostPresentation(), { flags, catalog: CATALOG, boundaryText: '不得输出密钥。' });
  const last = r.presentation.sections.at(-1);
  assert.equal(last.name, CATALOG.boundarySectionName);
  assert.equal(last.text, '不得输出密钥。');
  assert.equal(last.order, 31, 'one past the highest existing order (analysis A3: 整段最后)');
});

test('boundary enabled but empty text adds nothing', () => {
  const flags = effectiveFlags({ masterSwitch: true, contentBoundary: true });
  const r = transformPresentation(hostPresentation(), { flags, catalog: CATALOG, boundaryText: '   ' });
  assert.equal(r.presentation.sections.length, 3);
  assert.ok(r.changes.some((c) => c.op === 'boundary' && c.matched === false));
});

test('hideHostNotes removes host note sections and runtime contexts and suppresses runtime context', () => {
  const flags = effectiveFlags({ masterSwitch: true, hideHostNotes: true });
  const r = transformPresentation(hostPresentation(), { flags, catalog: CATALOG });
  const names = r.presentation.sections.map((s) => s.name);
  assert.ok(!names.includes('identity'), 'identity self-description goes (C2)');
  assert.ok(!names.includes('instructions'), 'host operation conventions go (C2)');
  assert.ok(names.includes('workspace'), 'an unrelated section survives');
  assert.deepEqual(r.presentation.contexts, [], 'the runtime context blocks go together (C2)');
  assert.equal(r.effects.suppressRuntimeContext, true);
});

test('hideHostNotes also matches by marker when the name is unknown', () => {
  const flags = effectiveFlags({ masterSwitch: true, hideHostNotes: true });
  const presentation = {
    sections: [{ name: 'mystery', order: 5, text: 'Current runtime context. cwd: /x' }],
    contexts: [],
  };
  const r = transformPresentation(presentation, { flags, catalog: CATALOG });
  assert.deepEqual(r.presentation.sections, []);
});

test('matchesCatalogEntry reports which rule matched', () => {
  assert.equal(matchesCatalogEntry({ name: 'a', text: '' }, { names: ['a'], markers: [] }), 'name');
  assert.equal(matchesCatalogEntry({ name: 'b', text: 'Current runtime context. x' }, { names: [], markers: ['Current runtime context'] }), 'marker');
  assert.equal(matchesCatalogEntry({ name: 'b', text: 'hello' }, { names: [], markers: ['Current runtime context'] }), null);
  assert.equal(matchesCatalogEntry({ name: '', text: '' }, { names: ['a'], markers: ['x'] }), null);
});

test('hide + custom persona: identity is dropped and the custom text gets its own section', () => {
  const flags = effectiveFlags({ masterSwitch: true, hideHostNotes: true, personaRewrite: true, personaMode: 'custom' });
  const r = transformPresentation(hostPresentation(), { flags, catalog: CATALOG, personaText: '你是小助手。' });
  const names = r.presentation.sections.map((s) => s.name);
  assert.ok(!names.includes('identity'));
  const personaSection = r.presentation.sections.find((s) => s.name === CATALOG.personaSectionName);
  assert.ok(personaSection, 'custom persona still reaches the model');
  assert.equal(personaSection.text, '你是小助手。');
  assert.equal(personaSection.order, 10, 'lands where the identity paragraph used to sit');
});

test('persona enabled but brand sentence missing is reported, not faked', () => {
  const flags = effectiveFlags({ masterSwitch: true, personaRewrite: true, personaMode: 'strip' });
  const presentation = { sections: [{ name: 'identity', order: 10, text: 'no brand here' }], contexts: [] };
  const r = transformPresentation(presentation, { flags, catalog: CATALOG });
  assert.deepEqual(r.presentation.sections, presentation.sections, 'text unchanged');
  assert.ok(r.changes.some((c) => c.op === 'persona' && c.matched === false));
});

test('custom persona with empty text falls back to keep and explains itself (A1/A2 note)', () => {
  const flags = effectiveFlags({ masterSwitch: true, personaRewrite: true, personaMode: 'custom' });
  const r = transformPresentation(hostPresentation(), { flags, catalog: CATALOG, personaText: '   ' });
  assert.ok(!r.changes.some((c) => c.op === 'persona' && c.matched === true));
  const record = r.changes.find((c) => c.op === 'persona');
  assert.equal(record.reason, 'empty-custom');
});

test('DEFAULT_CATALOG names match the installed host (MAJOR-1)', () => {
  // Checked against the installed dsh-system-prompt and dsh-harness-dev-context
  // builds + the systemPrompt service contract (2026-11-08).
  assert.deepEqual(DEFAULT_CATALOG.identityNames, ['harness:identity']);
  assert.deepEqual(DEFAULT_CATALOG.hostNoteNames, ['harness:source', 'app:web-surface']);
  assert.deepEqual(DEFAULT_CATALOG.runtimeContextNames, ['harness:source', 'app:web-surface']);
  assert.deepEqual(DEFAULT_CATALOG.runtimeContextMarkers, [
    'Current DeepSeek Harness implementation checkout:',
    'Current DeepSeek Harness Web GUI URL:',
  ]);
  assert.ok(DEFAULT_CATALOG.hostNoteMarkers.some((m) => m.startsWith('The runtime context names the DeepSeek Harness')));
  assert.ok(DEFAULT_CATALOG.hostNoteMarkers.some((m) => m.startsWith('You are interacting with the user through')));
  assert.ok(!DEFAULT_CATALOG.runtimeContextNames.includes('working-directory:current'), 'required context must stay');
});

test('hideHostNotes with the real names removes identity and both host-note sections/contexts', () => {
  const flags = effectiveFlags({ masterSwitch: true, hideHostNotes: true });
  const presentation = {
    sections: [
      { name: 'harness:identity', order: -1000, text: `${BRAND_SENTENCE} Tokens prefixed with @ are paths.` },
      { name: 'harness:source', order: 10000, text: 'The runtime context names the DeepSeek Harness implementation checkout.' },
      { name: 'app:web-surface', order: 10100, text: 'You are interacting with the user through the DeepSeek Harness Web GUI.' },
      { name: 'workspace', order: 500, text: 'Workspace instructions.' },
    ],
    contexts: [
      { name: 'working-directory:current', order: 100, text: 'cwd: C:\\repo' },
      { name: 'harness:source', order: 200, text: 'Current DeepSeek Harness implementation checkout: "C:\\dsh".' },
      { name: 'app:web-surface', order: 210, text: 'Current DeepSeek Harness Web GUI URL: "http://127.0.0.1:8314".' },
    ],
  };
  const r = transformPresentation(presentation, { flags, catalog: DEFAULT_CATALOG });
  const names = r.presentation.sections.map((s) => s.name);
  assert.deepEqual(names, ['workspace'], 'identity + both host-note sections go');
  assert.deepEqual(
    r.presentation.contexts.map((c) => c.name),
    ['working-directory:current'],
    'the two optional host contexts go; the required one stays',
  );
  assert.equal(r.effects.suppressRuntimeContext, true);
  assert.ok(r.changes.some((c) => c.op === 'hide-host-notes' && c.matched === true));
});

test('DEFAULT_CATALOG exposes every key the transform needs', () => {
  for (const key of [
    'identityNames',
    'hostNoteNames',
    'hostNoteMarkers',
    'runtimeContextNames',
    'runtimeContextMarkers',
    'boundarySectionName',
    'personaSectionName',
  ]) {
    assert.ok(key in DEFAULT_CATALOG, key);
  }
});
