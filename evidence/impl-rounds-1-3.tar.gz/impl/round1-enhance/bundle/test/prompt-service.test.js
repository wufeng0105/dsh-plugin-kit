// prompt-service.test.js — 提示运行时接线的"要不要挂"（挂载细节待探针，见 03-implementation.md）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { effectiveFlags, defaultState } from '../lib/state.js';
import { planRegistrations } from '../host/prompt-service.js';

const OFF = effectiveFlags(defaultState());

test('all off registers nothing (acceptance 1: the prompt must be byte-identical)', () => {
  assert.deepEqual(planRegistrations(OFF), { needsAssembleListener: false, needsBoundarySection: false });
});

test('the content boundary alone needs a section, not the waterfall', () => {
  const flags = effectiveFlags({ ...defaultState(), masterSwitch: true, contentBoundary: true });
  assert.deepEqual(planRegistrations(flags), { needsAssembleListener: false, needsBoundarySection: true });
});

test('persona rewriting needs the assemble waterfall', () => {
  const flags = effectiveFlags({ ...defaultState(), masterSwitch: true, personaRewrite: true, personaMode: 'strip' });
  assert.deepEqual(planRegistrations(flags), { needsAssembleListener: true, needsBoundarySection: false });
});

test('hiding host notes needs the assemble waterfall too', () => {
  const flags = effectiveFlags({ ...defaultState(), masterSwitch: true, hideHostNotes: true });
  assert.equal(planRegistrations(flags).needsAssembleListener, true);
});

test('master on with every switch off still registers nothing', () => {
  const flags = effectiveFlags({ ...defaultState(), masterSwitch: true });
  assert.deepEqual(planRegistrations(flags), { needsAssembleListener: false, needsBoundarySection: false });
});
