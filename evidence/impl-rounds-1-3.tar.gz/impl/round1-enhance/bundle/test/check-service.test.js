// check-service.test.js — 把会话里读回的系统提示交给纯比对函数
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { defaultState } from '../lib/state.js';
import { runCheck } from '../host/check-service.js';

const ON = { ...defaultState(), masterSwitch: true, contentBoundary: true, personaRewrite: true, personaMode: 'custom' };

test('a readable surface is compared and reported as effective', async () => {
  const r = await runCheck({
    state: ON,
    personaText: '你是小助手。',
    boundaryText: '不得输出密钥。',
    readSurface: async () => ({ systemText: '你是小助手。其余内容\n\n不得输出密钥。' }),
  });
  assert.equal(r.verdict, 'effective');
});

test('no surface yet is reported as no-data, not as success (A14)', async () => {
  const r = await runCheck({ state: ON, personaText: '你是小助手。', readSurface: async () => null });
  assert.equal(r.verdict, 'no-data');
});

test('a failing reader is reported, never rethrown into the page', async () => {
  const r = await runCheck({
    state: ON,
    personaText: '你是小助手。',
    readSurface: async () => {
      throw new Error('session gone');
    },
  });
  assert.equal(r.verdict, 'no-data');
  assert.ok(r.reasons.includes('read-failed'));
});

test('sections from the reader are preferred over the joined text', async () => {
  const r = await runCheck({
    state: ON,
    boundaryText: '不得输出密钥。',
    personaText: '你是小助手。',
    readSurface: async () => ({
      systemText: '你是小助手。\n\n不得输出密钥。',
      sections: [
        { name: 'identity', order: 1, text: '你是小助手。' },
        { name: 'enhance.content-boundary', order: 2, text: '不得输出密钥。' },
      ],
    }),
  });
  const boundary = r.items.find((item) => item.key === 'boundary');
  assert.equal(boundary.code, 'boundary-section-exact');
});

test('the hide proof (baseline/transformLog) reaches the comparison from the snapshot (MAJOR-2)', async () => {
  const hideOn = { ...defaultState(), masterSwitch: true, hideHostNotes: true };
  const r = await runCheck({
    state: hideOn,
    readSurface: async () => ({
      systemText: 'plain prompt without host notes',
      baseline: {
        text: 'plain\n\nCurrent runtime context. This snapshot supersedes earlier runtime-context snapshots.\n\nCurrent DeepSeek Harness implementation checkout: "C:\\dsh".',
      },
    }),
  });
  const item = r.items.find((entry) => entry.key === 'hostNotes');
  assert.equal(item.ok, true);
  assert.equal(item.code, 'host-notes-removed');
  assert.equal(item.detail.evidence, 'baseline');
  assert.equal(r.verdict, 'effective');
});
