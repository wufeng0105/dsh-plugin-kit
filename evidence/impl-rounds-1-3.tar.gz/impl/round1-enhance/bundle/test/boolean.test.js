// boolean.test.js — A12: 布尔值认字符串到什么程度
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseBoolFlag } from '../lib/boolean.js';

test('accepts real booleans', () => {
  assert.deepEqual(parseBoolFlag(true), { ok: true, value: true });
  assert.deepEqual(parseBoolFlag(false), { ok: true, value: false });
});

test('accepts true/false strings case-insensitive with surrounding spaces', () => {
  assert.deepEqual(parseBoolFlag('true'), { ok: true, value: true });
  assert.deepEqual(parseBoolFlag(' TRUE '), { ok: true, value: true });
  assert.deepEqual(parseBoolFlag('False'), { ok: true, value: false });
});

test('accepts 1/0, on/off, yes/no (A12)', () => {
  assert.deepEqual(parseBoolFlag('1'), { ok: true, value: true });
  assert.deepEqual(parseBoolFlag('0'), { ok: true, value: false });
  assert.deepEqual(parseBoolFlag('ON'), { ok: true, value: true });
  assert.deepEqual(parseBoolFlag('no'), { ok: true, value: false });
  assert.deepEqual(parseBoolFlag(1), { ok: true, value: true });
  assert.deepEqual(parseBoolFlag(0), { ok: true, value: false });
});

test('rejects anything else so the field falls back (C7)', () => {
  for (const bad of ['maybe', '', 'tru', 'yes!', null, undefined, {}, [], 2, -1]) {
    const r = parseBoolFlag(bad);
    assert.equal(r.ok, false, `unexpected accept for ${JSON.stringify(bad)}`);
    assert.equal('value' in r, false, `unexpected value for ${JSON.stringify(bad)}`);
  }
});
