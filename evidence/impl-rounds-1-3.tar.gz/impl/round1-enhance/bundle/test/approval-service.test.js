// approval-service.test.js — 审批三态运行时的一半（决定 + 环形记录 + waterfall 调用）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { defaultState } from '../lib/state.js';
import { createRing, recentDecisions } from '../lib/approval.js';
import { approvalPolicyOf, handleApprovalRequest } from '../host/approval-service.js';

const NOW = () => new Date('2026-11-07T15:28:53Z');
// Real host shape (`ApprovalRequestEvent`): toolName, not tool (MINOR-1).
const REQUEST = { agent: { id: 's1' }, toolName: 'bash', callId: 'call-1', reason: 'rm -rf /tmp/x' };

function stateWith(mode, { master = true, approvalSwitch = true } = {}) {
  return { ...defaultState(), masterSwitch: master, approvalOverride: approvalSwitch, approvalMode: mode };
}

test('allow answers allowed-once without consulting the user (C8)', async () => {
  let asked = 0;
  const next = async () => { asked += 1; return 'rejected'; };
  const r = await handleApprovalRequest({ state: stateWith('allow'), request: REQUEST, next, now: NOW, ring: createRing(5) });
  assert.equal(asked, 0, 'next() is the user; it must not run');
  assert.equal(r.outcome, 'allowed-once');
  assert.equal(r.usedNext, false);
  assert.equal(recentDecisions(r.ring).length, 1);
  assert.equal(recentDecisions(r.ring)[0].decision, 'allow');
  assert.equal(recentDecisions(r.ring)[0].request.tool, 'bash', 'the ring records the host toolName (MINOR-1)');
});

test('ask falls through to the host waterfall and returns its outcome', async () => {
  let asked = 0;
  const next = async () => { asked += 1; return 'allowed-once'; };
  const r = await handleApprovalRequest({ state: stateWith('ask'), request: REQUEST, next, now: NOW, ring: createRing(5) });
  assert.equal(asked, 1);
  assert.equal(r.usedNext, true);
  assert.equal(r.outcome, 'allowed-once', 'the user answer is what counts');
  assert.equal(recentDecisions(r.ring)[0].decision, 'ask');
});

test('deny rejects with the auto-deny reason and never asks', async () => {
  let asked = 0;
  const next = async () => { asked += 1; return 'allowed-once'; };
  const r = await handleApprovalRequest({ state: stateWith('deny'), request: REQUEST, next, now: NOW, ring: createRing(5) });
  assert.equal(asked, 0);
  assert.equal(r.outcome, 'rejected');
  assert.equal(recentDecisions(r.ring)[0].reasonCode, 'enhance.auto-deny');
});

test('a state that says nothing never denies by accident', async () => {
  const next = async () => 'allowed-once';
  const r = await handleApprovalRequest({
    state: stateWith('deny', { master: false }),
    request: REQUEST,
    next,
    now: NOW,
    ring: createRing(5),
  });
  assert.equal(r.usedNext, true, 'master off means passthrough');
  assert.equal(recentDecisions(r.ring)[0].decision, 'ask');
});

test('the recorded ring stays bounded', async () => {
  let ring = createRing(2);
  for (let i = 0; i < 3; i++) {
    const r = await handleApprovalRequest({ state: stateWith('allow'), request: { ...REQUEST, callId: `c${i}` }, next: async () => 'x', now: NOW, ring });
    ring = r.ring;
  }
  assert.equal(recentDecisions(ring).length, 2);
  assert.equal(recentDecisions(ring).at(-1).request.callId, 'c2');
});

test('approvalPolicyOf resolves the session preset approval through the host contract (MINOR-5)', () => {
  const session = { id: 's1' };
  const seen = [];
  const presets = {
    current: (target) => {
      seen.push(target);
      return 'enhanced';
    },
    resolve: (name) => ({ sandbox: 'danger-full-access', approval: 'never', name, description: 'x' }),
  };
  assert.equal(approvalPolicyOf(presets, session), 'never');
  assert.deepEqual(seen, [session], 'current() receives the exact session');

  const asking = {
    current: () => 'asker',
    resolve: () => ({ sandbox: 'workspace-write', approval: 'ask', name: 'asker', description: 'x' }),
  };
  assert.equal(approvalPolicyOf(asking, session), 'ask');
});

test('approvalPolicyOf answers undefined instead of guessing (MINOR-5)', () => {
  const session = { id: 's1' };
  assert.equal(approvalPolicyOf(undefined, session), undefined, 'service absent');
  assert.equal(approvalPolicyOf({ current: () => 'x', resolve: () => ({ approval: 'never' }) }, undefined), undefined, 'no session');
  const custom = {
    current: () => 'custom',
    resolve: () => {
      throw new Error('unknown preset');
    },
  };
  assert.equal(approvalPolicyOf(custom, session), undefined, 'custom / resolve throw');
  const bogus = { current: () => 'x', resolve: () => ({ approval: 'yolo' }) };
  assert.equal(approvalPolicyOf(bogus, session), undefined, 'unknown approval value');
});
