// approval.test.js — 越界审批三态映射（Step 5 纯函数层，验收 3 的离线部分）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { defaultState } from '../lib/state.js';
import {
  decideApproval,
  approvalDirective,
  explainTristate,
  createRing,
  pushDecision,
  recentDecisions,
} from '../lib/approval.js';

function stateWith({ master = true, approvalSwitch = true, mode = 'ask' } = {}) {
  return { ...defaultState(), masterSwitch: master, approvalOverride: approvalSwitch, approvalMode: mode };
}

test('decideApproval maps the state to the three outcomes', () => {
  assert.equal(decideApproval(stateWith({ mode: 'allow' })), 'allow');
  assert.equal(decideApproval(stateWith({ mode: 'deny' })), 'deny');
  assert.equal(decideApproval(stateWith({ mode: 'ask' })), 'ask');
});

test('master off or switch off means "do not take over" -> ask (never silent)', () => {
  assert.equal(decideApproval(stateWith({ master: false, mode: 'deny' })), 'ask');
  assert.equal(decideApproval(stateWith({ approvalSwitch: false, mode: 'allow' })), 'ask');
});

test('an unknown mode in the state cannot produce allow or deny', () => {
  assert.equal(decideApproval({ ...stateWith(), approvalMode: 'bogus' }), 'ask');
});

test('approvalDirective translates a decision into the host waterfall outcome (01-analysis §5)', () => {
  assert.deepEqual(approvalDirective('allow'), { callNext: false, outcome: 'allowed-once', reasonCode: null });
  assert.deepEqual(approvalDirective('ask'), { callNext: true, outcome: null, reasonCode: null });
  assert.deepEqual(approvalDirective('deny'), { callNext: false, outcome: 'rejected', reasonCode: 'enhance.auto-deny' });
});

test('an unknown decision falls through to "ask the user" instead of guessing', () => {
  assert.deepEqual(approvalDirective('bogus'), { callNext: true, outcome: null, reasonCode: 'enhance.fallback-ask' });
});

test('explainTristate tells the page the truth about a never-asking preset (C1)', () => {
  assert.deepEqual(explainTristate({ state: stateWith(), sessionPolicy: 'ask' }), { active: true, code: 'ok' });
  assert.deepEqual(explainTristate({ state: stateWith(), sessionPolicy: 'never' }), { active: false, code: 'preset-never' });
  assert.deepEqual(explainTristate({ state: stateWith({ master: false }), sessionPolicy: 'ask' }), { active: false, code: 'master-off' });
  assert.deepEqual(explainTristate({ state: stateWith({ approvalSwitch: false }), sessionPolicy: 'ask' }), { active: false, code: 'switch-off' });
});

test('createRing starts empty with its capacity', () => {
  assert.deepEqual(createRing(3), { capacity: 3, entries: [] });
});

test('pushDecision keeps the newest N entries, oldest first in recentDecisions (C8)', () => {
  const capacity = 3;
  let ring = createRing(capacity);
  for (let i = 1; i <= 4; i++) {
    ring = pushDecision(ring, { seq: i });
  }
  assert.deepEqual(recentDecisions(ring), [{ seq: 2 }, { seq: 3 }, { seq: 4 }]);
});

test('pushDecision is immutable: the previous ring stays intact', () => {
  const before = createRing(2);
  const pushed = pushDecision(before, { seq: 1 });
  assert.deepEqual(recentDecisions(before), []);
  assert.deepEqual(recentDecisions(pushed), [{ seq: 1 }]);
});
