// state-store.test.js — Step 3 集成：临时目录里真读写 JSON，不碰 DSH（02-plan Step 3 完成标志）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as fsPromises from 'node:fs/promises';
import { mkdtemp, rm, readFile, writeFile, readdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createEnhanceStore } from '../host/state-store.js';

async function withTempDir(fn) {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-enhance-store-'));
  try {
    return await fn(dir);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

const NOW = () => new Date('2026-11-07T15:28:53Z');

/** node:fs/promises satisfies the store's adapter contract directly. */
function realFsLike() {
  return fsPromises;
}

test('a fresh directory reports missing and hands out defaults', async () => {
  await withTempDir(async (dir) => {
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const r = await store.load();
    assert.equal(r.status, 'missing');
    assert.equal(r.state.masterSwitch, false);
    assert.deepEqual(r.issues, []);
    assert.deepEqual(await readdir(dir), [], 'load must not create anything');
  });
});

test('save writes version-1 JSON and a second save leaves a timestamped .bak', async () => {
  await withTempDir(async (dir) => {
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const first = await store.saveState({ masterSwitch: true });
    assert.equal(first.ok, true);
    const raw = await readFile(join(dir, 'state.json'), 'utf8');
    assert.equal(JSON.parse(raw).masterSwitch, true);
    assert.deepEqual(await readdir(dir), ['state.json'], 'no .bak on the first write');

    const second = await store.saveState({ contentBoundary: true });
    assert.equal(second.ok, true);
    const entries = await readdir(dir);
    assert.equal(entries.length, 2, entries.join(','));
    assert.ok(entries.some((name) => /^state-\d{8}-\d{6}\.bak$/.test(name)), entries.join(','));
    const backupName = entries.find((name) => name.endsWith('.bak'));
    assert.equal(JSON.parse(await readFile(join(dir, backupName), 'utf8')).masterSwitch, true, 'backup holds the previous content');
    const list = await store.listBackups();
    assert.deepEqual(list, { state: [backupName], persona: [], boundary: [] });
  });
});

test('a corrupt file loads as defaults with issues, and a later save backs the corrupt text up first', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'state.json');
    await writeFile(file, '{ broken', 'utf8');
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const loaded = await store.load();
    assert.equal(loaded.status, 'corrupt');
    assert.equal(loaded.state.masterSwitch, false, 'never run on corrupted values (acceptance 5)');
    assert.ok(loaded.issues.some((i) => i.code === 'invalid-json'));

    await store.saveState({ masterSwitch: true });
    const backup = (await readdir(dir)).find((name) => name.endsWith('.bak'));
    assert.ok(backup, 'corrupt content is preserved in a .bak before overwriting');
    assert.equal(await readFile(join(dir, backup), 'utf8'), '{ broken');
  });
});

test('per-field fallback comes from the file, and the issues travel to the page (C7)', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'state.json');
    await writeFile(file, '{"masterSwitch":"true","approvalMode":"bogus","note":"hi"}', 'utf8');
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const r = await store.load();
    assert.equal(r.status, 'degraded', 'a field-level fallback must trip the damage banner (MINOR-3)');
    assert.equal(r.state.approvalMode, 'ask');
    assert.ok(r.issues.some((i) => i.field === 'approvalMode'));
    assert.deepEqual(r.extra, { note: 'hi' });
  });
});

test('an unknown extra field alone does not degrade the status', async () => {
  await withTempDir(async (dir) => {
    await writeFile(join(dir, 'state.json'), '{"masterSwitch":true,"myNote":"keep me"}', 'utf8');
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const r = await store.load();
    assert.equal(r.status, 'ok', 'preserved unknown fields are not damage');
    assert.deepEqual(r.issues, []);
  });
});

test('unknown fields survive a save from the page (requirement 6: same file)', async () => {
  await withTempDir(async (dir) => {
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    await store.saveState({ masterSwitch: true });
    await writeFile(join(dir, 'state.json'), '{"masterSwitch":true,"myNote":"keep me"}', 'utf8');
    await store.saveState({ contentBoundary: true });
    const raw = JSON.parse(await readFile(join(dir, 'state.json'), 'utf8'));
    assert.equal(raw.myNote, 'keep me');
    assert.equal(raw.contentBoundary, true);
  });
});

test('over-limit persona text is refused before anything is written (acceptance 4)', async () => {
  await withTempDir(async (dir) => {
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    await store.savePersonaText('旧文本');
    const before = await readFile(join(dir, 'identity.txt'), 'utf8');
    const r = await store.savePersonaText('中'.repeat(1000)); // 3000 bytes > 2048
    assert.equal(r.ok, false);
    assert.equal(r.code, 'too-long');
    assert.equal(r.bytes, 3000);
    assert.equal(await readFile(join(dir, 'identity.txt'), 'utf8'), before, 'file byte-identical after refusal');
    const entries = (await readdir(dir)).filter((name) => name !== 'identity.txt');
    assert.deepEqual(entries, [], 'no .bak either: the write never happened');
  });
});

test('control characters are refused (A18) without touching the file', async () => {
  await withTempDir(async (dir) => {
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const r = await store.savePersonaText('bad\u0000text');
    assert.equal(r.ok, false);
    assert.equal(r.code, 'control-character');
    assert.deepEqual(await readdir(dir), [], 'nothing written');
  });
});

test('persona and boundary files are plain UTF-8 text with LF newlines', async () => {
  await withTempDir(async (dir) => {
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const saved = await store.savePersonaText('第一行\r\n第二行');
    assert.equal(saved.ok, true);
    assert.equal(await readFile(join(dir, 'identity.txt'), 'utf8'), '第一行\n第二行');
    const text = await store.readTextFile('persona');
    assert.equal(text, '第一行\n第二行');
    assert.equal(await store.readTextFile('boundary'), null);
  });
});

test('resetStateToDefault keeps the switches but never deletes user text (C4 ①)', async () => {
  await withTempDir(async (dir) => {
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    await store.saveState({ masterSwitch: true, personaRewrite: true, personaMode: 'custom' });
    await store.savePersonaText('我的人设');
    const r = await store.resetStateToDefault();
    assert.equal(r.ok, true);
    const raw = JSON.parse(await readFile(join(dir, 'state.json'), 'utf8'));
    assert.equal(raw.masterSwitch, false);
    assert.equal(raw.personaMode, 'keep');
    assert.equal(await readFile(join(dir, 'identity.txt'), 'utf8'), '我的人设', 'user text survives');
  });
});

test('a newer state version refuses saves instead of silently downgrading', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'state.json');
    await writeFile(file, '{"version":2,"masterSwitch":true}', 'utf8');
    const store = createEnhanceStore({ fs: realFsLike(), dir, now: NOW });
    const loaded = await store.load();
    assert.ok(loaded.issues.some((i) => i.code === 'unsupported-version'));
    const r = await store.saveState({ contentBoundary: true });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'version-conflict');
    assert.equal(await readFile(file, 'utf8'), '{"version":2,"masterSwitch":true}', 'file untouched');
  });
});

test('the store creates the directory on demand, even two levels deep', async () => {
  await withTempDir(async (dir) => {
    const deep = join(dir, 'a', 'b');
    const store = createEnhanceStore({ fs: realFsLike(), dir: deep, now: NOW });
    const loaded = await store.load();
    assert.equal(loaded.status, 'missing');
    const r = await store.saveState({ masterSwitch: true });
    assert.equal(r.ok, true);
    assert.equal(JSON.parse(await readFile(join(deep, 'state.json'), 'utf8')).masterSwitch, true);
  });
});

test('read errors are classified as unreadable, not as "no state"', async () => {
  await withTempDir(async (dir) => {
    const denied = Object.assign(new Error('denied'), { code: 'EACCES' });
    const fs = { ...realFsLike(), readFile: async () => { throw denied; } };
    const store = createEnhanceStore({ fs, dir, now: NOW });
    const r = await store.load();
    assert.equal(r.status, 'unreadable');
    assert.equal(r.code, 'readonly');
  });
});
