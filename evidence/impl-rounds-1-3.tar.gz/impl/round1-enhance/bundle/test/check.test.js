// check.test.js — Step 8 比对逻辑（纯函数）：读回的系统提示是否真的带上了用户文本
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BRAND_SENTENCE } from '../lib/constants.js';
import { defaultState, effectiveFlags } from '../lib/state.js';
import { checkAgainstSections, checkAgainstText, checkEffectiveness } from '../lib/check.js';
import { DEFAULT_CATALOG, transformPresentation } from '../lib/sections.js';

const CATALOG = {
  identityNames: ['identity'],
  hostNoteNames: ['instructions'],
  hostNoteMarkers: [],
  runtimeContextNames: ['runtime-context'],
  runtimeContextMarkers: ['Current runtime context'],
  boundarySectionName: 'enhance.content-boundary',
  personaSectionName: 'enhance.persona',
};

// The real names the installed host registers (verification MAJOR-1).
const REAL_SECTIONS = [
  { name: 'harness:identity', order: -1000, text: BRAND_SENTENCE },
  {
    name: 'harness:source',
    order: 10000,
    text: 'The runtime context names the DeepSeek Harness implementation checkout. Use pwd to determine the current working directory.',
  },
  {
    name: 'app:web-surface',
    order: 10100,
    text: 'You are interacting with the user through the DeepSeek Harness Web GUI whose URL the runtime context names.',
  },
  { name: 'workspace', order: 500, text: 'Follow the workspace rules.' },
];
const REAL_CONTEXTS = [
  { name: 'working-directory:current', order: 100, text: 'cwd: C:\\repo' },
  { name: 'harness:source', order: 200, text: 'Current DeepSeek Harness implementation checkout: "C:\\dsh".' },
  { name: 'app:web-surface', order: 210, text: 'Current DeepSeek Harness Web GUI URL: "http://127.0.0.1:8314".' },
];
const HIDE_ON = { ...defaultState(), masterSwitch: true, hideHostNotes: true };

const ORIGINAL = `${BRAND_SENTENCE} Tokens prefixed with @ are paths.`;
const BOUNDARY = '不得输出密钥。';
const PERSONA = '你是小助手。';

const CUSTOM_ON = {
  ...defaultState(),
  masterSwitch: true,
  personaRewrite: true,
  personaMode: 'custom',
  contentBoundary: true,
};
const STRIP_ON = { ...CUSTOM_ON, personaMode: 'strip' };

function itemOf(result, key) {
  return result.items.find((item) => item.key === key);
}

test('no system surface at all is reported as no-data, not as success (A14)', () => {
  const r = checkEffectiveness({ state: CUSTOM_ON, personaText: PERSONA, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.equal(r.verdict, 'no-data');
  assert.ok(r.reasons.includes('no-system-surface'));
});

test('all switches off says "not effective because the switches are off" (acceptance 8)', () => {
  const r = checkEffectiveness({ text: ORIGINAL, state: defaultState(), catalog: CATALOG });
  assert.equal(r.verdict, 'not-effective');
  assert.ok(r.reasons.includes('all-off'));
  for (const item of r.items) assert.equal(item.ok, null);
});

test('persona + boundary written and effective is proven from the text (acceptance 2)', () => {
  const text = `${PERSONA} Tokens prefixed with @ are paths.\n\n${BOUNDARY}`;
  const r = checkEffectiveness({ text, state: CUSTOM_ON, personaText: PERSONA, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.equal(r.verdict, 'effective');
  assert.deepEqual(itemOf(r, 'persona'), {
    key: 'persona',
    enabled: true,
    ok: true,
    code: 'custom-persona-present',
  });
  assert.deepEqual(itemOf(r, 'boundary'), { key: 'boundary', enabled: true, ok: true, code: 'boundary-present' });
  assert.equal(itemOf(r, 'hostNotes').ok, null, 'hideHostNotes is off, so it is not applicable');
});

test('a persona that did not land fails and drags the verdict to partial (requirement 7)', () => {
  const text = `${ORIGINAL}\n\n${BOUNDARY}`;
  const r = checkEffectiveness({ text, state: CUSTOM_ON, personaText: PERSONA, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.equal(itemOf(r, 'persona').ok, false);
  assert.equal(itemOf(r, 'persona').code, 'brand-still-first');
  assert.equal(itemOf(r, 'boundary').ok, true);
  assert.equal(r.verdict, 'partial');
});

test('strip mode is verified by the absence of the brand sentence', () => {
  const text = ` Tokens prefixed with @ are paths.\n\n${BOUNDARY}`;
  const r = checkAgainstText(text, { state: STRIP_ON, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.deepEqual(itemOf(r, 'persona'), { key: 'persona', enabled: true, ok: true, code: 'brand-removed' });
});

test('strip mode still finds the brand sentence in the leading window and fails', () => {
  const r = checkAgainstText(`${ORIGINAL}\n\n${BOUNDARY}`, { state: STRIP_ON, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.equal(itemOf(r, 'persona').ok, false);
  assert.equal(itemOf(r, 'persona').code, 'brand-still-first');
});

test('a missing boundary is reported as missing, not assumed', () => {
  const text = `${PERSONA} Tokens prefixed with @ are paths.`;
  const r = checkAgainstText(text, { state: CUSTOM_ON, personaText: PERSONA, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.equal(itemOf(r, 'boundary').ok, false);
  assert.equal(itemOf(r, 'boundary').code, 'boundary-missing');
});

test('hideHostNotes is claimed only with proof that the transform removed something', () => {
  const baseline = `plain\n\nCurrent runtime context. cwd: /tmp`;

  const hidden = checkAgainstText('plain prompt without host runtime context', {
    state: HIDE_ON,
    catalog: CATALOG,
    baseline,
  });
  assert.deepEqual(itemOf(hidden, 'hostNotes'), {
    key: 'hostNotes',
    enabled: true,
    ok: true,
    code: 'host-notes-removed',
    detail: { evidence: 'baseline' },
  });
  assert.equal(hidden.verdict, 'effective');

  const visible = checkAgainstText(baseline, { state: HIDE_ON, catalog: CATALOG, baseline });
  assert.equal(itemOf(visible, 'hostNotes').ok, false);
  assert.equal(itemOf(visible, 'hostNotes').code, 'host-notes-visible');

  const viaTransformLog = checkAgainstText('plain prompt without host runtime context', {
    state: HIDE_ON,
    catalog: CATALOG,
    transformLog: [{ op: 'hide-host-notes', matched: true, removed: ['harness:identity'] }],
  });
  assert.deepEqual(itemOf(viaTransformLog, 'hostNotes'), {
    key: 'hostNotes',
    enabled: true,
    ok: true,
    code: 'host-notes-removed',
    detail: { evidence: 'transform' },
  });
});

test('without evidence the hide check refuses success (MAJOR-2: no fake success)', () => {
  const plain = 'plain prompt without host runtime context';

  const noBaseline = checkAgainstText(plain, { state: HIDE_ON, catalog: CATALOG });
  assert.deepEqual(itemOf(noBaseline, 'hostNotes'), { key: 'hostNotes', enabled: true, ok: null, code: 'no-baseline' });
  assert.equal(noBaseline.verdict, 'not-effective', 'cannot claim effective on a snapshot it cannot compare');
  assert.ok(noBaseline.reasons.includes('hostNotes:no-baseline'), 'the reason is named, never silent');

  const sameAsInput = checkAgainstText(plain, { state: HIDE_ON, catalog: CATALOG, baseline: { text: plain } });
  assert.deepEqual(itemOf(sameAsInput, 'hostNotes'), {
    key: 'hostNotes',
    enabled: true,
    ok: null,
    code: 'no-change-evidence',
  });
  assert.equal(sameAsInput.verdict, 'not-effective', '"input was already like this" is not "we hid it"');

  const unmatchedLog = checkAgainstText(plain, {
    state: HIDE_ON,
    catalog: CATALOG,
    transformLog: [{ op: 'hide-host-notes', matched: false, reason: 'nothing-matched' }],
  });
  assert.equal(itemOf(unmatchedLog, 'hostNotes').ok, null, 'a matched:false log is not removal evidence');
});

test('untransformed host sections+contexts fail the hide item with the real catalog (MAJOR-1/2 regression)', () => {
  const r = checkAgainstSections(REAL_SECTIONS, {
    state: HIDE_ON,
    contexts: REAL_CONTEXTS,
    catalog: DEFAULT_CATALOG,
  });
  const item = itemOf(r, 'hostNotes');
  assert.equal(item.ok, false, 'the raw host surface still carries the identity/host-note sections');
  assert.equal(item.code, 'host-notes-visible');
  assert.ok(item.detail.names.includes('harness:identity'), item.detail.names.join(','));
  assert.ok(item.detail.names.includes('harness:source'), item.detail.names.join(','));
  assert.ok(item.detail.names.includes('app:web-surface'), item.detail.names.join(','));
  assert.equal(r.verdict, 'not-effective');
  assert.ok(r.reasons.includes('hostNotes:host-notes-visible'));
});

test('the real catalog transform passes the check when a baseline proves the removal', () => {
  const t = transformPresentation(
    { sections: REAL_SECTIONS.map((s) => ({ ...s })), contexts: REAL_CONTEXTS.map((c) => ({ ...c })) },
    { flags: effectiveFlags(HIDE_ON), catalog: DEFAULT_CATALOG },
  );
  const names = t.presentation.sections.map((s) => s.name);
  assert.ok(!names.includes('harness:identity'));
  assert.ok(!names.includes('harness:source'));
  assert.ok(names.includes('workspace'), 'an unrelated section survives');
  const contextNames = t.presentation.contexts.map((c) => c.name);
  assert.ok(!contextNames.includes('harness:source'));
  assert.ok(!contextNames.includes('app:web-surface'));
  assert.ok(contextNames.includes('working-directory:current'), 'required context stays (it cannot be suppressed)');

  const r = checkAgainstSections(t.presentation.sections, {
    state: HIDE_ON,
    contexts: t.presentation.contexts,
    catalog: DEFAULT_CATALOG,
    baseline: { sections: REAL_SECTIONS, contexts: REAL_CONTEXTS },
  });
  assert.equal(r.verdict, 'effective');
  assert.equal(itemOf(r, 'hostNotes').code, 'host-notes-removed');
});

test('a catalog that cannot identify host notes refuses to judge (no vacuous success)', () => {
  const blind = {
    identityNames: [],
    hostNoteNames: [],
    hostNoteMarkers: [],
    runtimeContextNames: [],
    runtimeContextMarkers: [],
    boundarySectionName: 'enhance.content-boundary',
    personaSectionName: 'enhance.persona',
  };
  const r = checkAgainstSections([{ name: 'whatever', order: 1, text: 'unrelated' }], {
    state: HIDE_ON,
    catalog: blind,
  });
  assert.deepEqual(itemOf(r, 'hostNotes'), { key: 'hostNotes', enabled: true, ok: null, code: 'no-catalog' });
  assert.equal(r.verdict, 'not-effective');
});

test('without markers the check refuses to claim hidden', () => {
  const r = checkAgainstText('whatever', { state: HIDE_ON, catalog: { ...CATALOG, hostNoteMarkers: [], runtimeContextMarkers: [] } });
  assert.deepEqual(itemOf(r, 'hostNotes'), { key: 'hostNotes', enabled: true, ok: null, code: 'no-marker' });
});

test('the sections path proves the boundary by name and exact text', () => {
  const sections = [
    { name: 'identity', order: 10, text: `${PERSONA} Tokens prefixed with @ are paths.` },
    { name: CATALOG.boundarySectionName, order: 31, text: BOUNDARY },
  ];
  const r = checkAgainstSections(sections, { state: CUSTOM_ON, personaText: PERSONA, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.equal(r.verdict, 'effective');
  assert.equal(itemOf(r, 'boundary').code, 'boundary-section-exact');
});

test('the sections path notices a host note that survived the hide switch', () => {
  const sections = [
    { name: 'identity', order: 10, text: 'whatever' },
    { name: 'instructions', order: 20, text: 'Follow workspace rules.' },
  ];
  const hideOn = { ...defaultState(), masterSwitch: true, hideHostNotes: true };
  const r = checkAgainstSections(sections, { state: hideOn, catalog: CATALOG });
  assert.equal(itemOf(r, 'hostNotes').ok, false);
  assert.equal(itemOf(r, 'hostNotes').code, 'host-notes-visible');
});

test('checkEffectiveness uses the sections path when sections are supplied', () => {
  const sections = [{ name: CATALOG.boundarySectionName, order: 1, text: BOUNDARY }];
  const r = checkEffectiveness({ sections, state: CUSTOM_ON, boundaryText: BOUNDARY, catalog: CATALOG });
  assert.equal(itemOf(r, 'boundary').code, 'boundary-section-exact');
});

test('custom persona with empty text is reported as empty-custom, not as success', () => {
  const r = checkAgainstText(ORIGINAL, { state: CUSTOM_ON, personaText: '  ', boundaryText: BOUNDARY, catalog: CATALOG });
  assert.deepEqual(itemOf(r, 'persona'), { key: 'persona', enabled: false, ok: null, code: 'empty-custom' });
});
