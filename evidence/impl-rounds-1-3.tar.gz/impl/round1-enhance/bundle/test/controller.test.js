// controller.test.js — 页面控制器（Step 3 + Step 8 的集成面；写宿主档位仍为 unauthorized）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as fsPromises from 'node:fs/promises';
import { mkdtemp, readFile, readdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createEnhanceStore } from '../host/state-store.js';
import { createEnhanceController } from '../host/controller.js';

async function withTempDir(fn) {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-enhance-controller-'));
  try {
    return await fn(dir);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

function makeController(dir, { readSurface, getSessionPolicy, getRecentApprovals } = {}) {
  const store = createEnhanceStore({ fs: fsPromises, dir, now: () => new Date('2026-11-07T15:28:53Z') });
  return createEnhanceController({
    store,
    readSurface: readSurface ?? (async () => null),
    getSessionPolicy,
    getRecentApprovals,
  });
}

test('status reports paths, the missing file state and that preset writing is not authorised', async () => {
  await withTempDir(async (dir) => {
    const controller = makeController(dir);
    const status = await controller.status();
    assert.equal(status.status, 'missing');
    assert.ok(status.paths.state.endsWith('state.json'));
    assert.ok(status.paths.persona.endsWith('identity.txt'));
    assert.ok(status.paths.boundary.endsWith('content-scope.txt'));
    assert.equal(status.effective.master, false);
    assert.equal(status.presetWrite, 'unauthorized');
    assert.deepEqual(status.issues, []);
    assert.deepEqual(status.backups, { state: [], persona: [], boundary: [] });
    assert.deepEqual(status.recentApprovals, [], 'the ring channel exists before the first approval (MINOR-4)');
  });
});

test('status and check expose the recent approval decisions (MINOR-4)', async () => {
  await withTempDir(async (dir) => {
    const entry = {
      at: '2026-11-07T15:28:53.000Z',
      decision: 'allow',
      reasonCode: null,
      request: { tool: 'bash', callId: 'call-1' },
    };
    const controller = makeController(dir, { getRecentApprovals: () => [entry] });
    const status = await controller.status();
    assert.deepEqual(status.recentApprovals, [entry]);
    const checked = await controller.check();
    assert.deepEqual(checked.recentApprovals, [entry]);
  });
});

test('status reports preset-never when the session policy resolver finds one (MINOR-5)', async () => {
  await withTempDir(async (dir) => {
    const seen = [];
    const controller = makeController(dir, {
      getSessionPolicy: (sessionRef) => {
        seen.push(sessionRef);
        return 'never';
      },
    });
    await controller.save({ state: { masterSwitch: true, approvalOverride: true } });
    const session = { id: 'session-1' };
    const status = await controller.status({ session });
    assert.deepEqual(seen, [session], 'the page session reaches the resolver');
    assert.deepEqual(status.tristate, { active: false, code: 'preset-never' });

    const again = await controller.status({ sessionId: 'session-1' });
    assert.deepEqual(seen[1], 'session-1', 'a bare session id reaches the resolver too');
    assert.deepEqual(again.tristate, { active: false, code: 'preset-never' });
  });
});

test('save writes state and text, and read returns them', async () => {
  await withTempDir(async (dir) => {
    const controller = makeController(dir);
    const saved = await controller.save({
      state: { masterSwitch: true, personaRewrite: true, personaMode: 'custom' },
      personaText: '你是小助手。',
      boundaryText: '不得输出密钥。',
    });
    assert.equal(saved.ok, true);
    const read = await controller.read();
    assert.equal(read.state.masterSwitch, true);
    assert.equal(read.personaText, '你是小助手。');
    assert.equal(read.boundaryText, '不得输出密钥。');
    assert.equal(read.effective.persona.enabled, true);
  });
});

test('an over-limit text makes the whole save a no-op (acceptance 4)', async () => {
  await withTempDir(async (dir) => {
    const controller = makeController(dir);
    const r = await controller.save({ state: { masterSwitch: true }, personaText: '中'.repeat(1000) });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'too-long');
    assert.equal(r.field, 'personaText');
    assert.deepEqual(await readdir(dir), [], 'nothing at all was written');
  });
});

test('check uses the injected surface reader and says where it stands', async () => {
  await withTempDir(async (dir) => {
    const controller = makeController(dir, {
      readSurface: async () => ({ systemText: '你是小助手。其余内容\n\n不得输出密钥。' }),
    });
    await controller.save({
      state: { masterSwitch: true, personaRewrite: true, personaMode: 'custom', contentBoundary: true },
      personaText: '你是小助手。',
      boundaryText: '不得输出密钥。',
    });
    const checked = await controller.check({});
    assert.equal(checked.verdict, 'effective');

    const emptyController = makeController(dir);
    const empty = await emptyController.check({});
    assert.equal(empty.verdict, 'no-data');
  });
});

test('reset turns everything off but keeps the user text (C4 ①)', async () => {
  await withTempDir(async (dir) => {
    const controller = makeController(dir);
    await controller.save({
      state: { masterSwitch: true, contentBoundary: true },
      personaText: '保留我',
      boundaryText: '也保留我',
    });
    const r = await controller.reset();
    assert.equal(r.ok, true);
    const read = await controller.read();
    assert.equal(read.state.masterSwitch, false);
    assert.equal(read.personaText, '保留我');
    assert.equal(read.boundaryText, '也保留我');
  });
});

test('writing or rolling back the host preset table stays unauthorised this round', async () => {
  await withTempDir(async (dir) => {
    const controller = makeController(dir);
    assert.deepEqual(await controller.writePreset(), { ok: false, code: 'unauthorized' });
    assert.deepEqual(await controller.rollbackPreset(), { ok: false, code: 'unauthorized' });
    assert.deepEqual(await readdir(dir), [], 'and it must not touch the state directory either');
  });
});

test('the state file the controller writes is valid JSON with a trailing newline', async () => {
  await withTempDir(async (dir) => {
    const controller = makeController(dir);
    await controller.save({ state: { masterSwitch: true } });
    const raw = await readFile(join(dir, 'state.json'), 'utf8');
    assert.ok(raw.endsWith('\n'));
    assert.equal(JSON.parse(raw).masterSwitch, true);
  });
});
