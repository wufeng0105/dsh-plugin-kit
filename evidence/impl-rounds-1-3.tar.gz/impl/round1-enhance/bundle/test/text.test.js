// text.test.js — 文本校验：UTF-8 字节上限（C6 拒绝保存）、控制字符（A18）、换行归一
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeNewlines, findDisallowedControlChar, validateText } from '../lib/text.js';

test('normalizeNewlines converts CRLF and lone CR to LF', () => {
  assert.equal(normalizeNewlines('a\r\nb\rc\nd'), 'a\nb\nc\nd');
  assert.equal(normalizeNewlines(''), '');
});

test('findDisallowedControlChar finds NUL and ESC, ignores newline and tab', () => {
  assert.deepEqual(findDisallowedControlChar('ok\ntext\twith tab'), null);
  assert.equal(findDisallowedControlChar('bad\u0000char').index, 3);
  assert.equal(findDisallowedControlChar('bad\u001bchar').index, 3);
  assert.equal(findDisallowedControlChar('bad\r\nline').index, 3); // \r 未归一时也算控制字符
});

test('validateText accepts empty text', () => {
  assert.deepEqual(validateText('', 100), { ok: true, bytes: 0, text: '' });
});

test('validateText accepts newline and tab and normalizes them', () => {
  const r = validateText('a\r\nb\tc', 100);
  assert.equal(r.ok, true);
  assert.equal(r.text, 'a\nb\tc');
  assert.equal(r.bytes, 5);
});

test('validateText rejects over-limit by UTF-8 bytes, not chars (C6)', () => {
  // 100 个中文字符 = 300 字节；按字符算会通过，按字节算必须拒绝
  const text = '中'.repeat(100);
  const r = validateText(text, 200);
  assert.equal(r.ok, false);
  assert.equal(r.code, 'too-long');
  assert.equal(r.bytes, 300);
});

test('validateText rejects control characters (A18)', () => {
  const r = validateText('keep\u0007this', 100);
  assert.equal(r.ok, false);
  assert.equal(r.code, 'control-character');
  assert.equal(r.index, 4);
});

test('validateText rejects non-string input', () => {
  assert.equal(validateText(42, 100).code, 'not-a-string');
  assert.equal(validateText(null, 100).code, 'not-a-string');
});
