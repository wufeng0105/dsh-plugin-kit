// identity.test.js — 品牌三态（C3 只替换开头那一句，其余身份说明保留）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { BRAND_SENTENCE, LIMITS, PERSONA_MODES, APPROVAL_MODES } from '../lib/constants.js';
import { applyPersonaToText, resolvePersonaMode, personaPreview } from '../lib/identity.js';

const ORIGINAL =
  'You are an AI agent powered by DeepSeek Harness. Tokens prefixed with @ are paths. ' +
  'The rest of the identity paragraph stays.';

test('the brand sentence constant is the exact host opening sentence', () => {
  assert.equal(BRAND_SENTENCE, 'You are an AI agent powered by DeepSeek Harness.');
});

test('limits are 2 KiB persona and 8 KiB boundary in bytes (C6)', () => {
  assert.deepEqual(LIMITS, { personaBytes: 2048, boundaryBytes: 8192 });
});

test('modes lists match the three states of the requirement', () => {
  assert.deepEqual(PERSONA_MODES, ['keep', 'strip', 'custom']);
  assert.deepEqual(APPROVAL_MODES, ['allow', 'ask', 'deny']);
});

test('keep mode leaves the text byte-identical', () => {
  const r = applyPersonaToText(ORIGINAL, { mode: 'keep', personaText: '' });
  assert.equal(r.text, ORIGINAL);
  assert.equal(r.changed, false);
  assert.equal(r.matched, null);
});

test('strip mode removes only the brand sentence, keeps the rest (C3)', () => {
  const r = applyPersonaToText(ORIGINAL, { mode: 'strip', personaText: '' });
  assert.equal(r.changed, true);
  assert.equal(r.matched, true);
  assert.ok(!r.text.includes(BRAND_SENTENCE));
  assert.ok(r.text.includes('Tokens prefixed with @ are paths.'));
  assert.ok(r.text.includes('The rest of the identity paragraph stays.'));
});

test('strip mode removes only the first occurrence', () => {
  const twice = `${BRAND_SENTENCE} mid text. ${BRAND_SENTENCE} tail`;
  const r = applyPersonaToText(twice, { mode: 'strip', personaText: '' });
  assert.equal(r.text, ' mid text. ' + BRAND_SENTENCE + ' tail');
});

test('custom mode replaces the brand sentence with the persona text', () => {
  const r = applyPersonaToText(ORIGINAL, { mode: 'custom', personaText: '你是小助手。' });
  assert.equal(r.changed, true);
  assert.equal(r.matched, true);
  assert.ok(r.text.startsWith('你是小助手。'));
  assert.ok(r.text.includes('Tokens prefixed with @ are paths.'), 'the rest of identity stays (C3)');
  assert.ok(!r.text.includes(BRAND_SENTENCE));
});

test('text without the brand sentence is reported as unmatched, not silently "success"', () => {
  const r = applyPersonaToText('no brand here', { mode: 'strip', personaText: '' });
  assert.equal(r.text, 'no brand here');
  assert.equal(r.changed, false);
  assert.equal(r.matched, false);
});

test('resolvePersonaMode: custom with empty text falls back to keep (analysis A1/A2 note)', () => {
  assert.deepEqual(resolvePersonaMode('custom', ''), { mode: 'keep', reason: 'empty-custom' });
  assert.deepEqual(resolvePersonaMode('custom', '   \n\t '), { mode: 'keep', reason: 'empty-custom' });
  assert.deepEqual(resolvePersonaMode('custom', '你好'), { mode: 'custom', reason: 'ok' });
  assert.deepEqual(resolvePersonaMode('strip', null), { mode: 'strip', reason: 'ok' });
  assert.deepEqual(resolvePersonaMode('keep', 'ignored'), { mode: 'keep', reason: 'ok' });
});

test('personaPreview gives the page a before/after pair (C3 preview)', () => {
  const p = personaPreview(ORIGINAL, { mode: 'custom', personaText: 'NEW IDENTITY' });
  assert.equal(p.before, ORIGINAL);
  assert.equal(p.after.startsWith('NEW IDENTITY'), true);
  assert.equal(p.matched, true);
});
