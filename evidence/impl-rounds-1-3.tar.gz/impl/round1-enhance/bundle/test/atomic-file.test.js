// atomic-file.test.js — 原子写与 .bak（R10：先备份成功，再写主文件；失败不动主文件）
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm, readFile, writeFile, readdir } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import * as realFs from 'node:fs/promises';
import { atomicWrite, readFileOrNull, saveWithBackup } from '../host/atomic-file.js';

async function withTempDir(fn) {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-enhance-atomic-'));
  try {
    return await fn(dir);
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
}

const NOW = () => new Date('2026-11-07T15:28:53Z');

test('atomicWrite creates the file and leaves no temp file behind', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'a.txt');
    await atomicWrite(realFs, file, 'hello');
    assert.equal(await readFile(file, 'utf8'), 'hello');
    assert.deepEqual(await readdir(dir), ['a.txt']);
  });
});

test('atomicWrite replaces existing content', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'a.txt');
    await writeFile(file, 'v1', 'utf8');
    await atomicWrite(realFs, file, 'v2');
    assert.equal(await readFile(file, 'utf8'), 'v2');
    assert.deepEqual(await readdir(dir), ['a.txt']);
  });
});

test('saveWithBackup copies the previous content to a timestamped .bak first', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'state.json');
    await writeFile(file, 'v1', 'utf8');
    const r = await saveWithBackup({ fs: realFs, file, text: 'v2', base: 'state', now: NOW, offsetMinutes: 480 });
    assert.equal(r.ok, true);
    assert.equal(r.backup, 'state-20261107-232853.bak');
    assert.equal(await readFile(file, 'utf8'), 'v2');
    assert.equal(await readFile(join(dir, r.backup), 'utf8'), 'v1');
  });
});

test('saveWithBackup does not create a backup when there is nothing to back up', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'state.json');
    const r = await saveWithBackup({ fs: realFs, file, text: 'v1', base: 'state', now: NOW });
    assert.equal(r.ok, true);
    assert.equal(r.backup, null);
    assert.deepEqual(await readdir(dir), ['state.json']);
  });
});

test('a failing backup aborts the write and leaves the main file byte-identical (R10)', async () => {
  await withTempDir(async (dir) => {
    const file = join(dir, 'state.json');
    await writeFile(file, 'original', 'utf8');
    const denied = Object.assign(new Error('denied'), { code: 'EACCES' });
    const fs = { ...realFs, copyFile: async () => { throw denied; } };
    const r = await saveWithBackup({ fs, file, text: 'new', base: 'state', now: NOW });
    assert.equal(r.ok, false);
    assert.equal(r.code, 'readonly');
    assert.equal(await readFile(file, 'utf8'), 'original');
  });
});

test('readFileOrNull distinguishes "missing" from "empty"', async () => {
  await withTempDir(async (dir) => {
    assert.equal(await readFileOrNull(realFs, join(dir, 'nope.txt')), null);
    await writeFile(join(dir, 'empty.txt'), '', 'utf8');
    assert.equal(await readFileOrNull(realFs, join(dir, 'empty.txt')), '');
  });
});
