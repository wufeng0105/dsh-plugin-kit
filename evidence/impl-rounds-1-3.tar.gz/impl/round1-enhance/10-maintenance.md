# 10 维护手册：dsh-enhance 0.1.0 升级体检

> 读者：下一个维护者。你手里的三件套：
> - [`09-touchpoints.json`](09-touchpoints.json) —— 44 条宿主触点清单（每条带证据、探针、降级后果）
> - [`tools/recheck.mjs`](tools/recheck.mjs) —— 复检脚本（读清单 + 快照，输出四态，退出码 0/1）
> - [`tools/host-snapshot.sample.json`](tools/host-snapshot.sample.json) —— 2026-11-08 在宿主 0.2.2-rc.1 上导出的真实快照样本
>
> 本手册只回答一件事：**DSH 出了新版本，这个插件还活着吗？** 不写产品功能。上游依据：`07-reverify.md`（GO-WITH-CONDITIONS）、`08-delivery.md`（交付判定与已知问题）。改 `bundle/` 之前请先读完 §6（迁移死锁）与 §7（清单维护）。

---

## 0. 什么时候用这份手册

| 触发条件 | 动作 |
|---|---|
| 宿主 DSH 升级（app 更新、版本号变化） | 全套体检（§2） |
| 准备做 round 2 接线（B1、设置页、Enhanced 写档） | 先跑体检 + 读 §4 的人工项，别带着过期契约开工 |
| 插件装上后行为异常（不加载 / 三态失效 / 检查恒 no-data） | 按 §3 的 MISSING/CHANGED 处置排查 |
| 机器上还有旧包 `@wufeng0105/dsh-enhance` | 先处理 §6 的迁移死锁，再谈别的 |

一句话立场（来自 REQ 边界）：本插件**不声明宿主版本要求**，存活完全靠这份体检确认——所以体检不是可选仪式，是唯一的兼容性保障。

---

## 1. 体检顺序总览

```
步 0  记录事实        宿主版本 / profile / 本插件版本 / 旧包是否在装
步 1  导出快照        cordis_inspect_query → tools/host-snapshot-<ver>-<date>.json
步 2  跑复检          node tools/recheck.mjs --snapshot <快照>
步 3  判读            OK / MISSING / CHANGED / UNVERIFIABLE / DRIFT（§3）
步 4  人工项          机器判不了的 18 条 + 卸载回归 + 验收走查（§4）
步 5  记录            写一份 recheck 报告（日期 + 快照名 + 四态计数 + 处置）
```

任何一步变红都先停下处理，不要带着红项进入下一步。

---

## 2. 各步怎么做

### 步 0：记录事实（2 分钟）

```powershell
# 宿主版本：从 app.asar 内 @deepseek-ai/dsh-base 的依赖版本读（08 §开头的做法）
# profile 与本插件：
Get-Content "$env:USERPROFILE\.dsh\profiles\desktop\package.json" -Raw | ConvertFrom-Json |
  Select-Object -ExpandProperty dependencies
Get-Content "$env:USERPROFILE\.dsh\profiles\desktop\package.json" -Raw | ConvertFrom-Json |
  Select-Object -ExpandProperty dsh
```

要点：`dsh.profile.bundles` 里有没有 `@local/dsh-enhance`（装了没）、有没有 `@wufeng0105/dsh-enhance`（旧包在不在，§6）。

### 步 1：导出宿主探测快照

快照 = 把 `cordis_inspect_query` 的输出抄进一个 JSON。**脚本自己不能调 MCP**，所以这一步永远由会话（你）来做。按清单里 `probe.via` 的指示，最少要做这 7 次查询：

| # | 调用 | 拿什么 |
|---|---|---|
| 1 | host / Service / listService，`{"service":"systemPrompt"}` | methods（signature 逐字抄） |
| 2 | host / Service / listService，`{"service":"sessionQuery"}` | methods + referencedTypes 里的 `SessionSurfaceSnapshot` |
| 3 | host / Service / listService，`{"service":"permissionPresets"}` | methods + referencedTypes 里的 `PresetSpec`/`ApprovalPolicy`/`SandboxMode` |
| 4 | host / Service / listService，`{"service":"agents"}` | `currentInitiator` 签名 |
| 5 | host / Service / listService，`{"service":"sessions"}` | `get(id)` 签名 |
| 6 | host / Event / listEvents，`{"event":"approval/request"}` | mode、signature、types（`ApprovalRequestEvent`/`ApprovalOutcome`/`Agent`） |
| 7 | host / Event / listEvents，`{"event":"system-prompt/assemble"}` | mode、signature、types（`PromptPresentation`） |

客户端在线时**加做**（在线与否都要如实记录）：

| 调用 | 拿什么 |
|---|---|
| client / Slots / listSubTree（不带 root） | slot 目录 → `client.slots-settings` |
| client / Service / listService | remote 命名空间 → `client.remote-enhance` |
| client / Builtin / listBuiltins | `__ModuleLoader__` 还在不在 → `client.module-loader` |

填写规则（脚本怎么读）：

- `services.<key>.methods.<method>` = inspect 输出的 `signature` 字段原样；`services.<key>.types.<Type>` = `referencedTypes` 里的 declaration。
- `events.<name>.{mode,signature,types}` 同理。
- declaration 可以整段抄（含换行），也可以按行拆成字符串数组；比对前脚本会把空白折叠成单空格，所以缩进无所谓、**换行也无所谓**，别改标识符和标点就行。
- client 查询超时 → 写 `"client": {"available": false, "reason": "…"}`，**不要伪造空结果**：slot/remote 类触点会正确落成 UNVERIFIABLE。
- 快照存 `tools/host-snapshot-<宿主版本>-<日期>.json`，不要覆盖 sample——sample 是基线对照物。

### 步 2：跑复检

```powershell
cd <本目录>
node tools/recheck.mjs --snapshot tools/host-snapshot-<ver>-<date>.json   # 退出码 0/1
node tools/recheck.mjs --self-test                                        # 先证明脚本自己没坏
node tools/recheck.mjs --strict            # UNVERIFIABLE 也算失败：发布前用
node tools/recheck.mjs --json              # 给机器/报告用
```

退出码：0 = 无 MISSING/CHANGED/DRIFT；1 = 有；2 = 脚本本身跑不了（清单/快照坏了）。`--strict` 时 UNVERIFIABLE 也计 1（用于「发版前必须人工过一遍」）。

脚本不会联网、不会安装、不会读写 `$DSH_HOME`——它只读清单、快照和本仓 `bundle/` 里的文件（做 hash/内容比对）。

### 步 3：判读（见 §3）

### 步 4：人工项（见 §4）

### 步 5：记录

写 `11-recheck-<日期>.md`（或追加到本文件末尾的记录节），至少包含：快照文件名、四态计数、DRIFT、每条非 OK 项的处置决定。下次升级前先读上一份记录——**触点的历史变迁比单次快照更有信息量**。

---

## 3. 四类结论的判读与处置

脚本输出的每条结论都是「清单期望 vs 新快照」的比对结果。**清单里的 `status` 字段是上一轮的人工判断，脚本不消费它**（只透传显示）；脚本只信 `probe`。

| 结论 | 含义 | 处置 |
|---|---|---|
| **OK** | 触点还在且形状与清单期望一致 | 不动 |
| **MISSING** | 触点整个没了：服务/方法/事件/类型/文件/清单键缺失 | ① 按 `fallback` 判断当前是崩、静默失效还是降级安全；② 用 inspect 目录页找宿主新名字；③ 改 `bundle/` → 全套回归（`node --test`、`check-syntax`、重新 pack、hash 对账）→ 更新清单（status 重新评，别沿用旧的 verified）。**注意**：`svc.inject-*` 类 MISSING 最重——插件根本不会加载 |
| **CHANGED** | 还在，但形状变了：签名不含期望片段 / mode 变了 / 类型声明字段改名 / 文件 hash 变了 / `absent` 探针命中（宿主**补上了**字段） | ① 差异是参数改名这类注释性的，还是行为性的；② 读清单 `why`/`fallback` 判断影响；③ 两条特殊路径：`type.PromptPresentation.variables` 报 CHANGED（变成数组）意味着 R1 反而自愈了；`type.SessionSurfaceSnapshot` 报 CHANGED（出现了 `systemText`/`sections`）意味着 B1 接线可以大幅简化——都按新契约改代码+清单 |
| **UNVERIFIABLE** | 机器判不了：清单标了 `probe.kind:"none"`（含 `manual` 步骤），或快照缺对应小节 | 按 `probe.manual` 一步步人工做；做完把结论写回清单（升级 status 与 evidence）。`--strict` 把它们全算失败，用于发布闸 |
| **DRIFT**（附加行） | 生产代码里有宿主引用，清单里没写 | 先补清单（含 probe/status/fallback），再继续任何别的判断——清单漏项比宿主变脸更危险 |

判读时的两个纪律：

1. **不要为了变绿改清单**。想放宽某个 `signatureIncludes`，先去 inspect 里确认新签名是真实契约，再改清单并在 evidence 里写明出处与日期。
2. **OK ≠ 能用**。脚本验证的是「契约形状没变」；行为对不对（三态真的拦、页面真的渲染）属于 §4 的人工项。

---

## 4. 永远无法自动判的项（人工清单）

脚本恒报 UNVERIFIABLE 的 **18 条** = 下面三张表里的 5 + 6 + 7 条；另外附 2 条「脚本判 OK、但只有真装才能定」的项。按验证成本从低到高排：

**读一段文本就能验（5 分钟）**

| id | 验法 |
|---|---|
| `catalog.brand-sentence` | 新开一个会话，读系统提示第一行是否仍是 `You are an AI agent powered by DeepSeek Harness.` |
| `catalog.host-note-markers` | 同一会话系统提示里搜两句宿主自述开头（清单里原文） |
| `catalog.runtime-context-markers` | 同一会话搜两行 `Current DeepSeek Harness …:` 前缀 |
| `layout.state-dir` | 对比 `$env:DSH_HOME` 与 `~/.dsh`：一旦宿主改用 storage 服务管理数据目录，这条要重新设计 |
| `config.stateDir-override` | 决策题：要不要给它声明 Config schema？不声明就承认它是死代码并在清单里注明 |

**要读安装源码（有 asar 解析能力再做）**

| id | 验法 |
|---|---|
| `catalog.harness-identity` / `catalog.host-note-names` | 在 app.asar 里核对 `harness:identity`、`harness:source`、`app:web-surface` 的注册名与 order（07 §二 MAJOR-1 的做法可复用） |
| `catalog.working-directory-current` | 确认 `working-directory:current` 仍是 `required: true`——它一旦变成可抑制的，hide 的抑制范围会误伤工作目录上下文 |
| `fw.ctx.get` / `fw.ctx.effect` / `fw.ctx.on-disposer` | Cordis 内核 API。间接验法：看在装的官方插件是否还在用同形调用；正式验法：装→卸一轮，确认卸载后无残留监听（`fw.ctx.on-disposer` 的失效方向是危险方向） |

**要装包在真实 GUI 里验（每次升级一次，7 条）**

| id | 验法 |
|---|---|
| `evt.approval-request.dispatch-scope` | 子 agent 里触发一次越界动作，确认插件级监听确实收到（R11） |
| `client.slots-settings` / `client.remote-enhance` | 打开 Harness 页面后 client inspect（超时就如实记）；或装包试注册最小 slot |
| `client.module-loader` 真实加载 | 插件页看 client 半有没有报错（本轮 apply 为空，坏也只是静默） |
| `manifest.exports-locale` / `manifest.exports-icon` | 插件页看文案与图标是否渲染 |
| `layout.host-config-backup` | 只有写档授权后才能验：确认宿主配置文件真实路径与备份命名（现状假设 `config-*.bak`，而实测 profile 里旧插件留的是 `cordis.patch.yml.bak-enhance-*`，不同形） |

**附：脚本判 OK、但只有真装才能定的 2 条**（别因为显示 OK 就当验过了）

| id | 为什么脚本绿了还不够 |
|---|---|
| `evt.approval-request` | 脚本只核对事件契约；allow/ask/deny 三态的真实弹窗行为、以及「档位本身是 never 时宿主根本不发请求」这条，必须按 08 §三 第 3 行走查 |
| `patch.insert-entry` | 脚本只核对 patch 文件内容与包名一致；Loader 是否接受「只有一条 insert」的 patch，只有在 `list_bundles` 里看到 `dsh-enhance` 且状态 applied 才算成立 |

**卸载回归（每次升级后至少一次）**：装 → 卸 → 重启 → 确认宿主正常、`~/.dsh/enhance/` 文件原样（mtime 未变）。这是 `fw.ctx.on-disposer` 和需求 8 的最终裁决。

---

## 5. 版本一致性怎么核（本目录没有 git）

### 能核的（都有真实命令，本轮全部跑过）

| # | 核什么 | 命令 | 本轮结果（2026-11-08） |
|---|---|---|---|
| 1 | 交付物没被换 | `(Get-FileHash bundle/local-dsh-enhance-0.1.0.tgz -Algorithm SHA1).Hash` | `cf45966260f6a69f3dc510a5a36ad2a27f6ae90a`，与 08 §1.2 逐字一致 |
| 2 | 包与源码同步 | `tar -xzf … -C $tmp` 后对 27 个文件逐个 `Get-FileHash -Algorithm SHA256` 与 `bundle/` 比对 | **27/27 一致** |
| 3 | 文件集没漂 | `tar -tzf … \| Measure-Object -Line`；对照 `package.json` 的 `files` 白名单 | 27 条；与 08 §1.4 一致 |
| 4 | 打包后源码没再改 | 比较 bundle 内源文件最新 mtime 与 tgz mtime | 00:40:41 < 01:02:57 ✔ |
| 5 | 功能基线没漂 | `cd bundle; node --test "test/*.test.js"`；`node scripts/check-syntax.mjs` | 153/153；40 files 0 failed（本轮亲跑） |
| 6 | 名字链一致 | `cordis.patch.yml` 的 `name` == `package.json.name` == `client.js` 的 `id` | 三处同为 `@local/dsh-enhance`（清单 `patch.insert-entry` / `client.module-loader` 的 contains 探针） |

### 不能核的（要如实告诉下一个人）

- **没有历史**：无法回答「哪个文件哪次改动、谁改的、为什么」。无法 bisect、无法 blame。08/07 里描述的 bundle 与现在的 bundle 只能靠上面那张表间接对账。
- **文档时效无锚点**：`03-implementation.md` 的页面规格、`04-selfcheck.md` 的用例数早已过期（07 条件 4）。没有 git 就没有「文档对应哪个代码状态」的证明，只能靠 mtime 这类弱证据 + 文内声明。
- **缓解办法**（把 hash 对账当穷人版 commit）：每次动 `bundle/` 之前，先记录当前 tgz 的 sha1；改完重打包、重算 sha1/条目数、跑 §5 表格全部 6 项，并把数字写进当次记录。**改了源码但不重打包**是本目录最容易出现的不一致——清单里的 `package.files-whitelist` 探针（sha1+size）就是抓它的。

---

## 6. 迁移死锁：旧 `state.json` v4 → degraded + version-conflict

### 现象与机理

本机（以及任何装过旧包 `@wufeng0105/dsh-enhance` 的机器）现状：`~/.dsh/enhance/state.json` 是旧格式——

```json
{ "version": 4, "enabled": true, "contentScope": true, "approval": "allow",
  "identity": "custom", "hideHarness": false, "updatedAt": "…" }
```

新包只认 `version: 1` 与 `masterSwitch/approvalOverride/…` 字段名。后果链（08 §四 D-1，已实测）：

1. `load()` → 字段全 unknown → 五开关回落 false、模式回落 keep/ask，status=`degraded`，issues 带 `unsupported-version`；
2. `saveState()` / `resetStateToDefault()` 看到 `unsupported-version` → 返回 `version-conflict`（`host/state-store.js:82-84`）；
3. **没有页面 → 没有任何入口能触发保存或提示** → 用户视角是「装了但什么都不会发生，且永远如此」。这就是「死锁」：状态卡住、无提示、无自救按钮。

### 维护处置（按优先级）

**A. 人工解锁（现在就能做，每步可逆）**——照 08 §2.6 的顺序，这里是维护者视角的最短版：

```powershell
# 1) 卸旧包（如果还在 bundles 里）：plugin_manager remove_bundle target=@wufeng0105/dsh-enhance，按提示重启
# 2) 备份并让新包看到「无文件」（missing = 全默认 = 安全）
$d = "$env:USERPROFILE\.dsh\enhance"
Copy-Item -LiteralPath $d -Destination "$d.old-plugin-backup" -Recurse
Rename-Item -LiteralPath "$d\state.json" -NewName "state.json.old-plugin"
# 3) 之后 status() 应为 missing；content-scope.txt 想清就改名 content-scope.txt.old-plugin（旧包内容会被当边界文本读入，D-4）
```

**B. 代码修法（round 2 接线时做）**，两条独立、都值得做：

1. `resetStateToDefault()` 绕过版本闸：「恢复出厂」语义上不需要旧文件合法——改 `state-store.js`，让 reset 在 `unsupported-version` 时先备份原文件再写默认值。这一行就能把「死锁」降级成「降级+可自救」。
2. 一次性迁移：`normalizeState`（`lib/state.js`）识别 `version >= 2` 且带旧字段名时做字段映射（`enabled→masterSwitch`、`contentScope→contentBoundary`、`approval→approvalMode`、`identity→personaMode`、`hideHarness→hideHostNotes`），映射后写 `version:1` 并在 issues 里注明迁移发生。注意 `approval:"allow"` 的语义迁移要保守：映射成 `approvalOverride:true + approvalMode:"allow"` 等于把旧包的自动放行原样继承，**建议映射成 `ask`** 并让用户在页面上重新选（风险提示文案这时才存在）。

**C. 不要做的**：手改 v4 文件把 `"version": 4` 改成 `1`。字段名完全不同，改完五个开关全按缺省回落、`approval:"allow"` 变成未知 extra 被丢弃——看起来「迁移成功」，实际是「假装迁移」，用户以为的配置与实际行为完全脱节，而且 `content-scope.txt`（D-4）照样被当边界文本读入。

### 体检时怎么发现它

- 步 0 的 `dsh.profile.bundles` 里有 `@wufeng0105/dsh-enhance`；
- 或清单 `layout.state-dir` 人工验证时发现 `state.json` 的 `version` 不是 1；
- 或装包后 `status()` 报 degraded + `version-conflict`。

任一命中 → 先做 A，再继续 §1 的其余步骤。**这个死锁不解除，插件的行为基线（全关=原样）就建立不起来**，后面所有验证都不可信。

---

## 7. 维护这个清单本身

- **新增触点先补清单**：改 `bundle/` 引入新的 `ctx.get/ctx.on/inject/slots/remote` 引用后，`recheck.mjs` 的 DRIFT 扫描会抓出来（退出码 1）。补的时候给全 `why/probe/status/fallback`——不许只写 ref。
- **不要从 02-plan 抄**：这份清单的每条都来自代码 grep + inspect 实测。计划文档里的「打算用」不是触点，只有写进代码（含注释草图，标 `usage: commented`）才算。
- **probe 必须可执行**：`kind:service/event/type/file/package` 会被脚本真实比对；写不出可机器判定的探针就用 `kind:"none"` + 具体的 `manual` 步骤，不要写「待验证」这种空话。
- **status 三态的纪律**：verified 要有 evidence（inspect 输出/本会话提示原文/文件 hash）；不确定写 unverified；inspect 结构性拿不到的写 unverifiable。升级后重评，旧 status 一律视为过期。
- **快照是小节级容错的**：快照缺某 service/event 小节时，对应触点报 MISSING（真缺）或 UNVERIFIABLE（client 小节整体缺失时 slot 类仍是 UNVERIFIABLE，因为 kind=none）。所以快照宁缺勿错：**宁可少抄一条，不要抄一个「差不多」的签名**。

---

## 8. 本轮体检基线（2026-11-08，宿主 0.2.2-rc.1）

```
node tools/recheck.mjs
  44 条：OK 26 / MISSING 0 / CHANGED 0 / UNVERIFIABLE 18（DRIFT 0）→ 退出码 0
node tools/recheck.mjs --self-test
  基线 + 3 组反例全 PASS（删方法→MISSING；改事件签名→CHANGED；改类型字段→CHANGED）
CLI 级反例（快照写到 %TEMP%\dsh-recheck-cp\）：cp1 exit=1（MISSING）、cp2 exit=1（CHANGED）、cp3 整服务消失 exit=1（4 条 MISSING）
版本一致性：tgz sha1 = cf45966260f6a69f3dc510a5a36ad2a27f6ae90a（与 08 一致）；
            tgz 解包 vs bundle/ 逐文件 sha256 27/27 一致；
            bundle 源文件最新 mtime 00:40:41 < tgz 01:02:57；
            node --test 153/153；check-syntax 40/0
宿主契约实测（本轮 inspect）：sessionQuery.readSurface 存在但 SessionSurfaceSnapshot 不含 systemText/sections/contexts（B1 根因）；
            PromptPresentation.variables 是 Record（R1 成立）；PresetSpec.name/description 可选（MINOR-7 依据）；
            client inspect（Slots.listSubTree）10s 超时 ×2
```

已知的最大盲区（下轮体检优先补探针）：

1. **运行时系统提示面没有任何探针**：`SessionSurfaceSnapshot.events` 里的 `system/message` 到底长什么样、能否折叠出稳定文本——B1 映射需要的正是它，目前只能装包实测。
2. **Client 半整体黑盒**：slot 目录、Remote 生成规则、`__ModuleLoader__` 真实加载路径全部依赖页面在线的 client inspect（历史 8 次超时）。
3. **分发行为**：插件级 `approval/request` 监听对子 agent 的覆盖（R11）——契约能查，行为查不了。
4. **数据目录政策**：宿主若把插件状态收进 storage 服务，`layout.state-dir` 整条失效，而它的失效是静默的。
5. **清单只覆盖「写了的引用」**：隐含依赖（Node 版本、Cordis effect 的 dispose 时机、服务初始化顺序）不在清单里——`bundle/index.js:32-34` 的注释声称读 `approval` 服务，实际代码没有，这类「注释与代码不符」只能靠读源码发现。

