# 03 实施记录：dsh-enhance（round 1）

> 输入：`00-client-answers.md`（C1–C8 优先于计划默认值）、`01-analysis.md`、`02-plan.md`。
> 产出：`bundle/`（代码 + 测试）。本文说明实现了什么、哪些留空壳、怎么跑、以及和计划的偏差。
> 三条硬约束遵守情况：**未安装任何插件、未改 `$DSH_HOME` 下任何 profile/插件数据目录、未写宿主配置**。全部测试只碰 `os.tmpdir()`。

---

## 1. 交付清单

### 1.1 纯逻辑内核（计划 Step 1，`bundle/lib/`，零 Node 依赖）

| 文件 | 导出 | 覆盖的需求点 |
|---|---|---|
| `constants.js` | `STATE_VERSION`、`LIMITS`、`PERSONA_MODES`、`APPROVAL_MODES`、`SANDBOX_MODES`、`APPROVAL_POLICIES`、`BRAND_SENTENCE`、`DECISION_RING_CAPACITY`、`DEFAULT_BACKUP_KEEP` | C6 字节上限、C3 只替换那一句 |
| `bytes.js` | `utf8ByteLength` | C6：按 UTF-8 字节（`TextEncoder`，浏览器/Node 通用） |
| `text.js` | `normalizeNewlines`、`findDisallowedControlChar`、`validateText` | C6 超限拒绝、A18 控制字符、CRLF 归一 |
| `boolean.js` | `parseBoolFlag` | A12：`true/false`、`1/0`、`on/off`、`yes/no`，大小写与空白不敏感 |
| `state.js` | `defaultState`、`normalizeState`、`parseState`、`serializeState`、`effectiveFlags` | C7 逐字段回落、未知字段保留、总开关门控 |
| `identity.js` | `resolvePersonaMode`、`applyPersonaToText`、`personaPreview` | C3：只替换/删除第一处品牌句，其余身份段保留 |
| `sections.js` | `transformPresentation`、`matchesCatalogEntry`、`DEFAULT_CATALOG` | Step 4 纯函数层：全关返回同一对象；隐藏宿主自述 + 两条 runtime context（C2）；末尾追加边界（A3） |
| `approval.js` | `decideApproval`、`approvalDirective`、`explainTristate`、`createRing`、`pushDecision`、`recentDecisions` | C1、C7、C8：三态映射、`never` 档如实说明、环形记录 |
| `preset.js` | `enhancedPreset`、`validatePresetTable`、`mergePresetTable`、`diffPresetTables`、`assertSafeWrite` | 需求 4：整表合并、保留 `defaultPreset`、幂等、写前安全闸 |
| `backup.js` | `timestampStamp`、`backupName`、`parseBackupName`、`pruneBackups` | 时间戳 `.bak`、防重名、按名排序取最新 |
| `check.js` | `checkAgainstText`、`checkAgainstSections`、`checkEffectiveness`、`DEFAULT_SCAN_WINDOW` | Step 8 比对：已生效/部分/未生效/暂无记录，且**从不把没出现的写成成功** |

### 1.2 状态文件服务（计划 Step 3，`bundle/host/`）

| 文件 | 职责 |
|---|---|
| `paths.js` | C5 固定路径解析 `<home>/.dsh/enhance`（可覆盖），三个文件名常量 |
| `atomic-file.js` | 先校验→再备份→再原子写（临时文件 + rename）；`classifyIoError` 把 `EACCES/EPERM/EROFS` 归为 `readonly`；备份失败则**不写主文件** |
| `state-store.js` | `load`（缺文件=默认 / 坏内容=逐字段回落 / 读不了=unreadable）、`saveState`（拒绝无效补丁与更高版本）、`savePersonaText`/`saveBoundaryText`（超限拒绝、控制字符拒绝、LF 归一）、`readTextFile`、`resetStateToDefault`、`listBackups` |
| `preset-service.js` | `preparePresetWrite`（合并 + `assertSafeWrite` + diff + `.bak` 名）、`planRollback`（C4 ②：恢复前再备一份） |
| `approval-service.js` | `handleApprovalRequest`：allow/deny 不走 `next()`，ask 走 `next()`，每次记环形缓冲 |
| `check-service.js` | `runCheck`：读会话表面（注入 `readSurface`）→ 纯比对；读失败/无数据 → `no-data`，不抛给页面 |
| `controller.js` | 页面控制器：`status / read / save / check / reset / writePreset / rollbackPreset`。`save` 是**全有或全无**：先校验两段文本，任一超限则一个字节都不写 |
| `prompt-service.js` | `planRegistrations`（纯函数，已测）+ `createPromptBridge`（**空壳**，见 §3） |

### 1.3 包骨架（计划 Step 2）

`package.json`（`type: module`、`exports` 含 `.`/`./client`/`./locale/*.json`/`./icon`、`files`、`dsh.bundle.patch`、`dsh.client`）、`cordis.patch.yml`（`insert` 一行 `id: dsh-enhance`）、`index.js`（Host 入口，`inject = ['systemPrompt','sessionQuery']`）、`client.js`（Client 入口空壳）、`locale/en.json`、`locale/zh.json`（含 `meta.title`/`meta.description` 与全部界面文案，含 C2/C8/C1 的强制警示）、`icon.svg`（原创 SVG）、`README.md`（安装/卸载/迁移/两级回退）。

### 1.4 测试（`bundle/test/`，18 个文件、138 个用例）

`node:test` + `node:assert/strict`，无第三方依赖。集成测试在 `os.tmpdir()` 下建临时目录，真读写文件，结束后递归删除。

| 测试文件 | 对应实现 |
|---|---|
| `bytes/text/boolean/paths.test.js` | 字节、校验、布尔、路径 |
| `state.test.js` | 解析、逐字段回落、未知字段、`effectiveFlags` |
| `identity.test.js` | 三态、只替换第一处、空自定义回落 |
| `sections.test.js` | 全关同引用、隐藏、追加、隐藏+自定义交互、无法匹配时如实报告 |
| `approval.test.js` / `approval-service.test.js` | 三态决定、`never` 档说明、环形缓冲、`next()` 是否被调用 |
| `preset.test.js` / `preset-service.test.js` | 整表合并、幂等、冲突、危险写入拦截、回滚计划 |
| `backup.test.js` | 时间戳命名、防重名、清理只对可识别文件 |
| `check.test.js` / `check-service.test.js` | 已生效/部分/未生效/无数据/读失败 |
| `atomic-file.test.js` / `state-store.test.js` / `controller.test.js` | 原子写、备份失败不写主文件、超限不落盘、损坏回落、版本冲突、全有或全无 |

---

## 2. 与计划的偏差（逐条，附理由）

1. **locale 文件名用 `locale/en.json` + `locale/zh.json`**，不是计划里写的 `zh-CN.json`/`en-US.json`。理由：宿主模板与官方技能文档都按 `locale/en.json`、`locale/zh.json` 举例，且导出模式是 `./locale/*.json`；采用模板惯例降低安装期被判定为"缺 locale"的风险。
2. **没有 `export const Config`**。计划 1.3 想要「状态文件路径覆盖 + 是否允许写档」两个配置项。宿主 `Config` 的声明形态（typert/装饰器）在纯 JS 下未核实，写错会让行激活失败。当前做法：`index.js` 防御式读取 `config.stateDir`，patch 行不带 `config`；**待探针补 Config 声明**。
3. **`system-prompt/assemble` 瀑布只用于"替换/隐藏"，边界段按 `systemPrompt.section()` 注册**。计划 Step 4 写的是"监听 assemble 同时处理追加和替换"；技能文档 `references/practices.md` 明确说不要用 assemble 瀑布加/删文本，加文本用 `section()`。纯函数层两者都支持（`transformPresentation` 一次性算完），接线时分开即可。**这是接线设计约束，不是已实现**（见 §3）。
4. **`hideHostNotes` 与 `custom` 人设的交互是新增决策**：C2 要求连身份段一起隐藏，但用户写了自定义人设时不能把它一起吞掉——实现为「身份段被移除时，自定义文本作为独立 section `enhance.persona` 注入到身份段原来的 order 位置」。计划没写这条；测试 `sections.test.js` 覆盖。
5. **`personaMode: "custom"` + 空文本 → 按 `keep` 处理并给出 `empty-custom` 原因**（不是把身份段清空）。计划未定，按"不能静默把提示词删空"处理。
6. **状态文件也做 `.bak`**（计划只要求写档留 `.bak`）。理由：损坏的 state.json 被一次保存覆盖就再也查不到原因；测试 `state-store.test.js` 证明坏文件也会先备份。**不自动清理**：`pruneBackups` 是纯函数且已测，但 store 没接它——本轮不删任何用户文件。
7. **新增 `version-conflict` 拒绝保存**：`state.json` 的 `version` 高于本插件认识的版本时，加载照样逐字段回落（C7），但**拒绝写回**，避免把未来格式静默降级成 v1。计划未涉及。
8. **审批监听每次请求重新读状态文件**（不缓存）。理由：满足"页面与手改文件同一份"和"下一条消息生效"；代价是每次审批一次小文件读。计划 R6 提到的 watch/缓存留到接线时做。
9. **`preset.description` 是中英双语对象** `{ en, zh }`（A6 要求双语）。宿主对 `name`/`description` 的确切类型未核实（探针 P6）；合并逻辑把它当不透明值，形态随时可换。
10. **包名 `@local/dsh-enhance`**（A16 只要求带 scope）。旧包迁移处理只在 README 说明，不做检测。

---

## 3. 空壳 / 未接线清单（附原因）

| 位置 | 现状 | 为什么 | 接线需要什么 |
|---|---|---|---|
| `host/prompt-service.js` `createPromptBridge` | 返回 `{ sync(){}, dispose(){}, status(){ wired:false, reason:'probe-required' } }` | 探针 P1/P2/P5：真实 section 名与 order、身份段是否 `complete` section（若是，瀑布改不动，01-R1 成立）、`suppressRuntimeContext()` 与两条 runtime context 的关系 | 探针结论 → 填 `DEFAULT_CATALOG`，在 `sync()` 里按 `planRegistrations` 注册/注销 section 与监听 |
| `index.js` `readSurfaceSnapshot` | 直接返回 `null` | 探针 P7：`SessionSurfaceSnapshot` 里系统提示的字段路径 | 把快照映射成 `{ systemText, sections, contexts }` |
| `index.js` `currentApprovalPolicy` | 返回 `undefined` | 探针 P6：`permissionPresets.resolve/current` 需要什么参数才能拿到当前档的 `approval` | 返回 `'ask'|'never'`，`explainTristate` 就能如实显示"此档不产生审批请求" |
| `controller.writePreset` / `rollbackPreset` | 返回 `{ ok:false, code:'unauthorized' }`，**不碰任何文件** | 项目约束：本轮不写宿主配置（00-client-answers 追加约束 1） | 授权后接 `settings.describe/prepareDocument/update` 或 `configEditor.edit`，用 `host/preset-service.js` 的 `preparePresetWrite`/`planRollback` |
| `host/preset-host.js` | **未创建**（避免出现"看起来能用"的写盘代码） | 同上；写盘路径完全依赖真实 profile 文件定位 | 授权后新增，调用 `preparePresetWrite` → 备份 → 整表写回 → 用 `assertSafeWrite` 复核 |
| `client.js` | 注册任何东西都不做，`inject: []` | 客户端 inspect 全过程超时（01-R4）：设置页槽位、注册 API、Remote 命名空间全部未知 | 页面在线时查 `Slots.listSubTree`，再按 §5 规格实现 |
| `index.js` 的 Remote 暴露 | 只把控制器挂到 `ctx.enhance` | 02-plan 3.8 未核实（`@Remote` 装饰器在纯 JS 下的形态） | 核实时改成 Remote 服务，页面用 `ctx.remote.enhance.*` |
| 设置页 | 未实现，规格见 §5 | 同上 + 不能安装验证 | — |

**没有做的验证**：安装、探针、真实 `readSurface`、真实审批弹窗、真实写档、卸载。全部列在 `04-selfcheck.md` 第 3 节。

---

## 4. 怎么跑

工作目录：`bundle/`。

```powershell
node --test "test/*.test.js"        # 138 个用例；等价于 npm test
node scripts/check-syntax.mjs       # 40 个 JS 文件 node --check
```

- 无需 `npm install`：没有任何依赖。
- 集成测试只在 `os.tmpdir()` 下读写，**不会碰 `$DSH_HOME`**。
- `scripts/check-syntax.mjs` 用 `spawnSync(..., { stdio: 'inherit' })`，因为 DSH 沙箱下 Node 子进程的管道捕获会 EPERM。

---

## 5. 设置页结构规格（Step 7：本轮只给规格，未实现）

目标位置未知（P4：客户端设置页槽位）。页面自上而下：

1. **顶部状态条（常驻）**
   - 状态文件路径（三段：目录、`state.json`、`identity.txt`、`content-scope.txt`）+「复制文件夹路径」按钮（C5）。
   - 状态：`missing` → "还没有状态文件，当前使用默认值"；`corrupt` → **红底常驻横幅**「状态文件有损坏：相关字段已按安全值回落（审批→先问我，人设→保留），文件没有被自动改写」，并列出 `issues[]` 的 `field/code/fellBackTo`（C7）；`unreadable` → 「状态文件夹不可读写」+ 禁用所有写入控件。
2. **组 1 总开关**：`role="switch"`，关掉时下面四组整体置灰但保留可见（用户能看到自己写了什么）。
3. **组 2 品牌人设**：三选一（保留 / 去掉开头那句 / 换成我写的文本）+ 文本框（≤2048 字节，右下角实时字节计数器，超限时保存按钮禁用并提示「超过上限，未保存」）+ **替换前后预览**（`personaPreview` 的 before/after 两栏，C3）。
4. **组 3 内容边界**：多行文本框（≤8192 字节计数器），说明「追加在每条系统提示的末尾」。
5. **组 4 越界审批**：三选一（一律放行 / 先问我 / 一律回绝）；选「一律放行」时**红字**风险提示（C8 原文文案）；当 `status.tristate.code === 'preset-never'` 时置灰并显示「当前权限档本身从不询问……这个开关在此档位下不生效」（C1）；下方「最近的决定」列表读环形缓冲（时间、工具、决定）。
6. **组 5 隐藏宿主说明**：开关 + **代价警告**（C2 原文文案：两条 runtime context 与操作约定一起消失，对改 DSH/写插件的人是行为退化）。
7. **Enhanced 档区**：「当前档位」只读展示；「写入 Enhanced 档」「从最近备份回滚档位」两个按钮，**本轮点下去返回 `unauthorized` 并显示「本构建未授权写宿主配置」**；`status.backups.state/persona/boundary` 列表展示最近 `.bak`。
8. **检查面板**：「检查」按钮 → 显示 `verdict`（已生效/部分生效/未生效/暂无记录）+ 三个条目（人设/边界/隐藏）各自的 `code` 与 `detail`；未生效时必须显示原因，禁止只显示成功（需求 7）。同时提示「下一条消息生效，不需要重启」。
9. **恢复默认**：二次确认弹窗（C4 ①），文案强调「开关全关，文本保留不删」。

交互约定：所有保存走一次 `controller.save({ state, personaText, boundaryText })`（全有或全无）；保存成功后重新拉 `status()/read()`，不本地乐观更新；手改文件后页面刷新靠重新拉取（watch 未实现）。

---

## 6. 下一步（给接手的人）

1. 先做探针（02-plan Step 0），把 P1/P2/P5/P6/P7 的答案填进 `lib/sections.js` 的 `DEFAULT_CATALOG` 与 §3 的空壳。
2. 若 R1 成立（身份段是 complete section）→ 只能降级：边界段单独一节，品牌三态标灰；不要改宿主配置，除非客户为 01-C2 签字。
3. 客户端 `Slots.listSubTree` 能查通后再写设置页；拿不到就按 §5 的降级（`webServer.register` + 本机鉴权）。

---

## 7. 如果下一个人接手，最可能误解的三处

1. **"全关 = 宿主原样"不是"返回一个内容相同的数组"，而是"同一引用 + 一个都不注册"**。`transformPresentation` 在全关时原样返回入参对象（测试断言 `===`），同时 `planRegistrations` 必须给出"不注册 section、不注册监听"。如果有人为了"统一路径"改成全关时也重建数组、或常驻注册一个空 section，验收 1 的逐字节比对就会失败——而单看输出文本可能看不出来。
2. **三个文件是三个独立的真源，`personaMode: "custom"` 不代表人设真的生效**。文本在 `identity.txt`、`content-scope.txt`，不在 `state.json`；custom 模式在文本为空/缺文件时回落 `keep`（`resolvePersonaMode`）。误把文本塞进 `state.json`、或在保存时只写 `state.json`，会让"页面与手改文件是同一份"当场破掉。
3. **`.bak` 有两套含义**：状态目录里 `state-*.bak` / `persona-*.bak` / `boundary-*.bak` 是**每次覆盖前的字节副本**；宿主档位备份是 `config-*.bak`，回滚时还要再备一份（`planRollback`）。而且**没有任何自动清理**：`pruneBackups` 只是纯函数、测试过、没接线。把 `config-*.bak` 当状态备份恢复、或以为旧 `.bak` 会被自动删掉，都会出事。
