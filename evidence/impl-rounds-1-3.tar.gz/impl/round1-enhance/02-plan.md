# 02 开发计划：dsh-enhance

> 阶段二产出。前置阅读：`01-analysis.md`。  
> 计划默认按 01 里「建议默认值」推进；8 条待澄清问题见 `01-analysis.md` 第 4 节，其中 C1（审批与 never 档）、C2（隐藏边界）、C4（卸载回退）会改变实现面，回答前先做不受影响的部分。

---

## 1. 形态判断：这个插件需要哪些组成部分

### 1.1 结论

一个 **DSH bundle 包**（单个 npm 包、带 Host 半 + Client 半），不是纯配置包，也不是纯 UI 包。理由：需求同时要「改模型读到的系统提示」「接管审批」「写宿主权限配置」「读会话日志」「设置页」，横跨宿主与浏览器两侧。

### 1.2 代码面（要写的东西）

| 面 | 文件 | 职责 | 关键依赖 |
|---|---|---|---|
| 状态存储 | `host/state.js` | 状态文件 schema（5 开关 + 人设三态 + 内容边界文本）、字符串布尔解析、UTF-8 字节上限校验、损坏按字段回落、原子写、`.bak`、watch 失效 | `fs`（readText/writeText/stat/watch）、`timer`（防抖） |
| 提示改造 | `host/prompt.js` | ① 注册自己的末尾 section（内容边界）② 监听 `system-prompt/assemble`，按人设三态改写开头身份段 / 按开关移除宿主自述 section | `systemPrompt.section`、`system-prompt/assemble` 瀑布 |
| 审批三态 | `host/approval.js` | 监听 `approval/request`：auto→`allowed-once`，ask→`next()`，deny→`rejected`；记录最近决定（内存环形缓冲）供「检查」展示 | `approval/request` 瀑布 |
| 档位写入 | `host/preset.js` | 读实时档位全表 → 合并 Enhanced 档 → 写前 `.bak`（时间戳） → 整表写回（不动 `defaultPreset`） → 回滚入口 | `permissionPresets.catalog`、`settings.describe/prepareDocument/update`（或 `configEditor.edit`）、`fs`/`os` 做 `.bak` |
| 检查 | `host/check.js` | 读当前会话最新 `system/message`，比对「开头段已替换」「末尾段已追加」；未命中即返回「未生效」，并说明原因（开关关闭 / 未到下一步 / 文件损坏回落） | `sessionQuery.readSurface` / `readSession` |
| 控制器 | `host/controller.js` | 面向页面的 `@Remote` 服务：`status()`、`read()`、`save(patch)`、`check()`、`writePreset()`、`revert()`、`subscribe()`（文件变化推送） | 宿主 Remote 机制（见 3.8，未核实） |
| 客户端页面 | `client/index.js` | 设置页五组：总开关、品牌三态（含预览）、内容边界（≤8KB 计数器）、越界审批三态、隐藏宿主说明（带代价警告）、Enhanced 档按钮（写档/回滚/当前档位显示）、检查按钮与结果区、状态文件路径与「复制路径」、恢复默认 | Client Slots + `ctx.remote.*` + 主题 token |
| 资源 | `locale/zh-CN.json`、`locale/en-US.json`、`icon.svg` | 文案与图标 | — |
| 包与装配 | `package.json`、`cordis.patch.yml`、`README.md` | bundle manifest、启用行、安装/卸载/迁移说明 | `plugin_manager.install_bundle`（实施期，需批准） |

### 1.3 配置面（要声明的配置）

| 配置 | 放哪 | 用途 | 约束 |
|---|---|---|---|
| 插件自身 Config | `cordis.patch.yml` 条目 | 只放**非业务**的可选项：状态文件路径覆盖（默认空=用固定路径）、是否允许写宿主档位（默认 true，客户可关） | 绝不用 Config 存 5 个开关/人设/边界文本（违反「不改宿主文件」+「页面与手改文件同一份」） |
| 设置页自动生成 | `settings.configure({ auto: false })` | 关掉由 Config schema 自动生成的设置页，避免和自绘页重复 | 未核实是否必需，实施时验证 |
| `permission-presets` 条目 | 宿主 profile 配置 | 写入 Enhanced 档 | 唯一允许的宿主写；整表写回；`.bak`；不动 `defaultPreset` |
| 状态文件 | `%USERPROFILE%\.dsh\enhance\state.json`（待 C5 定） | 5 开关 + 三态 + 两段文本 | 用户可手改；卸载保留 |

### 1.4 明确不做的面

- 不写 `system-prompt` 宿主配置（除非 C2 裁定必须，且需客户批准；见 5.1）。
- 不注册模型可见的工具（默认不做；检查只在设置页里点）。
- 不接管 `tools/pre-execute` 自己判越界（理由见 01-A4）。
- 不自定义会话事件类型、不伪造审批审计。
- 不 import 宿主内部模块（只走 `ctx.*` / `ctx.remote.*`），兼容立场与需求一致：不声明版本要求。

---

## 2. 开发顺序（每步 + 完成标志）

> 现实约束：本轮**不允许安装插件、不允许改 DSH 配置**。因此第 0–1 步可以在本轮完成；真正「装上去跑」的验证全部后移到实施期（需客户/负责人授权一个临时 profile）。每步都写清「本轮能不能验」。

### Step 0 探针设计（不写产品代码）
**做什么**：写一份探针清单与最小探针插件（只在临时 profile 装），回答 5 个问题：  
1. 宿主的系统提示 section 名字与顺序，身份段是哪个 name、是否 `complete`；  
2. 瀑布里改 `sections` 是否真的生效（R1）；  
3. `approval/request` 监听器是否对所有 agent 生效（R11）；  
4. `settings.describe('include:permission')` 返回的 presets 实时表长什么样、revision 语义；  
5. 客户端设置页 Slot 名与注册 API（页面在线时用 `Slots.listSubTree`）。  
**完成标志**：5 个问题各有书面结论；若 R1 成立（改不动），当场决定走 1.4 的降级或 C2 的配置方案。  
**本轮状态**：⛔ 做不了（要装探针包）；本轮只交付「探针清单」，随计划一起给。

### Step 1 纯逻辑内核（本轮可做、可验）
**做什么**：把不依赖宿主的逻辑抽成纯函数模块：  
- `parseState(rawText)`：字符串布尔、逐字段校验、损坏回落（审批→ask、人设→keep）、未知字段保留；  
- `validateText(text, limitBytes)`：UTF-8 字节计数、控制字符拒绝；  
- `transformPresentation(sections, state)`：给定 section 数组 → 删除/替换/追加后的数组（输入输出都是纯数据，方便测试）；  
- `decideApproval(state)` → `'allow' | 'ask' | 'deny'`；  
- `mergePresetTable(current, enhanced)`：整表合并、保留 defaultPreset、幂等；  
- `backupName(now)`：时间戳命名、防重名。  
**完成标志**：workspace 里一个 Node 测试脚本（无第三方依赖）跑出全绿，用例覆盖：全关一致性（输出数组与输入深相等）、损坏回落、超限不写、三态映射、整表保留、重复写入不产生重复档位、`.bak` 命名唯一。  
**本轮状态**：✅ 可做可验。

### Step 2 包骨架与配置面
**做什么**：`package.json`（bundle + client 声明）、`cordis.patch.yml`、`locale/*`、`icon.svg`、`README`（安装/卸载/旧包迁移/回退）；Host 入口导出、Client 入口空壳。  
**完成标志**：本地 `node --check` 通过；manifest 字段齐全（名称、版本、bundle 行、client 入口）；与 DSH 的 patch 方言一致（Loader 方言见 `cordis-composition-reference`）。  
**本轮状态**：⚠️ 半可做：模板在 `app.asar` 内、本轮不可读，需实施期允许读取模板或按方言手写；手写部分可在本轮完成并语法检查。

### Step 3 状态文件服务（Host）
**做什么**：接 Step 1 的纯函数，实现读/写/校验/watch/`.bak`；错误分类（不存在=默认、格式错=回落、权限错=只读提示）；保存即生效（写成功后才回传成功）。  
**完成标志**：纯函数测试全绿 + 一个用临时目录的集成脚本（在 workspace 里真读写 JSON，不碰 DSH）：写入后立即读回一致、故意写坏后回落、超限拒绝且原文件字节不变、`.bak` 生成。  
**本轮状态**：✅ 集成脚本可做（临时目录）。

### Step 4 提示注入与拦截（Host）
**做什么**：注册末尾 section；监听 `system-prompt/assemble` 实现开头段替换与宿主自述隐藏；开关全关时**不注册任何东西**（保证验收 1）；文件变化后下一次 assemble 生效。  
**完成标志**：  
- 纯函数层面：给「宿主原始 sections 快照」→ 四种开关组合的输出快照，`全关` 与输入逐字节一致；  
- 运行时：装到临时 profile 后，开/关各发一条消息，用 `sessionQuery.readSurface` 读回比对。  
**本轮状态**：⚠️ 纯函数可验；运行时验证需安装授权。

### Step 5 审批三态（Host）
**做什么**：监听 `approval/request`；auto 返回 `allowed-once`、deny 返回 `rejected` 并给本地化理由、ask 调 `next()`；记录最近决定环形缓冲；在 never 档位下不假装生效（界面显示「当前档位不产生审批请求」）。  
**完成标志**：纯函数三态映射测试；临时 profile 里用三个需要审批的动作各验一次（allow 直接过、ask 弹窗、deny 报错且理由可见），并核对审计日志是否仍有记录（R9）。  
**本轮状态**：⚠️ 纯函数可验；运行时需安装授权。

### Step 6 Enhanced 档写入与回滚（Host）
**做什么**：按钮触发 → 读实时全表 → 合并 → 写 `.bak`（`settings.prepareDocument()` 定位真实文件）→ 整表写回（带 revision）→ 返回前后 diff 给页面展示；回滚走最近 `.bak`。  
**完成标志**：纯函数测试（整表保留、defaultPreset 不变、幂等）；临时 profile 里写一次、重启后档位仍在、切到 Enhanced 档后沙箱全开且越界弹审批；模拟并发修改时 revision 冲突被正确拒绝。  
**本轮状态**：⚠️ 纯函数可验；写盘需安装授权。

### Step 7 设置页（Client）
**做什么**：五组表单 + 检查按钮 + 预览 + 告警 + 路径显示；订阅状态文件变化；保存走 Remote。  
**完成标志**：页面在 `http://127.0.0.1:8314` 打开后，五组可读可写、手改文件后页面刷新、错误态（损坏/超限）可见；截图留证。  
**本轮状态**：⛔ 完全做不了（客户端 inspect 离线 + 需安装）。本轮只产出页面结构规格与文案。

### Step 8 检查（读日志验证）
**做什么**：`sessionQuery.readSurface` 取当前会话最新系统消息，比对替换后的开头与追加的末尾；输出「已生效 / 未生效 + 原因」；同时展示审批拦截记录。  
**完成标志**：临时 profile 里开→检查=已生效；关→检查=未生效（并说明开关关闭）；写完人设不发消息直接检查→「未生效（下一条消息后生效）」。  
**本轮状态**：⛔ 运行时做不了；比对逻辑可作为纯函数测（给定 system 文本与状态 → 结论）。

### Step 9 打包、安装、迁移与验收走查
**做什么**：README 迁移说明（旧无 scope 包先卸）；验收 6 条逐条走查表；卸载验证（用户文件仍在、宿主正常）；回退验证。  
**完成标志**：验收对照表 6/6 通过并附证据（日志、截图、读回的 prompt 片段）。  
**本轮状态**：⛔ 待实施期。

---

## 3. 计划依赖的 DSH 能力清单（逐条说明为什么需要）

| # | 能力 | 我用它做什么 | 为什么非要它 | 探测状态 |
|---|---|---|---|---|
| 3.1 | `systemPrompt.section({name, order, text})` | 注册末尾「内容边界」段 | 这是宿主唯一受支持的「往系统提示里加一段」的注册点；自己拼字符串没有入口 | ✅ 已确认 |
| 3.2 | `system-prompt/assemble` 瀑布事件 | 改写开头身份段、隐藏宿主自述 | 不改宿主文件的前提下，唯一能在拼装时改文本的接缝；`personaPrefix/Suffix` 是配置写入，不在允许范围 | ✅ 签名已确认；⚠️ complete section 限制待探针（R1） |
| 3.3 | `approval/request` 瀑布事件 | 三态审批（放行/照常问/回绝） | 唯一「在宿主问用户之前做决定」的接缝；`approval.setPolicy` 只有 ask/never，表达不了 deny | ✅ 目录签名已确认（详情接口报错，类型名已知） |
| 3.4 | `approval.setPolicy` / `overrideOf` | 读取/推断会话当前策略，用于「never 档位下三态不生效」的提示 | 页面要如实告诉用户当前档位下三态有没有用 | ✅ 已确认 |
| 3.5 | `permissionPresets.catalog()` / `resolve()` | 读实时档位全表，写回前做基线 | 宿主配置整块替换，不先读全表就会抹掉内置档（需求明确要求写全） | ✅ 已确认 |
| 3.6 | `settings.describe` / `prepareDocument` / `update`（或 `configEditor.edit`） | 定位 profile patch 真实文件、按 revision 写回 | `.bak` 必须有真实路径；revision 是并发写冲突的唯一护栏 | ✅ 已确认 |
| 3.7 | `fs`（readText / writeText / stat / watch / moveFile） | 状态文件读写、原子保存、手改感知、`.bak` | 「页面与手改文件同一份」必须靠同一个文件 + watch，不能靠双写 | ✅ 已确认 |
| 3.8 | 客户端 Remote 服务（`@Remote` → `ctx.remote.*`） | 设置页读写状态、触发检查与写档 | 浏览器端拿不到文件系统，只能经宿主中转；宿主现有控制器（credentials/workspace/cua）都是这个形态 | ⚠️ 推断，客户端 inspect 离线未核实 |
| 3.9 | Client Slots（设置页槽位 + 注册 API） | 把设置页放进去 | 需求 #6 要求「设置页」；没有槽位就无处挂载 | ⚠️ 未核实（4 次超时） |
| 3.10 | `settings.configure({auto:false})` | 关闭自动生成的插件设置页 | 避免 Config 自动页与自绘页并存的混乱 | ✅ 已确认 |
| 3.11 | `sessionQuery.readSurface` / `readSession` / `listEvents` | 「检查」读回真实系统提示 | 需求 #7 要证据，不是自说自话；这是唯一权威来源 | ✅ 已确认 |
| 3.12 | `system-prompt/change` 事件 / `session/event` | 页面刷新、检查时机（可选） | 减少轮询 | ✅ 已确认存在 |
| 3.13 | `plugin_manager.install_bundle` | 实施期安装 | 唯一受支持的安装方式（不手写 profile 的 package.json/patch） | ✅ 已确认（需批准） |
| 3.14 | locale / 图标 / 主题 token | 界面文案与外观 | 设置页要「讲清代价」，必须有本地化文案 | ⚠️ 模板与 token 未核实（客户端离线） |

明确**不需要**的宿主能力：`tools.register`（不注册工具）、`tools/pre-execute`（不自己判越界）、`webServer` 自定义路由（走 Remote 即可，除非 Remote 不可用）、`credentials`、`storage`（状态用文件，不用宿主存储）。

---

## 4. 每一步怎么自验（做到什么程度算这步完成）

| 步骤 | 自验方式 | 证据形式 | 本轮可做？ |
|---|---|---|---|
| Step 1 纯函数 | Node 断言脚本，覆盖 20+ 用例 | 测试输出全绿 + 用例表 | ✅ |
| Step 2 骨架 | `node --check`、manifest 字段核对、patch 方言对照 | 检查清单 | ⚠️ 部分 |
| Step 3 状态文件 | 临时目录集成脚本：写→读→损伤→回落→超限拒绝→`.bak` | 脚本输出 + 文件前后字节比对 | ✅ |
| Step 4 提示 | 纯函数快照比对（四组合）+ 临时 profile 实测（`readSurface` 截取） | 快照 diff + 日志片段 | ⚠️ 部分 |
| Step 5 审批 | 纯函数映射 + 临时 profile 三动作实测 + 审计日志核对 | 三次操作记录 + 日志 | ⚠️ 部分 |
| Step 6 写档 | 纯函数合并测试 + 临时 profile 写/重启/切档/并发冲突 | 配置前后 diff + `.bak` 文件 + 重启后 catalog | ⚠️ 部分 |
| Step 7 页面 | 打开 `127.0.0.1:8314` 设置页，五组读写、手改刷新、错误态、截图 | 截图 + 页面 DOM 检查 | ⛔ |
| Step 8 检查 | 三种状态（已生效/未生效/切换后未发消息）各验一次 | 页面结果 + `readSurface` 原文 | ⛔ |
| Step 9 验收 | 需求 6 条验收逐条走查 | 对照表 6/6 + 证据链接 | ⛔ |

**验收对照（需求第 22–29 行）**

| 验收 | 由哪步覆盖 | 判定证据 |
|---|---|---|
| 1 全关=宿主原样 | Step 4 快照 + Step 7 页面关光后实测 | 系统提示逐字节 diff 为空 |
| 2 人设+边界下一条生效且可检查 | Step 4 + Step 8 | 替换后开头 / 追加末尾在 `readSurface` 里出现，检查=已生效 |
| 3 allow/ask/deny 各验一次 | Step 5 | 三次动作记录与档位一致 |
| 4 超限不损坏文件 | Step 1 + Step 3 | 拒绝写入后文件哈希不变 |
| 5 写坏状态文件回落且提示 | Step 1 + Step 3 + Step 7 | 回落结果 + 页面横幅 |
| 6 卸载后宿主正常、用户文件在 | Step 9 | 卸载后重启、文件仍在、设置页消失 |

---

## 5. 关键取舍与回退方案

### 5.1 如果 R1 成立（身份段是 complete section，瀑布改不动）
按优先级：
1. **降级**：只做「末尾追加 + 隐藏可隐藏部分」，品牌三态里的「去掉/自定义」明确标灰并说明原因；
2. **请示 C2**：经客户批准后改写 `system-prompt` 宿主配置（`includeHarnessIdentity=false` + `personaPrefix`），同时纳入 `.bak` 与「一键退回」；这会打破「不改宿主文件」，必须客户签字；
3. 不做第三条路（hook 源码、patch 宿主包）——升级即碎。

### 5.2 如果 R11 成立（审批监听器不跨 agent 生效）
退路：在 `agent/created` 时按 agent 注入作用域监听；成本 +1 步，风险是漏掉已存在的会话（需要在页面上说明「新会话生效」）。

### 5.3 如果 Remote/槽位不可用
退路：用 `webServer.register` 挂一个受本机鉴权保护的 `/api/enhance/*` 路由 + 页面 fetch；再不行则降级为「只有状态文件 + 检查工具」，设置页标注不可用。

### 5.4 一键退回
两级：① 状态文件回默认（5 开关全关，文本保留不删，避免误删用户内容）；② 档位回滚（从最近 `.bak` 恢复宿主配置，恢复前再备一份）。两步都在页面二次确认。

---

## 6. 本轮交付边界

- 本文件与 `01-analysis.md` 是**设计交付**，不含可安装的插件代码。
- 未安装、未改配置、未写宿主 profile。
- 待客户拍板 8 条（01 §4）后再进入实施；实施第一步就是 Step 0 探针（需临时 profile 授权）。
