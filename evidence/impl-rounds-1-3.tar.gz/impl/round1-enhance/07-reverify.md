# 07 复审：dsh-enhance round 1 修复（接替 05 验证）

> 复审者立场：只复核**修复本身**，不重写需求理解。未修改 `bundle/`、`05-verification.md`、`06-fix-report.md`；未安装任何插件；未写入 `$DSH_HOME`。
> 独立探针脚本全部在 `%TEMP%\dsh-reverify\`（bundle 之外，可复现：`node %TEMP%\dsh-reverify\probe.mjs`、`probe-preset-strict.mjs`）；对 DSH 安装包的源码核对使用**我自己写的 asar 解析器**独立抽取（`%TEMP%\dsh-reverify\asar\`，不依赖 06 留下的副本）。
> 复审时间：2026-11-08 ~00:45–00:55（Asia/Shanghai）。环境：Windows，Node v24.22.2。文中「L数字」指该文件行号。

---

## 0. 结论摘要

| 项 | 判定 | 一句话依据 |
|---|---|---|
| B1（端到端接线） | **未修（约定内）** | `index.js:114-116` 仍返回 `null`，`check()` 恒 no-data（探针 F2） |
| MAJOR-1（catalog 段名） | **成立** | 与安装源码逐字一致；真实宿主 surface 探针 A1/A2 全部按预期移除/判负 |
| MAJOR-2（检查假成功） | **成立（核心）** | 无证据一律 `ok:null` + verdict 不可为 `effective`（A5/A6）；原始宿主 surface 判 `host-notes-visible`（A2） |
| MAJOR-3（preset description） | **部分成立** | 主缺陷（对象 description）已修且写前闸能拦（B2/B3）；但新增的 name/description 校验**严于宿主契约**，会误拦合法表（MINOR-7） |
| MINOR-1（toolName） | **成立** | 读 `request.toolName`，环记录 `{tool:'bash'}`；宿主事件契约已核对 |
| MINOR-3（degraded 状态） | **部分成立** | 数据层正确（E1/E2/E3）；页面规格（03 §5）与文案未同步，用户可见「提示」仍不存在 |
| MINOR-4（决定环通道） | **成立** | ring 先于控制器声明、首调即 `[]`、status/check 双出口、有界且返回副本；无敏感字段泄漏 |
| MINOR-5（档位策略） | **成立（离线）** | `approvalPolicyOf` 严格 ask/never/undefined（D1）；apply 级真实解析链 Agent→Session→preset（D2/D3）；真实 GUI 取 session 仍未安装验证 |
| MINOR-2 / MINOR-6 | **未修（约定内）** | 未改动，与 06 声明一致 |

**三态统计：成立 5 / 部分成立 2 / 不成立 0**；另有**新增缺陷 2 处（MINOR-7/8）+ 遗留缺口 2 处（MINOR-9/10）**，见 §五。

**独立复跑：`node --test` 153/153 通过；`check-syntax` 40 files / 0 failed（我亲手跑）。**

**放行意见：GO-WITH-CONDITIONS**（理由与条件见 §七）。

**是否同意修复者的自我判断：大体同意。** 他点名的「把假成功换成永远不成功」在代码里成立、方向正确（fail-closed 优于假阳性），且 B1 接线后接口不堵死；但他**没料到自己的修法引入了两个接线陷阱**（MINOR-7 过严校验、MINOR-8 字符串 baseline 被忽略），而这两个陷阱恰好会让 round 2 更容易踩中他自己预言的失败方式。

---

## 一、独立复跑（全部亲手执行，不引用 06 的输出）

### 1.1 测试与语法

```text
> node --test "test/*.test.js"      （工作目录 bundle\）
ℹ tests 153  ℹ pass 153  ℹ fail 0          （EXIT=0）
> node scripts/check-syntax.mjs
40 files checked, 0 failed                 （EXIT=0）
```

`locale/*.json`、`package.json` JSON 解析通过。文件改动范围与 06 §5 清单一致（按 mtime 核对：00:20 之后只动了 06 列出的 17 个文件）。

### 1.2 宿主契约交叉核对（host inspect + 安装源码，双源）

| 契约点 | inspect / 源码结论 | 对修复的意义 |
|---|---|---|
| `approval/request` 事件 | waterfall，`ApprovalRequestEvent.toolName`、`ApprovalOutcome` 枚举 | MINOR-1 修法正确 |
| `permissionPresets` | `current(session): string`、`resolve(name): PresetSpec`、`PresetSpec.approval = 'ask'\|'never'`；`resolve` 未知名抛错；`Agent.id: SessionId` | MINOR-5 修法正确，且 `sessions.get(agent.id)` 成立 |
| `sessions` | `get(id): Session \| undefined` 公开契约 | 同上 |
| `systemPrompt` | `section/context/suppressRuntimeContext`；`PromptSection.complete?: boolean`；**`PromptPresentation.variables` 是 `Record`（对象）不是数组** | MAJOR-1 依据成立；同时暴露遗留风险 R1（§五） |
| `Config`（`@deepseek-ai/dsh-permission-presets`） | 投影 schema：每个 preset **只有 `sandbox`/`approval` 必填**；`name`/`description` 为 `["string","null"]` 且**非必填**；schemastery 源码（`lib/index.mjs:279-288`）证实「未标 `.required()` 的字段可空可缺省」 | **推翻 05/06 的「name/description 必须字符串（required）」前提**，是 MINOR-7 的直接依据 |
| 安装源码（我抽取自 app.asar） | `harness:identity`（order -1000，非 complete，文本=BRAND_SENTENCE）；`dsh-harness-dev-context` 以 `harness:source`/`app:web-surface` 注册 section+context；两段文本与两条 context 值前缀与 catalog 的 marker 逐字吻合；`working-directory:current` 为 `required: true` | MAJOR-1 修法正确 |

另外：本会话自身的系统提示逐行可见上述 marker/名字/品牌句，构成第三重印证。

### 1.3 独立探针（24 项，全部通过；A7/A8 是**设计缺口的观察**，非通过项）

```text
A1  真实宿主 surface：hide 移除 identity + 两条 host-note section + 两条 context，保留 working-directory .. ok
A2  未经变换的原始宿主 surface → host-notes-visible / not-effective（05 原探针回归） .. ok
A3  变换后 + baseline(对象) → evidence=baseline / effective .. ok
A4  变换后 + transformLog → evidence=transform / effective .. ok
A5  无 baseline 无 log → ok:null / no-baseline / not-effective .. ok
A6  baseline 与当前 surface 相同 → ok:null / no-change-evidence / not-effective .. ok
A7  【观察】baseline 以字符串传给 sections 路径 → 被忽略 → no-change-evidence .. （缺口，见 MINOR-8）
A8  【观察】文本路径：identity 仍在、两条 marker 块已消失 + baseline 有 marker → effective .. （缺口，见 MINOR-9）
A9  全关同一引用（新 catalog 下验收 1 不回归） .. ok
A10 hide+custom persona：persona 注入到 identity 原位，品牌句消失 .. ok
B1  enhancedPreset().description 为字符串 .. ok
B2  对象 description / 非字符串 name → invalid-description / invalid-name .. ok
B3  写前闸拦对象 description；正常写入 ok 且 backup 名生成 .. ok
C1  环记录 {tool:'bash', callId}，reason/displayReason 不入环 .. ok
C2  apply() 级：环首调为 []、status/check 双出口、真实监听器驱动后环更新、有界、副本 .. ok
D1  approvalPolicyOf 只答 ask/never/undefined（含 custom/抛错/未知值） .. ok
D2  apply() 级解析链：{id} 对象 / sessionId / currentInitiator 三种入参都到 resolver .. ok
D3  无 session/无 service → 不发明 preset-never .. ok
E1  字段级损坏 → degraded、字段回落、文件字节不变 .. ok
E2  未知 extra 单独存在 → ok；解不开 JSON → corrupt .. ok
E3  controller.status 透传 degraded；degraded 后保存仍可用 .. ok
F1  service 层：无证据快照 → not-effective；带 transformLog/baseline → effective .. ok
F2  当前构建 readSurface=null → check 恒 no-data .. ok
+   preset 过严探针：合法表（无 name/description 的用户 preset）被新校验拒绝 .. （缺口，见 MINOR-7）
```

---

## 二、逐条修复的独立判定

### MAJOR-1：catalog 段名 —— **成立**

- 修法核对：`lib/sections.js:40-57` 的 `identityNames=['harness:identity']`、`hostNoteNames/runtimeContextNames=['harness:source','app:web-surface']`、两条 `hostNoteMarkers`（宿主自述首句）与两条 `runtimeContextMarkers`（context 值前缀）与我独立抽取的安装源码逐字一致；`working-directory:current` 未入名单（源码 `required: true`，探针 A1 证实保留）。
- 行为核对：A1（真实名移除五项、保留 workspace 与 working-directory）、A2（原始 surface 判 `host-notes-visible`）、A9（全关同一引用不回归）、A10（hide+custom persona 注入原位）。
- 硬编码回归检查：`grep` 全 bundle 生产代码，宿主名只出现在 `sections.js` catalog 与注释；transform/check 全部走 catalog（`matchesCatalogEntry`），无第二个名字表。
- 附带修正（`runtimeContextMarkers` 改为 value 前缀而非通用表头）经我核对成立：`working-directory:current` 保留时通用表头仍在，用表头做 marker 会导致「hide 永远判可见」。

### MAJOR-2：检查假成功 —— **成立（核心）**

- 证据链实现核对：`lib/check.js:164-167`（`transformHideEvidence` 只认 `op:'hide-host-notes' && matched:true`）、`:183-191`（baseline 判定，缺省=unknown 绝不等于 absent）、`:214-242`（sections 路径：leftovers 优先 → 证据二选一 → 否则 `ok:null`）、`:131-137`（catalog 失明时 `no-catalog` 拒判）、`:59-76`（`finish()` 把 enabled 且 `ok:null` 计为 unproven，写进 reasons；`effective` 必须 `reasons.length===0 && applicable.length>0`）。
- 行为核对：A2（05 原假成功场景已变为 `not-effective`）、A3/A4（两种证据均能给出 `effective`，且 `detail.evidence` 区分来源）、A5/A6（无证据/无变化两种拒绝）、F1（service 层带证据即恢复 `effective`，不带即 `not-effective`）。
- 新成功码 `host-notes-removed` 不再混用「本来就空」与「删掉了」。
- **残余缺口**（不影响本条判定，列入 §五）：MINOR-8（字符串 baseline 在 sections 路径被忽略）与 MINOR-9（文本路径无法识别 identity 残留）。

### MAJOR-3：preset description —— **部分成立**

- **主缺陷成立已修**：`lib/preset.js:29` description 为字符串；`:63-68` 类型检查；`assertSafeWrite`（`:160-164`）把 `presets.*` issue 映射为 blocker；B2/B3 证明对象 description 在 `validatePresetTable` 与 `preparePresetWrite` 两层都被拦；双语落到 `locale/zh.json` / `en.json` 的 `preset.description`（JSON 合法）。
- **但前提有一处是错的**：05/06 都写「宿主 schema 要求 name/description 为必填 string」。inspect 的 Config 投影显示**只有 sandbox/approval 必填**，`name`/`description` 是 `["string","null"]` 且非必填；schemastery 源码证实未标 `.required()` 的字段可空。对象确实非法（修复正确），但「required」不成立。
- **由此引入新回归 MINOR-7**：新增的 `typeof entry.name !== 'string'` / `typeof entry.description !== 'string'` 校验严于宿主——用户表里合法的「无 name/description」preset 会让 `validatePresetTable` 报 `invalid-name/invalid-description`，`assertSafeWrite` 于是把**整次** Enhanced 写入判为 `invalid-preset`（探针：合法表 merge 后 `preparePresetWrite` 返回 `ok:false`）。本轮写盘未授权所以未爆发；授权后第一次写就可能被自己的闸拦住。修复方向：这两个字段只在「出现且非 null」时要求 string（或仅校验 enhanced 自身）。

### MINOR-1：审批环 toolName —— **成立**

`host/approval-service.js:17-25` 读 `request.toolName` 仍写 `request.tool`；inspect `ApprovalRequestEvent.toolName` 印证；C1 探针记录 `{tool:'bash', callId:'call-1'}`，且 `reason`/`displayReason` 不入环。

### MINOR-3：degraded 状态 —— **部分成立**

- 数据层正确：`host/state-store.js:70` 三态（corrupt/degraded/ok）；E1（字段损坏→degraded、回落、字节不变）、E2（未知 extra 不降级、JSON 坏→corrupt）、E3（controller 透传、保存不受影响）。文件不自动改写的验收 5 语义不变。
- 但「验收 5 的明确提示」仍闭环不了：页面不存在（B1/页面都未实现），03 §5 的横幅触发条件**仍写着 `corrupt`**（`03-implementation.md:115`），只有 06 的文字说页面该用 `corrupt||degraded`——按 03 实现页面的话原缺陷会原样复发。横幅文案 `bannerCorrupt` 可复用，但没有为 degraded 增加任何代码/文案/规格落点。判定：数据层成立，触发链路未落地。

### MINOR-4：决定环通道 —— **成立**

`index.js:43-51`（ring 先声明、getter 闭包读最新）、`:82`（`ctx.enhance.recentApprovals` apply 即存在）、`host/controller.js:34-41/84/133`（status/check 双出口、读失败回 `[]`）；C2 探针验证首调 `[]`、真实监听器驱动后更新、容量 20 有界、`recentDecisions` 返回副本。

**泄漏检查（任务点名的第三项回归）**：环条目仅 `{at, decision, reasonCode, request:{tool, callId}}`——不含工具参数、审批 reason、agent 身份；`callId` 为不透明 id；容量有界；`ctx.enhance` 只在同进程插件上下文可见。**无不该暴露的内容**。顺带观察（既有、非本次引入）：ask 类决定只记 `decision:'ask'`，不记用户最终放行/回绝结果，C8 的「放行/拦截记录」对 ask 场景信息不全。

### MINOR-5：档位策略 —— **成立（离线口径）**

- `approvalPolicyOf`（`host/approval-service.js:41-54`）严格按宿主契约：`current(session)`→`resolve(name)`→只认 `ask|never`，`custom`/抛错/未知/无 service/无 session 一律 `undefined`（D1 全覆盖）。
- 解析链（`index.js:133-166`）：页面传 `{id}` 对象 / sessionId / 无参（走 `agents.currentInitiator()`）三条路都验过（D2）；`Agent.id` 就是 `SessionId`（inspect 印证），`sessions.get(agent.id)` 成立；无参且无 initiator 时不发明 `preset-never`（D3）。
- 保留未验项：真实 GUI 里页面能否拿到 session（页面未实现）、`permissionPresets.current()` 对非 live session 对象的行为——这些都只在安装后可验，失败路径是诚实的 `undefined`，不会误报。

### 未修项核对（约定内）

- **B1**：`host/prompt-service.js` 仍是空壳、`index.js:114-116` 仍返回 `null` → `check()` 恒 no-data（F2）。未修属实，且是当前「检查永远无结果」的第一原因（见 §四.2）。
- **MINOR-2 / MINOR-6**：`host/controller.js:95-118` 仍是「校验全有或全无」、`state-store.js:143-147` 仍是文件名排序。未改动，与 06 声明一致。

---

## 三、「永远不成功」隐患的专项判定（任务第二节）

### 3.1 这个说法在代码里是否成立？——**成立，且实际状态比他说的更早一步**

- 分支位置：hide 开启时，`hostNotesSectionsItem`（`lib/check.js:229-241`）在「无残留」之后要求 transformLog 证据或 baseline 证据；两者皆无 → `ok:null, code:'no-baseline'`（baseline 缺失）或 `'no-change-evidence'`（baseline 与现状相同）；文本路径同理（`:201-211`）。`finish()`（`:59-76`）把 enabled+`ok:null` 计为 unproven 写进 reasons，`effective` 从此不可能拼出。构造输入证明：A5（无证据 → `not-effective` + `hostNotes:no-baseline`）、A6（baseline=现状 → `no-change-evidence`）。
- 但当前构建连这条分支都到不了：`readSurfaceSnapshot` 恒 `null` → `runCheck` 直接 `no-data`（F2）。所以「永远不成功」在现状是「永远 no-data」，B1 接线后才会落到「hide 项永远 `no-baseline`」——修复者的原话低估了一层，方向一致。

### 3.2 算不算把验收 #2 从「假阳性」换成「假阴性」？哪个更糟？——**是；假阳性更糟，但「持续假阴性」同样不可交付**

- 数据层它是诚实的：`ok:null` + 具名 reason，语义是「未证明」，不是「未生效」。
- 呈现层它仍会撒谎，只是方向反了：`finish` 把 unproven 折进 `verdict:'not-effective'`，而 03 §5 的页面只有 已生效/部分生效/未生效/暂无记录 四种文案——用户看到的会是「未生效」，即使 hide 实际生效了。这把「不可见的假成功」换成了「可见但错误的失败报告」。
- 两者权衡：**假阳性更糟**。理由：① 需求 7 明令禁止「糊弄」，假成功正是它的靶子；② 假阳性不可检测、无恢复路径，用户会带着错误认知继续用（隐私/行为预期全错）；③ 假阴性 fail-closed，信号可见（reasons 具名）、可修（补证据即恢复），不会造成错误行为。**但**这只在「临时过渡态」成立——若带着「永远无法证明」交付，验收 #2 的「检查能证实」同样过不去，而且 UI 会变成反向误导。结论：方向正确、口径可接受，**闭环条件必须写进 round 2**（证据接线 + 「未证明」的独立呈现）。

### 3.3 B1 接线后能否自动消解？——**不会自动，但接口没有堵死**

- 不堵死的证据：`host/check-service.js:39-43` 已透传 `snapshot.baseline / snapshot.transformLog`；F1 用假 readSurface 证明带证据的快照能拿到 `effective`。bridge（`system-prompt/assemble` waterfall 的实现方）天然同时持有 pre-transform assembly（baseline）与 `changes`（transformLog），把它按 session/turn 键控后塞进 `readSurfaceSnapshot` 的返回值即可——这是**必须显式完成的 round 2 工作**，不是自动消解。
- 两个可能让它在接线后**仍然失败**的陷阱（本轮新发现，务必先修）：
  1. **MINOR-8**：`baselineHasHostNotes`（`lib/check.js:183-191`）没有处理 `typeof baseline === 'string'`——文档承诺 baseline 可以是文本，但 sections 路径下字符串 baseline 被当成「无 sections 无 text」直接返回 false（A7）。若 round 2 以文本形式传 baseline 而快照带 sections，「永远不成功」会原样持续。
  2. **证据键控**：check 不校验 baseline/log 与当前 surface 的对应关系。若 bridge 用单一模块级变量存「最近一次 changes」，跨 session/turn 的旧证据可以把 `matched:true` 借给另一份 surface。虽然 leftovers 检查会先拦「仍可见」的场景，风险面小，但键控是必须的卫生条件。

---

## 四、回归检查（任务第三节三项）

1. **catalog 改名后有无其他硬编码**：无。生产代码中宿主名只存在于 `sections.js` 的 catalog；transform/check/persona 锚点全部走 catalog 或 `BRAND_SENTENCE` 常量。`grep` 证据见 §二 MAJOR-1。
2. **degraded 与验收 5「回落且提示」的自洽性**：数据层自洽（回落 + degraded + issues 三者一致，且不自动改写文件）；「提示」不闭环——页面未实现、03 规格仍是 corrupt-only、无 degraded 专属文案。MINOR-3 部分成立的根因。
3. **recentApprovals 是否泄漏**：不泄漏。字段最小集（时间/决定/理由码/工具名/callId）、有界、副本返回、不含参数与 reason 文本（详见 §二 MINOR-4）。

---

## 五、新发现与遗留风险清单

> 分级沿用 05：以下均不是 BLOCKER（本轮验收不因它们恶化），但 1/2 必须在 round 2 接线前修。

- **MINOR-7（新回归，MAJOR-3 修复引入）：`validatePresetTable` 对 name/description 过严，与宿主契约不符。**
  证据：inspect Config 投影（仅 sandbox/approval 必填）+ schemastery `lib/index.mjs:279-288`（未 `.required()` 的字段接受 null/缺省）+ 探针（合法表 `preparePresetWrite` 返回 `ok:false`，blockers=`presets.user.name/description`）。影响：授权写盘后，宿主里合法存在的「无标签 preset」会挡住 Enhanced 写入。修法：这两个字段仅在「存在且非 null」时要求 string；同时更正 05/06 的「required」表述。
- **MINOR-8（新缺陷，MAJOR-2 修复引入）：sections 路径忽略字符串 baseline。**
  证据：`lib/check.js:183-191` 无 `typeof baseline === 'string'` 分支；探针 A7（文档允许的字符串 baseline → `no-change-evidence`）。影响：round 2 若按文档以文本传 baseline 而 snapshot 带 sections，hide 永远无法被证明。修法：`baselineItems` 前先处理字符串（视作 `text`）。
- **MINOR-9（MAJOR-2 的残余假成功面）：文本路径无法识别 identity 残留。**
  证据：`hostNotesTextItem`（`lib/check.js:193-212`）只查 marker；探针 A8——当前文本仍以品牌句开头、两条 marker 块已消失、baseline 含 marker → `host-notes-removed / effective`。影响：文本-only 快照下，局部变换（host-note 块被删、identity 段留下）仍会被判「已生效」。当前 catalog 下 transform 会连 identity 一起删，所以正常链路不触发；触发条件是「未来宿主改名导致 identity 匹配失败」或第三方删块。修法：hide 开启时文本路径追加品牌句校验，或 round 2 强制走 sections 路径。
- **MINOR-10（MINOR-3 的落地缺口）**：03 §5 页面规格仍挂 `corrupt`，无 degraded 文案/触发条件落点；06 的口头要求未写进任何代码或规格。round 2 写页面时必须以 06/07 为准。
- **R1（遗留，非本次引入）：`transformPresentation` 会把宿主的 `variables` 对象变成 `[]`。**
  `lib/sections.js:217` `variables: asArray(pres.variables)`，而宿主 `PromptPresentation.variables` 是 `Record<string,string|undefined>`（inspect + 源码 `assemble` L362-364/L399）。任何开关开启时走 transform，变量全丢——round 2 接线 waterfall 时会导致 `{{var}}` 插值失败。06 未列此项；建议接线前改 `variables: pres.variables ?? {}` 并补类型。
- **R2（遗留，round 2 设计注意）**：`effects.suppressRuntimeContext`（`sections.js:215`）只要 hide 开启即为 true，且宿主 `suppressRuntimeContext()` 抑制的是**全部**非 required context，范围大于 C2 的两条；transform 本身已按 catalog 精确移除两条，round 2 应二选一（精确移除 或 全局抑制），不要叠加后误伤其他插件的 context。
- **R3（遗留，轻微）**：`hostNoteMarkers` 只匹配当前版本文案；session 恢复 legacy 段落（`dsh-harness-dev-context` 的 `LEGACY_SOURCE`）时 marker 不命中，但 section 名不变，sections 路径仍能删；文本路径会漏看 legacy 残留（与 MINOR-9 同根）。

---

## 六、验收对照的更新（相对 05）

| # | 05 判定 | 本轮后 |
|---|---|---|
| 1 | VERIFIED（离线） | 维持；A9 证明新 catalog 下全关仍同一引用、无注册路径 |
| 2 | GAP（B1） | **维持 GAP**；且新增「接线后必须补证据链（§三.3）」与 MINOR-8/9 两个前置条件 |
| 3 | UNVERIFIABLE（决策层已验） | 维持；MINOR-1/5 的数据通路已修好，真实弹窗仍需安装后验 |
| 4 | VERIFIED（离线） | 维持（本轮未触碰保存链路） |
| 5 | VERIFIED（服务层） | 服务层更完整（degraded），用户可见「提示」仍未闭环（MINOR-10） |
| 6 | UNVERIFIABLE | 维持（本轮未触碰卸载/写盘边界） |

---

## 七、放行意见

**GO-WITH-CONDITIONS。**
一句话理由：三条 MAJOR 的代码修复本身经独立复核成立（153/153 自跑 + 24 项独立探针 + inspect/安装源码双源核对），无 BLOCKER 级新缺陷；但 B1 仍未接线（「检查」当前恒 no-data），且修复引入了两处 round 2 极易踩中的陷阱（MINOR-7/8），不能按「功能可用」口径直接放行。

进入交付阶段（round 2）的附带条件：
1. 修 **MINOR-7**：`validatePresetTable` 按 host 契约（sandbox/approval 必填；name/description 仅在出现且非 null 时须为 string），并更正 05/06 的「required」表述；
2. 修 **MINOR-8**：`baselineHasHostNotes` 支持字符串 baseline（或规定 baseline 只能是对象并同步文档）；
3. B1 接线时：baseline/transformLog **按 session/turn 键控**放进 `SessionSurfaceSnapshot`；hide 的文本路径补 identity 校验或强制 sections 路径（MINOR-9）；页面为「未证明（no-baseline / no-change-evidence）」提供独立于「未生效」的文案（MINOR-10）；
4. 交付说明必须声明 03 §5（页面规格）、03 §2-9/§7（catalog/preset 描述）、04（138 用例数）均已过期，以 06/07 为准；
5. 接线 waterfall 前处理 R1（variables 对象被丢弃），并对 R2（全局 suppress 与精确移除二选一）做出明确决策。

---

## 八、本复审的局限（如实声明）

1. 未安装：验收 1/2/3/6 的运行时部分仍悬置；MINOR-5 的真实 GUI session 可用性未验。
2. 客户端 inspect 本轮未尝试（任务未要求；05 已记录 5 次超时）。
3. 宿主源码来自我对 app.asar 的独立只读解析（header pickle 解析 + JSON 目录），未做源码 checkout 级审计；结论以 inspect 契约 + 安装源码双源为准。
4. 探针脚本留在 `%TEMP%\dsh-reverify\`（bundle 之外），文中输出均来自当次真实运行。
