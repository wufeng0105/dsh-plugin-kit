# 08 交付说明：dsh-enhance round 1（`@local/dsh-enhance@0.1.0`）

> 上游结论：`07-reverify.md` 给出 **GO-WITH-CONDITIONS**（三条 MAJOR 修复成立；B1 端到端接线未做；新增 MINOR-7/8，遗留 MINOR-9/10、R1/R2/R3）。
> 本文只做交付：**真实打包、逐项核对、安装说明书、验收走查、已知问题、交付判定**。**未改 `bundle/` 任何源码**（唯一新增文件是打包产物 `bundle/local-dsh-enhance-0.1.0.tgz`）；**未安装进运行中的 DSH**；**未写 `$DSH_HOME`**（只读打开过 `~/.dsh/enhance/` 与 `app.asar`）。
> 环境：Windows，Node **v24.22.2**，npm **11.19.1**，宿主 DSH **0.2.2-rc.1**（取自 `app.asar` 内 `@deepseek-ai/dsh-base` 的依赖版本）。时间：2026-11-08 01:00–01:15（Asia/Shanghai）。

---

## 一、打包与清单核对（真实执行）

### 1.1 实际跑过的命令

```powershell
cd bundle
npm pack --json                                     # 真实出包
tar -tzf local-dsh-enhance-0.1.0.tgz                # 包内条目表
tar -xzf local-dsh-enhance-0.1.0.tgz -C %TEMP%\dsh-deliver\pkg
node %TEMP%\dsh-deliver\verify-pack.mjs             # 指针/解析/冒烟（对解包副本）
node %TEMP%\dsh-deliver\probe-delivery.mjs          # 旧状态文件迁移 + 审批三态（对解包副本）
node %TEMP%\dsh-deliver\probe-delivery2.mjs         # MINOR-7/8、R1/R2（对解包副本）
node %TEMP%\dsh-deliver\check-files.mjs             # files 白名单展开 vs tar 条目
# 另在临时目录真实 npm install 该 tgz，验证包本身可安装
```

所有探针只写 `%TEMP%\dsh-deliver\**`；`~/.dsh/enhance` 只被**复制读取**，未写入。

### 1.2 产物

| 项 | 值 |
|---|---|
| 包名 / 版本 | `@local/dsh-enhance` / `0.1.0` |
| 文件名 | `local-dsh-enhance-0.1.0.tgz`（留在 `bundle/` 下） |
| 压缩后 / 解压后 | 30,215 B / 97,440 B |
| 文件数 | **27**（`npm notice total files: 27`） |
| shasum (sha1) | `cf45966260f6a69f3dc510a5a36ad2a27f6ae90a` |
| integrity | `sha512-ASk7e1LWzCZHkeoiWAT80Da703tj4uuwqpYEQiOSMjAjoCi9kGkvRDGh0qsgZnQNk0YAvKqany3JCH7ZxaQFJg==` |
| npm 警告 | 无（`npm pack --dry-run` 全量输出只有 notice，无 warn） |

### 1.3 文件表（27 项，与 tar 条目逐字一致）

| # | 路径 | 大小 | `files` 来源 |
|---|---|---|---|
| 1 | `index.js` | 7.0 kB | 显式 |
| 2 | `client.js` | 1.0 kB | 显式 |
| 3 | `cordis.patch.yml` | 65 B | 显式 |
| 4 | `icon.svg` | 755 B | 显式 |
| 5 | `README.md` | 3.3 kB | 显式 |
| 6–7 | `locale/en.json`、`locale/zh.json` | 3.0 / 2.8 kB | `locale/*.json` |
| 8–18 | `lib/approval.js`、`backup.js`、`boolean.js`、`bytes.js`、`check.js`、`constants.js`、`identity.js`、`preset.js`、`sections.js`、`state.js`、`text.js` | 0.7–14.5 kB | `lib/*.js` |
| 19–26 | `host/approval-service.js`、`atomic-file.js`、`check-service.js`、`controller.js`、`paths.js`、`preset-service.js`、`prompt-service.js`、`state-store.js` | 1.6–5.8 kB | `host/*.js` |
| 27 | `package.json` | 803 B | npm 强制包含 |

### 1.4 `files` 与包内实际文件：**完全一致，0 多 0 少**

- 白名单展开 = 显式 5 + `locale/*.json` 2 + `lib/*.js` 11 + `host/*.js` 8 = **26**；加 npm 强制包含的 `package.json` = **27**；tar 条目 **27**。
- 三个方向都做了差集，全为空：
  - 打进包但不在 `files` 里的：**无**（`packed but NOT matched by files` → none）；
  - `files` 里有但包里没有的：**无**（`whitelist entries missing from tarball` → none）；
  - 工作区有、包里没有的：**19 个，全部是开发件**——`test/` 下 18 个 `*.test.js` 与 `scripts/check-syntax.mjs`。它们不在白名单里，属**有意排除**，不是打包缺陷。副作用一条：装好的包里跑 `npm test` 会找不到测试文件（`package.json` 的 `scripts.test`/`scripts.check` 指向未打包路径），对本插件运行无影响。
- 目录里的 `local-dsh-enhance-0.1.0.tgz` 本身没有被再次打包（白名单不含 `*.tgz`）。

### 1.5 清单指针核对（逐项，全部指向真实文件）

| 字段 | 值 | 文件存在 | 判定 |
|---|---|---|---|
| `exports["."]` | `./index.js` | 是 | ✔ 且用 `import()` 真实解析成功 |
| `exports["./client"]` | `./client.js` | 是 | ✔ 且真实 `__ModuleLoader__` 握手成功 |
| `exports["./locale/*.json"]` | `./locale/*.json` | 是（en/zh 两枚都在） | ✔ |
| `exports["./icon"]` | `./icon.svg` | 是 | ✔（755 B，SVG 根元素正常） |
| `dsh.bundle.patch` | `./cordis.patch.yml` | 是 | ✔ 用**宿主自带的 js-yaml** 解析通过，行 `{id: dsh-enhance, name: @local/dsh-enhance}` 与 `package.json.name` 逐字一致 |
| `dsh.client` | `{platform:"web", immediately:true}` | — | ✔ 该块**不含路径字段**，客户端入口由 `exports["./client"]` 决定；与在装包 `dsh-draft-studio`、`@wufeng0105/dsh-teammate-model-picker` 完全同形 |
| `main` | **字段缺失** | — | 非缺陷：`exports["."]` 已覆盖入口，且 `dsh-draft-studio` / `@wufeng0105/dsh-teammate-model-picker` 同样没有 `main` 且正常工作 |

`private: true` ⇒ 这个包**不能发布到 registry**，只能按路径/tgz 安装——与本交付方式一致，不是缺陷。

### 1.6 locale / icon

- `locale/zh.json`、`locale/en.json` 均为合法 JSON（`JSON.parse` 通过），键覆盖 `meta / state / switches / persona / boundary / approval / hideHostNotes / preset / check / actions` 十组，与需求 1–7 的界面文案一一对应。
- **缺两个键**：`state.statusDegraded`（MINOR-3 的 degraded 横幅没有专属文案）与 `check.unproven`（07 §3.2 要求「未证明」独立于「未生效」呈现）。当前没有页面消费这些文案，属**预留缺口**；round 2 写页面时必须补。
- 图标：`icon.svg` 在包里、可经 `exports["./icon"]` 引用。`@deepseek-ai/dsh-package-manifest` 的 README 明确 `PluginLocalizedMeta` 的图标来源是「包根的 `package.json.icon` **或**导出的 `<specifier>/icon`」，因此**合规**。但 `package.json` 没有顶层 `"icon"` 字段，而在装样例（`dsh-draft-studio`、`@wufeng0105/dsh-teammate-model-picker`）都写了——建议 round 2 补一行，非阻塞。

### 1.7 版本号与 `engines` 策略

- 版本 `0.1.0`。
- **`engines` 字段整体缺失**（既无 `dsh` 也无 `node`）→ 与需求「兼容立场：不声明宿主版本要求；升级后靠体检确认存活」**一致**。
- 附带证据：两份宿主文档对 `engines.dsh` 是否被强制执行**说法相反**——`@deepseek-ai/dsh-package-manifest` README 说「installers and loaders 目前不强制 `dsh.manifestVersion` 或 `engines.dsh`」，`@deepseek-ai/dsh-plugin-manager` README 却说「未满足的 DSH 版本要求会在 pnpm 运行前使操作失败」。**我们什么都不声明，两种实现下都不会被拦**——这正是需求要的稳健性。
- 对照：在装的旧包 `@wufeng0105/dsh-enhance@1.3.4` 声明 `engines.dsh: ">=0.2.1-rc.1 <0.2.2-rc.2"`（当前宿主 `0.2.2-rc.1` 恰好卡在区间内）；新包不再背这类窄区间。

### 1.8 包内冒烟（全部对**解包后的 tgz 副本**执行，不碰源码目录）

| # | 检查 | 结果 |
|---|---|---|
| S1 | `import()` 包入口 | ✔ `inject = ["systemPrompt","sessionQuery"]`；两个服务在本机安装源码中均存在（`systemPrompt` 由 `dsh-system-prompt` 注册，`sessionQuery` 由 `dsh-session-query` 注册、随 `dsh-base` 内置），**不会因缺服务而静默不加载** |
| S2 | `apply()` 挂到 stub ctx（状态目录指到 `%TEMP%`） | ✔ 注册 1 个 `approval/request` 监听；`ctx.enhance.controller` 存在 |
| S3 | `status()`（空状态目录） | ✔ `{ok:true, status:"missing", presetWrite:"unauthorized", recentApprovals:[]}` |
| S4 | `check()` | ✔ `verdict:"no-data"`，`reasons:["no-system-surface"]` —— **B1 未接线的直接可见后果** |
| S5 | `writePreset()` / `rollbackPreset()` | ✔ 都返回 `{ok:false, code:"unauthorized"}`，不碰任何文件 |
| S6 | `apply()` 是否写盘 | ✔ 连状态目录都没创建（`missing` 是「没文件」不是「空文件」） |
| S7 | `client.js` | ✔ 经 `window.__ModuleLoader__.load` 注册 `id:"@local/dsh-enhance"`，`inject: []`、`apply()` 为空 |
| S8 | 真实 `npm install <tgz>`（临时目录） | ✔ `added 1 package`，落盘 27 个文件（26 + `package.json`），随后 `import` 正常 |

### 1.9 打包层缺陷（只记录，未改代码）

| 编号 | 现象 | 影响 |
|---|---|---|
| P1 | `README.md` 正文写「See `../03-implementation.md`」 | 装好的包里没有父目录，链接必然 404；用户读不到「本构建为什么是空壳」 |
| P2 | `README.md` 的「Install」段只说 `plugin_manager install_bundle target=<folder>`，没提 tgz、没提重启判定、没提与旧包共用 `~/.dsh/enhance` 的后果 | 用户按 README 装完会以为插件坏了（详见 §二、§四 D-1） |
| P3 | `package.json` 无 `license` 字段 | npm pack 不报错；对外分发建议补 |
| P4 | `scripts.test` / `scripts.check` 指向未打包的 `test/`、`scripts/` | 装好的包里 `npm test` 不可用；无运行时影响 |
| P5 | `dsh.client` 无 `inject` 字段 | 两个在装样例分别写 `[...]` 与 `[]`；建议 round 2 显式写 `[]`，避免宿主对 `undefined` 的解释差异 |

---

## 二、安装说明书（给用户看的）

> **这一版装上去，系统提示一个字都不会变，也没有任何设置页。** 这不是装错了——是本轮的约定范围（B1 接线与设置页留到 round 2）。下面每一步都写清「你会看到什么」，避免把「没变化」误判成「装失败」。

### 2.0 前置

| 项 | 要求 |
|---|---|
| 宿主 | 本机 DeepSeek Harness 桌面版（本文核对的是 **0.2.2-rc.1**）；插件不声明宿主版本，升级后靠下面的「生效判定」体检 |
| 网络 | **不需要**（包是本地 tgz，无第三方依赖，无构建脚本） |
| Node/pnpm | 不需要手动操作；安装由宿主自带的 pnpm 完成 |
| 权限 | `plugin_manager` 的安装动作要求 `danger-full-access` 或单次批准 |
| **必读** | 如果你的机器上装过旧版 `@wufeng0105/dsh-enhance`，**先做 §2.6 的迁移**，否则新包装上就是 degraded 且**永远无法保存/重置**（已实测，见 §四 D-1） |

### 2.1 安装（推荐：用 tgz，不要让 profile 依赖你的源码目录）

包里就一个文件：`local-dsh-enhance-0.1.0.tgz`（与本说明同在 `bundle/`）。把它拷到一个**不会被移动/清理**的固定目录，例如 `D:\dsh-pkgs\`，然后：

```
plugin_manager install_bundle target=D:\dsh-pkgs\local-dsh-enhance-0.1.0.tgz
```

- GUI 等价路径：侧边栏 **插件**页 → 安装本地组合包 → 选择该 tgz。
- `target` **必须是绝对路径**；相对路径会按 profile 目录解析，容易指错。
- 备选（开发用）：`target=<bundle 目录绝对路径>`。这条路 pnpm 会以 `link:` 方式依赖源目录——**目录一旦移动/改名/删除，插件就坏**，且需要重新安装。交付场景**不要**用这条。

装完应看到：插件页/`list_bundles` 里出现 **`@local/dsh-enhance` 0.1.0**，行 id 为 `dsh-enhance`，且 `patch` 状态为 `applied`（或被判定为需要重启，见下）。

### 2.2 重启要求

- 看回来结果里的 `application` / `nextStep`：
  - `applied` → **不用重启**，已生效。
  - `restart-required`（宿主未开 HMR 时的常态）→ **完全退出 DSH 再启动**。刷新浏览器页面**不算**重启，插件是 Host 侧加载的。
- 若安装被拒（`already-installed` / `invalid-spec` / `not-a-bundle` / `network`），按提示处理，**不要**用复制文件到 profile 的方式绕过。

### 2.3 生效判定（三步，缺一不可）

1. **装配判定**：插件页出现 `@local/dsh-enhance` 且 `applied`（重启后复查一次）。
2. **加载判定**：宿主日志/插件详情里**没有** `import` 或 `apply` 报错；有报错说明装配了但没跑起来。
3. **行为判定（本构建的诚实结论）**：**系统提示与装之前逐字一致**，包括开头那句 `You are an AI agent powered by DeepSeek Harness.`；并且**没有任何设置页、没有「检查」按钮**。这两条「什么都没变」正是本构建的正确表现。

**这一版明确不会发生的事**（别等，等不到）：

- 不会出现设置页、五个开关、品牌人设三态、内容边界输入框。
- 不会因为你在 `~/.dsh/enhance/` 里放文本就改变系统提示（提示词桥是空壳）。
- 「检查」永远返回「暂无记录（no-data）」——`check()` 的 `reasons` 是 `["no-system-surface"]`。
- 「写入 Enhanced 档 / 从备份回滚档位」永远返回 `unauthorized`，**不写宿主配置**。

**这一版会真实发生的一件事（务必知道）**：如果你手工把 `state.json` 写成合法 v1 且 `masterSwitch:true`、`approvalOverride:true`、`approvalMode:"allow"`，**越界审批会真的被自动放行**（本构建对 `approval/request` 的监听是接线的，实测返回 `allowed-once`）；`"deny"` 则会直接回绝（`rejected`）。而**页面上那条红字风险提示在本构建不存在**——没有界面告诉你在发生什么。

### 2.4 必须由用户在场手工验的验收项（离线证不了）

| 验收项 | 为什么必须你来做 | 怎么做（在场） |
|---|---|---|
| **验收 1**（全关=宿主原样） | 要读真实会话里的系统提示 | 装前记一次、装后新开一个会话再读一次，逐字比对；见 §三 第 1 行的具体步骤 |
| **验收 3**（allow/ask/deny 三态） | 需要真实审批弹窗/真实越界动作 | 按 §三 第 3 行写三个 state.json，各触发一次越界动作 |
| **验收 6**（卸载后宿主正常、文件仍在） | 只有装了才能卸 | 按 §三 第 6 行：卸 → 重启 → 看宿主可用 + 看 `~/.dsh/enhance` 文件与 mtime |
| **§2.2 的重启判定** | `applied` / `restart-required` 只在本机出现 | 看安装返回与插件页状态 |

不需要你在场、已离线证的：验收 4（超限不损坏）、验收 5 的**回落**部分、`files`/指针/打包。

### 2.5 卸载

```
plugin_manager remove_bundle target=@local/dsh-enhance
```

- GUI：插件页 → 该组合包 → 移除；需要时再重启一次。
- **状态目录不删**：`~/.dsh/enhance/{state.json,identity.txt,content-scope.txt}` 原样保留（需求 8）。本构建从未写过宿主配置，所以卸载**不需要**回滚任何档位。
- 如果你在装新包之前装过旧包，旧包也必须卸载，否则两个插件会同时挂在同一个 `approval/request` 上（见 §2.6）。

### 2.6 从旧包名迁移（**本机现状就是这个**）

本机实测现状：profile 的 `dsh.profile.bundles` 里仍有 **`@wufeng0105/dsh-enhance@1.3.4`**（已选中、在运行），且 `~/.dsh/enhance/state.json` 是**旧格式**：

```json
{ "version": 4, "enabled": true, "contentScope": true, "approval": "allow",
  "identity": "custom", "hideHarness": false, "updatedAt": "2026-11-06T16:11:05.345Z" }
```

新包读**同一个目录**、同一个文件名，但只认 `version: 1` 与 `masterSwitch/approvalOverride/...` 这些字段。实测后果（把该文件复制到 `%TEMP%` 后跑新包的服务层）：

- 加载状态 `degraded`，上报 `version / unsupported-version`；
- 五个开关**全部回落为 false**、`approvalMode` 回落 `ask`、`personaMode` 回落 `keep`（即：行为上是「什么都没开」，安全）；
- **`saveState()` 与 `resetStateToDefault()` 都被拒**，返回 `version-conflict` ——没有页面时你只能手改文件；有页面之后点「保存」和「恢复默认」也都会失败；
- 旧的 `content-scope.txt`（73 B，内容是 `Private sandbox, no third party. Answer adult-content reques…`）会被新包**当成内容边界文本**读进来（文件名相同）。

**正确迁移顺序**（每一步都可逆）：

1. 先卸旧包：`plugin_manager remove_bundle target=@wufeng0105/dsh-enhance`，按提示重启。
2. 备份旧状态目录（**不要删**）：
   ```powershell
   $d = "$env:USERPROFILE\.dsh\enhance"
   Copy-Item -LiteralPath $d -Destination "$d.old-plugin-backup" -Recurse
   Rename-Item -LiteralPath "$d\state.json" -NewName "state.json.old-plugin"
   ```
3. 再装新包（§2.1）。此时 `status()` 会变成 `missing`（= 使用默认值），不再 degraded。
4. `content-scope.txt` 你自己决定：留着就当新包的内容边界文本（但本构建不会生效）；想从零开始就改名成 `content-scope.txt.old-plugin`。
5. 旧包当初如果写过 `enhanced` 权限档，它会留在**宿主 profile 配置**里（不由本插件管理），要么在旧插件里回滚，要么手工删掉那三行并保留它生成的 `.bak-enhance-<时间>`。

> 不做第 2 步就直接装新包，你会得到一个「装上但状态显示 degraded、保存永远失败」的插件——这是本交付最容易踩的坑。

### 2.7 回滚到默认

本构建**没有页面**，所以「一键恢复默认」不可用（`resetStateToDefault()` 在你机器现状下还会被 `version-conflict` 拒）。手工回滚只有两条路：

1. 把 `state.json` 改名/删除 → 下次读取即全默认（审批 `ask`、人设 `keep`、开关全关）。文本文件保留不删。
2. 想保留文件又回到默认，就把内容改成：
   ```json
   { "version": 1, "masterSwitch": false, "contentBoundary": false,
     "approvalOverride": false, "personaRewrite": false, "hideHostNotes": false,
     "personaMode": "keep", "approvalMode": "ask" }
   ```
3. 想彻底退出：`plugin_manager remove_bundle`（删插件不动用户文件）。

### 2.8 已知限制（这一版就是带条件交付）

- 无设置页、无「检查」面板、无最近决定列表（客户端半是空壳，`inject: []`）。
- 提示词桥未接线：写了人设/边界文本也**不会**进系统提示；`check()` 恒 `no-data`。
- Enhanced 权限档的写/回滚未授权：按钮路径不存在，服务层返回 `unauthorized`。
- 状态文件字段级损坏**有回落**但**没有提示**（degraded 横幅只存在于规格里，MINOR-10）。
- 手工把审批设成「一律放行」时**没有风险提示**（页面才有的红字文案）。
- 备份文件不会自动清理（`pruneBackups` 是纯函数，未接线）；`listBackups` 按文件名排序，同一秒内可能顺序反（MINOR-6）。
- 一次保存里两段文本不是事务：人设写成功、边界写失败会留下半笔（MINOR-2）。超限文本在写盘前就被拒，**不会**损坏任何文件（验收 4 已证）。

---

## 三、验收走查表（6 条，逐条）

状态口径：**已离线证** = 有可复跑的离线证据；**需运行时验** = 只有装上并在场才能判；**已知不满足** = 这一版做不到。

| # | 验收标准 | 当前状态 | 谁来做 | 怎么做 | 预期看到什么 |
|---|---|---|---|---|---|
| 1 | 全部开关关闭时，系统提示与宿主原样一致 | **结构性已离线证 + 需运行时复核**。本构建根本不注册任何 section、不改提示词（`planRegistrations` 不给注册、`apply()` 只挂审批监听），所以「全关=没装」；纯函数层另有 A9 证明全关返回同一引用 | 交付负责人（已证）＋ 用户（运行时候） | ① 装前新开一个会话，读回它的系统提示首段与末尾 100 字，存成 `before.txt`；② 装包 + 重启；③ 再新开会话，同法取 `after.txt`；④ `Compare-Object` / `fc` 比对。会话日志在 `%USERPROFILE%\.dsh\sessions`（JSONL，具体文件按最新 mtime） | 两份**逐字节相同**，开头仍是 `You are an AI agent powered by DeepSeek Harness.`，末尾没有新增段落 |
| 2 | 人设+边界写好后，下一条消息的系统提示首句已替换、末尾已追加，且「检查」能证实 | **已知不满足**（B1 未接线）。`check()` 实测 `verdict:"no-data"`、`reasons:["no-system-surface"]`；`index.js:114-116` 仍 `return null` | round 2 开发者（修复）＋ 用户（复验） | 现在无法验：写了文本也不会进提示词，「检查」恒暂无记录。round 2 接线后才按原设计验 | 现状：系统提示完全不变、检查面板不存在。**这一条是本版不可交付的唯一硬缺口** |
| 3 | allow / ask / deny 三档行为各验一次，与档位一致 | **服务层已离线证 + 需运行时验（弹窗路径）**。实测：默认（无状态文件）→ 放行路径调用 `next()`（`nextCalls=1`）；手写 v1 `approvalMode:"allow"` → `allowed-once`、`nextCalls=0`；`"deny"` → `rejected`、`nextCalls=0` | 用户（必须，要真实越界动作） | ① 在 `~/.dsh/enhance/state.json` 写合法 v1（见 §2.7 第 2 条）并把 `approvalMode` 依次改成 `allow` / `ask` / `deny`（每改一次不用重启，监听每次请求现读文件）；② 每档触发一次会越界的动作（例如让 agent 在 `danger-full-access` 之外执行一条外部命令 / 写系统目录）；③ 记录：有没有弹确认、动作有没有执行 | `allow`：**不弹**、直接执行；`ask`：弹确认，选拒绝则动作不执行；`deny`：**不弹**、动作被回绝。注意：若当前权限档本身是「从不询问」档（`preset-never`），宿主根本不发审批请求，三档都不会有反应——这不是 bug |
| 4 | 写入超限文本不损坏任何文件 | **已离线证** | 交付负责人（已证） | 复核：`node --test "test/*.test.js"`（153/153，含超限/原子写/备份失败不写主文件）+ 本轮对 tgz 解包副本的实测：9000 B 边界文本 → `too-long`，`state.json` 字节未变、未生成 `content-scope.txt` | 返回超限错误；旧文件字节完全不变；不产生半截文件 |
| 5 | 故意写坏状态文件 → 行为回落且**明确提示**，而不是按损坏值执行 | **部分满足**：回落**已离线证**；「明确提示」**已知不满足**（无页面/横幅，MINOR-10） | 交付负责人（回落已证）＋ 用户（只能验回落）＋ round 2（补提示） | ① 把 `state.json` 写成 `{ this is not json`；② 触发一次越界动作；③ 观察是「弹确认」还是「被自动放行/回绝」 | 回落正确：加载状态 `corrupt`，`approvalMode` 回到 `ask`、`personaMode` 回到 `keep`，越界动作**弹确认**（不是按损坏值执行）。同时：**你看不到任何提示横幅**——这是已知缺口。另注：对「字段级损坏」文件，现状 `status` 是 `degraded`（不是 `corrupt`），保存时会先留 `.bak` 再改写；对「JSON 解不开」的文件，现状 `status` 是 `corrupt`，保存同样会先留 `.bak` |
| 6 | 卸载后宿主正常、用户文件仍在 | **需运行时验**（结构上安全） | 用户 | ① 记下 `~/.dsh/enhance` 下所有文件的 mtime/大小；② `plugin_manager remove_bundle target=@local/dsh-enhance`；③ 按提示重启；④ 看宿主正常开会话、插件页不再有该组合包；⑤ 复查状态目录 | 宿主一切正常（系统提示回到宿主原样）；`state.json`/`identity.txt`/`content-scope.txt` **仍在、内容与 mtime 未变**；没有残留的 `config-*.bak`（本构建从不写宿主配置） |

**状态分布**：已离线证 1 条（#4）、结构性已证 + 需运行时复核 1 条（#1）、服务层已证 + 需运行时验 1 条（#3）、回落已证但提示不满足 1 条（#5）、需运行时验 1 条（#6）、**已知不满足 1 条（#2）**。

---

## 四、已知问题清单

### 4.1 `07-reverify.md` 的 5 条放行条件 + 新缺陷 + 遗留风险

| 编号 | 影响 | 触发条件 | 规避方式（本版） | 何时修 |
|---|---|---|---|---|
| **条件 1 / MINOR-7**（preset 校验过严） | 宿主里存在「没有 name/description 的合法档」时，Enhanced 写入被自己的复核闸判 `invalid-preset`，整次写盘被拒 | 宿主权限表里有任一 preset 缺 `name`/`description`（宿主 schema 里这两项本就非必填）。本轮对 tgz 解包副本实测：合法表 → `ok:false`，4 条 blocker（`presets.default.name/description`、`presets.preset-never.name/description`） | 本构建 `writePreset` 恒 `unauthorized`，**触发不到**；别手工去写宿主配置 | **round 2 接线前必修**：这两个字段只在「出现且非 null」时要求 string |
| **条件 2 / MINOR-8**（字符串 baseline 被忽略） | 若接线时按文档以**字符串**传 baseline 而快照带 sections，hide 项永远 `no-change-evidence`，「检查」永远证不成功（把假成功换成永久假阴性） | 接线实现选择字符串 baseline。实测：对象 baseline → `host-notes-removed/baseline`；字符串 baseline → `ok:null, no-change-evidence`；transformLog → `host-notes-removed/transform` | 接线时**只传对象 baseline 或 transformLog**（两者实测都通） | **round 2 接线前必修**（或明确文档化「baseline 只能是对象」） |
| **条件 3 / B1 接线 + MINOR-9 + 证据键控** | 不接线，「检查」恒 `no-data`（验收 2 不过）；接歪了会变成「永远无法证明」；旧证据跨 session 借给另一份 surface 会误判 | 现状即触发第一条（实测 `no-data`）。后两条在接线后才可能触发 | 本版按「无效果」使用；不承诺验收 2 | round 2：baseline/transformLog 按 **session/turn 键控**；文本路径补 identity 校验或强制走 sections 路径 |
| **条件 4 / 文档过期** | 03 §5（页面规格只挂 `corrupt`）、03 §2-9（preset.description 双语对象）、03 §7-1（catalog 名字待定）、04（138 用例数）都已过期；照 03 写页面会让 degraded 横幅漏触发（MINOR-10 复发） | 任何人按 03/04 实现 | **以 06/07/08 为准**；本文件 §三/§四 已标注 | round 2 开工时先改 03 或直接作废 |
| **条件 5 / R1 + R2** | R1：`transformPresentation` 把宿主 `variables`（对象）变成 `[]`，接线后 `{{var}}` 插值全废（实测 `[]`）。R2：hide 开启即 `suppressRuntimeContext: true`，抑制范围大于 catalog 里那两条，会误伤别的插件 context（实测 true，且 sections 已被精确裁到只剩 `working-directory:current`） | 任一开关打开走 transform | 本版不走 transform，触发不到 | **接线前必修 R1**；R2 在「精确移除」与「全局抑制」中**二选一**，不要叠加 |
| **MINOR-9** | 文本-only 快照下，局部变换（宿主自述块被删、identity 段留下）仍判「已生效」 | 未来宿主改名导致 identity 匹配失败，或第三方删块 | 本版 `readSurface` 恒 `null`，无文本路径输入 | round 2（与条件 3 合并处理） |
| **MINOR-10** | degraded 状态**没有用户可见提示**：无页面、无横幅、locale 无 `statusDegraded` 键 | 状态文件字段级损坏（本机现状即 degraded，见 D-1） | 改完文件后自己 `Get-Content state.json` 检查；或按 §2.7 重置 | round 2 写页面时：横幅条件用 `corrupt \|\| degraded`，补专属文案 |
| **MINOR-3 残余** | 数据层三态（`corrupt`/`degraded`/`ok`）已正确，但「提示」链路没落地（同上） | 同上 | 同上 | round 2 |
| **MINOR-2** | 一次 `save()` 里人设与边界不是事务：人设写成功、边界失败会留半笔 | 同时保存两段文本且第二段写盘失败（权限/磁盘） | 本版无页面，只能通过服务层触发；超限在写盘前就被拒，不受影响 | round 2（临时文件 + 多文件回滚） |
| **MINOR-6** | `status().backups` 按文件名字符串排序，同一秒内 `state-….bak` 与 `state-…-2.bak` 顺序可能反 | 同一秒内连续两次覆盖 | 只影响展示顺序，不影响恢复正确性 | round 2 或更低优先级 |
| **R3** | `hostNoteMarkers` 只匹配当前文案；会话恢复 legacy 段落时 marker 不命中（section 名不变，sections 路径仍能删；文本路径会漏看） | 恢复 legacy 会话 + 走文本路径 | 本版不走文本路径 | round 2（并入 MINOR-9） |

### 4.2 本轮交付新发现（打包/迁移层，只记录未改）

| 编号 | 影响 | 触发条件 | 规避方式（本版） | 何时修 |
|---|---|---|---|---|
| **D-1**（最严重） | 新包读到旧插件的 `state.json`（v4）→ `status:"degraded"` + `unsupported-version`；**`saveState()` 与 `resetStateToDefault()` 都返回 `version-conflict`**，即装上后**永远无法保存、也无法一键恢复默认** | 机器上装过 `@wufeng0105/dsh-enhance` 且保留 `~/.dsh/enhance/state.json`（**本机现状**）。实测：`load→degraded`；`saveState→{ok:false,code:"version-conflict"}`；`resetStateToDefault→同一错误` | 按 §2.6：先卸旧包 → 备份并改名 `state.json` → 再装新包 | round 2（迁移逻辑：识别旧 `version:4` 并给一次性迁移/提示），或至少让 `resetStateToDefault` 能绕过版本闸 |
| **D-2** | 手工开「一律放行」会**静默生效**，且本构建没有那条红字风险提示 | 手写合法 v1 + `masterSwitch/approvalOverride:true` + `approvalMode:"allow"`。实测返回 `allowed-once`、不再询问 | 别手改 `approvalMode`；要用就自己在心里记着 | round 2（页面落地时文案一并生效）；本版靠说明兜底 |
| **D-3** | 新旧包**共用** `~/.dsh/enhance/`：同时装着，两套代码读同一份文件、同时挂 `approval/request`，且旧包还有自己的 `/enhance/api` 路由与设置页 | 旧包未卸载就装新包（而且是**本机默认路径**） | §2.6 第一步：先卸旧包 | 交付流程（本文件）解决；代码层可考虑换目录或加 `owner` 标记 |
| **D-4** | 旧包的 `content-scope.txt` 被新包当**内容边界文本**读入（实测读回 73 B 原文） | 同上（同一目录、同一文件名） | §2.6 第 4 步自行决定留或改名 | 迁移逻辑（与 D-1 一并） |
| **D-5** | `README.md` 的 `../03-implementation.md` 链接在装好的包里必然失效；README 也没写重启判定与迁移风险 | 用户按包内 README 操作 | 用本文件 §二 代替 | round 2 重写 README |
| **D-6** | locale 缺 `state.statusDegraded`、`check.unproven` 两个键 | round 2 写页面时 | 无（当前无页面消费） | round 2 |
| **D-7** | `package.json` 无 `icon` 顶层字段、`dsh.client` 无 `inject`、无 `license` | 分发/展示 | 无实际影响（图标可经 `exports["./icon"]` 取到；两个在装样例的 `inject` 亦为可选） | round 2 一并补齐 |

---

## 五、交付判定

### 结论：**可交付（带条件）**

一句话理由：这一版是「装得上、跑得住、但功能没接完」的**诚实空壳**——27 个文件与 `files` 清单逐字一致，包内所有指针都指向真实文件，`import`/`apply`/卸载边界都干净、不写宿主配置，三条 MAJOR 修复经独立复核成立；但它**不改变任何系统提示、没有设置页、检查恒无数据**，且与机器上现存的旧插件共用状态目录会直接 degraded，所以只能按「带条件的预发布版」交付，不能按「功能可用」交付。

### 交付条件（具体到「谁在什么情况下会遇到什么」）

1. **装过旧包 `@wufeng0105/dsh-enhance` 的用户（本机就是）**：不按 §2.6 先卸旧包、备份并改名 `state.json`，装上后插件状态恒为 `degraded`，任何「保存」与「恢复默认」都返回 `version-conflict`，且旧包的 `content-scope.txt` 会被当成新包的边界文本读入。
2. **期待「改提示词」的用户**：装上后系统提示**一个字都不会变**（B1 未接线），「检查」永远显示暂无记录；写了人设/边界文本也不会生效。验收 2 在本版**不成立**。
3. **手工编辑 `state.json` 把 `approvalMode` 设为 `allow` 的用户**：越界审批会**真的被自动放行**（实测 `allowed-once`），而本构建**没有**任何红字风险提示；设为 `deny` 则一律回绝。
4. **想用 Enhanced 权限档的用户**：本版不会写宿主配置（`unauthorized`），也不会改动你现有档位；想回滚别人写过的 `enhanced` 档，本版无能为力。
5. **接手 round 2 的开发者**：接线前必须先修 **MINOR-7**（宿主里只要有一个缺 `name`/`description` 的合法档，Enhanced 写入就会被自己的闸拦住——实测 4 条 blocker）与 **MINOR-8**（字符串 baseline 被忽略，hide 永远证明不了——实测 `no-change-evidence`），否则接线后验收 2 会从「假成功」变成「永久假阴性」。

### 附：可交付 / 不可交付的边界

- **可交付**的部分：包本体（打包、清单、指针、locale/icon、版本与 `engines` 策略）、安装/卸载/迁移/回滚的可操作性、审批三态的服务层行为、超限与损坏文件的回落安全性。
- **不可交付**的部分（必须等 round 2）：验收 2 的全部内容、设置页、degraded 提示、Enhanced 档写入、以及 R1/R2 两个接线前置。

---

## 六、复现清单（给下一个人）

```powershell
cd bundle
npm pack --json                                    # 出包
tar -tzf local-dsh-enhance-0.1.0.tgz               # 27 个条目
node --test "test/*.test.js"                       # 153/153
node scripts/check-syntax.mjs                      # 40 files, 0 failed
# 对解包副本的交付探针（脚本在 %TEMP%\dsh-deliver\，不在交付物内）
tar -xzf local-dsh-enhance-0.1.0.tgz -C %TEMP%\dsh-deliver\pkg
node %TEMP%\dsh-deliver\verify-pack.mjs
node %TEMP%\dsh-deliver\probe-delivery.mjs
node %TEMP%\dsh-deliver\probe-delivery2.mjs
```

本文件所有「实测」二字均指上面这些命令在 2026-11-08 01:00–01:15 的真实输出；所有「本机现状」均指 `C:\Users\Administrator` 这台机器（profile `desktop`，DSH 0.2.2-rc.1）。
