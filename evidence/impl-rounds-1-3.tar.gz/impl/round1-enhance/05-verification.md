# 05 验证：dsh-enhance（round 1）

> 验证者立场：只证伪，不背书。**未修改 `bundle/` 内任何文件**；未安装任何插件；未改 `$DSH_HOME` 下任何内容。独立探针脚本全部写在 `%TEMP%\dsh-verify-05\`（bundle 之外），跑完已删除。
> 验证时间：2026-11-08 ~00:10（Asia/Shanghai）。环境：Windows，Node v24.22.2。
> 复跑命令与探针均可重现；文中「L数字」指该文件行号。

---

## 0. 结论摘要

| 项 | 结果 |
|---|---|
| 验收 6 条 | **VERIFIED 3 / UNVERIFIABLE 2 / GAP 1**（详见 §二） |
| 缺陷 | **BLOCKER 1 / MAJOR 3 / MINOR 6**（详见 §四） |
| 放行意见 | **GO-WITH-CONDITIONS**（详见 §五） |
| 测试复跑 | `node --test`：138/138 通过（我亲手跑）；`node scripts/check-syntax.mjs`：40 files, 0 failed |
| 实现者自述可信度 | 04-selfcheck 的「已验/未验」划分与我的独立核查**一致**，没有发现虚报「已验」的条目；但 03 §7 的三个易误解处中，第 1 处的实现声明在「接线后是否仍成立」上不成立（见 §二.2.1 的空真性说明与 §四 MAJOR-1） |

---

## 一、独立复跑

### 1.1 测试（我自己跑，未引用实现者输出）

```text
> node --version
v24.22.2

> node --test "test/*.test.js"   （工作目录 bundle\，末段）
✔ effectiveFlags: master off beats switch off (0.7199ms)
✔ effectiveFlags: master on with switches off (0.4445ms)
✔ effectiveFlags: master on, everything on, modes pass through (0.2787ms)
✔ normalizeState agrees with parseState on the same data (0.2876ms)
✔ the keep fallback keeps approval at ask even if the file also says deny (acceptance 5) (0.3375ms)
✔ normalizeNewlines converts CRLF and lone CR to LF (2.5587ms)
...
ℹ tests 138
ℹ suites 0
ℹ pass 138
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1161.7832
```

与 04-selfcheck 的 138/138 一致（耗时不同属正常毫秒差异，文件名集合一致）。

### 1.2 语法检查

```text
> node scripts/check-syntax.mjs
40 files checked, 0 failed
exit=0
```

脚本统计的 40 个文件与目录里实际的 js/mjs 文件数一致（我另用 `Get-ChildItem -Recurse` 数了 40 个）。

### 1.3 我的独立探针（不用 bundle 的测试文件，直接 import 生产代码 + 真临时目录）

13 个探针全部通过（脚本已删，命令与输出原文如下，截取关键行）：

```text
1  A4 over-limit boundary whole-save no-op ........ ok  (code=too-long, field=boundaryText, unchanged=true)
2  A4 at-limit accepted / over rejected / CRLF normalised ... ok (2048 ok, 2049 rejected, crlfBytes=2048)
3  A5 field-corrupt file → status:"ok" + issues, fields fall back, file NOT auto-rewritten ... ok
4  A5 unparseable file → status:"corrupt" + defaultState ... ok
5  A1 all-off returns SAME reference (master off, feature switches on) ... ok
6  A1 master-on/all-switches-off also SAME reference ... ok
7  three-files: state.json contains NEITHER user text token; texts live in identity/content-scope ... ok
8  custom + empty text → keep (transform reason=empty-custom, check code=empty-custom) ... ok
9  .bak no auto-prune: 25 saves → 24 .bak kept ... ok
10 approval with real host shape (toolName) → outcome allowed-once, ring entry.tool = null ... ok
11 preset merge idempotent (2nd merge changed=false, same ref, defaultPreset kept) ... ok
12 check with readSurface=null → no-data (never success) ... ok
13 sections path proves appended boundary exactly ... ok
```

另跑了一个「用真实宿主 section/context 名」的目录核对探针（结果见 §四 MAJOR-1/2，此探针**失败性质发现**而非通过项）。

### 1.4 宿主契约核对（host inspect 可用；宿主源码只读）

本机 host 侧 inspect 可用，我用它 + 只读 DSH 安装源码核对了三个实现者标注「探针待验」的问题（未安装任何东西）：

| 实现者的待验项 | 我的核对结论 | 证据 |
|---|---|---|
| P1 身份段名/是否 complete | section 真名是 **`harness:identity`**（不是 catalog 里的 `harness-identity`），order = `HARNESS_IDENTITY`(-1000)，**未标 `complete`**；文本就是 `BRAND_SENTENCE` 一字不差 | `dsh-system-prompt/lib/index.js` L230-234、L10-45；`complete` 只在 L383-384/L410 生效，且本会话系统提示是多 section 拼装（非单一 complete 块），R1 在本机构型下**不成立** |
| P6 `PresetSpec.name/description` 类型 | `name?: string`、**`description?: string`**；Config schema 同样 `description: z.string()` | inspect `permissionPresets` 服务契约（PresetSpec 声明）；`dsh-permission-presets/lib/index.js` L139-160 |
| R11 插件级 `approval/request` 监听是否覆盖所有 agent | **是**：scope 过滤「untagged listeners admitted globally；events flow up the chain, never down」，插件根上下文未打 tag → 收到全部 dispatch | `dsh-scope/lib/index.js` L316-338（`scopeTarget`） |

同时确认宿主事件契约与实现吻合：`'approval/request'` 是 waterfall，`(req: ApprovalRequestEvent, next) => Promise<ApprovalOutcome>`，`ApprovalOutcome = 'allowed-once'|'rejected'|'cancelled'|'unavailable'`；**`ApprovalRequestEvent` 的工具名字段是 `toolName`**（见 MINOR-1）。

### 1.5 客户端 inspect

任务提示说客户端探测现在可用，但我在本会话内 **5 次全部 10s 超时**（`Slots.listSubTree`×3、`Service.listService`×1、`Builtin.listBuiltins`×1），报错均为「Client inspect query … timed out … Open or reconnect the Harness page」。因此：
- 计划中的设置页槽位（settings.section 等）**仍然无法核对**；
- 实现者 01-R4「客户端 inspect 全程超时」的陈述被我独立复现，**属实**（至少在本会话环境）。

---

## 二、验收对照（核心）

> 判定口径：VERIFIED = 我亲手用代码/测试/探针证实；UNVERIFIABLE = 需要装进真实 DSH（或打开真实 GUI 页面）才能验；GAP = 实现与验收不符（含「实现者没声称已验但验收本身目前过不去」）。

### 2.1 六条逐条

| # | 验收 | 判定 | 证据 |
|---|---|---|---|
| 1 | 全部开关关闭时，系统提示与宿主原样一致 | **VERIFIED（离线）** | ① `lib/sections.js` L90-92：无任何生效开关时 `return { presentation: pres, …, noop: true }`，`pres` 是**入参同一引用**；`test/sections.test.js` L37-52 断言 `===`。② `host/prompt-service.js` L29-36：全关 `planRegistrations → {needsAssembleListener:false, needsBoundarySection:false}`，测试 L9-11。③ `grep` 全 bundle：生产代码没有任何 `systemPrompt.section(...)` / `suppressRuntimeContext()` 调用，`index.js` L98-100 只挂了空壳 bridge——当前构建在任何开关状态下都不注册 section。我的探针 5/6 复核了同一引用。**注意**：这条在当前构建里是「因为什么都没接」而成立的空真；接线（round 2）后必须用 `sessionQuery.readSurface` 逐字节重验 |
| 2 | 人设+内容边界写好后，下一条消息的系统提示：开头句已替换、末尾已追加，且「检查」能证实 | **GAP（端到端未实现）** | 纯函数层已验：替换/追加/`empty-custom` 回落/比对全绿（探针 7、8、12、13 + `test/check.test.js` L48-69）。但**运行时链路不存在**：`host/prompt-service.js` L63-71 `createPromptBridge` 是空壳（`sync(){}` / `dispose(){}` / `status: wired:false`），`index.js` L99-100 只注册这个空壳，`index.js` L109-111 `readSurfaceSnapshot` 恒返回 `null` → 「检查」在真实环境恒为 no-data。**即使装上，本构建也不会改任何提示词、检查也不会有数据**。实现者如实披露了这一点（未虚报已验），但按验收标准此条目前过不去 → 记 BLOCKER B1 |
| 3 | allow / ask / deny 三档行为各验一次，与档位一致 | **UNVERIFIABLE（决策层已验）** | 决策层已验：`test/approval.test.js`（L18-48：三态映射、master 关→ask、坏值→ask、never 档如实说明）+ 我的探针 10。接缝已在 `index.js` L81-96 真实挂上，监听签名与宿主事件契约一致，且 R11（是否覆盖所有 agent）已由宿主源码解决（§1.4）。未验部分：真实弹窗三态各一次、`next()` 透传的真实结果、审批审计日志是否仍成对记录（R9）。这三项只能装进临时 profile 后验 |
| 4 | 写入超限文本不损坏任何文件 | **VERIFIED（离线）** | 代码链：`controller.save` 先验两段文本再写（`host/controller.js` L72-93）→ `state-store.saveText` 校验先于建目录/备份/写盘（`host/state-store.js` L99-113）→ `saveWithBackup` 先 `copyFile` 备份成功才原子写（`host/atomic-file.js` L63-78）。测试：`controller.test.js` L57-66（整目录空）、`state-store.test.js` L99-112（原文件字节不变、连 `.bak` 都没有）、`atomic-file.test.js` L62-73（备份失败不写主文件）。我的独立探针 1/2 复核：boundary 3000 字节超限 → 整次 save 为 no-op，state/persona/boundary 三文件字节不变、目录项不变；2048 字节边界可过、2049 拒绝；CRLF 先归一再计数 |
| 5 | 故意写坏状态文件 → 行为回落且明确提示，而不是按损坏值执行 | **VERIFIED（服务层）** | 整文件坏：`lib/state.js` L96-126 → `corrupt:true` + `defaultState` + `invalid-json` issue；字段坏：L39-90 逐字段回落（approvalMode→ask、personaMode→keep、masterSwitch→false），issue 带 `fellBackTo`。文件不自动改写：探针 3 前后字节一致。审批侧绝不按损坏值执行：`index.js` L82-90 每次审批重读，读不出 → `defaultState()` → ask；`test/state-store.test.js` L58-73（坏文件先备份）、L150-162（version 冲突拒绝写回）。**保留项**：「明确提示」的用户可见部分（横幅）依赖未实现的页面，且 MINOR-3 的 status 语义会让规格里的横幅触发条件落空（见 §四） |
| 6 | 卸载后宿主正常、用户文件仍在 | **UNVERIFIABLE** | 无安装/卸载可测（本轮约束）。设计证据充分：状态目录固定在 `%USERPROFILE%\.dsh\enhance`（`host/paths.js` L11-30），不在 bundle 内；`index.js` 全文无任何删除该目录的钩子；本轮唯一可能的宿主写（Enhanced 档）固定返回 `unauthorized`（`host/controller.js` L118-124，测试 `controller.test.js` L104-111 断言连状态目录都不碰）→ 宿主配置字节不变。README 的旧包迁移说明只是文档。真实卸载行为必须装/卸一次才能证 |

**三态分布：VERIFIED 3（#1 #4 #5）/ UNVERIFIABLE 2（#3 #6）/ GAP 1（#2）。**

### 2.2 实现者点名的三个「易误解处」核查

**1）「全关 = 同一引用 + 一个都不注册」——实现者的说法属实，但要加一个限定。**
- 同一引用：属实（`sections.js` L90-92 返回入参对象本身；`test/sections.test.js` L49 断言 `===`；探针 5/6 复核）。
- 一个都不注册：**在当前构建里是空真**——不是「全关时不注册」，而是「任何时候都没有注册代码路径」（bridge 空壳，见 §2.1 #1 证据③）。`planRegistrations` 的决策逻辑本身正确且已测，但它只是「接线计划」，没有消费者。验收 1 在当前构建成立，可一旦 round 2 把 bridge 接上，「全关不注册」就要靠 `sync()` 每次按 `planRegistrations` 动态注册/注销来实现，届时这条才能算真正落地。
- 顺带发现（见 MAJOR-1）：`planRegistrations`/catalog 的**名字**是错的，接线后第一条要炸的不是这条，而是 hide。

**2）三文件真源 + custom 空文本回落 keep——属实。**
- `state.json` 里没有用户文本：`serializeState` 只写 8 个已知字段 + extra（`lib/state.js` L136-152）；控制器把两段文本分别写进 `identity.txt` / `content-scope.txt`（`host/state-store.js` L99-113）。探针 7 用 token 级字符串证明 `state.json` 不含 `UNIQUE-PERSONA-TOKEN` / `UNIQUE-BOUNDARY-TOKEN`，而两个 txt 文件包含。
- `personaMode:"custom"` + 空文本（含纯空白/缺文件→`readTextFile` 返回 null→空串）→ `resolvePersonaMode` 回落 `keep`，reason `empty-custom`（`lib/identity.js` L21-28）；transform 层记录 `matched:false` 且**不动文本**（`sections.js` L147-150），check 层报 `empty-custom` 而非成功（`check.js` L65-66）。探针 8 复核。三个生产调用点（transform/preview/check）都先经过 resolve，防线成立。
- 附加约定要写进交接说明：底层 `applyPersonaToText` 本身**不设防**——直接以 `mode:'custom'` + 空串调用会把品牌句替换成空串（等于删句）。这不是当前缺陷（无调用点这么用），但是接线时必须守住的不变量。

**3）`.bak` 双套语义 + 无自动清理——属实。**
- 状态目录里 `state-*.bak` / `persona-*.bak` / `boundary-*.bak` 是每次覆盖前的字节副本（`atomic-file.js` L63-78：先 `readFileOrNull` → 命名避撞 → `copyFile` 成功 → 才原子写主文件）。
- 宿主档位备份名 `config-*.bak` 只在 `preparePresetWrite`（`preset-service.js` L37）和 `planRollback`（L59-67，恢复前再备一份）里**生成名字**；真正的档位写盘/恢复整条路径未实现（controller 固定 `unauthorized`）。
- 无自动清理：`grep pruneBackups` 全 bundle 只被 `lib/backup.js`（定义）和 `test/backup.test.js`（测试）引用，生产代码零接线。探针 9：25 次保存留下全部 24 个 `.bak`（首次无旧文件不备份），无一被删。
- 与 03 §7 的表述一致，没有发现「以为旧 `.bak` 会被自动删掉」之类的意外行为。

---

## 三、代码级抽查（读过 + 结论）

| 抽查点 | 读过 | 结论 |
|---|---|---|
| **状态解析回落逻辑** `lib/state.js`（全文 178 行）+ `host/state-store.js` load/saveState | 全文 | 回落语义正确：布尔字段走 `parseBoolFlag` 白名单（true/false/1/0/on/off/yes/no，大小写与空白不敏感），枚举字段 trim+小写后匹配；任何无效值只产生 issue + 该字段回落，不影响邻字段；未知字段进 `extra` 并在序列化时保留（手改文件与页面同一份的承诺成立）。版本处理：`version` 缺失可、非正整数报 `invalid-version`、更高版本报 `unsupported-version` 且 `saveState` 拒绝写回（防静默降级）。**发现 MINOR-3**：字段级损坏时 `status:'ok'`、`corrupt:false`（L64-65/L124-125），损坏只体现在 `issues[]` |
| **超限拒绝路径** `lib/text.js` → `controller.save` / `state-store.saveText` | 全文 + 探针 1/2 | 校验（非字符串→控制字符→字节数）全部发生在任何写盘之前；controller 对两段文本先**全部**验完再动手，超限不落盘不截断（C6），控制字符拒绝（A18），CRLF 先归一再计数。**发现 MINOR-2**：跨文件 I/O 失败时不是全有或全无（persona 写成功后 boundary 写失败会留下部分写入）；验收 4 只约束超限，不受影响 |
| **审批三态映射** `lib/approval.js` + `host/approval-service.js` + `index.js` L81-96 | 全文 + 探针 10 | `decideApproval`：master 关 / 开关关 / 非法 mode 一律 ask（绝不静默放行或回绝）；`approvalDirective`：allow→不调 `next()` 返回 `allowed-once`、deny→`rejected`+`enhance.auto-deny`、ask/未知→`next()` 透传。返回值都在宿主 `ApprovalOutcome` 枚举内。监听器每次请求重读状态文件（满足「存盘即生效」「同一份文件」），读失败回落默认态→ask。环形缓冲有界、不可变。**发现 MINOR-1**：`summarizeRequest` 读 `request.tool`，宿主字段是 `toolName` → 记录里工具名恒为 null。**R11 已由宿主源码排除**（untagged 监听全局收） |
| **档位整表合并幂等性** `lib/preset.js` + `host/preset-service.js` | 全文 + 探针 11 | `mergePresetTable`：同值合并返回 `changed:false` 且**原表同一引用**（幂等）；冲突时默认保留用户编辑、`overwrite:true` 才覆盖；表里没有 `presets` 时拒绝而不是重建（防抹掉内置档）；`assertSafeWrite` 拦截「删档位 / 改 defaultPreset / 非法 sandbox|approval」。`preparePresetWrite` 把合并、安全闸、diff、`config-*.bak` 命名串成一步且纯函数可测；`planRollback` 恢复前再备一份（C4②）。**发现 MAJOR-3**：`enhancedPreset().description` 是 `{en,zh}` 对象，宿主 schema 要求 `string`；且 `validatePresetTable` 不校验 name/description 类型，安全闸拦不住 |
| **包骨架/manifest**（`package.json`、`cordis.patch.yml`、`client.js`、locale、icon） | 全文 + 与官方模板逐字段比对 | patch 方言与官方模板一致（`- insert: - id/name`）；`dsh.bundle.patch`、`dsh.client{platform,immediately}`、`exports`（`.`/`./client`/`./locale/*.json`/`./icon`）、`files` 全齐；locale 含 `meta.title/description` 与全部警示文案（C1/C2/C8）；icon 为合法 SVG（≤256KiB，包内）。本轮不可安装验证，manifest 只能判「形制正确」 |

---

## 四、缺陷清单

> 分级：BLOCKER = 验收过不去；MAJOR = 行为与需求/客户裁定不符；MINOR = 局部瑕疵/接线隐患。每条附证据。

### BLOCKER（1）

- **B1：验收 2 的端到端链路不存在——本构建装上也不会改变系统提示，「检查」永远 no-data。**
  证据：`bundle/host/prompt-service.js` L63-71（`createPromptBridge` 返回 `sync(){}/dispose(){}` 空壳，status `wired:false`）；`bundle/index.js` L98-100（只注册空壳，无 `systemPrompt.section` 调用——grep 全 bundle 生产代码零命中）；`bundle/index.js` L109-111（`readSurfaceSnapshot` 恒 `return null`）→ `host/check-service.js` L27-29 恒 `no-data`。
  影响：验收 1/2/3/6 的运行时部分全部悬空；验收 2 字面不成立。
  备注：这是 03 §3 明确披露的计划内缺口（探针前置），不是虚报；但按验收口径仍是 BLOCKER。**并且我在 §1.4 已把接线前的两个最大未知解决了**：R1（identity 非 `complete`，waterfall 可改）与 R11（根级监听全局收），round 2 接线没有已知的硬阻断。

### MAJOR（3）

- **MAJOR-1：`DEFAULT_CATALOG` 的身份段名字是错的，`hideHostNotes` 对真实宿主 section 无效。**
  证据：`bundle/lib/sections.js` L32-34 `identityNames:['harness-identity']`、`hostNoteNames:[]`、`hostNoteMarkers:[]`；宿主源码 `dsh-system-prompt/lib/index.js` L230-234 注册名是 **`harness:identity`**（冒号）。我的探针（真实宿主名喂入）：hide 开启后 sections 仍含 `harness:identity`，change 记录 `matched:false, reason:'nothing-matched'`；contexts 数组也原样保留（靠 `effects.suppressRuntimeContext` 在源头抑制是另一条未接线的路径）。
  影响：一旦接线，C2「隐藏宿主自述」**不会隐藏身份段**（两段 runtime context 倒是能靠 suppress 标志去掉）；03 §7-1 的「全关不注册」没炸，先炸的是这条。
  修复方向：catalog 改为 `identityNames:['harness:identity']` 并在探针后补 `hostNoteNames/markers`；`identity.js`/`check.js` 无需动。

- **MAJOR-2：「检查」的 sections 路径会把「未隐藏」误报为已隐藏（假成功），违反需求 7。**
  证据：`bundle/lib/check.js` L121-143 `hostNotesSectionsItem` 只按 catalog 名字/marker 找「漏网」，同一份错 catalog 导致：我的探针把**未经任何 transform 的宿主原始 sections+contexts** 喂进去，结果 `hostNotes.ok=true, code:'host-notes-hidden'`，整体 verdict **`effective`**；对 hide 后（身份段还在）的结果同样报 `effective`。测试全绿的原因是测试用的合成名字恰好匹配 catalog（`test/check.test.js` L8-16 自造的 `identity`/`instructions`/`runtime-context`）。
  影响：接线后「检查」面板会对「隐藏没生效」的场景报「已生效」，正是需求 7 明令禁止的「糊弄」。
  修复方向与 MAJOR-1 同源：修 catalog 后此项自动修复；另建议在 marker 缺失时保持现在的 `no-marker` 拒判行为（这部分实现是对的）。

- **MAJOR-3：Enhanced 档的 `description` 形态与宿主 schema 冲突，授权后写入必被拒。**
  证据：`bundle/lib/preset.js` L20-34 `description: { en:…, zh:… }`；宿主 `dsh-permission-presets/lib/index.js` L139-160 Config：`presets: z.dict(z.object({ …, name: z.string(), description: z.string() }))`；inspect 的 `PresetSpec` 契约同样 `description?: string`。`validatePresetTable`（L44-68）只校验 sandbox/approval，不校验 name/description 类型，所以 `assertSafeWrite` 也拦不住。
  影响：本轮写盘未授权所以未爆发（无数据损坏风险——Loader/`configEditor.edit` 会校验拒绝）；但需求 4 的「唯一碰宿主配置的动作」在授权后第一步就会失败。实现者偏差 #9 把它标为「探针 P6 待核实」，现在探针答案已知：**只能是单语字符串**（A6 的「双语描述」在宿主 preset 字段上做不到，需改走界面文案）。
  修复方向：`enhancedPreset()` 的 `description` 改字符串；`validatePresetTable` 补 name/description 类型检查。

### MINOR（6）

- **MINOR-1：审批环形记录取错字段名，工具名恒为 null。**
  `bundle/host/approval-service.js` L17-22 读 `request.tool`；宿主事件 `ApprovalRequestEvent` 的字段是 `toolName`（host inspect 事件契约；探针 10 用真实形状复现 `entryTool=null`）。决定/时间/callId 都在，只缺工具名 → C8 要求的「最近放行/拦截记录」展示数据不全。
- **MINOR-2：`controller.save` 的「全有或全无」只对校验成立，跨文件 I/O 失败会留下部分写入。**
  `bundle/host/controller.js` L72-95：先验两段文本（这半是对的），随后 persona→boundary→state 顺序写；boundary 写失败/state 校验失败时 persona 已写、不回滚。验收 4（超限）不受影响——超限在写盘前就被拦。测试只覆盖超限路径，没有覆盖 I/O 失败的部分写。
- **MINOR-3：字段级损坏的 state.json 返回 `status:'ok'`（`corrupt:false`），规格里的损坏横幅触发条件会落空。**
  `bundle/host/state-store.js` L64-65、`lib/state.js` L124-125：只有 JSON 解不开/非对象才算 `corrupt`；单字段非法（C7 的主场景，A11 明确要求横幅）走 `status:'ok'` + `issues[]`。而 03 §5 页面规格把红底常驻横幅挂在 `status==='corrupt'` 上，横幅文案（`locale/zh.json` `state.bannerCorrupt`）恰恰描述的是字段回落场景。页面未实现所以未爆发；若按规格实现，字段损坏时**不会**显示横幅。修复：页面改用 `issues.length>0` 判横幅，或 store 给字段损坏单独的 status（如 `degraded`）。
- **MINOR-4：决定环形缓冲没有通向页面的数据通道。**
  `bundle/index.js` L80-96：ring 是闭包变量，只在第一次审批后才通过 `ctx.enhance.recentApprovals` 暴露，且控制器 `status()/read()/check()` 都不含它（`host/controller.js` L30-64/L98-108）。C8 要求「检查」展示最近 N 次决定，目前页面拿不到；也没有初始值（未发生任何审批前 `ctx.enhance.recentApprovals` 不存在）。
- **MINOR-5：C1 的「档位从不询问→如实说明」在宿主侧永远不会触发。**
  `bundle/index.js` L114-122 `currentApprovalPolicy` 恒返回 `undefined`（探针 P6 的占位）；宿主明明有 `permissionPresets.current(session)` / `resolve(name).approval`（服务契约已核实）。于是 `status().tristate` 只会是 ok/master-off/switch-off，`preset-never` 分支（`lib/approval.js` L49）死代码，页面永远显示不出「当前档位从不询问」。属披露过的空壳，但 C1 是客户裁定，接线清单里必须有它。
- **MINOR-6：`listBackups` 的排序不是按时间序。**
  `bundle/host/state-store.js` L137-142 对文件名直接 `.sort()`：同一秒的 `state-…-2.bak` 会排在 `state-….bak` 前面（`'-' < '.'`）。只影响 `status().backups` 的展示顺序（「最近」判断错位），不影响备份/恢复正确性。

**未发现**的项（点名说明）：没有发现超限截断、损坏值被执行、`state.json` 混入用户文本、自动删除 `.bak`、写宿主配置的暗道（`writeFile/copyFile/rename/unlink` 全部只在 `host/atomic-file.js` + 测试里，`writePreset/rollbackPreset` 固定 `unauthorized` 且不碰状态目录）。

---

## 五、给交付阶段的放行意见

**GO-WITH-CONDITIONS。**

一句话理由：纯逻辑内核、状态文件服务与包骨架是真实可信且经我独立复核的（测试 138/138、探针 13/13、无 BLOCKER 级代码缺陷），但验收 2 的端到端接线整体缺位（B1）+ 两个接线即炸的 catalog/schema 错误（MAJOR-1/3）决定了**不能以「功能可用」口径放行**，只能以「round 1 纯函数内核交付」口径放行。

放行附带条件（进入 round 2 / 交付前必须完成）：
1. 修 `DEFAULT_CATALOG`（`harness:identity`）与 `enhancedPreset().description`（string），并让 `validatePresetTable` 覆盖 name/description 类型（MAJOR-1/2/3，三处半天工作量）；
2. round 2 首项做探针+接线（B1）：P1/P2/P5 的两个关键未知（identity 非 complete、根级监听全局收）已由我离线解决，剩余是真实 `readSurface` 字段映射与 `suppressRuntimeContext()` 的挂接；
3. 接线后重验验收 1（逐字节）、2、3（真实弹窗三态各一次）与 6（装/卸一轮），并补 MINOR-1/3/4/5 这四个只影响页面/记录的小项；
4. 客户端 inspect 在本会话仍不可用（5 次超时），设置页槽位结论继续悬置——页面动工前必须先拿到 `Slots.listSubTree`。

---

## 附录 A：证据索引（相对 `impl/round1-enhance/`，宿主源码为只读安装内路径）

| 证据 | 位置 |
|---|---|
| 全关同一引用 | `bundle/lib/sections.js:90-92`；`bundle/test/sections.test.js:37-52` |
| 注册计划（全关 false/false） | `bundle/host/prompt-service.js:29-36`；`bundle/test/prompt-service.test.js:9-31` |
| bridge 空壳 / readSurface null | `bundle/host/prompt-service.js:63-71`；`bundle/index.js:98-100,109-111` |
| 审批监听与三态 | `bundle/index.js:81-96`；`bundle/lib/approval.js:23-51`；`bundle/host/approval-service.js:29-45` |
| 三文件真源 / 序列化 | `bundle/lib/state.js:136-152`；`bundle/host/state-store.js:97-127` |
| custom 空文本回落 | `bundle/lib/identity.js:21-28`；`bundle/lib/sections.js:147-150`；`bundle/lib/check.js:65-66` |
| 超限/原子写/.bak | `bundle/lib/text.js:40-51`；`bundle/host/controller.js:72-95`；`bundle/host/atomic-file.js:42-78` |
| 档位合并/安全闸 | `bundle/lib/preset.js:85-158`；`bundle/host/preset-service.js:23-67` |
| unauthorized 边界 | `bundle/host/controller.js:118-124`；`bundle/test/controller.test.js:104-111` |
| pruneBackups 未接线 | grep：仅 `bundle/lib/backup.js:74`（定义）与 `bundle/test/backup.test.js:39` 引用 |
| 宿主 identity section（真名/非 complete/原文） | `…\app.asar\dsh\node_modules\@deepseek-ai\dsh-system-prompt\lib\index.js:230-234`（另 L10-45、L383-384、L401-412） |
| 宿主 preset Config（description 必须 string） | `…\dsh\node_modules\@deepseek-ai\dsh-permission-presets\lib\index.js:139-160`（另 L296-311） |
| scope 过滤（untagged 全局收） | `…\dsh\node_modules\@deepseek-ai\dsh-scope\lib\index.js:316-338` |
| 宿主事件契约 | host inspect `Event.listEvents`（`approval/request`：`ApprovalRequestEvent.toolName`、`ApprovalOutcome` 枚举） |
| 我的探针输出 | §1.3 十三项 + §四 MAJOR-1/2 的目录核对探针（脚本已删，命令可重现） |

## 附录 B：本验证的局限（如实声明）

1. **未安装**：验收 1/2/3/6 的运行时部分（真实提示词逐字节比对、真实审批弹窗、真实卸载）无法离线完成，均已标注。
2. **客户端 inspect 不可用**（5 次超时）：设置页槽位、Client 注册 API、Remote 命名空间全部悬置；实现者 01-R4 的陈述被复现。
3. 宿主源码读取仅限安装包内已构建产物（`lib/index.js`），未做源码 checkout 级审计；结论以 inspect 契约 + 安装源码双源为准。
4. 探针脚本为一次性验证用，未留在工作区；本文引用的输出均来自当次真实运行。
