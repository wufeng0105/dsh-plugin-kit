# 04 自检：dsh-enhance（round 1）

> 环境与约束：Windows / Node v24.22.2 / 工作目录 `bundle/`。本轮**未安装任何插件、未改 `$DSH_HOME`、未写宿主配置**；集成测试只在 `os.tmpdir()` 下真读写。

## 1. 命令

```powershell
node --test "test/*.test.js"      # 等价于 npm test
node scripts/check-syntax.mjs     # 全部 JS 文件 node --check
```

## 2. 测试运行的真实输出（原文，未删减）

命令 `node --test "test/*.test.js"`，退出码 0（同一次运行经 `Tee-Object` 落盘后原样贴回）：

```text
✔ allow answers allowed-once without consulting the user (C8) (2.4895ms)
✔ ask falls through to the host waterfall and returns its outcome (0.6384ms)
✔ deny rejects with the auto-deny reason and never asks (0.2094ms)
✔ a state that says nothing never denies by accident (0.1579ms)
✔ the recorded ring stays bounded (0.2196ms)
✔ decideApproval maps the state to the three outcomes (1.905ms)
✔ master off or switch off means "do not take over" -> ask (never silent) (0.2034ms)
✔ an unknown mode in the state cannot produce allow or deny (0.1397ms)
✔ approvalDirective translates a decision into the host waterfall outcome (01-analysis §5) (1.3945ms)
✔ an unknown decision falls through to "ask the user" instead of guessing (0.1735ms)
✔ explainTristate tells the page the truth about a never-asking preset (C1) (0.2482ms)
✔ createRing starts empty with its capacity (0.1785ms)
✔ pushDecision keeps the newest N entries, oldest first in recentDecisions (C8) (0.2363ms)
✔ pushDecision is immutable: the previous ring stays intact (0.2134ms)
✔ atomicWrite creates the file and leaves no temp file behind (18.6765ms)
✔ atomicWrite replaces existing content (10.8119ms)
✔ saveWithBackup copies the previous content to a timestamped .bak first (21.1968ms)
✔ saveWithBackup does not create a backup when there is nothing to back up (11.1024ms)
✔ a failing backup aborts the write and leaves the main file byte-identical (R10) (13.0391ms)
✔ readFileOrNull distinguishes "missing" from "empty" (5.1262ms)
✔ timestampStamp formats local time with an explicit offset (3.3091ms)
✔ backupName appends the stamp and the extension (0.3333ms)
✔ backupName avoids collisions with -2, -3 suffixes (0.2647ms)
✔ backupName is filename-safe on Windows (no colons, no plus signs) (0.4783ms)
✔ parseBackupName reads stamp and sequence back (1.6679ms)
✔ pruneBackups keeps the newest N and never touches unrecognised files (0.6003ms)
✔ accepts real booleans (2.0888ms)
✔ accepts true/false strings case-insensitive with surrounding spaces (1.257ms)
✔ accepts 1/0, on/off, yes/no (A12) (0.32ms)
✔ rejects anything else so the field falls back (C7) (0.5511ms)
✔ ascii text counts one byte per char (1.1753ms)
✔ CJK text counts three bytes per char (1.5416ms)
✔ emoji counts four bytes (0.1572ms)
✔ empty string is zero bytes (0.0845ms)
✔ non-string input throws TypeError (0.7888ms)
✔ a readable surface is compared and reported as effective (1.8718ms)
✔ no surface yet is reported as no-data, not as success (A14) (0.3784ms)
✔ a failing reader is reported, never rethrown into the page (0.477ms)
✔ sections from the reader are preferred over the joined text (0.6381ms)
✔ no system surface at all is reported as no-data, not as success (A14) (1.8764ms)
✔ all switches off says "not effective because the switches are off" (acceptance 8) (0.829ms)
✔ persona + boundary written and effective is proven from the text (acceptance 2) (1.2469ms)
✔ a persona that did not land fails and drags the verdict to partial (requirement 7) (0.2709ms)
✔ strip mode is verified by the absence of the brand sentence (0.2007ms)
✔ strip mode still finds the brand sentence in the leading window and fails (0.1825ms)
✔ a missing boundary is reported as missing, not assumed (0.162ms)
✔ hideHostNotes is only claimed when the runtime-context markers are gone (0.3729ms)
✔ without markers the check refuses to claim hidden (1.5833ms)
✔ the sections path proves the boundary by name and exact text (0.5445ms)
✔ the sections path notices a host note that survived the hide switch (0.3523ms)
✔ checkEffectiveness uses the sections path when sections are supplied (0.1775ms)
✔ custom persona with empty text is reported as empty-custom, not as success (0.2237ms)
✔ status reports paths, the missing file state and that preset writing is not authorised (10.2065ms)
✔ save writes state and text, and read returns them (28.1052ms)
✔ an over-limit text makes the whole save a no-op (acceptance 4) (3.6937ms)
✔ check uses the injected surface reader and says where it stands (21.1247ms)
✔ reset turns everything off but keeps the user text (C4 ①) (34.1149ms)
✔ writing or rolling back the host preset table stays unauthorised this round (1.8284ms)
✔ the state file the controller writes is valid JSON with a trailing newline (6.7989ms)
✔ the brand sentence constant is the exact host opening sentence (1.6187ms)
✔ limits are 2 KiB persona and 8 KiB boundary in bytes (C6) (1.1476ms)
✔ modes lists match the three states of the requirement (0.2508ms)
✔ keep mode leaves the text byte-identical (0.2693ms)
✔ strip mode removes only the brand sentence, keeps the rest (C3) (0.3139ms)
✔ strip mode removes only the first occurrence (0.1871ms)
✔ custom mode replaces the brand sentence with the persona text (0.1811ms)
✔ text without the brand sentence is reported as unmatched, not silently "success" (0.1597ms)
✔ resolvePersonaMode: custom with empty text falls back to keep (analysis A1/A2 note) (0.3533ms)
✔ personaPreview gives the page a before/after pair (C3 preview) (0.404ms)
✔ default base dir is <home>/.dsh/enhance (2.5803ms)
✔ an explicit override wins over the fixed path (1.1492ms)
✔ missing home yields an error instead of a relative path (0.1481ms)
✔ the three state files have the agreed names (C5) (0.2195ms)
✔ statePaths joins the three file names onto the base dir (0.2772ms)
✔ a normal write prepares the merged table, the diff and a timestamped backup name (2.8499ms)
✔ the backup name steps aside when the same second already has one (0.3553ms)
✔ a user-edited enhanced preset is reported as a conflict, not overwritten (1.8422ms)
✔ blockers from assertSafeWrite stop the write (0.5078ms)
✔ a table without presets cannot be written at all (0.3226ms)
✔ rollback restores the backup text and takes a fresh backup first (C4 ②) (0.2605ms)
✔ rollback without a backup says so instead of restoring empty text (0.25ms)
✔ enhanced preset is sandbox wide open but still asks (requirement 4) (2.3482ms)
✔ validatePresetTable accepts the built-in shape and flags bad entries (1.5865ms)
✔ merge adds the enhanced preset and keeps every existing one untouched (0.2621ms)
✔ merge is idempotent: merging the same preset twice changes nothing (0.2473ms)
✔ merge keeps the user-edited enhanced entry unless overwrite is requested (0.2158ms)
✔ merge reports a table without presets instead of inventing one (0.1823ms)
✔ diffPresetTables reports exactly what a write would change (0.2721ms)
✔ assertSafeWrite blocks any write that would drop a preset or change defaultPreset (0.5584ms)
✔ all off registers nothing (acceptance 1: the prompt must be byte-identical) (2.1234ms)
✔ the content boundary alone needs a section, not the waterfall (0.2551ms)
✔ persona rewriting needs the assemble waterfall (0.2203ms)
✔ hiding host notes needs the assemble waterfall too (0.2426ms)
✔ master on with every switch off still registers nothing (0.216ms)
✔ all flags off returns the identical presentation object (acceptance 1) (2.5935ms)
✔ persona strip rewrites the identity section and leaves other sections untouched (0.5653ms)
✔ persona custom replaces the sentence with the user text in place (0.225ms)
✔ boundary is appended as the last section with the exact user text (0.2759ms)
✔ boundary enabled but empty text adds nothing (0.2707ms)
✔ hideHostNotes removes host note sections and runtime contexts and suppresses runtime context (0.4804ms)
✔ hideHostNotes also matches by marker when the name is unknown (0.4214ms)
✔ matchesCatalogEntry reports which rule matched (0.2636ms)
✔ hide + custom persona: identity is dropped and the custom text gets its own section (0.802ms)
✔ persona enabled but brand sentence missing is reported, not faked (1.3148ms)
✔ custom persona with empty text falls back to keep and explains itself (A1/A2 note) (0.5207ms)
✔ DEFAULT_CATALOG exposes every key the transform needs (values stay probe-gated) (1.9792ms)
✔ a fresh directory reports missing and hands out defaults (8.5457ms)
✔ save writes version-1 JSON and a second save leaves a timestamped .bak (27.6057ms)
✔ a corrupt file loads as defaults with issues, and a later save backs the corrupt text up first (18.2997ms)
✔ per-field fallback comes from the file, and the issues travel to the page (C7) (5.9923ms)
✔ unknown fields survive a save from the page (requirement 6: same file) (18.5096ms)
✔ over-limit persona text is refused before anything is written (acceptance 4) (9.8372ms)
✔ control characters are refused (A18) without touching the file (3.0335ms)
✔ persona and boundary files are plain UTF-8 text with LF newlines (9.1836ms)
✔ resetStateToDefault keeps the switches but never deletes user text (C4 ①) (18.3398ms)
✔ a newer state version refuses saves instead of silently downgrading (6.3159ms)
✔ the store creates the directory on demand, even two levels deep (10.64ms)
✔ read errors are classified as unreadable, not as "no state" (2.748ms)
✔ default state: all switches off, persona keeps, approval asks (C7) (1.75ms)
✔ missing version is fine, but a wrong version is reported without blocking fields (0.6411ms)
✔ string booleans are recognised (A12) (0.2927ms)
✔ corrupt fields fall back per field, valid neighbours survive (C7) (0.3943ms)
✔ unparseable JSON means whole-file corrupt fallback, never silent (C7) (0.2709ms)
✔ a JSON value that is not an object is also corrupt (0.1757ms)
✔ unknown top-level fields are preserved for the round trip (0.3256ms)
✔ serialize is deterministic and ends with a newline (0.2295ms)
✔ effectiveFlags: master off beats switch off (0.3879ms)
✔ effectiveFlags: master on with switches off (0.347ms)
✔ effectiveFlags: master on, everything on, modes pass through (0.2781ms)
✔ normalizeState agrees with parseState on the same data (0.2876ms)
✔ the keep fallback keeps approval at ask even if the file also says deny (acceptance 5) (0.3375ms)
✔ normalizeNewlines converts CRLF and lone CR to LF (2.2755ms)
✔ findDisallowedControlChar finds NUL and ESC, ignores newline and tab (0.6507ms)
✔ validateText accepts empty text (0.7989ms)
✔ validateText accepts newline and tab and normalizes them (0.1905ms)
✔ validateText rejects over-limit by UTF-8 bytes, not chars (C6) (0.2842ms)
✔ validateText rejects control characters (A18) (0.1707ms)
✔ validateText rejects non-string input (0.1485ms)
ℹ tests 138
ℹ suites 0
ℹ pass 138
ℹ fail 0
ℹ cancelled 0
ℹ skipped 0
ℹ todo 0
ℹ duration_ms 1147.5607
```

> 备注：耗时（ms）每次运行会有毫秒级差异，但文件名/内容一致；`npm test` 复跑结果同为 `tests 138 / pass 138 / fail 0`。

## 3. 语法检查（`node --check` 全量）

```text
> node scripts/check-syntax.mjs

40 files checked, 0 failed
```

（覆盖 `index.js`、`client.js`、`lib/*.js`、`host/*.js`、`test/*.js`、`scripts/*.mjs` 共 40 个文件。`package.json`、`locale/en.json`、`locale/zh.json` 另用 `ConvertFrom-Json` 校验通过；`cordis.patch.yml` 是按 Loader 方言手写的最小 patch，只能由安装期 Loader 校验，本轮未装。）

## 4. 变红实验（测试确实会失败）

改动：把 `lib/approval.js` 里 `decideApproval` 的安全闸 `return 'ask'` 故意改成 `return 'allow'`（模拟"状态读不出来就放行"这个 bug）。

```text
> node --test "test/*.test.js"      # 改坏后，关键行（按 ✖ / ℹ 统计过滤）

✖ a state that says nothing never denies by accident (1.3413ms)
✖ master off or switch off means "do not take over" -> ask (never silent) (0.9952ms)
ℹ tests 138
ℹ pass 136
ℹ fail 2
✖ failing tests:
✖ a state that says nothing never denies by accident (1.3413ms)
✖ master off or switch off means "do not take over" -> ask (never silent) (0.9952ms)

[exit code: 1]
```

改回原样后复跑：`tests 138 / pass 138 / fail 0`（见第 2 节）。结论：测试对"损坏状态不得按损坏值执行"这条行为是可红的。

开发过程中还发生过两次真实的红→绿（都由新写的测试先抓住）：

- `lib/text.js` 的控制字符正则最初漏了 `\r`，被 `findDisallowedControlChar finds NUL and ESC, ignores newline and tab` 打红后修正为 `/[\u0000-\u0008\u000B-\u001F\u007F]/`；
- `lib/preset.js` 最初对"没有 `presets` 的表"按"重建"实现，被 `merge reports a table without presets instead of inventing one` 打红后改成"拒绝并报 `presets-missing`"（否则真写盘会抹掉宿主内置档）。

## 5. 验收标准（行为版）逐条标注

| # | 验收 | 状态 | 证据 / 原因 |
|---|---|---|---|
| 1 | 全部开关关闭时，系统提示与宿主原样一致 | **已验（纯函数层）；运行时未验** | `test/sections.test.js`「all flags off returns the identical presentation object (acceptance 1)」断言返回**同一个对象引用**、`changes` 为空；`test/prompt-service.test.js`「all off registers nothing」证明接线计划是"不注册 section、不注册监听"。运行时逐字节比对需安装后用 `sessionQuery.readSurface`（探针期），本轮无法做 |
| 2 | 人设 + 内容边界都写好后，下一条消息的系统提示：开头句已替换、末尾已追加，且检查能证实 | **已验（纯函数层）；运行时未验** | `test/check.test.js`「persona + boundary written and effective is proven from the text (acceptance 2)」；`test/sections.test.js` 的替换/追加用例；`test/controller.test.js`「check uses the injected surface reader and says where it stands」。真实"下一条消息后 `readSurface` 读回"需安装授权 |
| 3 | allow / ask / deny 三档行为各验一次，与档位一致 | **已验（决策层）；真实弹窗未验** | `test/approval.test.js`（映射、master 关 → ask、坏值 → ask）与 `test/approval-service.test.js`（allow 不调 `next()`、ask 调一次并透传结果、deny 返回 `rejected`、坏状态不回绝）。三个真实动作各验一次需临时 profile 安装（02-plan Step 5 运行时部分） |
| 4 | 写入超限文本不损坏任何文件 | **已验（文件级集成）** | `test/state-store.test.js`「over-limit persona text is refused before anything is written (acceptance 4)」：3000 字节 > 2048 拒绝、`identity.txt` 字节不变、目录里连 `.bak` 都没有；`test/controller.test.js`「an over-limit text makes the whole save a no-op (acceptance 4)」证明全有或全无；`test/atomic-file.test.js`「a failing backup aborts the write and leaves the main file byte-identical (R10)」证明备份失败也不写主文件 |
| 5 | 故意写坏状态文件 → 行为回落且明确提示，而不是按损坏值执行 | **已验（文件级集成）** | `test/state.test.js`「corrupt fields fall back per field…」「unparseable JSON…」「the keep fallback keeps approval at ask even if the file also says deny (acceptance 5)」；`test/state-store.test.js`「a corrupt file loads as defaults with issues…」；`test/controller.test.js` 的 `status().issues` 透传。页面横幅文案已备（`locale/*.json` → `state.bannerCorrupt`），页面本身未实现 |
| 6 | 卸载后宿主正常、用户文件仍在 | **未验；设计上必然成立** | 本轮没有安装行为可测（约束不允许安装）。设计保证：状态目录 `%USERPROFILE%\.dsh\enhance\` 是 `plugin_manager` 之外的固定路径，卸载不删（`bundle/README.md` 已写明）；本轮唯一可能的宿主写（Enhanced 档）从未发生（`writePreset` 返回 `unauthorized`，`test/controller.test.js`「writing or rolling back the host preset table stays unauthorised this round」断言连状态目录都不碰），因此卸载后宿主配置字节不变 |

## 6. 无法离线验证（诚实清单）

1. **系统提示真的被改了**——依赖安装 + 探针 P1/P2（身份段是否 complete section，01-R1 最大风险）。纯函数层只证明"给定宿主 sections 快照"的变换正确。
2. **审批监听器是否对所有 agent 生效**（01-R11）与 `approval/request` 的实际监听签名——`handleApprovalRequest` 只在 01-analysis §5 记录的签名假设下测试。
3. **`readSurface` 返回结构**（探针 P7）——`index.js` 的 `readSurfaceSnapshot` 现在返回 `null`，Check 面板会诚实地说"暂无记录"，不会假报成功。
4. **Enhanced 档写盘 / 重启后仍在 / 并发 revision 冲突**（02-plan Step 6 运行时）——本轮连读真实宿主配置都没有，`preparePresetWrite` 只对构造的表测试。
5. **设置页**——客户端 inspect 全程超时（01-R4），槽位/Remote/主题 token 全部未知；只有 `03-implementation.md` §5 的结构规格。
6. **locale / 图标的渲染**——`en.json`/`zh.json` 与 `icon.svg` 按 host-plugin 清单准备（`meta.title`/`meta.description`、SVG 合法），但"装上去之后 Plugin Manager 里显示成什么样"未验。
